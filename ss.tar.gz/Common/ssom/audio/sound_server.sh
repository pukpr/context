cd  `dirname $0`
env division=sifc01 PACE=../ PACE_NODE=1 PACE_NODES=nodes.pro ../../bin/Windows/surrsound.exe
