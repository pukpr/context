#### Debug flags make a mockery of Mockup, 
#### stick in dummy flags to override

# TO build archive

# cd win/import_lib
# ./build_archive.sh
# cd ../..

env DEBUG="-v" GGDB="-v" gprbuild dvplugin.gpr
