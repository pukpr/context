/*
 *    PROJECT:      DVS
 *    SUBSYSTEM:    dmd
 *    MODULE:       dm.h
 *
 *    File:         $RCSfile: dmd.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:07:40 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: dmd.h,v 1.1 2005/09/13 15:07:40 pukitepa Exp $
 *
 *    FUNCTION:
 *    This file contains the external declarations of the dm library
 *    routines and types. 
 *
 *
 * Copyright (c) 1996 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _DMDTYPES_H
#define _DMDTYPES_H

#ifndef DMD__EXPORT
#if defined(_WIN32) && !defined(__EPP__) &&!defined (BUILD_STATIC)
/*
 * only  Windoze needs this baroque construct.
 * On sensible systems simply use `extern'
 */
#ifdef  _LIB_DIVU
#define DMD__EXPORT __declspec(dllexport) extern
#else
#define DMD__EXPORT __declspec(dllimport) extern
#endif /* _LIB_DIVU */
#else
#define DMD__EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ndef DMD__EXPORT*/

#include <stdio.h>

#if defined(_WIN32)
/*
 * These are not defined on windoze.
 */
#define M_E             2.71828182845904523540
#define M_LOG2E         1.44269504088896340740
#define M_LOG10E        0.43429448190325182765
#define M_LN2           0.69314718055994530942
#define M_LN10          2.30258509299404568402
#define M_PI            3.14159265358979323846
#define M_PI_2          1.57079632679489661923
#define M_PI_4          0.78539816339744830962
#define M_1_PI          0.31830988618379067154
#define M_2_PI          0.63661977236758134308
#define M_2_SQRTPI      1.12837916709551257390
#define M_SQRT2         1.41421356237309504880
#define M_SQRT1_2       0.70710678118654752440
#endif

#include <math.h>

#ifdef _WIN32
#define rint(x)	    floor ((x) + 0.5)
#endif /* WIN32 */

#include <stdlib.h>
#include <float.h>
#include <dsys/divtypes.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * The basic linear algebra types.
 */
typedef enum {
    DMD_X     = 0,
    DMD_Y     = 1,
    DMD_Z     = 2,
    DMD_W     = 3,
    DMD_PITCH = 0,
    DMD_YAW   = 1,
    DMD_ROLL  = 2
} dmdIndex;

typedef float64 dmdVector[3];
typedef float64 dmdScale[3];
typedef float64 dmdPoint[3];
typedef float64 dmdEuler[3];
typedef float64 dmdQuaternion[4];
typedef float64 dmdMatrix[4][4];

typedef struct {
    dmdMatrix   pos;
    dmdVector   linearVel;
    dmdVector   linearAccn;
    dmdVector   angularVel;
    dmdVector   angularAccn;
} dmdPosition, *dmdPosition_Ptr;

/*
 * Small value used to check floating point values for equality
 * or smallness. This number is withing 2 bits of the smallest
 * representable relative differance between two numbers.
 */
#define DMD_EPSILON ((float64)(DBL_EPSILON * 4.0))

/*
 * fast macros for common ops.
 */
#define dmdSqr(x) ((x) * (x))

#define dmdCrossProd3(r,a,b)                    \
do {                                            \
    float64 _ax = (a)[DMD_X], _bx = (b)[DMD_X]; \
    float64 _ay = (a)[DMD_Y], _by = (b)[DMD_Y]; \
    float64 _az = (a)[DMD_Z], _bz = (b)[DMD_Z]; \
                                                \
    (r)[DMD_X] = (_ay * _bz) - (_az * _by);     \
    (r)[DMD_Y] = (_az * _bx) - (_ax * _bz);     \
    (r)[DMD_Z] = (_ax * _by) - (_ay * _bx);     \
} while (0)
    
#define dmdDotProd3(x, y) ( ((x)[DMD_X] * (y)[DMD_X])  \
                          + ((x)[DMD_Y] * (y)[DMD_Y])  \
                          + ((x)[DMD_Z] * (y)[DMD_Z]))
    
#define dmdDotProd4(x, y) ( ((x)[DMD_X] * (y)[DMD_X])  \
                          + ((x)[DMD_Y] * (y)[DMD_Y])  \
                          + ((x)[DMD_Z] * (y)[DMD_Z])  \
                          + ((x)[DMD_W] * (y)[DMD_W]))
    
#define dmdLength3(x) sqrt( dmdSqr(x[DMD_X]) \
                           +dmdSqr(x[DMD_Y]) \
                           +dmdSqr(x[DMD_Z]))
    
#define dmdVectorCrossProd(r,a,b)  dmdCrossProd3((r),(a),(b)) 
#define dmdVectorDotProd(a,b)        dmdDotProd3((a),(b))
#define dmdVectorLength(a)            dmdLength3(a)
#define dmdVectorSqrLength(a)        dmdDotProd3((a),(a))
#define dmdVectorNorm(d,s)                       \
do {                                             \
    float64 l =  dmdVectorLength(s);             \
    if(l != 0.0) {                               \
        float64 t = 1.0/l;                       \
        dmdVectorScaleScalar((d),(s),t);         \
    }                                            \
}while (0)
    
#define dmdScaleInvert(d,s)    (((d)[DMD_X] = 1.0/(s)[DMD_X]), \
                                ((d)[DMD_Y] = 1.0/(s)[DMD_Y]), \
                                ((d)[DMD_Z] = 1.0/(s)[DMD_Z]))
    
#define dmdVectorInvert(d,s)   (((d)[DMD_X] = -(s)[DMD_X]), \
                                ((d)[DMD_Y] = -(s)[DMD_Y]), \
                                ((d)[DMD_Z] = -(s)[DMD_Z])) 
    
    
#define dmdDegToRad(x) ((x) * ( M_PI / 180.0))
#define dmdRadToDeg(x) ((x) * ( M_1_PI * 180.0))
    
    

/*
 * Optimised and Safe trig functions.
 */
DMD__EXPORT void           dmdSinCos(float64 *s,
                                     float64 *c,
                                     float64 angle);
DMD__EXPORT float64     dmdSafeAtan2(float64 opposite,
                                     float64 adjacent);

/*
 * Copy functions
 */
#ifdef _TRANSPUTER
#include <string.h>
#define    dmdMatCopy(d,s) memcpy(d,s,sizeof(dmdMatrix))
#define   dmdQuatCopy(d,s) memcpy(d,s,sizeof(dmdQuaternion))
#define  dmdEulerCopy(d,s) memcpy(d,s,sizeof(dmdEuler))
#define dmdVectorCopy(d,s) memcpy(d,s,sizeof(dmdVector))
#define  dmdPointCopy(d,s) memcpy(d,s,sizeof(dmdPoint))
#define  dmdScaleCopy(d,s) memcpy(d,s,sizeof(dmdScale))
#define    dmdPosCopy(d,s) ((d) = (s))
#define    __dmdCopy3(d,s) memcpy(d,s,3 * sizeof(float64))
#define    __dmdCopy4(d,s) memcpy(d,s,4 * sizeof(float64))
#else
#define __dmdCopy3(d,s) do { \
   (d)[DMD_X] = (s)[DMD_X];  \
   (d)[DMD_Y] = (s)[DMD_Y];  \
   (d)[DMD_Z] = (s)[DMD_Z];  \
} while (0) 
     
#define __dmdCopy4(d,s) do { \
   (d)[DMD_X] = (s)[DMD_X];  \
   (d)[DMD_Y] = (s)[DMD_Y];  \
   (d)[DMD_Z] = (s)[DMD_Z];  \
   (d)[DMD_W] = (s)[DMD_W];  \
} while (0) 
    
#define     dmdMatCopy(d,s) do {       \
    __dmdCopy4((d)[DMD_X],(s)[DMD_X]); \
    __dmdCopy4((d)[DMD_Y],(s)[DMD_Y]); \
    __dmdCopy4((d)[DMD_Z],(s)[DMD_Z]); \
    __dmdCopy4((d)[DMD_W],(s)[DMD_W]); \
} while (0)
    
#define dmdQuatCopy(d,s)   __dmdCopy4(d,s)
#define dmdEulerCopy(d,s)  __dmdCopy3(d,s)
#define dmdVectorCopy(d,s) __dmdCopy3(d,s)
#define dmdPointCopy(d,s)  __dmdCopy3(d,s)
#define dmdScaleCopy(d,s)  __dmdCopy3(d,s)
    
#define   dmdPosCopy(d,s) (*(d) = *(s))
#endif
    
    /*
 * Ident functions. 
 */
#define dmdMatIdent(m)       dmdMatCopy(m, dmdIdentM)
#define dmdQuatIdent(q)     dmdQuatCopy(q, dmdIdentQ)
#define dmdEulerIdent(e)   dmdEulerCopy(e, dmdIdentE)
#define dmdVectorIdent(v) dmdVectorCopy(v, dmdIdentV)
#define dmdPointIdent(p)   dmdPointCopy(p, dmdIdentP)
#define dmdScaleIdent(s)   dmdScaleCopy(s, dmdIdentS)
#define dmdPosIdent(p)       dmdPosCopy(p, &dmdIdentPos)
    
DMD__EXPORT const dmdMatrix     dmdIdentM;
DMD__EXPORT const dmdQuaternion dmdIdentQ;
DMD__EXPORT const dmdEuler      dmdIdentE;
DMD__EXPORT const dmdVector     dmdIdentV;
DMD__EXPORT const dmdPoint      dmdIdentP;
DMD__EXPORT const dmdScale      dmdIdentS;
DMD__EXPORT const dmdPosition   dmdIdentPos;

DMD__EXPORT void    (dmdMatIdent)(dmdMatrix mat);
DMD__EXPORT void   (dmdQuatIdent)(dmdQuaternion q);
DMD__EXPORT void  (dmdEulerIdent)(dmdEuler e);
DMD__EXPORT void (dmdVectorIdent)(dmdVector s);
DMD__EXPORT void  (dmdPointIdent)(dmdPoint s);
DMD__EXPORT void  (dmdScaleIdent)(dmdScale s);
DMD__EXPORT void    (dmdPosIdent)(dmdPosition_Ptr p);

/*
 * initialisation functions
 */
#define dmdEulerSet(e,p,y,r) ((e)[DMD_PITCH] = (p), \
                              (e)[DMD_YAW]   = (y), \
                              (e)[DMD_ROLL]  = (r)) 
     
#define dmdEulerSetD(e,p,y,r) ((e)[DMD_PITCH] =  dmdDegToRad(p), \
                               (e)[DMD_YAW]   =  dmdDegToRad(y), \
                               (e)[DMD_ROLL]  =  dmdDegToRad(r)) 
    
#define dmdQuatSet(q,x,y,z,w) ((q)[DMD_X] = (x), \
                               (q)[DMD_Y] = (y), \
                               (q)[DMD_Z] = (z), \
                               (q)[DMD_W] = (w))
    
#define  dmdPointSet(p,x,y,z) ((p)[DMD_X] = (x), \
                               (p)[DMD_Y] = (y), \
                               (p)[DMD_Z] = (z))
    
#define  dmdVectorSet(v,x,y,z) ((v)[DMD_X] = (x), \
                                (v)[DMD_Y] = (y), \
                                (v)[DMD_Z] = (z))
        
#define  dmdScaleSet(s,x,y,z) ((s)[DMD_X] = (x), \
                               (s)[DMD_Y] = (y), \
                               (s)[DMD_Z] = (z))
    
    
DMD__EXPORT void     (dmdEulerSet)(dmdEuler e,
                                  float64 pitch,
                                  float64 yaw,
                                  float64 roll);
DMD__EXPORT void    (dmdEulerSetD)(dmdEuler e,
                                  float64 pitch,
                                  float64 yaw,
                                  float64 roll);
DMD__EXPORT void      (dmdQuatSet)(dmdQuaternion q,
                                   float64 x,
                                   float64 y,
                                   float64 z,
                                   float64 w);
DMD__EXPORT void     (dmdPointSet)(dmdPoint p,
                                  float64 x,
                                  float64 y, 
                                  float64 z);
DMD__EXPORT void    (dmdVectorSet)(dmdVector p,
                                   float64 x,
                                   float64 y, 
                                   float64 z);
DMD__EXPORT void     (dmdScaleSet)(dmdScale p,
                                   float64 x,
                                   float64 y, 
                                   float64 z);

/*
 * Matrix generation functions
 */
#define dmdMatFromScale(m,s) do { \
    dmdMatIdent(m);               \
    (m)[DMD_X][DMD_X] = s[DMD_X]; \
    (m)[DMD_Y][DMD_Y] = s[DMD_Y]; \
    (m)[DMD_Z][DMD_Z] = s[DMD_Z]; \
} while (0)
     
#define dmdMatFromEuler(m,e) do { \
    dmdQuaternion __q;            \
    dmdQuatFromEuler(__q,e);      \
    dmdMatFromQuat(m,__q);        \
} while (0)
    
#define dmdMatFromPoint(m,p) do { \
    dmdMatIdent(m);               \
    m[DMD_W][DMD_X] = p[DMD_X];   \
    m[DMD_W][DMD_Y] = p[DMD_Y];   \
    m[DMD_W][DMD_Z] = p[DMD_Z];   \
} while (0)
    
#define dmdMatFromPointEulerScale(m, p,e,s) do { \
    dmdMatFromScale(m,s);                        \
    dmdMatRotEuler(m,e);                         \
    m[DMD_W][DMD_X] = p[DMD_X];                  \
    m[DMD_W][DMD_Y] = p[DMD_Y];                  \
    m[DMD_W][DMD_Z] = p[DMD_Z];                  \
} while (0)
    
#define dmdMatFromPointQuatScale(m, p,q,s) do {  \
    dmdMatFromScale(m,s);                        \
    dmdMatRotQuat(m,q);                          \
    m[DMD_W][DMD_X] = p[DMD_X];                  \
    m[DMD_W][DMD_Y] = p[DMD_Y];                  \
    m[DMD_W][DMD_Z] = p[DMD_Z];                  \
} while (0)

DMD__EXPORT void              dmdMatFromQuat(      dmdMatrix mat,
                                             const dmdQuaternion quat);
DMD__EXPORT void       dmdMatFromGeneralQuat(      dmdMatrix mat,
                                             const dmdQuaternion quat);
DMD__EXPORT void           (dmdMatFromEuler)(      dmdMatrix m,
                                             const dmdEuler e);
DMD__EXPORT void           (dmdMatFromScale)(      dmdMatrix m,
                                             const dmdScale  s);
DMD__EXPORT void           (dmdMatFromPoint)(      dmdMatrix m,
                                             const dmdPoint  p);
DMD__EXPORT void (dmdMatFromPointEulerScale)(      dmdMatrix m,
                                             const dmdPoint p,
                                             const dmdEuler e,
                                             const dmdScale s);
DMD__EXPORT void  (dmdMatFromPointQuatScale)(      dmdMatrix m,
                                             const dmdPoint p,
                                             const dmdQuaternion q,
                                             const dmdScale s);

/*
 * matrix manipulation functions.
 */
#define dmdMatRotQuat(m,q) do { \
    dmdMatrix __m;              \
    dmdMatFromQuat(__m, (q));   \
    dmdMatMultH((m),(m),__m);   \
} while (0)
     
#define dmdMatRotEuler(m, e) do { \
    dmdMatrix __m;                \
    dmdMatFromEuler(__m,e);       \
    dmdMatMultH((m), (m), __m);   \
} while (0)
    
    
DMD__EXPORT void       dmdMatRotX(dmdMatrix m,
                                float64  angle);
DMD__EXPORT void       dmdMatRotY(dmdMatrix m,
                                float64  angle);
DMD__EXPORT void       dmdMatRotZ(dmdMatrix m,
                                float64  angle);

DMD__EXPORT void (dmdMatRotEuler)(      dmdMatrix m,
                                  const dmdEuler e);
DMD__EXPORT void  (dmdMatRotQuat)(      dmdMatrix m,
                                  const dmdQuaternion q);
DMD__EXPORT void      dmdMatScale(      dmdMatrix m,
                                  const dmdScale s);

DMD__EXPORT void      dmdMatXlate(      dmdMatrix m,
                                  const dmdVector v);

DMD__EXPORT void    dmdMatInvertH(      dmdMatrix inv,
                                        dmdMatrix mat);

DMD__EXPORT void      dmdMatMultH(      dmdMatrix res,
                                        dmdMatrix left,
                                        dmdMatrix right);

DMD__EXPORT int      dmdMatInvert(      dmdMatrix inv,
                                        dmdMatrix mat);

DMD__EXPORT void       dmdMatMult(      dmdMatrix res,
                                        dmdMatrix left,
                                        dmdMatrix right);

/*
 * Quaternion manipulation ops.
 */
#define dmdQuatNorm(x) do {       \
    if ((x)[DMD_W] < 0.0) {       \
        (x)[DMD_X] = -(x)[DMD_X]; \
        (x)[DMD_Y] = -(x)[DMD_Y]; \
        (x)[DMD_Z] = -(x)[DMD_Z]; \
        (x)[DMD_W] = -(x)[DMD_W]; \
    }                             \
}while(0)
     
DMD__EXPORT void       dmdQuatInvert(      dmdQuaternion res,
                                     const dmdQuaternion q);
DMD__EXPORT void         dmdQuatMult(      dmdQuaternion res,
                                     const dmdQuaternion left,
                                     const dmdQuaternion right);
DMD__EXPORT void         dmdQuatMake(      dmdQuaternion quat,
                                     const dmdVector axis,
                                     float64  angle);
DMD__EXPORT void dmdQuatMakeUnitAxis(      dmdQuaternion rot,
                                     const dmdVector axis,
                                     float64    angle);
DMD__EXPORT void       (dmdQuatNorm)(dmdQuaternion q);


/*
 * Conversions between Euler angles and
 * quaternions.
 */

DMD__EXPORT void    dmdQuatFromEuler(      dmdQuaternion quat,
                                     const dmdEuler erot);

DMD__EXPORT void    dmdEulerFromQuat(      dmdEuler e,
                                     const dmdQuaternion q);


/*
 * Functions to split matricies in various ways.
 */

#define dmdPointFromMat(p,m)   dmdPointQuatScaleFromMat((p),  NULL, NULL, (m))
#define dmdScaleFromMat(s,m)   dmdPointQuatScaleFromMat(NULL, NULL, (s),  (m))
#define dmdQuatFromMat(q,m)    dmdPointQuatScaleFromMat(NULL, (q),  NULL, (m))
#define dmdEulerFromMat(e,m)  dmdPointEulerScaleFromMat(NULL, (e),  NULL, (m))

DMD__EXPORT int          (dmdQuatFromMat)(      dmdQuaternion quat,
                                                dmdMatrix mat);
DMD__EXPORT int         (dmdEulerFromMat)(      dmdEuler e,
                                                dmdMatrix m);
DMD__EXPORT int         (dmdPointFromMat)(      dmdPoint p,
                                                dmdMatrix m);
DMD__EXPORT int         (dmdScaleFromMat)(      dmdScale s,
                                                dmdMatrix m);

DMD__EXPORT int  dmdPointQuatScaleFromMat(      dmdPoint      p,
                                                dmdQuaternion q,
                                                dmdScale      s,
                                                dmdMatrix     m);

DMD__EXPORT int dmdPointEulerScaleFromMat(      dmdPoint  p,
                                                dmdEuler  e,
                                                dmdScale  s,
                                                dmdMatrix m);

/*
 * Functions to manipulate vectors and points
 * using matricies, quaternions, rotations and scales
 */
#define __dmdAdd3(r,a,b)   ((r)[DMD_X] = (a)[DMD_X] + (b)[DMD_X], \
                            (r)[DMD_Y] = (a)[DMD_Y] + (b)[DMD_Y], \
                            (r)[DMD_Z] = (a)[DMD_Z] + (b)[DMD_Z])
#define __dmdSub3(r,a,b)   ((r)[DMD_X] = (a)[DMD_X] - (b)[DMD_X], \
                            (r)[DMD_Y] = (a)[DMD_Y] - (b)[DMD_Y], \
                            (r)[DMD_Z] = (a)[DMD_Z] - (b)[DMD_Z])
#define __dmdScale3(r,a,b) ((r)[DMD_X] = (a)[DMD_X] * (b)[DMD_X], \
                            (r)[DMD_Y] = (a)[DMD_Y] * (b)[DMD_Y], \
                            (r)[DMD_Z] = (a)[DMD_Z] * (b)[DMD_Z])
     
#define __dmdScaleScalar3(r,a,b)   ((r)[DMD_X] = (a)[DMD_X] * (b), \
                                    (r)[DMD_Y] = (a)[DMD_Y] * (b), \
                                    (r)[DMD_Z] = (a)[DMD_Z] * (b))
    
    
#define __dmdRotEuler3(r,a,b)    \
do {                             \
    dmdQuaternion __q;           \
    dmdQuatFromEuler(__q,b);     \
    __dmdRotQuat3((r),(a),__q);  \
} while (0)
    
DMD__EXPORT void       __dmdRotQuat3(      float64     *r,
                                     const float64     *a,
                                     const dmdQuaternion q);

#define dmdVectorAdd(r,a,b)         __dmdAdd3(r,a,b)
#define dmdVectorSub(r,a,b)         __dmdSub3(r,a,b)
#define dmdPointSub(r,a,b)          __dmdSub3(r,a,b)
#define dmdPointAddVector(r,a,b)    __dmdAdd3(r,a,b)

#define dmdVectorScale(r,a,b)       __dmdScale3(r,a,b)
#define dmdPointScale(r,a,b)        __dmdScale3(r,a,b)
#define dmdVectorScaleScalar(r,a,b) __dmdScaleScalar3(r,a,b)
#define dmdVectorRotQuat(r,v,q)     __dmdRotQuat3(r,v,q) 
#define dmdPointRotQuat(r,p,q)      __dmdRotQuat3(r,p,q) 

#define dmdVectorRotEuler(r,v,e)    __dmdRotEuler3(r,v,e)
#define dmdPointRotEuler(r,p,e)     __dmdRotEuler3(r,p,e)


DMD__EXPORT void         (dmdVectorAdd)(      dmdVector r,
                                        const dmdVector a,
                                        const dmdVector b);

DMD__EXPORT void        (dmdVdectorSub)(      dmdVector r,
                                        const dmdVector a,
                                        const dmdVector b);

DMD__EXPORT void          (dmdPointSub)(      dmdVector r,
                                        const dmdPoint  a,
                                        const dmdPoint  b);

DMD__EXPORT void    (dmdPointAddVector)(      dmdPoint  r,
                                        const dmdPoint  a,
                                        const dmdVector b);

DMD__EXPORT void       (dmdVectorScale)(      dmdVector r,
                                        const dmdVector a,
                                        const dmdScale  b);

DMD__EXPORT void (dmdVectorScaleScalar)(      dmdVector r,
                                        const dmdVector a,
                                              float64   b);

DMD__EXPORT void        (dmdPointScale)(      dmdPoint r,
                                        const dmdPoint a,
                                        const dmdScale b);

DMD__EXPORT void     (dmdVectorRotQuat)(      dmdVector r,
                                        const dmdVector v,
                                        const dmdQuaternion);

DMD__EXPORT void    (dmdVectorRotEuler)(      dmdVector r,
                                      const dmdEuler  e,
                                      const dmdVector v);


DMD__EXPORT void      (dmdPointRotQuat)(      dmdPoint r,
                                        const dmdPoint p,
                                        const dmdQuaternion q);
DMD__EXPORT void     (dmdPointRotEuler)(      dmdPoint r,
                                        const dmdPoint p,
                                        const dmdEuler  e);

DMD__EXPORT void      dmdVectorXformMat(      dmdVector r,
                                        const dmdVector v,
                                              dmdMatrix m);
DMD__EXPORT void       dmdPointXformMat(      dmdPoint r,
                                        const dmdPoint v,
                                              dmdMatrix m);



/*
 * Dead reckoning et al. Actually most of these functions only 
 * deal with zero order stuff.
 */

#define dmdPosFromMat(p,m) do {                  \
    dmdMatCopy((p)->pos, m);                     \
    dmdVectorIdent((p)->linearVel);              \
    dmdVectorIdent((p)->linearAccn);             \
    dmdVectorIdent((p)->angularVel);             \
    dmdVectorIdent((p)->angularAccn);            \
} while (0)
    
#define dmdPosFromPointEulerScale(p,p2,e,s) do {      \
    dmdMatFromPointEulerScale((p)->pos,(p2),(e),(s)); \
    dmdVectorIdent((p)->linearVel);                   \
    dmdVectorIdent((p)->linearAccn);                  \
    dmdVectorIdent((p)->angularVel);                  \
    dmdVectorIdent((p)->angularAccn);                 \
}while(0)
    
#define dmdPosFromPointQuatScale(p,p2,q,s) do {       \
    dmdMatFromPointQuatScale((p)->pos,(p2),(q),(s));  \
    dmdVectorIdent((p)->linearVel);                   \
    dmdVectorIdent((p)->linearAccn);                  \
    dmdVectorIdent((p)->angularVel);                  \
    dmdVectorIdent((p)->angularAccn);                 \
}while(0)
     
DMD__EXPORT void             (dmdPosFromMat)(      dmdPosition_Ptr p,
                                                   dmdMatrix       m);
DMD__EXPORT void (dmdPosFromPointEulerScale)(      dmdPosition_Ptr p,
                                             const dmdPoint        p2,
                                             const dmdEuler        e,
                                             const dmdScale        s);
DMD__EXPORT void  (dmdPosFromPointQuatScale)(      dmdPosition_Ptr p,
                                             const dmdPoint        p2,
                                             const dmdQuaternion   q,
                                             const dmdScale        s);

DMD__EXPORT void               dmdDeadReckon(      dmdMatrix       m,
                                                   float64         time,
                                             const dmdPosition_Ptr pos);
/*
 *
 *    given four points a, b, c, d defining two line segments AB and CD,
 *    generate a matrix m that will transform AB to CD.
 *    If the length of either line segment is zero, the results are undefined.
 */
DMD__EXPORT void dmdPointToPoint(dmdMatrix m,
                                 dmdPoint  a,
                                 dmdPoint  b,
                                 dmdPoint  c,
                                 dmdPoint  d);

/*
 * bring a matrix that is no longer orthogonal
 * back into orthogonality - Only looks at the
 * top 3x3 part of the matrix. Note that a
 * scaled matrix os not orthogonal, so this
 * will remove a >small<  (ie close to 1)
 * scale, but anything too  far from one will cause
 * the algorithm to 'blow up'. In general
 * unless you *know* the scales are unity,
 * use dmdMatOrthogPreserveScale.
 */
DMD__EXPORT void     dmdMatOrthog(dmdMatrix r,
                                  dmdMatrix s);

/*
 * same as dmdMatOrthog, but it strips
 * out scales befor orthogonalisation,
 * and re-introduces them afterwards.
 * Will return 0 if the matrix is singular
 * (any scale == 0), otherwide returns 1
 */
DMD__EXPORT int dmdMatOrthogPreserveScale(dmdMatrix r,
                                          dmdMatrix s);

/*
 * version function
 */
DMD__EXPORT void               dmdVersion(FILE *fp);

#ifdef __cplusplus
}
#endif
#endif /*_DMDTYPES_H */

