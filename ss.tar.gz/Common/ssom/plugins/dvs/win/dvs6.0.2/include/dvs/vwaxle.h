/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: vwaxle.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:08:11 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: vwaxle.h,v 1.1 2005/09/13 15:08:11 pukitepa Exp $
 *
 *    FUNCTION: Contains all functions for scalar widgets.
 * 
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _VWAxle_H
#define _VWAxle_H
#ifdef __cplusplus
extern "C" {
#endif

/* INCLUDES ==============================================*/
#include "vwidgets.h"

/* PUBLIC FORWARD DECLARATIONS ===========================*/

VW_EXPORT VWidget *VWAxle_CreateManaged(VWidget *parent, char *name, VWArg args[], int argc);
VW_EXPORT VWidget *VWAxle_Create(VWidget *parent, char *name, VWArg args[], int argc);

VW_EXPORT void VWAxle_GetUnitVector(VWidget *AxleWig, dmVector unitVector);

VW_EXPORT void VWAxle_GetEndPoints(VWidget *AxleWig, dmPoint firstPoint, dmPoint secondPoint);

/* PUBLIC TYPES ========================================== */

enum VWAxleArgTypes {
    VWrAxleBarVisual = VW_RESOURCES_AXLE, 
    VWrAxleBarMaterial, 
    VWrAxleBarHighlightMaterial, 
    VWrAxleBarWidth, 
    VWrAxlePuckVisual, 
    VWrAxlePuckMaterial, 
    VWrAxlePuckHighlightMaterial, 
    VWrAxlePuckSize, 
    VWrAxlePuckDragCallback, 
    VWrAxlePuckDragCalldata, 
    VWrAxlePuckDropCallback, 
    VWrAxlePuckDropCalldata, 
    VWrAxleBarDragCallback, 
    VWrAxleBarDragCalldata, 
    VWrAxleBarDropCallback, 
    VWrAxleBarDropCalldata
};



#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /*_VWAxle_H */
