/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1995 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS 2.1
--  Module       : Audio support library
--  Object Name  : $RCSfile: resparam.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : $Date: 2005/09/13 15:08:04 $
--  Author       : $Author: pukitepa $
--
--  Description	
--	Audio resource parameter information.
--
--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __RESPARAM_H__
#define __RESPARAM_H__

/*
 * ------------------------------------------------------------
 *
 * Used as index into res param array
 *
 * ------------------------------------------------------------
 */

typedef enum ResParamName 
{
    RESPARAM_MODE,              /* controls which fields are active */
    RESPARAM_HRTF,              /* hrtf file name */
    RESPARAM_IAD,               /* inter-aural distance */
    RESPARAM_VOLUME,            /* scene volume */
    RESPARAM_ABSORB,            /* atmospheric absorption */
    RESPARAM_ROLLOFF,           /* spreading roll off over distance */
    RESPARAM_SCALE,             /* world scaling factor */
    RESPARAM_NUM_ENTRIES        /* number of entries in ResParamName enum */
} ResParamName;


typedef struct ResParam ResParam;

extern ResParam *ResParamInit(void);
extern int ResParamEquals(ResParam *, ResParamName, ...);
extern void ResParamClearChanged(ResParam *);
extern void ResParamSetChanged(ResParam *, ResParamName);
extern int ResParamTestChanged(ResParam *, ResParamName);
extern void ResParamSet(ResParam *, ResParamName, ...);
extern void ResParamGet(ResParam *, ResParamName, ...);

#endif /* __RESPARAM_H__ */
