/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1993 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: xdmsg.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 5 January 1995
--  Author       : Tony Coombes
--
--  Description	 : Maintain message buffer
--
--  Modified
--    By         : $Author: pukitepa $
--    Date       : $Date: 2005/09/13 15:08:25 $
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __XDMSG_H__
#define __XDMSG_H__

#ifdef __cplusplus
extern "C" {
#endif

#ifndef XDV_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `XDV_EXPORT'
 */
#ifdef  _LIB_XDV
#define XDV_EXPORT __declspec(dllexport) extern
#else
#define XDV_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define XDV_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ifndef XDV_EXPORT */

XDV_EXPORT void XdMsgAppend(char *message);
XDV_EXPORT void XdMsgClear(void);

#ifdef __cplusplus
}
#endif

#endif /* __XDMSG_H__ */

