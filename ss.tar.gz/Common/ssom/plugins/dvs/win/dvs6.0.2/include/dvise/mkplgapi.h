/* 
-- ----------------------------------------------------------------------------
--
--  			Copyright 1998 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVISE
--  Module       : View and Markup
--  Object Name  : $RCSfile: mkplgapi.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : $Date: 2005/09/13 15:07:55 $
--  Author       : $Author: pukitepa $
--
--  Description	
--	Markup plugin API
--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __MKPLGAPI_H__
#define __MKPLGAPI_H__

#ifdef _LIB_DV
#include "mkparam.h"
#else
#include <dvise/mkparam.h>
#endif

#define MARKUP_PLUGIN_MAJOR_VERSION 1
#define MARKUP_PLUGIN_MINOR_VERSION 0

typedef void (*MarkupOpCompleteCb)(const void* const clientData,
                                  const char* const markupFileName);
typedef void (*MarkupErrorCb)(const void* const clientData,
                              const char* const msg);

typedef void (*MarkupPluginCreate)(const char* const name,
                                   const char* const imageFileName,
                                   const void* const clientData);
typedef void (*MarkupPluginEdit)(const char* const name,
                                 const char* const imageFileName,
                                 const char* const markupFileName,
                                 const void* const clientData);
typedef void (*MarkupPluginView)(const char* const name,
                                 const char* const imageFileName,
                                 const char* const markupFileName,
                                 const void* const clientData);
typedef void (*MarkupPluginDelete)(const char* const imageFileName,
                                   const char* const markupFileName,
                                   const void* const clientData);
typedef void (*MarkupPluginCompleted)(const char* const imageFileName,
                                      const char* const markupFileName,
                                      const void* const clientData);
typedef void (*MarkupPluginSetOpCompleteCb)(MarkupOpCompleteCb);
typedef void (*MarkupPluginSetErrorCb)(MarkupErrorCb);

typedef struct MarkupPluginAPI
{
    MarkupPluginCreate create;
    MarkupPluginEdit edit;
    MarkupPluginView view;
    MarkupPluginDelete delete;
    MarkupPluginCompleted completed;
    MarkupPluginSetOpCompleteCb setOpCompleteCb;
    MarkupPluginSetErrorCb setErrorCb;
} MarkupPluginAPI;



typedef MarkupPlugParams* (*MarkupPluginParameters)(void);

typedef int (*MarkupPluginRegister)(MarkupPlugParams *parameters,
                                     MarkupPluginAPI *api);

#endif /* __MKPLGAPI_H__ */
