/*
 *    PROJECT:
 *    SUBSYSTEM:
 *    MODULE:
 *
 *    File:         $RCSfile: fltpath.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:07:54 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: fltpath.h,v 1.1 2005/09/13 15:07:54 pukitepa Exp $
 *
 *    FUNCTION:
 *
 * Copyright (c) 1992 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */

/* Version Control */

#ifndef _FLTPATH_H
#define _FLTPATH_H
#ifdef __cplusplus
extern "C" {
#endif

#include <dvise/camera.h>

/* PUBLIC TYPES =========================================*/

struct ECFlightData;
typedef struct ECFlightData ECFlightData;

/* PUBLIC DEFINES =======================================*/


/* PUBLIC VARIABLES ======================================*/


/* PUBLIC FUNCTIONS ======================================*/

DV_EXPORT void ECBody_AddFlightData(VCBody *body);
DV_EXPORT void ECBody_RemoveFlightData(VCBody *body);
DV_EXPORT ECFlightData *ECBody_GetFlightData(VCBody *body);
DV_EXPORT int ECBody_OnFlightPath(VCBody *body, ECAssembly *camera, int *dormant);
DV_EXPORT void ECBody_BailOut(VCBody *body);
DV_EXPORT int ECBody_AtAssembly(VCBody *body, ECAssembly *a);

DV_EXPORT int ECFlightPath_Control(ECFlightData *data, int control);
DV_EXPORT void ECFlightPath_AutoPlay(ECFlightData *data);
DV_EXPORT void ECFlightPath_Initialise(ECCamera *cam, VCBody *body);
DV_EXPORT void ECFlightPath_Cleanup(ECFlightData *data);
DV_EXPORT int ECFlightPath_SetUserData(ECFlightData *fd, ECUserData *ud);
DV_EXPORT void ECFlightPath_RemoveArrivedCB(ECFlightData *fd);
DV_EXPORT int ECFlightPath_SetTickFlag(ECFlightData *fd, int onoff);
DV_EXPORT int ECFlightPath_DoingTick(ECFlightData *data);

DV_EXPORT ECCamera *ECLandmark_GetReference(ECLandmark *l);
DV_EXPORT int ECLandmark_ForIncludeNodes(ECAssembly *l);
DV_EXPORT int ECLandmark_ExIncludeNodes(ECAssembly *l);
DV_EXPORT int ECAssembly_SetPosFromBody(ECAssembly *a, VCBody *body);
DV_EXPORT void ECBody_GetEyePosition(VCBody *body, dmPoint retPos, dmEuler retOr);

DV_EXPORT ECUserData *ECFlightPath_DoControlUD(int control);

#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /* _FLTPATH_H */
