/****************************************************************************
 *
 *  			Copyright 1995 Division Limited.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: ptool.h,v $
 *  Revision      : $Revision: 1.1 $
 *  Date          : $Date: 2005/09/13 15:07:46 $
 *  Author        : $Author: pukitepa $
 *  Last Modified : <070199.1058>
 *
 *  Description	
 *
 *  Notes
 *
 ****************************************************************************
 *
 *  Copyright (c) 1995 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 *  This Document may not, in whole or in part, be copied,
 *  photocopied, reproduced, translated, or reduced to any
 *  electronic medium or machine readable form without prior
 *  written consent from Division Ltd.
 ****************************************************************************/

#ifndef __PTOOL_H__
#define __PTOOL_H__

#include <dsys/dmd.h>
#include <dsys/pfile.h>
#ifdef _PT_LOCAL
#include "pimage.h"
#else
#include <dsys/pimage.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define dptHedgehogNormalName  "show_Normal"
#define dptHedgehogBBoxName    "show_BBox"
#define dptHedgehogBSphereName "show_BSphere"
#define dptHedgehogBPmeshName  "show_BPmesh"

/*****************************************************************************/
/* pfile error numbers */
#define dptENO_NOTIMP    0x8001
#define dptENO_FORM      0x8002
#define dptENO_VALUE     0x8003
#define dptENO_USAGE     0x8004
#define dptENO_NULL      0x8005
#define dptENO_INTER     0x8006
#define dptENO_GRAPH     0x8007

/*****************************************************************************/
/* ptool monitor flags */
#define dptMON_ALL       0x01000000
    
    
/* returns 0 if the triangle is small, 1 and the normal otherwise
*/
int32
dptCalcVTriNorm(dmVector pnt1, dmVector pnt2, dmVector pnt3,
                dmVector normal) ;
int32
dptCalcTriNorm(dpfVERTEXPTR vert1, dpfVERTEXPTR vert2, dpfVERTEXPTR vert3,
               dmVector normal) ;
void
dptMatMultVector(dmVector OutVec, dmVector vec, dmMatrix mat) ;


/*
 *  FILE __ptmesh.c
 *  Creates and saves meshes
 */
#define dpt_OPT_PMESH  0x010000
#define dpt_OPT_PSTRIP 0x020000

dptMESHPTR
dptCreateMesh(int32 hash_size, int32 normals) ;
void
dptFreeMesh(dptMESHPTR mesh) ;
void
dptGetMeshStats(dptMESHPTR mesh) ;
int32
dptGetMeshNoTriangles(dptMESHPTR mesh) ;
int32
dptGetMeshNoVertices(dptMESHPTR mesh) ;
int32
dptGetMeshNoDropTri(dptMESHPTR mesh) ;

int32
dptMeshLoadFile(dptMESHPTR mesh, dpfFILEPTR file) ;
int32
dptMeshLoadObject(dptMESHPTR mesh, dpfOBJECTPTR object) ;
int32
dptMeshLoadLOD(dptMESHPTR mesh, dpfLODPTR LOD) ;
int32
dptMeshLoadGeogroup(dptMESHPTR mesh, dpfGEOGROUPPTR geogroup) ;
int32
dptMeshLoadGeometry(dptMESHPTR mesh, dpfGEOMETRYPTR geom) ;
int32
dptMeshLoadTriangle(dptMESHPTR mesh, dpfVERTEXPTR vert1, dpfVERTEXPTR vert2,
                   dpfVERTEXPTR vert3) ;

int32
dptMeshCalcFaceNormals(dptMESHPTR mesh) ;
void
dptMeshSetVertexPoint(dptMESHPTR mesh, dpfVERTEXPTR vert, dmVector point) ;

int32
dptMeshUnloadGeogroup(dpfGEOGROUPPTR geogroup, dptMESHPTR mesh, int32 usePmesh) ;
int32
dptMeshUnloadLOD(dpfLODPTR LOD, dptMESHPTR mesh, int32 usePmesh) ;
int32
dptMeshUnloadMesh(dptMESHPTR mesh, int32 usePmesh) ;

/*
** Octize utilitises
**
** must load the file into a mesh using dptMeshLoadFile etc.
** Then use dptOctizeMesh to octize followed by
** dptUnloadOctizedMeshSingle or dptUnloadOctizedMeshMulti
** for single and All file outputs.
*/
int32
dptOctizeMesh(dptMESHPTR mesh, dpfIVECTOR div, dmVector Min, dmVector Dif) ;
int32
dptSpatialiseMesh(dptMESHPTR mesh) ;

int32
dptUnloadDividedMeshSingle(dptMESHPTR mesh, int32 octPos, 
                          int32 usePmesh, int32 *noTriangles) ;
int32
dptUnloadOctizedMeshSingle(dptMESHPTR mesh, dpfIVECTOR pos,
                          int32 usePmesh, int32 *noTriangles) ;
int32
dptUnloadDividedMeshAll(dptMESHPTR mesh, int32 usePmesh) ;


/*
 *  File ptbbox
 * Gets bounding box of files, objects, geogroups & geoms
 *
 * dpfBbox??? must have the MaxVec and MinVec initialized by the user
 *           before it is first called.
 * dpfGetbbox??? Initializes itself, and gets the bounding box and
 *              difference vector for the structure.
 */
int32
dptGetBBoxGeometry(dpfGEOMETRYPTR geom, dmVector MaxVec, dmVector MinVec, 
                  dmVector differ) ;
int32
dptGetBBoxGeogroup(dpfGEOGROUPPTR geogroup, dmVector MaxVec, dmVector MinVec, 
               dmVector differ) ;
int32
dptGetBBoxLOD(dpfLODPTR LOD, dmVector MaxVec, dmVector MinVec, 
                dmVector differ) ;
int32
dptGetBBoxFile(dpfFILEPTR file, dmVector MaxVec, dmVector MinVec, 
              dmVector differ) ;

/*
 *  File ptscale
 *  scales files, objects, geogroups & geoms
 */
/* NOTE! :- If dptScaleGeometry or Geogroup is used it is up to the USER to 
**          scale all LOD reference points !!! DON'T FORGET.
*/
int32
dptScaleGeometry(dpfGEOMETRYPTR geom, int32 normals, dmVector scale) ;
int32
dptScaleGeogroup(dpfGEOGROUPPTR geogroup, dmVector scale) ;
int32
dptScaleObject(dpfOBJECTPTR object, dmVector scale) ;
int32
dptScaleFile(dpfFILEPTR file, dmVector scale) ;
int32
dptChangeFileUnit(dpfFILEPTR file, dpfUNIT unit) ;

int32
dptScaleNPGeometry(dpfGEOMETRYPTR geom, dmVector scale, dpfIVECTOR NP) ;
int32
dptScaleNPGeogroup(dpfGEOGROUPPTR geogroup, dmVector scale, dpfIVECTOR NP) ;
int32
dptScaleNPObject(dpfOBJECTPTR object, dmVector scale, dpfIVECTOR NP) ;
int32
dptScaleNPFile(dpfFILEPTR file, dmVector scale, dpfIVECTOR NP) ;

/*
 *  File ptxlate
 *  translates files, objects, geogroups & geoms
 */
/* NOTE! :- If dptTranslateGeometry or Geogroup is used it is up to the USER to 
**          scale all LOD reference points !!! DON'T FORGET.
*/
int32
dptTranslateGeometry(dpfGEOMETRYPTR geom, dmVector trn) ; 
int32
dptTranslateGeogroup(dpfGEOGROUPPTR geogroup, dmVector trn) ; 
int32
dptTranslateLOD(dpfLODPTR LOD, dmVector trn) ;
int32
dptTranslateObject(dpfOBJECTPTR object, dmVector trn) ; 
int32
dptTranslateFile(dpfFILEPTR file, dmVector trn) ; 

/*
 *  File ptcentre
 *  Centre's given file
 */
int32
dptCentreFile(dpfFILEPTR file) ;

/*
 *  File ptcoales
 * coalesces short geogroups into longer ones
 * reduces file size, execution time
 */
int32
dptCoalesceLOD(dpfLODPTR LOD) ;
int32
dptCoalesceFile(dpfFILEPTR file, int32 coalesceLODs, int32 coalesceGEOMs) ;

/*
 *  File pttextur
 *  Places planar texture co-ordinates on given file
 */
#define dpt_TEXTURE_PLANE     0
#define dpt_TEXTURE_AXIAL     1
#define dpt_TEXTURE_CYLINDER  2

typedef struct 
{
    /* The following MUST be set when passed to dptTextureInit */
    int32      method ;
    int32      noWraps ;
    int32      gotSize, gotRef ;
    int32      distort ;
    
    /* must be set to a +ve valid number of wraps or -ve */
    float32    Uwrap, Vwrap ;
    
    /* must be init if gotSize is non-zero */
    float32    Usize, Vsize ;
    
    /* must be init if gotRef is non-zero */
    dmVector   reference ;

    /* for planemap Uco, Vco must be init to -1 or an axis (0-2) */
    int32      Uco, Vco ;
    
    /* for axial mapping axes must be init */
    int32      axes[3] ;
    
    /* for cylinder mapping, both Cswap & Cangle must be init (usually 0) */
    int32      Cswap ;
    float32    Cangle ;
    
    /* always calculated from Cangle */
    float32    Coffset ;
} dptTEXTURE, *dptTEXTUREPTR ;


void
dptCorrectTriangleTexture(dptMESHPTR mesh, dpfGEOGROUPPTR geogroup, 
                          dpfVERTEXPTR vert1, dpfVERTEXPTR vert2,
                          dpfVERTEXPTR vert3, int32 noWraps, int32 *distort) ;
dpfGEOMETRYPTR
dptCorrectGeometryTexture(dpfGEOMETRYPTR geom, int32 noWraps, int32 *distort) ;

int32
dptTextureInit(dptTEXTUREPTR txt, dmVector  MinVec, dmVector differ) ;
int32
dptTextureFileInit(dpfFILEPTR file, dptTEXTUREPTR txt) ;
dpfGEOMETRYPTR
dptTextureGeometry(dpfGEOMETRYPTR geom, dptTEXTUREPTR txt) ;
int32 
dptTextureGeogroup(dpfGEOGROUPPTR ptch, dptTEXTUREPTR txt) ;
int32 
dptTextureLOD(dpfLODPTR LOD, dptTEXTUREPTR txt) ;
int32
dptTextureFile(dpfFILEPTR file, dptTEXTUREPTR txt) ;

/*
 *  File __ptrot.c
 *  rotates files, objects, geogroups & geoms
 *  Order the rotations are performed are the same as MAZ
 *  ie Z, X then Y
 */
/* Matrix point transformers.
 * Transforms (Xforms) files using a 4x4 homogeneous matrix, 
 * Note that translations are performed, hence the use of dmPntXformMat
 * 
 * Used directly by the dptRotate functions.
 */
#define dptVectorXformMat(OutVec,vec,mat) dmPointXformMat(OutVec,vec,mat)
extern void
(dptVectorXformMat)(dmVector OutVec, dmVector vec, dmMatrix mat) ;
int32
dptXformGeometry(dpfGEOMETRYPTR geom, int32 Normals, dmMatrix rotate) ;
int32
dptXformGeogroup(dpfGEOGROUPPTR geogroup, dmMatrix rotate) ;
int32
dptXformObject(dpfOBJECTPTR object, dmMatrix rotate) ;
int32
dptXformFile(dpfFILEPTR file, dmMatrix rotate) ;

/*****************************************************************************
* NOTE! :- If dptRotateGeometry or Geogroup is used it is up to the USER to     *
*          scale all LOD reference points !!! DON'T FORGET.                  *
*****************************************************************************/
/*
 * Rotation functions use the Xform functions directly, so error messages
 * will be dptXform's.
 */
extern void
dptRotateSetup(dmMatrix outMat, dmVector inRot) ;
#define dptRotateGeometry(geom,Normals,rotate)                               \
            dptXformGeometry(geom,Normals,rotate)
#define dptRotateGeogroup(geogroup,rotate)                                         \
            dptXformGeogroup(geogroup,rotate)
#define dptRotateObject(object,rotate)                                       \
            dptXformObject(object,rotate)
#define dptRotateFile(file,rotate)                                           \
            dptXformFile(file,rotate)

/*
 *  File __pticon.h
 *  Centre's and scales a given file to produce an icon
 */

#define dpt_ICONSIZE  1.0

int32
dptIconizeFile(dpfFILEPTR file, float32 size) ;

/*
 *  File __ptrond.h
 *  Rounds given file to the given number of sig. figures
 *  if the given number is <= 0 then default is used.
 */

#define dpt_DEFAULTSIGFIG 6
#define dpt_DEFAULTDPS    4
#define dpt_DEFAULTWRAP   255

int32
dptRoundFvertex(dpfFILEPTR file, int32 SigFig, int32 dps) ;

int32
dptMeshLocalVertexWeld(dptMESHPTR mesh, float32 distTol, float32 angTol, int32 *joinCount) ;
int32
dptGeogroupLocalVertexWeld(dpfGEOGROUPPTR geogroup, int32 hash_size, int32 usePmesh, 
                           float32 distTol, float32 angTol, int32 *joinCount) ;
int32
dptMeshGlobalVertexWeld(dptMESHPTR mesh, float32 distTol, float32 angTol, int32 *joinCount) ;
int32
dptGeogroupGlobalVertexWeld(dpfGEOGROUPPTR geogroup, int32 hash_size, int32 usePmesh, 
                            float32 distTol, float32 angTol, int32 *joinCount) ;
int32
dptMeshEdgeWeld(dptMESHPTR mesh, float32 initAngle, float32 contAngle) ;

typedef struct 
{
    /* Check setup parameters */
    int32 dps ;               /* decimal places to check to        */
    int32 NoWraps ;           /* maximum no. of texture wraps      */
    int32 autoFix ;           /* autoFix on if non-zero            */
    int32 disableText ;       /* don't fix textures if non-zero    */
    int32 splitGeom ;         /* if non-zero the split triangle    */
                              /* rather than distort texture       */

    /* Things calculated on setup */
    float32 MulFac ;           /* Normal modulus accuracy mul factor*/
    
    /* No. things found empty */
    int32  emptyLod ;
    int32  emptyGeogroup ;
    int32  emptyGeom ;
    
    /* LOD error report */
    int32  badDummy ;         /* got a dummy with other lods       */
    int32  badOrder ;         /* lods in wrong order - flag only   */
    int32  distSame ;         /* switch-in == out count            */
    int32  distSwap ;         /* switch-in > out count             */ 
    int32  overLap ;          /* lod switch in overlaps others out */
    
    /* geometry bad report */
    int32  badPmeshT ;        /* No of bad pmesh triangle connects */
    int32  badSphere ;        /* No of spheres with bad radii      */
    int32  badLine ;          /* No of 0 length lines              */
    int32  badPoint ;         /* No. points with nans, inc. lod ref*/
    int32  badNorm ;          /* No. normals with bad mod          */
    int32  badCook ;          /* No. rgb's out of range            */
    int32  badText ;          /* no. nan | text co-ords out of wrap*/
    float32 maxText ;         /* the maximum range of a texture    */
    int32  badVertCount ;     /* Too many vertices in the geometry */
    
    /* boundary report */
    int32  badBBox ;
    int32  badBSphere ;
    int32  badBPmesh ;

    int32  isBad ;            /* Summary flag - if true then error found */
    
    /* auto-fix output */
    int32  dropLod ;          /* No dropped lods as empty          */
    int32  dropGeogroup ;     /* No dropped geogroups as empty       */
    int32  dropGeom ;         /* No dropped geometries as empty    */
    int32  dropTri ;          /* No tri's dropped because duff     */
                              /* duff cos nan's or pmesh connect   */
    int32  dropLine ;         /* No lines's dropped cos len = 0    */
    int32  dropSphere ;       /* No tri's dropped cos radius = 0   */

    int32  dropBPart ;        /* No B box, sphere and pmeshes drop */
    int32  dropBound ;        /* No bounds dropped                 */
    
    int32  normDistort ;      /* No normal 0 or nan mods           */
    int32  textDistort ;      /* No texture distorts (0 if split)  */
    int32  newTriCnt ;        /* No new tris created from splitting*/

    int32  isAwful ;          /* Summary flag - if true then Distortion */
    
} dptCHECK, *dptCHECKPTR ;


int32
dptCheckLODs(dpfFILEPTR file, dptCHECKPTR check) ;
int32
dptCheckGeogroup(dpfGEOGROUPPTR geogroup, dptCHECKPTR check) ;
void
dptCheckSetup(dptCHECKPTR check, int32 dps, int32 NoWraps, int32 autoFix,
              int32 disableText) ;
int32
dptCheckFile(dpfFILEPTR file, dptCHECKPTR check, int32 dps, int32 NoWraps, 
             int32 autoFix, int32 disableText) ;

int32
dptNormalizeMesh(dptMESHPTR mesh, float32 Tolerence) ;
int32
dptNormalGeogroup(dpfGEOGROUPPTR geogroup, int32 hash_size, float32 Tolerence, 
              int32 usePmesh) ;
int32
dptMeshCorrectNormals(dptMESHPTR mesh, float32 angle) ;


/* reduce a geogroup
 * NOTE :-
 * Method is a bit field using the following #defines
 */
#define dptRED_DUPS   0x0001
#define dptRED_DUPD   0x0002
#define dptRED_SQUR   0x0004
#define dptRED_DEC    0x0008
#define dptRED_QUICK  0x0010
#define dptRED_PERC   0x0020
#define dptRED_NORM   0x0040

int32
dptReduceGeogroup(dpfGEOGROUPPTR geogroup, int32 Method, int32 hash_size, 
                  float32 redDecPercent, float32 redDecVDistTol, 
                  float32 redDecCDistTol, float32 redDecTextTol,
                  float32 redDecTextToDist, float32 redDecCookTol,
                  float32 redDecCookToDist, float32 redDecFeatTol,
                  float32 redDecMinPer, int32 usePmesh) ;

/*
** Reduces the number of faces in a cylinder.
** Tolerences :-
**      MaxRadiusTol
**      RatioTol      - The maximum ratio between the largest and
**                      smallest end edges.
**      NormTol       - How correctly shaped the pairs are.
**      MaxNoFaces    - Max faces in a cylinder -> 2* no of trian.
**      MinNoFaces    - Min faces in a cylinder
**      FinNoFaces    - Final no faces.
*/


/* The cylinder structure
 * The following rules must be adhered to if blast is to correctly re-create
 * them.
 * 1) there are 2 different types of cylinders, flat (disks and ring) and 
 *    non-flat (cones and tubes).
 * 2) flat cylinders must have a length of 0.0, the larger ring must be 
 *    stored in slot 0 and inner ring or centre in slot 1. PlnNorm and 
 *    CenLine must be the same and point in the direction it is facing.
 *    Flipping the centLine direction and facing bit in flags (bit 1) 
 *    can be used to change its orientation
 * 3) Non-flat tubes have a non-zero length, the CentLine is the direct
 *    needed to go for the centre point of ring in slot 0 to the centre
 *    of ring in slot 1. Bit 1 of flags indicates where the cylinder is
 *    in or outwardly facing, set if in.
 * 4) flat disk cylinders are automatically converted to cylinder ends if 
 *    an apropriate cylinder is found.
 * 5) Bit 2 of flags gives the orientation of the cylinder in the pipe, if
 *    set then it is facing the other way.
 * 6) Bit 3-5 of flags indicates the part got of a cylinder
 * 7) the plane normals must point outwards of a tube if inwardly facing,
 *    or inwardly if inwardly facing. With a ring, the large radius ring must
 *    point in the direction the ring faces and it will join that way, the 
 *    smaller must point the oposite way.
 */    
#define dptBLAST_FACE   0x0001
#define dptBLAST_DIR    0x0002
#define dptBLAST_BODY   0x0004
#define dptBLAST_END1   0x0008
#define dptBLAST_END2   0x0010
#define dptBLAST_DISK   0x0020
#define dptBLAST_CONE   0x0040
#define dptBLAST_RING   0x0080
#define dptBLAST_TUBE   0x0100

typedef struct dptCYLINDER_str
{
    int32      noFaces ;
    int32      flags ;
    float64    Length ;
    dmdVector  CentLine ;
        
    float64    Radius[2] ;
    dmdVector  Centre[2] ;
    dmdVector  PlnNorm[2] ;
    
    struct dptCYLINDER_str *next ;
    
} dptCYLINDER, *dptCYLINDER_ptr ;    


typedef struct dptCYLLIST_str
{
    int32      flags[2] ;
    int32      NoVert ;
    float64    maxRadius ;
    float64    minRadius ;
    float64    Radius[2] ;
    dmdVector  Centre[2] ;
    dmdVector  PlnNorm[2] ;
    dptCYLINDER_ptr EndCyl[2] ;
    
    struct dptCYLLIST_str *next ; 
} dptCYLLIST, *dptCYLLIST_ptr ;    


typedef struct
{
    dptMESHPTR  curMesh  ;
    dpfGEOGROUPPTR curGeogroup ;
    
    int32    BBlast ;
    float32  BMaxSideTol ;
    float32  BRatioTol ;
    float32  BEdgeTol ;
    float32  BNormTol ;

    int32    CBlast ;
    int32    CStats ;
    int32    CMinFcs ;
    int32    CMaxFcs ;
    int32    CNoRanges ;
    float32 *CMinRad ;
    float32 *CMaxRad ;
    int32   *CFinFcs ;

    /* to be filled */
    int32    KeepParts ;
    float32  CRatioTol ;
    float32  CNormTol ;
    float32  CCentDif ;
    float32  CRadDif ;
    float32  CTurnTol ;

    /* to be left alone */
    float32  TurnTol ;
    float32  cNorm0Tol ;
    float32  cNorm90Tol ;
    dptCYLLIST_ptr CList_hd, CList_tl ;
    dpfVERTEXPTR *TopVerts, *BotVerts ;

} dptBLAST, *dptBLASTPTR ;


int32
dptBlastGeogroup(dpfGEOGROUPPTR geogroup, int32 hash_size, dptBLASTPTR blast,
             int32 usePmesh, int32 *DropTri) ;


int32
dptTinyKillMesh(dptMESHPTR mesh, float32 Angl_Tol, float32 areaTol) ;
int32
dptTinyKillGeogroup(dpfGEOGROUPPTR geogroup, int32 hash_size,
                    float32 Angl_Tol, float32 areaTol, int32 usePmesh) ;


/*
** ptflip - module to flip the trangle direction face
*/
int32
dptFlipAllGeometry(dpfGEOMETRYPTR geom, int32 flipNormals) ;
int32
dptFlipAllGeogroup(dpfGEOGROUPPTR geogroup, int32 flipNormals) ;
int32
dptFlipAllObject(dpfOBJECTPTR object, int32 flipNormals) ;
int32
dptFlipAllFile(dpfFILEPTR file, int32 flipNormals) ;

int32
dptFlipRightMesh(dptMESHPTR mesh, int32 *flipCount) ;
int32
dptFlipRightGeogroup(dpfGEOGROUPPTR geogroup, int32 hash_size, int32 usePmesh, 
                  int32 *DropTri, int32 *flipCount) ;

/*
** hedgehog a given file
*/
int32
dptCreateVisualMaterials(dpfFILEPTR file) ;
int32
dptAddVertexNormalVisual(dpfFILEPTR file, char *matLib, float32 Pscale, 
                         float32 Bscale) ;
int32
dptAddBoundBoxVisual(dpfFILEPTR file, char *matLib) ;
int32
dptAddBoundSphereVisual(dpfFILEPTR file, char *matLib,
                        int32 udice, int32 vdice) ;
/* JK for dv/geomtool - adds files bsphere visual to individual lod */
int32
dptAddBoundSphereVisualLOD(dpfFILEPTR file, dpfLODPTR lod, char *matLib, 
                           int32 udice, int32 vdice);
int32
dptAddBoundPmeshVisual(dpfFILEPTR file, char *matLib) ;

int32
dptRmvVertexNormalVisual(dpfFILEPTR file) ;
int32
dptRmvBoundBoxVisual(dpfFILEPTR file) ;
int32
dptRmvBoundSphereVisual(dpfFILEPTR file) ;
int32
dptRmvBoundPmeshVisual(dpfFILEPTR file) ;
int32
dptRmvBoundOtherGeometry(dpfFILEPTR file) ;

int32
dptCookGeometry(dpfGEOMETRYPTR geom, dpfRGBA col) ;
int32
dptCookFile(dpfFILEPTR file, dpfRGBA col) ;

/* Boundary stuff */
int32
dptCalcMinBBox(dpfFILEPTR file, int32 res, dpfBOUNDPTR bound) ;
int32
dptCreateBoundary(dpfFILEPTR file, int32 minBBoxRes, int32 doHierarchy, 
                  int32 keepPmesh, int32 hashSize) ;

/* Tessellate a polygon, allowing for concavity.
 * 
 * The pmesh must already contain all the required vertices, noPnts is
 * a count of the number of points in the polygon (doesnt have to be the 
 * number of vertices), and vrtlst is an int array of size noPnts giving
 * the pmesh vert numbr for the nth point.
 * Assumes that the polygon is closed, so vrtlst[0] != vrtLst[noPnts-1] 
 * should be true.
 */
int32
dptPolyTessellate(dpfGEOMETRYPTR pmesh, int32 noPnts, int32 *vrtLst) ;


typedef void  (*dptVFSVARG)(char *, ...) ;
typedef void  (*dptVFUIUI)(uint32,uint32) ;
typedef int32 (*dptIFS)(char *) ;
typedef int32 (*dptIFII)(int32,int32) ;
typedef int32 (*dptIFV)(void) ;
typedef int32 (*dptIFVC)(dmVector) ;
typedef int32 (*dptIFVCVC)(dmVector,dmVector) ;
typedef int32 (*dptIFIVCF)(int32,dmVector,float32) ;
typedef int32 (*dptIFCCCC)(uint8,uint8,uint8,uint8) ;

/* Verbose routines */
#define dptVERBOSEPROG 0x01
#define dptVERBOSEQUIT 0x02
#define dptVERBOSEFLIP 0x04
extern int32      dptVerbose ;
extern dptVFSVARG dptVerbosePrint ;
extern dptVFSVARG dptVerbosePrintDynamic ;
extern dptVFUIUI  dptVerbosePrintPercent ;
extern dptIFS     dptVerboseQuit ;
extern dptIFII    dptVerboseFlip ;

extern int32     dptVerboseDynLen ;
void
__dptVerbosePrint(char *format, ...) ;
void
__dptVerbosePrintDynamic(char *format, ...) ;
void
__dptVerbosePrintPercent(uint32 Cur, uint32 Tot) ;
int32
__dptVerboseQuit(char *name) ;
int32
__dptVerboseFlip(int32 flip0, int32 flip1) ;

/* graphics routines */
/*
 * dptGrInitGraphics is called once at the start.
 * dptGrInitView can be called many times, with a call to dptGrEndView in
 * between. dptGrResetView can also be called many times within each view. i.e
 * 
 * dptGrInitGraphics
 *     dptGrInitView
 *         dptGrResetView
 *         dptGrResetView
 *             .
 *     dptGrEndView
 *     dptGrInitView
 *         dptGrResetView
 *         dptGrResetView
 *             .
 *     dptGrEndView
 *     dptGrInitView
 *         dptGrResetView
 *         dptGrResetView
 *             .
 *     dptGrEndView
 *         .
 *         .
 * dptGrEndGraphics
 * 
 * 2D graphics is the same except there is no need for dptGrInitView as 
 * view never changes.
 */

#ifdef _dptGR_CAPABLE
#define _dptGR2D_CAPABLE
#define _dptGR3D_CAPABLE
#endif

/* 3D Graphics */
#ifdef _dptGR3D_CAPABLE

#define dptGRAPHICPROG 0x01
#define dptGRAPHICZOOM 0x02

extern int32 dptGraphic ;
extern dptIFVCVC  dptGrStart3DView ;
extern dptIFV     dptGrEnd3DView ;
extern dptIFCCCC  dptGrReset3DView ;
extern dptIFCCCC  dptGrSet3DColour ;
extern dptIFV     dptGrStart3DOpenLine ;
extern dptIFV     dptGrEnd3DOpenLine ;
extern dptIFV     dptGrStart3DClosedLine ;
extern dptIFV     dptGrEnd3DClosedLine ;
extern dptIFV     dptGrStart3DPolygon ;
extern dptIFV     dptGrEnd3DPolygon ;
extern dptIFV     dptGrStart3DPoint ;
extern dptIFV     dptGrEnd3DPoint ;
extern dptIFVC    dptGrAdd3DPoint ;
extern dptIFIVCF  dptGrDraw3DSphere ;

/* Initial Graphics initialisation.
 * Creates a window and configures it for the renderer
 */
int32
dptGrStart3DGraphics(char *name, int32 xsize, int32 ysize, int32 resizable,
                     dpfRGBA bgColour) ;
int32
dptGrEnd3DGraphics(void) ;

/* Function to calculate the new from to viewing position, set up the renderer
 * with this new view and clear the screen and zbuffer. 
 * Can be called many times, with a call to dptGrEndView in between.
 * dptGrResetView can also be called many times within each view.
 * 
 */
int32
__dptGrStart3DView(dmVector boxMin, dmVector boxDif) ;

/* ends the current view, called after the current veiw is finished and
 * before the next is initialised.
 */
int32
__dptGrEnd3DView(void) ;

/* Clear the screen and the z-buffer ready for redrawing */
int32
__dptGrReset3DView(uint8 r,uint8 g,uint8 b,uint8 a) ;

/* Sets the current drawing colour */
int32
__dptGrSet3DColour(uint8 r,uint8 g,uint8 b,uint8 a) ;

int32
__dptGrStart3DOpenLine(void) ;
int32
__dptGrEnd3DOpenLine(void) ;

int32
__dptGrStart3DClosedLine(void) ;
int32
__dptGrEnd3DClosedLine(void) ;

int32
__dptGrStart3DPolygon(void) ;
int32
__dptGrEnd3DPolygon(void) ;

int32
__dptGrStart3DPoint(void) ;
int32
__dptGrEnd3DPoint(void) ;

int32
__dptGrAdd3DPoint(dmVector point) ;

int32
__dptGrDraw3DSphere(int32 wire, dmVector point, float32 rad) ;
#endif /* _dptGR3D_CAPABLE */

/* 2D Graphics */
#ifdef _dptGR2D_CAPABLE
/* Initial Graphics initialisation.
 * Creates a window and configures it for the renderer
 */
int32
dptGrStart2DGraphics(char *name, int32 xsize, int32 ysize, int32 Zoom) ;
int32
dptGrEnd2DGraphics(void) ;
int32
dptGr2DWait(void (*refreshfunc)(void)) ;

/* Clear the screen to the given colour */
int32
dptGrReset2DView(uint8 r, uint8 g, uint8 b) ;

/* Plotting pixel routines, used for vtxpaste */
int32
dptGrDraw2DImage(int32 xpos, int32 ypos, int32 xsize, int32 ysize,
                 VTXIRGBA *quads) ;

#endif /* _dptGR2D_CAPABLE */

void
dptVersion(FILE *fp) ;

#ifdef __cplusplus
}
#endif

#endif /* __PTOOL_H__ */
