/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1995 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: gui.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 2 Semptember 1994
--  Author       : Tony Coombes
--
--  Description	 : General GUI stuff
--
--  Modified     : 
--    $Log: gui.h,v $
--    Revision 1.1  2005/09/13 15:08:20  pukitepa
--    init
--
--    Revision 1.28  1998/08/12 11:14:16  simon
--    fixed varous bugs, removed colour overrides in fallback resources.
--
--    Revision 1.27  1998/08/05 15:34:24  wman
--    Removed old navigation dlg references and files.
--
--    Revision 1.26  1998/07/07 13:20:55  wman
--    Fixes for UNIX version of the second tool bar.
--
--    Revision 1.25  1998/07/03 13:53:51  wman
--    Fixes for second toolbar on Unix
--
--    Revision 1.24  1998/07/02 16:10:37  wman
--    Changes for second edit toolbar and functions.
--
--    Revision 1.23  1998/06/25 10:39:24  wman
--    Unix changes for Mark Greening's markup annotation code.
--
--    Revision 1.22  1998/06/23 11:08:04  wman
--    Added second toolbar with selection options.
--
--    Revision 1.21  1998/06/12 08:53:23  simon
--    changes for filter tool
--
--    Revision 1.20  1998/04/01 14:16:22  simon
--    added progress dlg
--
--    Revision 1.19  1998/03/30 15:28:24  simon
--    Added the dist create dlg
--
--    Revision 1.18  1998/03/19 18:49:45  simon
--    Added icons for distance tool
--
--    Revision 1.17  1998/03/19 16:20:46  simon
--    added the new distance tool
--
--    Revision 1.16  1998/03/13 14:28:59  tony
--    Support to allow users to configure the units
--    used to display distance measurements
--
--    Revision 1.15  1998/01/28 15:40:42  simon
--    fixed various bugs
--
--    Revision 1.14  1997/11/12 17:11:41  dvs-dev
--    Changes to get sectioning gui to work on NT.
--
--    Revision 1.13  1997/11/07 14:58:07  tony
--    Prevent Assembly and Library Viewers from being instanced more than once.
--    Removed all reference to the old Library Editor.
--
--    Revision 1.12  1997/10/22 15:42:01  tony
--    Removed options for spherical collision detection and made Advanced
--    Collision Property Dialog modal.
--
--    Revision 1.11  1997/10/07 09:49:02  simon
--    Lots of bug fixes, and added the new selection, new question and plugin
--    about dlgs
--
--    Revision 1.10  1997/09/18 15:34:00  dvs-dev
--    Generic dialog box font type and generic dialog box size fixed.
--
--    Revision 1.9  1997/08/26 11:47:43  simon
--    Mainly changes to library viewer, and additional reset parts stuff
--
--    Revision 1.8  1997/08/22 19:15:41  tony
--    Introduced the concept of Loaded and Enabled Cameras and Flight Paths
--
--    Revision 1.7  1997/08/14 10:39:02  dvs-dev
--    NT Changes for User Data Dlg.
--
--    Revision 1.6  1997/07/29 16:35:19  tony
--    Addition of "Error", "Locked" and "Changed" Pixmaps
--    to indicate the state of Property Fields.
--
--    Revision 1.5  1997/07/18 16:55:40  tony
--    Addition of Attach and Detach Pixmaps
--
--    Revision 1.4  1997/07/16 17:22:56  tony
--    Addition of Flight Path Pixmap
--
--    Revision 1.3  1997/07/15 15:00:39  dvs-dev
--    Assembly view toolbar implemented dynamically.
--    Also, Modified the way in which the animation toolbar works
--
--    Revision 1.2  1997/07/10 11:31:20  tony
--    Addition of Fast Forward, Rewind and insensative Animation control Pixmaps
--
--    Revision 1.1  1997/07/09 12:30:38  simon
--    *** empty log message ***
--
--    Revision 1.47  1997/07/08 09:13:41  tony
--    Addition of GUIBtn_SetPixmaps(), GUIToggleBtn_SetPixmaps()
--    and new Pixmaps
--
--    Revision 1.46  1997/07/02 13:09:19  dvs-dev
--    Changes for NT build.
--    Modified header files for windows __declspec definitions
--    Added some NON working code for keyboard accelerators.
--
--    Revision 1.45  1997/06/12 14:31:43  dvs-dev
--    Latest NT stuff.  Fixed up animation dlg.
--    Changes to way in which property dlgs work on NT.
--
--    Revision 1.44  1997/05/13 16:57:35  dvs-dev
--    MFC Development
--
--    Revision 1.43  1997/05/13 10:16:57  wman
--    Change for NT
--
--    Revision 1.42  1997/05/07 15:37:58  wman
--    Added libmfc for windows build
--
--    Revision 1.41  1997/03/10 17:56:54  tony
--    *** empty log message ***
--
--    Revision 1.40  1997/03/07 18:55:03  wman
--    Bug fixes
--
--    Revision 1.39  1997/02/22 17:34:05  wman
--    Implemented new exponential scale on navigator distance.
--    Message window pops up automatically on first message.
--    General Bug Fixes
--
--    Revision 1.38  1997/02/19 19:13:01  wman
--    Bug Fixes, and Right Mouse Button popup menu implementation
--
--    Revision 1.37  1997/02/16 17:19:49  tony
--    Cjor VS:
--
--    Revision 1.36  1997/02/13 17:03:45  wman
--    Added colour to frame manager
--
--    Revision 1.35  1997/02/07 12:00:14  wman
--    Bug fixes for animation dlg.
--
--    Revision 1.34  1997/02/07 11:01:45  tony
--    *** empty log message ***
--
--    Revision 1.33  1997/02/04 20:47:28  tony
--    *** empty log message ***
--
--    Revision 1.32  1997/01/24 20:54:23  tony
--    *** empty log message ***
--
--    Revision 1.31  1997/01/22 17:53:00  tony
--    *** empty log message ***
--
--    Revision 1.30  1997/01/21 21:35:36  tony
--    *** empty log message ***
--
--    Revision 1.29  1997/01/15 18:19:38  tony
--    *** empty log message ***
--
--    Revision 1.28  1997/01/09 15:57:00  tony
--    *** empty log message ***
--
--    Revision 1.27  1997/01/03 14:00:56  wman
--    Added bitmaps to the animation dialog.  Fixed some minor bugs in the animation
--    dialog.
--
--    Revision 1.26  1996/12/11 16:47:38  tony
--    *** empty log message ***
--
--    Revision 1.25  1996/12/06 18:09:24  wman
--    Key Frame additions - feedback from dVISE on selection on frames.
--    Bugs in external multiple selection and update fixed.
--
--    Revision 1.24  1996/11/29 21:35:45  tony
--    *** empty log message ***
--
--    Revision 1.23  1996/11/27 20:45:14  tony
--    Added Attributes to the Assembly view
--
--    Revision 1.22  1996/11/22 16:29:18  wman
--    Updates to annimation dlg.
--
--    Revision 1.21  1996/11/21 11:51:33  wman
--    New postit icons
--
--    Revision 1.20  1996/11/19 18:52:06  wman
--    Animation grid widget installed
--
--    Revision 1.19  1996/11/18 17:47:27  tony
--    *** empty log message ***
--
--    Revision 1.18  1996/11/07 00:56:39  tony
--    *** empty log message ***
--
--    Revision 1.17  1996/11/05 08:37:17  tony
--    *** empty log message ***
--
--    Revision 1.16  1996/11/02 11:59:32  tony
--    *** empty log message ***
--
--    Revision 1.15  1996/10/29 17:44:59  tony
--    *** empty log message ***
--
--    Revision 1.14  1996/10/28 18:16:43  tony
--    *** empty log message ***
--
--    Revision 1.13  1996/10/25 16:55:13  tony
--    *** empty log message ***
--
--    Revision 1.12  1996/10/23 18:09:19  wman
--    New Navigator prototype
--
--    Revision 1.11  1996/10/23 16:42:59  wman
--    UserRole Dialog stuff
--
--    Revision 1.10  1996/10/21 17:41:00  wman
--    Latest annotation stuff.
--
--    Revision 1.9  1996/10/21 08:59:43  tony
--    *** empty log message ***
--
--    Revision 1.8  1996/10/18 17:47:15  wman
--    New annotation stuff!
--
--    Revision 1.7  1996/10/17 17:01:01  tony
--    *** empty log message ***
--
--    Revision 1.6  1996/10/16 15:36:12  wman
--    UserRoleDialog stuff
--
--    Revision 1.5  1996/10/11 13:26:29  tony
--    *** empty log message ***
--
--    Revision 1.4  1996/09/23 11:15:11  tony
--    *** empty log message ***
--
--    Revision 1.3  1996/09/17 16:52:22  tony
--    *** empty log message ***
--
--    Revision 1.2  1996/09/10 15:39:42  tony
--    Changed "Object" to "Assembly"
--
--    Revision 1.1.1.1  1996/08/29 09:26:08  tony
--    first version of xdvise
--
--    Revision 3.2  1996/08/05 15:06:37  tony
--    Check in prior to starting development for IDP
--
--    Revision 3.1  1996/02/26 16:31:06  tony
--    Release 3.0
--
--    Revision 1.8  1995/10/31 15:26:19  tony
--    Bug TC53 - Collapsing trees is inefficient
--        Added GUItreeIsCollapsed()
--        Removed GUImapWidget() & GUIunmapWidget()
--
--    Revision 1.7  1995/10/24 18:10:10  tony
--    Added GUImapWidget() & GUIunmapWidget()
--
--    Revision 1.6  1995/10/23 12:09:57  tony
--    TC19 - Made code for using Action Argument browsers generic.
--           GUIcmdPopupEventSelectDlg() became GUIcmdActionDlgPopupBrowser()
--
--    Revision 1.5  1995/10/20 08:34:35  tony
--    TC79 New fn GUIcmdNodeListDlgZoneBrowseSelection()
--
--    Revision 1.4  1995/10/09 10:21:30  tony
--    Bug TC22 - New function GUIassemblyVisible()
--
--    Revision 1.3  1995/10/06 17:21:53  tony
--    Product release 18/08/95
--
--
-- ----------------------------------------------------------------------------
*/

#ifndef __GUI_H__
#define __GUI_H__

#ifndef _WIN32
#include <X11/Intrinsic.h>
#else
#include "intrinsic.h"
#endif /* WIN32 */

#define String VLString
#define Environment VLEnvironment
#include <dvs/vc.h>
#include <dvise/ectools.h>
#undef Environment
#undef String

#include "wkeys.h"
#include "xddlg.h" /* for dialogInstanceData type */

#ifdef __cplusplus
extern "C" {
#endif

#ifndef XDV_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `XDV_EXPORT'
 */
#ifdef  _LIB_XDV
#define XDV_EXPORT __declspec(dllexport) extern
#else
#define XDV_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define XDV_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ifndef XDV_EXPORT */

typedef enum {
    XDPM_UNSPECIFIED,
    XDPM_ASSY_ENABLED_LOADED,
    XDPM_ASSY_DISABLED_LOADED,
    XDPM_ASSY_ENABLED_UNLOADED,
    XDPM_ASSY_DISABLED_UNLOADED,
    XDPM_CAMERA_ENABLED_LOADED,    /* Camera */
    XDPM_CAMERA_DISABLED_LOADED,
    XDPM_CAMERA_ENABLED_UNLOADED,
    XDPM_CAMERA_DISABLED_UNLOADED,
    XDPM_SECTION_ENABLED_LOADED,    /* Section */
    XDPM_SECTION_DISABLED_LOADED,
    XDPM_SECTION_ENABLED_UNLOADED,
    XDPM_SECTION_DISABLED_UNLOADED,
    XDPM_FOLDER,
    XDPM_FILM, 
    XDPM_NOTE, 
    XDPM_UNLOADED_NOTE, 
    XDPM_CLOSED_NOTE,
    XDPM_CLOSED_UNLOADED_NOTE,
    XDPM_HYPERSPACE, 
    XDPM_PAUSE,
    XDPM_STOP,
    XDPM_PLAY,
    XDPM_RECORD,
                         /* Animation Controls */
    XDPM_FIRSTANIM,        /* ||< First        */
    XDPM_LASTANIM,         /* >|| Last         */
    XDPM_STPFWDANIM,       /* >|  Step Forward */
    XDPM_STPBAKANIM,       /* |<  Step Back    */
    XDPM_FFANIM,           /* >>  Fast Forward */
    XDPM_REWANIM,          /* <<  Rewind       */
    XDPM_STOPANIM,         /*     Stop         */
    XDPM_PAUSEANIM,        /* ||  Pause        */
    XDPM_PLAYANIM,         /* >   Play         */
    XDPM_RECANIM,          /* O   Record       */
    XDPM_ATCHANIM,         /* V   Attach       */
    XDPM_DTCHANIM,         /* ^   Detach       */
                   /* Armed Animation Controls */
    XDPM_ARM_ANIM_FIRST,   /* ||< First        */
    XDPM_ARM_ANIM_LAST,    /* >|| Last         */
    XDPM_ARM_ANIM_STPFWD,  /* >|  Step Forward */
    XDPM_ARM_ANIM_STPBAK,  /* |<  Step Back    */
    XDPM_ARM_ANIM_FF,      /* >>  Fast Forward */
    XDPM_ARM_ANIM_REW,     /* <<  Rewind       */
    XDPM_ARM_ANIM_STOP,    /*     Stop         */
    XDPM_ARM_ANIM_PAUSE,   /* ||  Pause        */
    XDPM_ARM_ANIM_PLAY,    /* >   Play         */
    XDPM_ARM_ANIM_REC,     /* O   Record       */
    XDPM_ARM_ANIM_ATCH,    /* V   Attach       */
    XDPM_ARM_ANIM_DTCH,    /* ^   Detach       */
             /* Insensitive Animation Controls */
    XDPM_INS_ANIM_FIRST,   /* ||< First        */
    XDPM_INS_ANIM_LAST,    /* >|| Last         */
    XDPM_INS_ANIM_STPFWD,  /* >|  Step Forward */
    XDPM_INS_ANIM_STPBAK,  /* |<  Step Back    */
    XDPM_INS_ANIM_FF,      /* >>  Fast Forward */
    XDPM_INS_ANIM_REW,     /* <<  Rewind       */
    XDPM_INS_ANIM_STOP,    /*     Stop         */
    XDPM_INS_ANIM_PAUSE,   /* ||  Pause        */
    XDPM_INS_ANIM_PLAY,    /* >   Play         */
    XDPM_INS_ANIM_REC,     /* O   Record       */
    XDPM_INS_ANIM_ATCH,    /* V   Attach       */
    XDPM_INS_ANIM_DTCH,    /* ^   Detach       */
    XDPM_ANIMATION, 
    XDPM_ANIMATION_LKD, 
    XDPM_ANIMATION16, 
    XDPM_AUDIO, 
    XDPM_AUDIO_LKD, 
    XDPM_AUDIO16, 
    XDPM_BASE, 
    XDPM_BASE_LKD, 
    XDPM_BASE16, 
    XDPM_BEHAVIOUR, 
    XDPM_BEHAVIOUR_LKD, 
    XDPM_BEHAVIOUR16, 
    XDPM_COLLISION, 
    XDPM_COLLISION_LKD, 
    XDPM_COLLISION16, 
    XDPM_CONSTRAINT, 
    XDPM_CONSTRAINT_LKD, 
    XDPM_CONSTRAINT16, 
    XDPM_LIGHT, 
    XDPM_LIGHT_LKD, 
    XDPM_LIGHT16, 
    XDPM_PHYSICS, 
    XDPM_PHYSICS_LKD, 
    XDPM_PHYSICS16, 
    XDPM_VISUAL, 
    XDPM_VISUAL_LKD, 
    XDPM_VISUAL16, 
    XDPM_USERDATA, 
    XDPM_USERDATA_LKD, 
    XDPM_USERDATA16, 
    XDPM_LIB, 
    XDPM_LIBEXT, 
    XDPM_MATLIB, 
    XDPM_MATERIAL, 
    XDPM_TEXTURE, 
    XDPM_LOCKED,     /* Licence locked */
    XDPM_LOGO,       /* dVISE Logo */
    XDPM_FLY_TO,     /* Fly To */
    XDPM_LANDMARK,   /* Landmark */
    XDPM_FLTP_ENABLED_LOADED,    /* Flight Path */
    XDPM_FLTP_DISABLED_LOADED,
    XDPM_FLTP_ENABLED_UNLOADED,
    XDPM_FLTP_DISABLED_UNLOADED,
    XDPM_FIELD_ERROR,   /* Property field status - Error   */
    XDPM_FIELD_LOCKED,  /* Property field status - Locked  */
    XDPM_FIELD_CHANGED, /* Property field status - Changed */
    XDPM_SMALLMARKER_UP,
    XDPM_SMALLMARKER_DWN,
    XDPM_SMALLMARKER_DIS,
    XDPM_MEDIUMMARKER_UP,
    XDPM_MEDIUMMARKER_DWN,
    XDPM_MEDIUMMARKER_DIS,
    XDPM_LARGEMARKER_UP,
    XDPM_LARGEMARKER_DWN,
    XDPM_LARGEMARKER_DIS,
    XDPM_VIEWMARKER_UP,
    XDPM_VIEWMARKER_DWN,
    XDPM_VIEWMARKER_DIS,
    XDPM_ADDMARKER_UP,
    XDPM_ADDMARKER_DWN,
    XDPM_ADDMARKER_DIS,
    XDPM_EDITMARKER_UP,
    XDPM_EDITMARKER_DWN,
    XDPM_EDITMARKER_DIS,   
    XDPM_SINGLELINE,   
    XDPM_SINGLELINE_UNLOADED,   
    XDPM_MULTILINE,   
    XDPM_MULTILINE_UNLOADED,   
    XDPM_CIRCLE,   
    XDPM_CIRCLE_UNLOADED,   
    XDPM_SINGLE_SELECT, 
    XDPM_MULTIPLE_SELECT, 
    XDPM_SUBTREE_SELECT, 
    XDPM_SINGLE_SELECT_SEL, 
    XDPM_MULTIPLE_SELECT_SEL, 
    XDPM_SUBTREE_SELECT_SEL, 
    XDPM_LOAD, 
    XDPM_LOAD_ONLY, 
    XDPM_UNLOAD, 
    XDPM_TOGGLE_VISIBILITY, 
    XDPM_TOGGLE_HIGHLIGHT, 
    XDPM_TOGGLE_ENABLE_PICKING, 
    XDPM_FLYTO, 
    XDPM_FLYTO_ALL, 
    XDPM_SEPARATOR, 
    XDPM_LOAD_SEL_DIS, 
    XDPM_LOAD_SEL_DWN, 
    XDPM_LOAD_ONLY_DIS, 
    XDPM_LOAD_ONLY_DWN, 
    XDPM_UNLOAD_DIS, 
    XDPM_UNLOAD_DWN, 
    XDPM_TOGGLE_VISIBILITY_DIS, 
    XDPM_TOGGLE_VISIBILITY_DWN, 
    XDPM_TOGGLE_HIGHLIGHT_DWN, 
    XDPM_TOGGLE_ENABLE_PICKING_DWN, 
    XDPM_FLYTO_DIS, 
    XDPM_FLYTO_DWN, 
    XDPM_FLYTO_ALL_DWN,
    XDPM_UP, /* behaviour dlg up button */
    XDPM_DOWN, /* behaviour dlg down button */
    XDPM_UP_DIS, /* behaviour dlg up button */
    XDPM_DOWN_DIS, /* behaviour dlg down disabled button */
    /* DON'T change the last entry! */
    XDPM_NUM_PIXMAPS 
} pixmapEnum;

/* Prototypes */
XDV_EXPORT void GUIincVal(wKeys valueWidgetKey,
               XtPointer    callData, 
	       float  minVal, 
	       float  maxVal, 
	       float  largeInc, 
	       float  smallInc, 
	       int    loop);
/* Replacement for GUIincVal (uses widget directly) */
XDV_EXPORT void GUIincValue(Widget widget,
               XtPointer callData,
	       float minVal, 
	       float maxVal,  
	       float smallInc, 
	       float largeInc, 
	       int   loop);
XDV_EXPORT void GUIincInt(Widget widget,
               XtPointer callData,
	       int32 minVal, 
	       int32 maxVal,  
	       int32 smallInc, 
	       int32 largeInc, 
	       int   loop);

XDV_EXPORT void PopupDeadKidDlg(void);
XDV_EXPORT void GUIpopupInterface(compT dlg);
XDV_EXPORT void GUIpopdownInterface(compT dlg);
XDV_EXPORT void GUIlistDeleteAllItems(wKeys widgKey);
XDV_EXPORT void GUInewListDeleteAllItems(compT comp);
XDV_EXPORT void GUInewListOverwriteItem(compT listWidget, int itemIndex, char *str);
XDV_EXPORT void GUIlistAddItem(wKeys widgKey, char *str);
XDV_EXPORT void GUInewListAddItem(compT comp, char *str);
XDV_EXPORT void GUIlistAddSelectedItem(wKeys widgKey, char *str);
XDV_EXPORT void GUInewListAddSelectedItem(compT comp, char *str);
XDV_EXPORT void GUInewListSelectItem(compT comp, int selectedItem, int notify);
XDV_EXPORT void GUInewListSelectItemAsNT(compT comp, int selectedItem, int notify);
XDV_EXPORT char *GUIlistGetSelected(wKeys widgKey);
XDV_EXPORT char **GUIlist_MakeSelectedList(void *list, int *numItems, int multipleSelect);
XDV_EXPORT char **GUIlist_MakeList(void *list, int *numItems);
XDV_EXPORT int  GUInewListGetSize(void *list);
XDV_EXPORT void GUInewListRemoveSelected(void *list, int multipleSelect);
XDV_EXPORT int GUInewListGetSelectedItemsPosition(compT listWidget, int **selectedList);


XDV_EXPORT void GUInewBarSetValue(compT comp, int val);
XDV_EXPORT void GUInewBarSetRange(compT comp, int lower, int upper);
XDV_EXPORT void GUIoptMenuAddBtn(wKeys widgKey, char *str, XtCallbackProc callback);
XDV_EXPORT void GUIdlgTitle(compT comp, char *str);
XDV_EXPORT void GUIMsgDlg_SetSymbol(compT comp, pixmapEnum pixmap);
XDV_EXPORT void GUIdlgShellTitle(compT component, char *str);
XDV_EXPORT void GUIsetLabel(wKeys widgID, char *str);
XDV_EXPORT void GUInewSetLabel(compT comp, char *str);
XDV_EXPORT void GUIsetSelectionLabel(compT comp, char *str);
XDV_EXPORT void GUIsetSelectionText(compT comp, char *str);
XDV_EXPORT void GUIsetText(wKeys widgID, char *str);
XDV_EXPORT void GUInewSetText(compT comp, char *str);
XDV_EXPORT void GUIsetTextWithFloat(wKeys widgID, float *num);
XDV_EXPORT float GUIgetFloat(compT comp);
XDV_EXPORT void GUInewSetTextWithFloat(compT comp, float *num);
XDV_EXPORT void GUIsetTextAsPercentage(wKeys widgID, float *num);
XDV_EXPORT void GUIsetTextWithInt(wKeys widgKey, int num);
XDV_EXPORT void GUInewSetTextWithInt(compT comp, int num);
XDV_EXPORT int  GUIgetInt(compT comp);
XDV_EXPORT char *GUIgetText(wKeys widgID);
XDV_EXPORT char *GUInewGetText(compT comp);
XDV_EXPORT void GUIgetPromptText(compT dlg, char **str);
XDV_EXPORT void GUIsetMessage(compT dlg, char *str);
XDV_EXPORT void GUIsetScale(compT comp, float val);
XDV_EXPORT void GUIsetRotationScale(compT comp, unsigned short val);
XDV_EXPORT void GUIsetListSelection(compT comp, int multiple);
XDV_EXPORT void GUIinitColDlg(compT comp, unsigned long *colCell);
XDV_EXPORT void GUIinitAfterCreation(void);
XDV_EXPORT void GUIsetCol(unsigned long colCell, float r, float g, float b);
XDV_EXPORT void GUIsetCheckBtn(wKeys widgID, int visible);
XDV_EXPORT void GUInewSetCheckBtn(compT comp, int visible);
XDV_EXPORT void GUItoggleNodeState(Widget button);
XDV_EXPORT void GUIcmdXdviseMsgPopup(Widget w, XtPointer clientData, 
                                 XtPointer callData);
XDV_EXPORT void GUIdestroyComponent(compT comp);
XDV_EXPORT void GUIoptionMenuSet(wKeys menuWidgKey, wKeys btnWidgKey);
XDV_EXPORT void GUInewOptionMenuSet(compT menuComp, compT btnComp);
XDV_EXPORT wKeys GUIoptionMenuQry(wKeys menuWidgKey);
XDV_EXPORT compT GUInewOptionMenuQry(compT menuComp);
XDV_EXPORT void GUIpbSetLabel(Widget w, char *str);
XDV_EXPORT void GUImanageWidget(wKeys widgID);
XDV_EXPORT void GUInewManageWidget(compT widgID);
XDV_EXPORT void GUIunmanageWidget(wKeys widgID);
XDV_EXPORT void GUInewUnmanageWidget(compT widgID);
XDV_EXPORT void GUIMapWidget(compT comp);
XDV_EXPORT void GUIUnmapWidget(compT comp);
XDV_EXPORT void GUIwidgetSetSensitive(wKeys widgKey, int sensitive);
XDV_EXPORT void GUInewWidgetSetSensitive(compT comp, int sensitive);
XDV_EXPORT void GUItoolbarWidgetSetSensitive(compT comp, int sensitive);
XDV_EXPORT void GUIWidget_SetLicensedState(compT comp, int licensed);
XDV_EXPORT int  GUItreeIsCollapsed(compT comp);
XDV_EXPORT char *GUIfileSelectionGetPath(compT comp);

#ifndef _WIN32
XDV_EXPORT void  GUIfileSelectionSetFilter(compT comp, char *path, char *ext);
#else
XDV_EXPORT void GUIfileSelectionSetFilter(compT comp, char* path, char* ext, int index);
#endif

XDV_EXPORT void GUInewSetHeight(compT comp, int height);
XDV_EXPORT void GUIRegisterWMProtocols(compT comp, dialogInstanceData *inst);
XDV_EXPORT void GUIRaiseDlg(compT comp);

/****************************
 * Base(Prop) Diaolg Position(x,y,z)
 */
XDV_EXPORT void GUIcmdBaseDlgIncPositionX(Widget w, XtPointer clientData, XtPointer callData);
XDV_EXPORT void GUIcmdBaseDlgDecPositionX(Widget w, XtPointer clientData, XtPointer callData);
XDV_EXPORT void GUIcmdBaseDlgIncPositionY(Widget w, XtPointer clientData, XtPointer callData);
XDV_EXPORT void GUIcmdBaseDlgDecPositionY(Widget w, XtPointer clientData, XtPointer callData);
XDV_EXPORT void GUIcmdBaseDlgIncPositionZ(Widget w, XtPointer clientData, XtPointer callData);
XDV_EXPORT void GUIcmdBaseDlgDecPositionZ(Widget w, XtPointer clientData, XtPointer callData);

/****************************
 * Base Diaolg Orientation(x,y,z)
 */
XDV_EXPORT void GUIcmdBaseDlgIncOrientationX(Widget w, XtPointer clientData, XtPointer callData);
XDV_EXPORT void GUIcmdBaseDlgDecOrientationX(Widget w, XtPointer clientData, XtPointer callData);
XDV_EXPORT void GUIcmdBaseDlgIncOrientationY(Widget w, XtPointer clientData, XtPointer callData);
XDV_EXPORT void GUIcmdBaseDlgDecOrientationY(Widget w, XtPointer clientData, XtPointer callData);
XDV_EXPORT void GUIcmdBaseDlgIncOrientationZ(Widget w, XtPointer clientData, XtPointer callData);
XDV_EXPORT void GUIcmdBaseDlgDecOrientationZ(Widget w, XtPointer clientData, XtPointer callData);

/****************************
 * Base Diaolg Scale(x,y,z)
 */
XDV_EXPORT void GUIcmdBaseDlgIncScaleX(Widget w, XtPointer clientData, XtPointer callData);
XDV_EXPORT void GUIcmdBaseDlgDecScaleX(Widget w, XtPointer clientData, XtPointer callData);
XDV_EXPORT void GUIcmdBaseDlgIncScaleY(Widget w, XtPointer clientData, XtPointer callData);
XDV_EXPORT void GUIcmdBaseDlgDecScaleY(Widget w, XtPointer clientData, XtPointer callData);
XDV_EXPORT void GUIcmdBaseDlgIncScaleZ(Widget w, XtPointer clientData, XtPointer callData);
XDV_EXPORT void GUIcmdBaseDlgDecScaleZ(Widget w, XtPointer clientData, XtPointer callData);

/****************************
 * Audio Diaolg Volume
 */
XDV_EXPORT void GUIcmdAudioDlgIncVolume(Widget w, XtPointer clientData, XtPointer callData);
XDV_EXPORT void GUIcmdAudioDlgDecVolume(Widget w, XtPointer clientData, XtPointer callData);

/****************************
 * Audio Diaolg Priority
 */
XDV_EXPORT void GUIcmdAudioDlgIncPriority(Widget w, XtPointer clientData, XtPointer callData);
XDV_EXPORT void GUIcmdAudioDlgDecPriority(Widget w, XtPointer clientData, XtPointer callData);

/****************************
 * Audio Diaolg Looping
 */
XDV_EXPORT void GUIcmdAudioDlgIncLooping(Widget w, XtPointer clientData, XtPointer callData);
XDV_EXPORT void GUIcmdAudioDlgDecLooping(Widget w, XtPointer clientData, XtPointer callData);

/****************************
 * Other(Send) Event Dialog
 */
XDV_EXPORT void GUIcmdSendEventDlgBrowseSelection(Widget w, XtPointer clientData, XtPointer callData);

/****************************
 * EventList Dialog
 */
XDV_EXPORT void GUIcmdEventListDlgBrowseSelection(Widget w, XtPointer clientData, XtPointer callData);

/****************************
 * Event Dialog
 */
XDV_EXPORT void GUIcmdEventDlgEventBrowseSelection(Widget w, XtPointer clientData, XtPointer callData);
XDV_EXPORT void GUIcmdEventDlgActionBrowseSelection(Widget w, XtPointer clientData, XtPointer callData);

/****************************
 * Action List Dialog
 */
XDV_EXPORT void GUIcmdActionListDlgBrowseSelection(Widget w, XtPointer clientData, XtPointer callData);

/****************************
 * Action Dialog Argument Field functions
 */
XDV_EXPORT void GUIcreateActionArgField(compT comp, ECParameterType type, char *name, int arg);
XDV_EXPORT void GUIunmanageActionArgField(int arg);
XDV_EXPORT ECParameterType GUIgetActionArgType(int arg);

XDV_EXPORT ECParameter *GUIgetParams(ECActionFunc *actionFunc);
XDV_EXPORT void GUIsetParams(int paramNo, ECParameter *param);
XDV_EXPORT void GUIsetParamWithString(int paramNo, ECParameterType type, char *str);

/* Generic Increment/Decrement callback routine for dynamic value entry fields.
 * e.g. Value fields created for the Action dialog arguments.
 * Uses cliend data to indicate which widget to increment.
 */
XDV_EXPORT void GUIcmdIncArg(Widget w, 
                  XtPointer clientData, 
                  XtPointer callData);
XDV_EXPORT void GUIcmdDecArg(Widget w, 
                  XtPointer clientData, 
                  XtPointer callData);
XDV_EXPORT void GUIcmdIncIntArg(Widget w, 
                  XtPointer clientData, 
                  XtPointer callData);
XDV_EXPORT void GUIcmdDecIntArg(Widget w, 
                  XtPointer clientData, 
                  XtPointer callData);
XDV_EXPORT void GUIcmdActionDlgPopupBrowser(Widget w, XtPointer clientData, XtPointer callData);

XDV_EXPORT void GUIaddMapCallback(compT comp);

/****************************
 * Node List Dialog
 */
XDV_EXPORT void GUIcmdNodeListDlgZoneBrowseSelection(Widget w, XtPointer clientData, XtPointer callData);
XDV_EXPORT void GUIcmdNodeListDlgExtendedSelection(Widget w, XtPointer clientData, XtPointer callData);

/****************************
 * Item List Dialog
 */
XDV_EXPORT void GUIcmdItemListDlgBrowseSelection(Widget w, XtPointer clientData, XtPointer callData);

/*  Register a new file as an input source */
#ifdef _WIN32
XDV_EXPORT void GUIsetSocketNotifyWindow (void* hWnd);
XDV_EXPORT void GUIremoveInput(int srcFP);
#endif /* _WIN32 */
XDV_EXPORT void GUIaddInput(int srcFP);
XDV_EXPORT void GUIpipeReader(XtPointer client_data, int *fid);

XDV_EXPORT void GUIappContextSet(XtAppContext appC);
XDV_EXPORT XtAppContext GUIappContextGet(void);

/*
 * GUI manipulation
 */
XDV_EXPORT int  GUIisRealized(compT comp);
XDV_EXPORT void GUIrealizeWidget(compT comp);
XDV_EXPORT void GUIunrealizeWidget(compT comp);

XDV_EXPORT void GUIassemblyVisible(compT tree, compT assembly);

XDV_EXPORT void GUInewComboListSelect(compT comp, int index, int totalOptions);
XDV_EXPORT void GUInewComboListReset(compT comp);
XDV_EXPORT compT GUInewComboListAddOption(compT comp, char *option);
XDV_EXPORT int GUInewComboListGetSelection(compT comp);


XDV_EXPORT void GUITree_AddNode(compT treeComp, char *name, int row, int level, 
                            int leafNode, int expands, uint32 type, int loaded, 
			    int enabled);
XDV_EXPORT void GUITree_AddAttributeNode(compT treeComp, char *name, 
                                     int row, int level, uint32 type);
XDV_EXPORT void GUITree_Freeze(compT treeComp);
XDV_EXPORT void GUITree_Thaw(compT treeComp);
XDV_EXPORT void GUITree_Select(compT treeComp, int row, int selected);
XDV_EXPORT void GUITree_DeleteRows(compT treeComp, int row, int count);
XDV_EXPORT void GUITree_Clear(compT treeComp);
XDV_EXPORT void GUITree_ExposeRow(compT treeComp, int row);
XDV_EXPORT void GUITree_SetExpanded(compT treeComp, int row, int expands, int expanded);
XDV_EXPORT void GUITree_SetRepresentation(compT treeComp, int row, uint32 type, int loaded, int enabled);
XDV_EXPORT void GUITree_SetRowName(compT treeComp, int row, char *name);
XDV_EXPORT compT GUITree_Create(compT parent, void *clientData);
XDV_EXPORT int  GUITree_GetSelectedCount(compT treeComp);
XDV_EXPORT int  GUITree_GetSelected(compT treeComp, int *positions, int count);

XDV_EXPORT compT GUISeparator_Create(compT parent);
XDV_EXPORT void  GUIMenuBar_SetHelpBtn(compT menuBar, compT helpBtn);

/* Pixmap addition call */
XDV_EXPORT void GUIaddArmedPixmap(compT comp, pixmapEnum pixmapType);
XDV_EXPORT void GUIaddPixmap(compT comp, pixmapEnum pixmapType);
XDV_EXPORT void GUIBtn_SetPixmaps(compT comp, int pixmapID, int armPixmapID, 
		    int insensitivePixmapID);
XDV_EXPORT void GUIToggleBtn_SetPixmaps(compT comp, int pixmapID, 
		    int selectPixmapID, int insensitivePixmapID, 
		    int selectInsensitivePixmapID);

/* WMan - My bits for Grid Widget */
XDV_EXPORT void GUIGridAddNewTitle(compT comp, char *title);
XDV_EXPORT void GUIGridAddRow(compT comp, int rowNumber, char *rowData);
XDV_EXPORT void GUIGridAddColumn(compT comp);
XDV_EXPORT void GUIGridDeleteAllColumns(compT comp);
XDV_EXPORT int GUIGridGetSelectedRow(compT comp);
XDV_EXPORT void GUIGridSelectRow(compT comp, int row);
XDV_EXPORT void GUIGridDeselectRow(compT comp, int row);
XDV_EXPORT char *GUIGridGetRowColumnContent(compT comp, int row, int column);
XDV_EXPORT void GUIGridSetRowColumnContent(compT comp, int row, int column, char *content);
XDV_EXPORT char *GUIGridGetSelected(compT comp, int column);
XDV_EXPORT void GUIGridSetItem(compT comp, char *newItem, int row, int column);
XDV_EXPORT void GUIGridSetSelectedItem(compT comp, char *newItem);
XDV_EXPORT void GUIGridSetRowColumnColour(compT comp, int rowNumber, int column, char *colour);

/* WMan - My bits for userRole dialog */
XDV_EXPORT void GUIpopulateSelectionDlg(compT comp, char *list[]);
XDV_EXPORT void GUIaddCallbackSelectionDlg(compT comp, void (*proc)(compT, char *));

XDV_EXPORT compT GUIBtnWidget_Create(compT parent, char *label, int left, int right, int shadowSupport, void *clientData);
XDV_EXPORT compT GUIToggleMenuBtnWidget_Create(compT parent, char *label, char *mnemonic, void *clientData);
XDV_EXPORT compT GUIRadioMenuBtnWidget_Create(compT parent, char *label, char *mnemonic, void *clientData);
XDV_EXPORT int   GUIToggleBtn_GetState(compT comp);
XDV_EXPORT void  GUIToggleBtn_SetState(compT comp, int state);
XDV_EXPORT compT GUIMenuBtnWidget_Create(compT parent, char *label, char *mnemonic, 
                                     char *accelerator, char *acceleratorText, void *clientData);
XDV_EXPORT compT GUIToolBtnWidget_Create(compT parent, int pixmap, int armPixmap, 
                                      int insensitivePixmap, void *clientData);
XDV_EXPORT compT GUISeparatorToolBtnWidget_Create(compT parent, void *clientData);
XDV_EXPORT compT GUIToolToggleBtnWidget_Create(compT parent, int pixmap, int armPixmap, 
                                      int insensitivePixmap, void *clientData);
extern compT GUIToolBtnWidget_CreateDynamic(compT parent, char **pixmapStr, char **armPixmapStr, 
                                            char **insensitivePixmapStr, void *clientData);


#ifdef _WIN32
XDV_EXPORT void GUIupdateMenu(compT parent);
XDV_EXPORT void GUISetDlgType(compT parent, dialogType type);
XDV_EXPORT compT GUIToolBtnMenu_Create(compT parent, int type);
XDV_EXPORT void GUIScrolledWindowResizeFromChild(compT comp);
XDV_EXPORT void GUISetWaitCursor(int state);
XDV_EXPORT void GUIOptnFieldSetSensitive(compT comp, int sensitive);
XDV_EXPORT void GUIOptnFieldUnmanageWidget(compT comp);
XDV_EXPORT void GUIOptnFieldManageWidget(compT comp);
XDV_EXPORT void GUIPosVecFieldSetSensitive(compT comp, int sensitive);
XDV_EXPORT void GUIPosVecFieldUnmanageWidget(compT comp);
XDV_EXPORT void GUIPosVecFieldManageWidget(compT comp);
XDV_EXPORT void GUIFltValueFieldSetSensitive(compT comp, int sensitive);

XDV_EXPORT void GUITreeLoadCB(compT treeComp, void* clientData, void* callData, int load);
XDV_EXPORT void GUITreeEnableCB(compT treeComp, void* clientData, void* callData, int enable);

#endif

#ifdef __cplusplus
}
#endif

#endif /* __GUI_H__ */
