/****************************************************************************
 *
 *  			Copyright 1995 Division Limited.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: vdifile.h,v $
 *  Revision      : $Revision: 1.1 $
 *  Date          : $Date: 2005/09/13 15:07:46 $
 *  Author        : $Author: pukitepa $
 *  Last Modified : <191198.1300>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 ****************************************************************************
 *
 *  Copyright (c) 1995 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 *  This Document may not, in whole or in part, be copied,
 *  photocopied, reproduced, translated, or reduced to any
 *  electronic medium or machine readable form without prior
 *  written consent from Division Ltd.
 ****************************************************************************/

#ifndef __VDIFILE_H__

#define __VDIFILE_H__

#include <assert.h>
#include <dsys/pfile.h>

#ifdef __cplusplus
extern "C" {
#endif

/* vdifile error numbers */

void
dvfVersion(FILE *fp) ;

#define dvf_OBJECT_TYPE    0x01       /* if flag bit set then obj in zone   */
#define dvf_PARENT_TYPE    0x02       /* if flag bit set then obj is parent */
#define dvf_OBJECT_LIB     0x04       /* if flag bit set obj is a library   */
#define dvf_OBJ_FORCE_POSORSCALE 0x08 /* if flag bit set then force writing object pos, or, scale  */
#define dvf_OBJECT_CAMERA  0x10       /* if flag bit set then Assembly is a camera */
#define dvf_OBJECT_ANNOTATION 0x20    /* if flag bit set then Assembly is an annotation */ 
#define dvf_OBJECT_LOADED  0x40       /* if flag bit set then Assembly is loaded */

#define dvfFILE_DISLIGHT   0x01       /* if set then disable default lights */
#define dvfFILE_COLLIDE    0x02       /* if set then make object collidable */
#define dvfFILE_CONSTRAIN  0x04       /* if set make object constrained     */

#define dvf_TABSIZE     4

typedef enum { 
    dvfVERSION_1=0,
    dvfVERSION_2=1
} dvfVERSION ;

typedef enum { 
    dvfLIGHT_AMBIENT,
    dvfLIGHT_DIRECT,
    dvfLIGHT_POINT,
    dvfLIGHT_SPOT
} dvfLIGHTTYPE ;
typedef enum {
    dvfSTATE_ON=0,
    dvfSTATE_OFF
} dvfSTATE ;

typedef enum {
    dvfKEYMODE_ABSOLUTE=0,
    dvfKEYMODE_RELATIVE
} dvfKEYMODE ;

typedef enum {
    dvfPATHLINEAR=0,
    dvfPATHCATMULLROM
} dvfPATHINTERPOLATION ;

typedef enum {
    dvfRENDERMODE_POLYGONAL=0,
    dvfRENDERMODE_WIREFRAME
} dvfRENDERMODE ;


typedef struct dvfMFILETYPE
{
    char       *name ;
    dpfFILEPTR  file ;
    struct dvfMFILETYPE *next ;
} dvfMFILE, *dvfMFILEPTR ;

typedef struct
{
    float32      halfangle ;
    float32      exponent ;
}  dvfLIGHTCONE ;

typedef struct
{
    /* lighting stuff */
    dvfLIGHTTYPE lightType ;
    dvfSTATE     lightState ;
    dvfLIGHTCONE lightCone ; /* applies only to spotlights */
    dpfRGBA      colour ;
} dvfLIGHT, *dvfLIGHTPTR ;

typedef struct dvfEVENTTYPE
{
    int32  flags ;
    char  *name ;
    char  *command ;
    struct dvfEVENTTYPE *next ;
} dvfEVENT, *dvfEVENTPTR ;

/* These attributes are needed for conversion of ComputerVision
 * product structure (_ps) files */
typedef enum {
    dvfATTRIBUTE_ASSY ,
    dvfATTRIBUTE_PROPERTY    
} dvfATTRIBUTETYPE ;

typedef struct dvfATTRIBUTE
{
    dvfATTRIBUTETYPE type ;
    char * attribute ;
    char * attribute_name ;
    char * attribute_file ;
    struct dvfATTRIBUTE * next ;
} dvfATTRIBUTE, *dvfATTRIBUTEPTR ;

typedef struct
{
    char * field ;
    char * value ;
} dvfTEXTDATA ;

typedef struct
{
    char * field ;
    int32 value ;
} dvfINTEGERDATA ;

typedef struct
{
    char * field ;
    float32 value ;
} dvfFLOAT32DATA ;

/* Structures needed for dVISE UserData */

/* enum for dVISE UserData types.  This not a complete list -- just what's
 * needed to support ProE user data. */
typedef enum {
    dvfUSERBOOL,
    dvfUSERINTEGER,
    dvfUSERFLOAT,
    dvfUSERTEXT
} dvfUSERFIELDTYPE ;


typedef struct
{
    char             * name ;
    dvfUSERFIELDTYPE   type ;
    union {
        float32 f ;
        char  * s ;
        int     i ;
        int     b ;
    } value ;
    
} dvfUSERFIELD, * dvfUSERFIELDPTR ;

typedef struct dvfUSERDATA
{
    char                * name ;
    int32                 nFields ;
    dvfUSERFIELDPTR       fields ;
    struct dvfUSERDATA  * next ;

} dvfUSERDATA, * dvfUSERDATAPTR ;

#define dvfFRAME_POSIT 0x01
#define dvfFRAME_ORIEN 0x02
#define dvfFRAME_SCALE 0x04

typedef struct dvfFRAME
{
    float32  time ;
    int32    flags ;
    dmVector posit ;
    dmQuaternion orien ;
    dmVector scale ;
    struct dvfFRAME *next ;
} dvfFRAME, *dvfFRAMEPTR ;

typedef struct
{
    float32              totalTime ;
    int32                loop ;
    dvfKEYMODE           mode ;
    dvfSTATE             state ;           /* if ON then start running */
    dvfPATHINTERPOLATION interpolation ;
    dvfFRAMEPTR frame_hd, frame_tl ;
} dvfKEYFRAME, *dvfKEYFRAMEPTR ;

typedef struct dvfOBJECTTYPE
{
    /* Object name, library file name, template name and comment */
    char          *name ;
    char          *libName ;
    char          *tempName ;
    char          *comment ;
    
    /* New field for file defining object */
    char          *fileName ;
    
    /* position in the world relative to parent */
    dmPoint        point ;
    dmScale        scale ;
    dmEuler        orien ;
    
    /* visual info */
    char          *geomName ;
    dpfFILEPTR     geometry ;
    dvfSTATE       geomState ;           /* if ON then visible else invisble */
    dvfRENDERMODE  renderMode ;
    char          *geomFMat ;
    char          *geomBMat ;
    
    /* object is a key frame */
    dvfKEYFRAMEPTR keyFrame ;
              
    /* Light setting of the object */
    dvfLIGHTPTR    light ;
    
    /* Events for the object */
    dvfEVENTPTR    events ;
    
    /* Attributes for the object */
    dvfATTRIBUTEPTR attributes ;
    
    /* Pointer to dVISE User data for the object. Note that two objects may point
     * to the same piece of UserData. */
    dvfUSERDATAPTR dviseUserData ;
    
    /* User data - do what you want with these. 
     * Guaranteed to be initialised to 0s and NULLs
     */
    int32          userFlags ;
    void          *userData ;
    int32          userFlags2 ;
    void          *userData2 ;
    
    /* internal flags */
    int32          flags ;
    struct dvfOBJECTTYPE *child_hd, *child_tl ;
    struct dvfOBJECTTYPE *next, *objParent ;
    struct dvfFILETYPE   *fileParent ;
} dvfOBJECT, *dvfOBJECTPTR ;


typedef struct dvfFILETYPE
{
    char  *fileName, *zoneName ;
    char  *basePath, *extPath ;
    FILE  *fp ;
    int32  useMid, type ;
    dpfRGBA bgColour ;
    int32  flags ;
    int32  tab ;
    
    /* dVISE user data attached to vdifile.
     * This is because assemblies within the vdifile can share userdata nodes. */
    dvfUSERDATAPTR dviseUserData_hd ;
    
    int32  userFlags ;
    void  *userData ;
    
    dvfOBJECTPTR defs_hd, defs_tl ;    
    dvfOBJECTPTR zone_hd, zone_tl ;
    dvfMFILEPTR  mfile_hd ;
    dvfVERSION   version ;
} dvfFILE, *dvfFILEPTR ;
    

/* Copies sname into dname, correcting any bad characters to '_'
 *
 * Note:- if the name starts with a non alpha character (inc numeric),
 *        it is illegal so a pre-pending 'A' is added. For this reason
 *        dname must be 1 character bigger than sname.
 * 
 *        dname can been sname! (if so ensure sname is 1 character bigger)
 */
void
dvfCorrectName(char *dname, char *sname) ;

/* File setup and saving ****************************************************/
dvfFILEPTR
dvfCreateFile(void) ;
int32
dvfSaveFile(dvfFILEPTR file) ;
int32
dvfFreeFile(dvfFILEPTR file) ;
typedef void (*dvfFREEUSERDATAFUNC)(void *) ;
extern dvfFREEUSERDATAFUNC dvfFreeObjectUserDataFunc ;
extern dvfFREEUSERDATAFUNC dvfFreeObjectUserData2Func ;
int32
dvfSetFileName(dvfFILEPTR file, char *name, char *rcpName) ;
int32
dvfSetZoneName(dvfFILEPTR file, char *name) ;

/* v is the version which can be dvfVERSION_1 or dvfVERSION_2
 * if type is non-zero then the file is a library and saved with the 
 * extension of .vdl
 */
#define dvfSetFileVersion(f,v)       ((f)->version = (v))
#define dvfSetFileLibraryType(f,t)   ((f)->type = (t))
#define dvfSetBackGroundColour(f,c)  (dpfRGBACpy((f)->bgColour,c))
#define dvfDisableDefaultLighting(f) ((f)->flags |= dvfFILE_DISLIGHT)
#define dvfEnableObjectCollide(f)    ((f)->flags |= dvfFILE_COLLIDE)
#define dvfEnableObjectConstrain(f)  ((f)->flags |= dvfFILE_CONSTRAIN)

int32
dvfSetFilePaths(dvfFILEPTR file, char *basePath, int32 useMid, char *extPath) ;
#define dvfGetFileZoneName(f)        ((f)->zoneName)
#define dvfGetFileFileName(f)        ((f)->fileName)

/* Material File calls ******************************************************/
dvfMFILEPTR
dvfCreateMaterialFile(void) ;
int32
dvfAddMaterialFile(dvfFILEPTR file, dvfMFILEPTR mfile) ;
int32
dvfSetMaterialFileName(dvfMFILEPTR mfile, char *name) ;
void 
dvfSaveMaterialFile(dvfMFILEPTR  mfile, dvfFILEPTR file ) ;

/* OBJECT Functions *********************************************************/


dvfOBJECTPTR
dvfCreateObject(void) ;
void
dvfUnlinkObject(dvfOBJECTPTR object) ;

/* adding object to the hierarchy */
int32
dvfAddDefinitionObject(dvfFILEPTR file, dvfOBJECTPTR object) ;
int32
dvfAddZoneObject(dvfFILEPTR file, dvfOBJECTPTR object) ;
int32
dvfAddObjectObject(dvfOBJECTPTR parent, dvfOBJECTPTR object) ;

/* setting object information */
int32
dvfSetObjectName(dvfOBJECTPTR object, char *name) ;
int32
dvfSetObjectComment(dvfOBJECTPTR object, char *comment) ;
int32
dvfSetObjectGeometryName(dvfOBJECTPTR object, char *name) ;
#define dvfSetObjectGeometryState(o,s) ((o)->geomState = s)
#define dvfSetObjectRenderMode(o,m)    ((o)->renderMode = m)
int32
dvfSetObjectGeometryFile(dvfOBJECTPTR object, dpfFILEPTR file) ;
int32
dvfSetObjectGeometryMaterial(dvfOBJECTPTR object, char *fMatName,
                             char *bMatName) ;
int32
dvfSetObjectLight(dvfOBJECTPTR object, dvfLIGHTPTR light) ;
int32
dvfSetObjectKeyFrame(dvfOBJECTPTR object, dvfKEYFRAMEPTR keyFrame) ;
#define dvfSetObjectPoint(o,p)       dmVectorCopy((o)->point,p)
#define dvfSetObjectScale(o,s)       dmVectorCopy((o)->scale,s)
#define dvfSetObjectOrien(o,r)       dmVectorCopy((o)->orien,r)
#define dvfSetObjectLoaded(o)        ((o)->flags |= dvf_OBJECT_LOADED)
#define dvfSetObjectCamera(o)        ((o)->flags |= dvf_OBJECT_CAMERA)
#define dvfSetObjectAnnotation(o)    ((o)->flags |= dvf_OBJECT_ANNOTATION)
#define dvfForceObjectPosOrScale(o)  ((o)->flags |= dvf_OBJ_FORCE_POSORSCALE)

/* Getting information back again */
#define dvfGetObjectName(o)          ((o)->name)
#define dvfGetObjectObjectParent(o)  ((o)->objParent)
#define dvfGetObjectFileParent(o)    ((o)->fileParent)
#define dvfGetObjectGeometryName(o)  ((o)->geomName)
#define dvfGetObjectGeometryFile(o)  ((o)->geometry)
#define dvfGetObjectLight(o)         ((o)->light)
#define dvfGetObjectPoint(o,p)       dmVectorCopy(p,(o)->point)
#define dvfGetObjectScale(o,s)       dmVectorCopy(s,(o)->scale)
#define dvfGetObjectOrien(o,r)       dmVectorCopy(r,(o)->orien)
#define dvfGetObjectGeometryState(o) ((o)->geomState)
#define dvfGetObjectRenderMode(o)    ((o)->renderMode)
/* These functions return 1 if a colour, point, orientation, scale
 * respectively are set to default values, zero otherwise. */
int32 dvfTestDefaultColour(dpfRGBA col) ;
int32 dvfTestDefaultPosition(dmPoint point) ;
int32 dvfTestDefaultOrientation(dmEuler orien) ;
int32 dvfTestDefaultScale(dmScale scale) ;

/* The next makes it a UseLibrary if the file name is not NULL or
 * a defineLibrary if NULL
 */
int32
dvfSetObjectLibrary(dvfOBJECTPTR object, char *filename) ;
/* Sets the library name and object name the use as a Template */
int32
dvfSetObjectTemplate(dvfOBJECTPTR object, char *library, char *oname) ;
int32
dvfSaveFreeGeometry(dvfFILEPTR file, dvfOBJECTPTR object) ;
int32
dvfSaveFreeAllGeometry(dvfFILEPTR file) ;
int32
dvfFreeObject(dvfOBJECTPTR object) ;
/* Dont use the following as it doesnt up-date pointers */
int32
dvfFreeObjectList(dvfOBJECTPTR object) ;

/* KeyFrame Functions *******************************************************/
dvfKEYFRAMEPTR
dvfCreateKeyFrame(void) ;
#define dvfGetKeyFrameState(k)       ((k)->state)
#define dvfSetKeyFrameState(k,s)     ((k)->state = s)

#define dvfGetKeyFrameMode(k)        ((k)->mode)
#define dvfSetKeyFrameMode(k,m)      ((k)->mode = m)

#define dvfGetKeyFrameInterpolation(k)    ((k)->interpolation)
#define dvfSetKeyFrameInterpolation(k,m)  ((k)->interpolation = m)

#define dvfGetKeyFrameLoop(k)        ((k)->loop)
#define dvfSetKeyFrameLoop(k,l)      ((k)->loop = l)

#define dvfGetKeyFrameTotalTime(k)   ((k)->totalTime)
#define dvfSetKeyFrameTotalTime(k,t) ((k)->totalTime = t)

dvfFRAMEPTR
dvfCreateFrame(void) ;
#define dvfSetFrameTime(f,t)         ((f)->time = t)
void
dvfSetFramePosition(dvfFRAMEPTR f, dmVector p) ;
void
dvfSetFrameOrientation(dvfFRAMEPTR f, dmQuaternion q) ;
void
dvfSetFrameScale(dvfFRAMEPTR f, dmVector s) ;
void
dvfAddFrame(dvfKEYFRAMEPTR keyFrame, dvfFRAMEPTR frame) ;

/* Light Functions **********************************************************/
dvfLIGHTPTR
dvfCreateLight(void) ;

#define dvfGetLightType(l)        ((l)->lightType)
#define dvfGetLightState(l)       ((l)->lightState)
#define dvfGetLightColour(l,c)    (dpfRGBCpy(c,(l)->light))

#define dvfSetLightType(l,t)      ((l)->lightType = t)
#define dvfSetLightState(l,s)     ((l)->lightState = s)
#define dvfSetLightColour(l,c)    (dpfRGBACpy((l)->colour,c))
#define dvfSetLightCone(l,a,e)    ((l)->lightCone.halfangle = (a), (l)->lightCone.exponent = (e))

/* Event Functions **********************************************************/
dvfEVENTPTR
dvfCreateEvent(void) ;
int32
dvfAddObjectEvent(dvfOBJECTPTR object, dvfEVENTPTR event) ;
int32
dvfSetEventName(dvfEVENTPTR event, char *name) ;
int32
dvfSetEventCommand(dvfEVENTPTR event, char *com) ;

/* File functions ***********************************************************/
int32 
dvfSetAssemblyFile(dvfOBJECTPTR assy, char * filename) ;

/* Attribute Functions ******************************************************/
dvfATTRIBUTEPTR
dvfCreateAttribute(dvfATTRIBUTETYPE type, 
                   char * attribute ,
                   char * attribute_name ,
                   char * attribute_file ) ;

int32
dvfAddObjectAttribute(dvfOBJECTPTR object, dvfATTRIBUTEPTR attr) ;

void
dvfFreeAttributeList(dvfATTRIBUTEPTR attr) ;

/* dVISE User data functions ************************************************/

dvfUSERDATAPTR
dvfCreateUserData(dvfFILEPTR vdifile, int32 nfields) ;

int32
dvfAddFieldsToUserData(dvfUSERDATAPTR udata, int32 nfields);

void 
dvfObjectSetUserData(dvfOBJECTPTR object, dvfUSERDATAPTR udata) ;

dvfUSERDATAPTR 
dvfObjectGetUserData(dvfOBJECTPTR object);

void
dvfSetNameUserData(dvfUSERDATAPTR ud, char * name) ;

void
dvfSetIntegerUserData(dvfUSERFIELDPTR uf, char * fieldName, int32 value) ;

void
dvfSetFloatUserData(dvfUSERFIELDPTR uf, char * fieldName, float32 value) ;

void
dvfSetTextUserData(dvfUSERFIELDPTR uf, char * fieldName, char * value) ;

void
dvfSetBoolUserData(dvfUSERFIELDPTR uf, char * fieldName, int32 value) ;


/* Find object utilities ****************************************************/
dvfOBJECTPTR dvfFindUseLibrary(dvfFILEPTR vdiFile, char *libname) ;

#ifdef __cplusplus
}
#endif

#endif /* __VDIFILE_H__ */
