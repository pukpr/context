#ifndef __VCSTRUCT_H
#define __VSTRUCT_H

struct VCAttribute { 
    ElementHandle	 type;               /* The element handle */
    InstanceNo		 ino;
    VCEntity		*first;
    int			 index;
    uint32		 mode;
    uint32		 cacheMode;
    uint32		 registerMode;
    void		*instanceData;
    uint32		 instanceDataSize;
    uint32		 instanceDataCount;
    VCUserDataList	*userDataList;
    VCAttributeDeleteFunc	 deleteFunc;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
}; 

struct VCCollision
{
    InstanceNo			 ino;
    uint32			 status;
    uint32			 instanceCount;
    uint32			 collReportCount;
    uint32			 cacheMode;
    void			*instanceData;
    uint32			 instanceDataSize;
    uint32			 instanceDataCount;
    VCCollisionReportData	*collReportData;
    uint32			 collReportDataSize;
    uint32			 collReportDataCount;
    uint32			 numCollisionsReported;
    VCUserDataList		*userDataList;
    VCCallbackFunctions		*createFunctionList;
    VCCallbackFunctions		*deleteFunctionList;
    VCCallbackFunctions		*updateFunctionList;
    void			*createCallbackHandle;
    void			*updateCallbackHandle;
    void			*deleteCallbackHandle;
};

struct VCIntersection
{
    InstanceNo			 ino;
    uint32			 status;
    uint32			 instanceCount;
    uint32			 intersectReportCount;
    uint32			 cacheMode;
    void			*instanceData;
    uint32			 instanceDataSize;
    uint32			 instanceDataCount;
    VCIntersectionReportData	*intersectReportData;
    uint32			 intersectReportDataSize;
    uint32			 intersectReportDataCount;
    uint32			 numIntersectionsReported;
    VCUserDataList		*userDataList;
    VCCallbackFunctions		*createFunctionList;
    VCCallbackFunctions		*deleteFunctionList;
    VCCallbackFunctions		*updateFunctionList;
    void			*createCallbackHandle;
    void			*updateCallbackHandle;
    void			*deleteCallbackHandle;
};

struct VCPosition
{
    InstanceNo		 ino;
    VCEntity		*entity;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
};

struct VCXWindowId
{
    InstanceNo		 ino;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    uint32		 instanceDataSize;
    uint32		 instanceDataCount;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
};

struct VCWindow
{
    InstanceNo		 ino;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    uint32		 instanceDataSize;
    uint32		 instanceDataCount;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
};

struct VCVisualViewResource
{
    InstanceNo		 ino;
    VCAttribute		*attribute;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
};

struct VCVisualSourceResource
{
    InstanceNo		 ino;
    VCAttribute		*attribute;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
};

struct VCPseudoGravity
{
    InstanceNo		 ino;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
};

struct VCMaterial
{
    
    InstanceNo		 ino;
    char		*name;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    uint32		 instanceDataSize;
    uint32		 instanceDataCount;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
};

struct VCCollisionSet
{
    
    InstanceNo		 ino;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    uint32		 instanceDataSize;
    uint32		 instanceDataCount;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
    void		*entityList;
};

struct VCCollisionRequestReport
{
    
    InstanceNo		 ino;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    uint32		 instanceDataSize;
    uint32		 instanceDataCount;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
    struct VCCollisionRequestReport *next;
    float32             *polylines;
    int32                polylineSize;
};

struct VCCollisionRequestState
{
    
    InstanceNo		 ino;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    uint32		 instanceDataSize;
    uint32		 instanceDataCount;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
    struct VCCollisionRequestReport **reportData;
    uint32		 reportDataSize;
};

struct VCCollisionRequest
{
    
    InstanceNo		 ino;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    uint32		 instanceDataSize;
    uint32		 instanceDataCount;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
    void 		*setList;
};

struct VCSearchPath
{
    
    InstanceNo		 ino;
    char		*name;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    uint32		 instanceDataSize;
    uint32		 instanceDataCount;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
};

struct VCRadiator
{
    
    InstanceNo		 ino;
    char		*name;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
};

struct VCVisualBoundingBox
{
    InstanceNo		 ino;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
};

struct VCSectionBounds
{
    InstanceNo		 ino;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
};

struct VCTexture
{
    InstanceNo		 ino;
    char		*name;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    uint32		 instanceDataSize;
    uint32		 instanceDataCount;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
};

struct VCTextureImage
{
    InstanceNo		 ino;
    char		*name;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    uint32		 instanceDataSize;
    uint32		 instanceDataCount;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
};

struct VCVisualScreenDump
{
    InstanceNo		 ino;
    char		*name;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    uint32		 instanceDataSize;
    uint32		 instanceDataCount;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
};

struct VCSectionImageSave
{
    InstanceNo		 ino;
    char		*name;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    uint32		 instanceDataSize;
    uint32		 instanceDataCount;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
};

struct VCAudioRecord
{
    InstanceNo		 ino;
    char		*name;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    uint32		 instanceDataSize;
    uint32		 instanceDataCount;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
    int16		 lastRecordCount;
};

struct VCRamp
{
    InstanceNo		 ino;
    char		*name;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    uint32		 instanceDataSize;
    uint32		 instanceDataCount;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
};

struct VCInput
{
    InstanceNo		 ino;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    uint32		 instanceDataSize;
    uint32		 instanceDataCount;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
    uint32		 numWraps;
    uint32		 head;
};

struct VCTracker
{
    InstanceNo		 ino;
    char 		*name;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    uint32		 instanceDataSize;
    uint32		 instanceDataCount;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
};

struct VCSync
{
    VCSync		*next;
    InstanceNo		 ino;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    uint32		 instanceDataSize;
    uint32		 instanceDataCount;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
};

struct VCMonitor
{
    InstanceNo		 ino;
    char 		*name;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    uint32		 instanceDataSize;
    uint32		 instanceDataCount;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
};

struct VCActorResource
{
    InstanceNo		 ino;
    char		*name;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    uint32		 instanceDataSize;
    uint32		 instanceDataCount;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;
} ;

typedef struct 
{
    VCAttribute		*attribute;
    int32		 index;
    int32		 flags;
    VCUserDataList	*userDataList;
} VCAttributeData;

typedef struct VCEntityData
{
    dmMatrix			 apos;
    VCEntity			*newParent;
    uint32			 traverseMode;
    VCCallbackFunctions		*createFuncList;
    VCCallbackFunctions		*updateFuncList;
    VCCallbackFunctions		*deleteFuncList;
    VCUserDataList		*userData;
    void			*objCallbackInfo;
    VCCallbackFunctions		*entityRelocateCallbackList;
    uint32			 entityRelocateMode;
    VCCallbackFunctions		*intersectFuncList;
} VCEntityData;

struct	VCEntity {
    VCEntity  	 	*cs_parent;      /* Local parental ptr */
    VCEntity 	 	*cs_child;       /* Local child ptr */
    VCEntity 	 	*cs_sibling;     /* Local sibling ptr */
    VCEntity  	 	*parent;         /* Local parental ptr */
    VCEntity 	 	*child;          /* Local child ptr */
    VCEntity 	 	*sibling;        /* Local sibling ptr */
    _VCObject		*object;         /* Hierarchy VL data */
    InstanceNo	     	 ino;            /* VCObject Instance No */
    VCEntityData	*systemData;
    int			 numAttributes;
    VCAttributeData   	 *attributes;/* Hierarchy data objects */
};

typedef struct
{
    VCColour	backgroundColour;
    int		backgroundColourSet;
    float32	nearClip;
    int		nearClipSet;
    float32	farClip;
    int		farClipSet;
    VCColour	fogColour;
    uint32	fogMode;    
    int		fogColourSet;
    float32	nearFog;
    int		nearFogSet;
    float32	farFog;
    int		farFogSet;

    void	*callbackHandle;
    
}_VCBodyVisResInfo;

typedef struct
{
    char	*resourceFile;
    float32	 volume;
    int		 volumeSet;
    float32	 spreadingRollOff;
    int		 spreadingRollOffSet;
    float32	 atmosphericAbsorption;
    int		 atmosphericAbsorptionSet;
    void	*callbackHandle;
}_VCBodyAudioResInfo;

struct VCBody
{
    VCBody		*next;
    _VCBody    		*body;
    uint32		 bodySize;
    uint32		 bodyCount;
    VCEntity	 	*rootEntity;
    VCEntity		*bodyPosEntity;
    InstanceNo 		 ino;
    VCCallbackFunctions	*bodyPartCreateList;
    VCCallbackFunctions	*bodyPartDeleteList;
    _VCBodyPartList	*bodyPartList;
    VCCallbackFunctions	*attributeFuncList;
    VCCallbackFunctions	*inputFuncList;
    VCCallbackFunctions	*collisionFuncList;
    VCCallbackFunctions	*screenIntersectFuncList;
    VCCallbackFunctions	*deleteFuncList;
    _VCBodyVisResInfo	 visualInfo;
    _VCBodyAudioResInfo  audioInfo;
    unsigned char	 messageChar;
};

struct _VCBody_InputFuncData 
{
    uint32		 minKeyCode;
    uint32		 maxKeyCode;
    char		*limbName;
};

struct _VCBody_CollideFuncData 
{
    char		*limbName;
};

struct _VCInput_FuncData 
{
    uint32		 minKeyCode;
    uint32		 maxKeyCode;
};

struct VCUserDataList
{
    VCUserDataList	*next;
    uint32		 vcId;
    void		*data;
};

struct VCCollisionReport_Traverse
{
    uint32	 instanceCount;
    VCCollision	*collision;
    uint32	 nextOffset;
};

struct VCIntersectionReport_Traverse
{
    uint32		 instanceCount;
    VCIntersection	*intersection;
    uint32		 nextOffset;
};
    
struct	VCEntity_Traverse 
{
    VCEntity	*currentObject;   /* Current hierarchy pos */
    VCEntity	*startObject;     /* Start hierarchy pos */
};

struct VCAttribute_EntityTraverse
{
    VCEntity	*entity;
    int32	 index;
};

struct VCEntity_AttributeTraverse
{
    VCEntity		*entity;
    int32		 nextIndex;
    ElementHandle	 element;
};

struct VCBody_Traverse
{
    VCBody		*body;
};

struct VCVisualView_Traverse
{
    duHashIterator	 hashIter;
    VCAttribute		*visResource;
};

struct VCBody_AttributeTraverse
{
    VCBody		*body;
    char 		*limbName; /* Request limb */
    ElementHandle	 element;
    _VCBodyPartList	*currentBodyPart;
    int			 currentAttribute;
    VCBody		*currentBody;
    VCBody_Traverse	 bodyTraverseInfo;
};

struct VCCallbackFunctions
{
    VCCallbackFunctions	*next;
    VC_CallbackFunc	 function;
    void		*data;
    void		*systemData;
};

typedef union 
{
    VCEntity_Traverse		entityT;
    VCEntity_AttributeTraverse	entityAttributeT;
    VCAttribute_EntityTraverse	attributeEntityT;
    VCBody_Traverse		bodyT;
    VCBody_AttributeTraverse	bodyAttributeT;
    VCCollisionReport_Traverse	collReportT;
    VCIntersectionReport_Traverse	intersectReportT;
    VCVisualView_Traverse	viewT;
}VC_Traverse;

typedef struct
{
    ElementHandle	 element;
    char		*limbName;
} _VCAttributeElementData;

typedef struct 
{
    InstanceNo		 inst;
    VCCallbackFunctions	*functionList;
} _VCInstCallback;

typedef struct 
{
    VCBody		*body;
    _VCBodyPartList	*bodyPart;
}_VCBodyPartInfo;

struct _VCTimer_CallbackInfo
{
    VLTime		 lastTime;
    VLTime		 time;
    VLTimerMode		 mode;
};

struct _VCBodyPartList
{
    _VCBodyPartList	*next;
    VCAttribute		*bodyPartAttr;
    VCBody		*body;
    uint32		 inputNeeded;
};

typedef struct	
{
    VCAttribute		*bodyPartAttr;
    VCBody		*body;
    VCEntity		*pickedEntity;
    VCEntity_DropFunc	 dropFunc;
    void		*dropData;
    VCPickObjectData	 pickObject;
}_VCBodyPickInfo;


/* Hoppy, 11/07/98 */
typedef struct	
{
    VCAttribute			*bodyPartAttr;
    VCBody			*body;
    VCEntity			*selectedEntity;
    VCEntity_DeselectFunc	 deselectFunc;		/* XXXX: Need these ?? */
    void			*deselectData;		/* XXXX: Need these ?? */
    VCSelectObjectData		 selectObject;
}_VCBodySelectInfo;

typedef struct 
{
    VCCallbackFunctions		*relocateFunctionList;
    VCCallbackFunctions		*createFunctionList;
    VCCallbackFunctions		*invalidFunctionList;
    VCCallbackFunctions		*updateFunctionList;
    VCCallbackFunctions		*deleteFunctionList;
    void			*createCallbackHandle;
    void			*updateCallbackHandle;
    void			*deleteCallbackHandle;
    uint32			 relocateMode;
} _VCObjectFunctions;    

typedef struct 
{
    _VCObjectFunctions	 functions;
    int           	 explicitInstances;
    duHashTab		*instTable;
    ElementHandle 	 element;
    uint32	  	 registered;
} _VCAttributeCallback;

typedef struct
{
    _VCAttributeCallback		*callbackList;
    int32	 		 listSize;
} _VCAttributeCallbackList;

typedef struct
{
    void *relocateCallbackHandle;
    void *invalidCallbackHandle;
}_VCEntityRelocateCallbackHandles;
typedef struct _VCSyncCallbackInfo
{
    struct _VCSyncCallbackInfo	*next;
    char 			*actorName;
    char 			*actorType;
    VCSync_Func			 updateFunc;
    VCSync_Func			 deleteFunc;
    void			*data;
    void			*updateCallbackHandle;
    void			*deleteCallbackHandle;
    VCSync			*sync;
}_VCSyncCallbackInfo;

typedef struct
{
    uint32 mode;
} _VCCallbackModeInfo;

typedef struct _vcBgfFile
{
    FILE *fp;
    int32 endian_swap;
    int32 error;
    uint32 buffer_size;
    int32 buffer_allocated;
    uint32 file_pos;
    char8 *buffer;
    char8 *pos;
    int32 bytes_read;
    int32 bytes;
    float32 scale;
    int8  precision;
    void *data;
} _vcBgfFile;

#endif
