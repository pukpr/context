/*
 *    PROJECT:      dvise
 *    SUBSYSTEM:    ec
 *    MODULE:
 *
 *    File:         $RCSfile: ectools.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:07:53 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: ectools.h,v 1.1 2005/09/13 15:07:53 pukitepa Exp $
 *
 *    FUNCTION:
 *
 *
 *
 * Copyright (c) 1994 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */

#ifndef _ECTOOLS_H
#define _ECTOOLS_H

#ifdef __cplusplus
extern "C" {
#endif
#ifdef _dummyBrace_
}
#endif

#ifndef DV_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `DV_EXPORT'
 */
#ifdef  _LIB_DV
#define DV_EXPORT __declspec(dllexport) extern
#else
#define DV_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define DV_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ifndef DV_EXPORT */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include <time.h>
#include <sys/types.h>
#include <stdarg.h>

#include "ectypes.h"
#include "ecconst.h"

/* PUBLIC DEFINES =======================================*/


/* PUBLIC TYPES =========================================*/


/* PUBLIC VARIABLES ======================================*/


/* PUBLIC FUNCTIONS ======================================*/

/*
 * Version Control
 */
DV_EXPORT void ecVersion(FILE *);

DV_EXPORT void EC_Error(char *string, ...);
DV_EXPORT void EC_Warning(char *string);
DV_EXPORT void EC_ErrorStdOut(void);
DV_EXPORT void EC_ErrorStdErr(void);

/* logging for debugging */
DV_EXPORT void EC_Log(char *s);

DV_EXPORT void EC_LogInt(int i);

DV_EXPORT FILE *EC_LogOpen(char *name);

DV_EXPORT int32 EC_InClient(void);
DV_EXPORT int32 EC_InServer(void);


/* ========================= Item functions ========================= */

DV_EXPORT ECItem *ECItem_Allocate(void);
DV_EXPORT int32 ECItem_Destroy(ECItem *item);
DV_EXPORT int32 ECItem_DestroyItemOnly(ECItem *item);
DV_EXPORT int32 ECItemList_DestroyItems(ECItem *list);
DV_EXPORT int32 ECItem_SimpleDataDestroy(ECItem *item);
DV_EXPORT ECItem *ECItem_Copy(ECItem *orig);
DV_EXPORT ECItem *ECItem_CreateInstance(ECItem *from);
/* Makes an item pointing to a new instance of the attribute within the
 * given item. */
DV_EXPORT ECItem *ECItemList_CreateInstances(ECItem *from);
/* Makes an item list pointing to new instances of the attributes within the
 * given item list. */
DV_EXPORT ECItem *ECItemList_FindNamedItem(ECItem *list, ECItem *item);
DV_EXPORT char *ECItem_GetName(ECItem *item);
DV_EXPORT void ECItemList_TypeOperate(ECItem *list, ECItemType type, 
			   void (*func)(void *, void *), void *userData);
/* Applies func to each item in the given list matching the given type.
 * func is called with the data value of the item, 
 * e.g. for type ECItemTypeVisual, func should have prototype
 *   void func(ECVisual *, void *)
 */
DV_EXPORT ECAction *ECItemAddEventAction (ECItem *item, int eventId, 
				       ECActionFunc *af, ECParameter *params);
/* Adds a new action based on given action func with given params
 * attached to the given item (containing an dobject, zone, role, etc)
 * for the given event type.  If this is an animate event then an
 * ECAnimatedAssemblyUpdate (libecapp) may be required following this.
 */
DV_EXPORT void ECItemList_TypeOperate2(ECItem *list, ECItemType type, void (*func)(void *));
/* As above, but with no user data. */
DV_EXPORT int32 ECItemList_ApplyChanges(ECItem *origList, ECItem *defList, 
				    ECItem *changesList);
DV_EXPORT int32 ECItem_ApplyChanges(ECItem *orig, ECItem *defList, ECItem *changes);
DV_EXPORT int32 ECItem_ApplyListChanges(ECItem *, ECItem *, ECItem *, int32 );
DV_EXPORT int32 ECItem_AddListMember(ECItem *, ECItem *, int32 );
DV_EXPORT int32 ECItem_RemoveListMember(ECItem *, int32 );
DV_EXPORT int32 ECItem_SetType(ECItem *item, ECItemType type);
DV_EXPORT ECItemType ECItem_GetType(ECItem *i);
DV_EXPORT ECItem *ECItem_GetNext(ECItem *i);
DV_EXPORT int32 ECItem_SetNext(ECItem *i, ECItem *n);
DV_EXPORT int32 ECItem_SetData(ECItem *item, void *data);
DV_EXPORT int32 ECItem_SetDataOfType(ECItemType, ECItem *item, void *data);
DV_EXPORT void *ECItem_GetData(ECItem *i);
DV_EXPORT void *ECItem_GetDataOfType(ECItemType, ECItem *i);
DV_EXPORT ECItem *ECItem_GetItemList(ECItem *item);

DV_EXPORT int32 ECItemList_AddItemToStart(ECItem **list, ECItem *newItem);
DV_EXPORT int32 ECItemList_AddItemToEnd(ECItem **list, ECItem *newItem);
DV_EXPORT int ECItemList_RemoveItem(ECItem **list, void *data);
/* Remove the first item within the given list that points to the given
 * data location.  Returns 1 if an item was removed, 0 otherwise. 
 * Any ECItem structure removed is freed (*data is intact, though).
 */
DV_EXPORT int ECItemList_UnlinkItem(ECItem **list, ECItem *item);
DV_EXPORT ECItem *ECItemList_FindByType(ECItem *list, ECItemType type);
DV_EXPORT ECItem *ECItem_FindLastByType(ECItem *list, ECItemType type);
DV_EXPORT int32 ECItemList_Destroy(ECItem *list);
/* Destroys the given item list and all data items it points to. */
DV_EXPORT int32 ECItemList_DifferencesDestroy(ECItem *inst, ECItem *def);
/* Destroys an item list and any data items pointed to in the instance
 * list that are not pointed to by the definition list.
 */
DV_EXPORT int ECItemList_DiffersFromDefinition(ECItem *item, ECItem *defItemList);
DV_EXPORT ECItem *ECItemList_Copy(ECItem *from);
DV_EXPORT ECItem *ECItem_Copy(ECItem *from);
DV_EXPORT ECItem *ECItem_Create(ECItemType typ, void *);

/* The following procedures exist because the items they are adding 
 * should only occur once within some item list and form a linked
 * list from that pointer.  These procedures are provided to simplify
 * this task.
 *
 * e.g. only one item of type ECItemTypeAssembly should occur in the
 *      attribute list of a zone and all the objects are linked 
 *      through this reference
 */
DV_EXPORT int32 ECItemList_AddEvent(ECItem **itemList, ECEvent *event);
DV_EXPORT int32 ECItemList_AddEventListEvents(ECItem **itemList, 
					 ECEventList *eventList);

DV_EXPORT void *ECItemList_FindNamedOfType(ECItemType type, ECItem *item, char *name);
DV_EXPORT ECItem *ECItemList_FindNamedItemOfType(ECItemType type, ECItem *list, char *name);
DV_EXPORT ECItem * ECItemList_FindWithData(ECItem *list, void *data);
DV_EXPORT void *ECItemList_FindNamedEntity(ECItem *item, char *name, ECItemType type);
DV_EXPORT ECAssembly *ECItemList_FindNamedAssembly(ECItem *item, char *name);
DV_EXPORT ECUserData *ECItemList_FindUserData(ECItem *item);
DV_EXPORT int ECItemList_GetLength(ECItem *itemList);
DV_EXPORT void ECItemList_SetOwner(ECItem *list, void *owner);
DV_EXPORT int32 ECFocus_RegisterInterest(ECItem *focus, int32 eventId, char *exp, ECAction *act);
DV_EXPORT int32 ECFocus_DeregisterInterest(ECItem *focus, int32 eventId, ECAction *act);
DV_EXPORT int32 ECEntity_RegisterInterest(void *focus, int32 eventId, char *exp, ECAction *act);
DV_EXPORT int32 ECEntity_DeregisterInterest(void *focus, int32 eventId, ECAction *act);
DV_EXPORT ECItemType ECEntity_GetType(void *);
DV_EXPORT char *ECEntity_GetName(void *);
DV_EXPORT char *ECEntity_CalculatePathName(void *entity);
DV_EXPORT char *ECEntity_GetPathName(void *);
DV_EXPORT char *ECEntity_CalculatePathName(void *entity);
DV_EXPORT char *ECItem_GetPathName(ECItem *);
DV_EXPORT int32 ECEntity_SetPathName(void *, char *);
DV_EXPORT void *ECEntity_GetOwner(void *);
DV_EXPORT int ECEntity_SetOwner(void *, void *);
DV_EXPORT void *ECItem_GetOwner(ECItem *);
DV_EXPORT int ECEntity_SetClientData(void *, void *);
DV_EXPORT void *ECEntity_GetClientData(void *);
DV_EXPORT int ECEntity_SetSpareData(void *, void *);
DV_EXPORT void *ECEntity_GetSpareData(void *);
DV_EXPORT int ECEntity_SetRestoreData(void *, void *);
DV_EXPORT void *ECEntity_GetRestoreData(void *);
DV_EXPORT void *ECEntity_Create(ECItemType type, char *name, char *path);
DV_EXPORT void ECItem_Debug(ECItem *);

/*====================== Plugin functions ========================*/

DV_EXPORT ECPlugin *ECPlugin_GetFirst(void);
DV_EXPORT ECPlugin *ECPlugin_GetNext(ECPlugin *plugin);
DV_EXPORT int ECPlugin_GetNumLoaded(void);
DV_EXPORT char *ECPlugin_GetName(ECPlugin *plugin);
DV_EXPORT ECPlugin *ECPlugin_Allocate(void);
DV_EXPORT DLOAD_HANDLE ECPlugin_Load(char *sysName, char *pluginname);
DV_EXPORT int ECPlugin_Unload(ECPlugin *plugin);
DV_EXPORT DLOAD_HANDLE ECPlugin_GetStandardHandle(void);
DV_EXPORT DLOAD_HANDLE ECPlugin_GetHandle(ECPlugin *plugin);
DV_EXPORT ECPlugin *ECPlugin_FindWithHandle(DLOAD_HANDLE handle);

/*====================== Action functions ========================*/

DV_EXPORT ECAction *ECAction_Allocate(void);
DV_EXPORT char *ECAction_GetFunctionName(ECAction *action);
DV_EXPORT ECAction *ECAction_Create(ECActionFunc *af, ECParameter *mps);
DV_EXPORT ECAction *ECAction_CreateInvocation(char *func, ...);
DV_EXPORT int32 ECAction_Destroy(ECAction *);
DV_EXPORT int32 ECActionList_AddAction(ECAction *list, ECAction *newAct);
DV_EXPORT ECAction	*ECActionListGetLast(ECAction *list);
DV_EXPORT ECAction *ECActionList_GetNext(ECAction *list);
DV_EXPORT int32 ECActionLists_Join(ECAction *first, ECAction *second);
DV_EXPORT ECAction *ECAction_Copy(ECAction *from);
DV_EXPORT ECAction *ECActionList_Copy(ECAction *fromList);
DV_EXPORT int ECAction_NotInList(ECAction *newAct, ECAction *list);
DV_EXPORT int ECActionLists_Differ(ECAction *first, ECAction *second);
DV_EXPORT int32 ECActions_Destroy(ECAction *);
DV_EXPORT ECActionFunc *ECActionFuncList_AddActionFunc(ECActionFunc **list,
						   int (*func)(), char *name,
						   int numParams, ECParameterType *param_types,
						   char **paramNames, char *comment);
DV_EXPORT int ECAction_ExtractParameters(ECAction *action, ...);
DV_EXPORT int32 ECActionFunctionsList_Set(ECActionFunc *funcs);
DV_EXPORT ECActionFunc *ECActionFunctionsList_Get(void);
DV_EXPORT void **ECParameters_Copy(void **orig, ECActionFunc *af);
DV_EXPORT ECActionFunc *ECUserActionFuncRegister(ECActionFunction func, 
                                                 char *name, char *comment, ...);
DV_EXPORT ECActionFunc *EC_UserActionFuncRegister(ECActionFunction func, ECActionDestructor df, 
                                                  char *name, char *comment, ...);
DV_EXPORT ECActionDestructor ECActionFunc_GetDestructor(ECActionFunc *af);
DV_EXPORT ECActionFunc *ECAction_FindNamedFunc(char *name);
DV_EXPORT ECActionFunc *ECNamedActionFuncSetFunc(char *name, int (*func)());
DV_EXPORT void ECActionFunc_ChangePluginLibrary(char *name);
DV_EXPORT void ECActionFunc_RemoveFromList(char *name);
DV_EXPORT void ECActionFunc_DeleteList(void);

/*============================ Material functions ================================*/
DV_EXPORT int32 ECMaterial_ApplyChanges(ECMaterial* , ECMaterial* );
DV_EXPORT int32 ECTexture_ApplyChanges(ECTexture* , ECTexture* );
DV_EXPORT ECItem *ECMaterialLibrary_GetItems(ECLibrary *library);
DV_EXPORT ECLibrary *ECMaterialLibrary_Read(char *);
DV_EXPORT int32 ECMaterialLibrary_Write(ECLibrary *, char *);
DV_EXPORT ECItem *ECMaterialLibrary_FindNamedEntity(ECLibrary *, char *name, ECItemType);
DV_EXPORT void ECMaterialLibrary_AddItem( ECAssembly *library, ECItem *item );
DV_EXPORT void ECMaterialLibrary_Rename( ECLibrary *library, char *newName );
DV_EXPORT int ECMaterialLibrary_SetupBMFFileAtRuntime(ECLibrary *matLib);
DV_EXPORT void ECMaterialLibrary_SetupFile( ECLibrary *matLib );

DV_EXPORT ECItemType ECMaterialEntity_GetType(ECMaterial*);
DV_EXPORT ECLibrary *ECMaterialLibrary_Find(char *fileName);
DV_EXPORT char * ECMaterialLibrary_GetFileName(ECLibrary *matLib);
DV_EXPORT ECMaterial* ECMaterial_Allocate(void);
DV_EXPORT ECMaterial* ECMaterial_Create(char *name, char *texture, int ttype, char *ramp, 
				      float32 *ambient,	float32 *diffuse, float32 *speclr, 
				      float32 *emiss, float32 *opacity,
				      char *envName, int etype);
DV_EXPORT char *ECMaterial_GetName(ECMaterial* );
DV_EXPORT char *ECTexture_GetName(ECTexture*);
DV_EXPORT int32 ECMaterial_SetName(ECMaterial* , char *);
DV_EXPORT int32 ECMaterial_SetLibName(ECMaterial*, char *);
DV_EXPORT char *ECMaterial_GetLibName(ECMaterial* ecMat);
DV_EXPORT ECLibrary *ECMaterial_GetLib(ECMaterial* ecMat);
DV_EXPORT char *ECMaterial_GetVCName(ECMaterial*);
DV_EXPORT char *ECMaterial_GetVCTextureName(ECMaterial*);
DV_EXPORT char *ECMaterial_GetVCEnvironmentName(ECMaterial*);
DV_EXPORT int32 ECTexture_SetName(ECTexture*, char *);
DV_EXPORT char *ECTexture_GetLibName(ECTexture* ecText);
DV_EXPORT ECLibrary *ECTexture_GetLib(ECTexture* ecText);
DV_EXPORT char *ECRamp_GetName(void *);
DV_EXPORT int ECMaterial_GetData(ECMaterial* , char **, char **, int *, char **, float32 *, 
			     float32*, float32 *, float32 *, float32 *, char **, int *);
DV_EXPORT int ECMaterial_PutData(ECMaterial* , char *, char **, int, char **, float32 *, 
			     float32*, float32 *, float32 *, float32 *, char **, int);
DV_EXPORT ECMaterial* ECMaterial_Copy(ECMaterial* );
DV_EXPORT int32 ECMaterial_Insert(ECLibrary *, ECMaterial* );
DV_EXPORT int32 ECMaterial_Delete(ECMaterial* );
DV_EXPORT int32 ECMaterial_Delete_NoUnlinkFromItemList(ECMaterial* );
DV_EXPORT void *ECMaterial_GetVCMaterial(ECMaterial* );
DV_EXPORT int32 ECMaterial_SetVCMaterial(ECMaterial* , void *);
DV_EXPORT int32 ECMaterial_GetRefCount(ECMaterial* ecMat);
DV_EXPORT ECMaterial * ECMaterial_Find( char *materialName );
DV_EXPORT ECTexture * ECMaterial_FindTexture( ECMaterial *ecMat );
DV_EXPORT ECTexture * ECMaterial_FindEnvTexture( ECMaterial *ecMat );
DV_EXPORT void ECMaterial_AddReference(char *mat);
DV_EXPORT void ECMaterial_DeleteReference(char *mat);
DV_EXPORT ECLibrary *ECMaterialLibrary_CreateAtRuntime(char *bmfFileName);
DV_EXPORT ECTexture* ECTexture_Allocate(void);
DV_EXPORT ECTexture* ECTexture_Create(char *name, uint8 minify, uint8 magnify, 
			 uint8 alpha, uint8 wrapU, uint8 wrapV, uint8 detailType, 
			 char *textureMap, char *detailMap);
DV_EXPORT int32 ECTexture_SetVCTexture(ECTexture* ecText, void *vcText);
DV_EXPORT void *ECTexture_GetVCTexture(ECTexture*);
DV_EXPORT int ECTexture_GetData(ECTexture* ecText, char **name, uint8 *minify, uint8 *magnify, 
			 uint8 *alpha, uint8 *wrapU, uint8 *wrapV, uint8 *detailType, 
			 char **textureMap, char **detailMap);
DV_EXPORT int ECTexture_PutData(ECTexture* ecText, char *name, uint8 minify, uint8 magnify, 
			 uint8 alpha, uint8 wrapU, uint8 wrapV, uint8 detailType, 
			 char **textureMap, char **detailMap);
DV_EXPORT int32 ECTexture_Insert(ECLibrary *, ECTexture*);
DV_EXPORT int32 ECTexture_Delete(ECTexture*);
DV_EXPORT int32 ECTexture_Free(ECTexture*);
DV_EXPORT ECTexture* ECTexture_Copy(ECTexture*);
DV_EXPORT int32 ECTexture_SetLibName(ECTexture*, char *);
DV_EXPORT char *ECTexture_GetVCName(ECTexture*);
DV_EXPORT ECTexture * ECTexture_Find( char *textureName );
DV_EXPORT int32 ECTexture_GetRefCount(ECTexture* ecText);

/* ======================= String functions ===================== */

DV_EXPORT int32 ECString_Destroy(ECString *);
DV_EXPORT int32 ECString_ApplyChanges(ECString *original, ECString *changes);
DV_EXPORT char *ECQuotedString_Create(char *val);
DV_EXPORT int32 ECQuotedString_Destroy(char *val);
DV_EXPORT char *EC_Strsave(char *s);
DV_EXPORT int EC_StrCmp(char *a, char *b);
DV_EXPORT char *EC_InstanceNameCreate(char *definitionName, uint32 instanceNumber);
DV_EXPORT int EC_NameIsInstanceName(char *name, char *defname);
/* returns 1 if name is of the form defname.number, otherwise 0 */
DV_EXPORT int EC_HexToInt(char *string);
/* returns int from a hex string [0-9a-f]+ */

/*If in is of the form X:Y then returns 1 and copies X to 
out1 and Y to out2 else returns zero */
DV_EXPORT int32 EC_NameSplit(char *in, char **out1, char **out2);
/* split names of the form /ass0/ass1/.../assN */
DV_EXPORT int32 EC_PathNameSplit(char *in, char **prefix, char **suffix);
DV_EXPORT int32 EC_PathNameTruncate(char *in, char **prefix, char **suffix);
DV_EXPORT char *EC_PathNameToName(char *path);
DV_EXPORT char *EC_PathNameExtend(char *parent, char *name, int addSlash);
DV_EXPORT char *EC_PathNameExtend2(char *parent, char *name, 
                                  int initialSeprtr, char seprtr);
DV_EXPORT int EC_ComparePaths(char *path1, char *path2);
DV_EXPORT int EC_ComparePathArray(char **paths, int index);
DV_EXPORT int EC_CheckIfFilesAreDifferent( char *filename1, char *filename2 );

/* ======================= Float functions ======================= */

DV_EXPORT float32 *EC_FloatSave(float32 f);
DV_EXPORT int32 EC_FloatDestroy(ECFloat *f);
DV_EXPORT int32 EC_FloatApplyChanges(ECFloat *orig, ECFloat *changes);
DV_EXPORT int EC_FloatsDiffer(float32 *a, float32 *b);

/* ======================= Audio functions ======================= */

DV_EXPORT ECAudio *ECAudio_Allocate(void);
DV_EXPORT ECAudio *ECAudio_Copy(ECAudio *from);
DV_EXPORT int ECAudio_ApplyChanges(ECAudio *orig, ECAudio *changes);
DV_EXPORT int ECAudio_Destroy(ECAudio *);
DV_EXPORT float32 ECAudio_GetGain(ECAudio *audio);
DV_EXPORT int ECAudio_GetLoopCnt(ECAudio *audio);
DV_EXPORT char *ECAudio_GetName(ECAudio *);
DV_EXPORT char *ECAudio_CheckLibName(ECAudio *);
DV_EXPORT int ECAudio_GetPriority(ECAudio *audio);
DV_EXPORT char *ECAudio_GetRadiatorFileName(ECAudio *audio);
DV_EXPORT char *ECAudio_GetRadiatorName(ECAudio *audio);
DV_EXPORT VCAttribute *ECAudio_GetVCAttribute(ECAudio *audio);
DV_EXPORT uint8 ECAudio_GetVelocity(ECAudio *audio);
DV_EXPORT char *ECAudio_GetVoice(ECAudio *audio);
DV_EXPORT int ECAudio_SetState(ECAudio *, ECStateType);
DV_EXPORT int ECAudio_SetGain(ECAudio *, float32 gain);
DV_EXPORT int ECAudio_SetLoopCnt(ECAudio *, int looping);
DV_EXPORT int ECAudio_SetName(ECAudio *, char *name);
DV_EXPORT int ECAudio_SetPriority(ECAudio *, int priority);
DV_EXPORT int ECAudio_SetRadiatorName(ECAudio *, char *filename);
DV_EXPORT int ECAudio_SetRadiatorFileName(ECAudio *, char *filename);
DV_EXPORT int ECAudio_SetVCAttribute(ECAudio *audio, VCAttribute *attr);
DV_EXPORT int ECAudio_SetVoice(ECAudio *, char *filename);

DV_EXPORT int ECAudios_Differ(ECAudio *a, ECAudio *b);
DV_EXPORT int ECAudio_Destroy(ECAudio *a);
DV_EXPORT ECStateType ECAudio_GetState(ECAudio *audio);
DV_EXPORT uint32 ECAudio_GetMode(ECAudio *audio);
DV_EXPORT int ECAudio_SetMode(ECAudio *audio, uint32 mode);
DV_EXPORT int ECAudio_SetVelocity(ECAudio *audio, uint8 vel);

DV_EXPORT int ECAudio_CopyDefined(ECAudio *def, ECAudio *newAudio);

/* ================== Collision functions =================== */

DV_EXPORT ECCollision *EC_CollisionAllocate(void);
DV_EXPORT int32 ECCollision_CopyDefined(ECCollision *from, ECCollision *to);
DV_EXPORT ECCollision *ECCollision_Copy(ECCollision *from);
/*
 * Allocate memory for a new ECCollision and copy 
 * the information from an existing structure
 * into it
 */

DV_EXPORT int32 ECCollision_Destroy(ECCollision *);
DV_EXPORT int32 ECCollision_SetName(ECCollision *, char *);
DV_EXPORT int32 ECCollision_SetGeometry(ECCollision *, char *);
DV_EXPORT int32 ECCollision_SetLod(ECCollision *, char *lod);
DV_EXPORT char *ECCollision_CheckLibName(ECCollision *);
DV_EXPORT char *ECCollision_GetLod(ECCollision *c);

DV_EXPORT int ECCollision_SetState(ECCollision *, ECStateType);
DV_EXPORT char *ECCollision_GetName(ECCollision *);
DV_EXPORT char *ECCollision_GetGeometry(ECCollision *);
DV_EXPORT ECStateType ECCollision_GetState(ECCollision *);
DV_EXPORT int ECCollisions_Differ(ECCollision *a, ECCollision *b);
DV_EXPORT int32 ECCollision_ApplyChanges(ECCollision *orig, ECCollision *changes);
DV_EXPORT int ECCollision_SetMode(ECCollision *c, uint32 mode);
DV_EXPORT int ECCollision_ModifyMode(ECCollision *c, uint32 setMode, uint32 clearMode);
DV_EXPORT uint32 ECCollision_GetMode(ECCollision *c);

DV_EXPORT VCAttribute *ECCollisionGetVCAttribute(ECCollision *collision);

/* ====================== Icon functions ========================= */
DV_EXPORT ECIcon *ECIcon_Allocate(void);
DV_EXPORT int32 ECIcon_Destroy(ECIcon *);
DV_EXPORT int32 ECIcon_SetName(ECIcon *c, char *n);
DV_EXPORT int32 ECIcon_SetGeometry(ECIcon *c, char *g);
DV_EXPORT char *ECIcon_GetName(ECIcon *c);
DV_EXPORT char *ECIcon_CheckLibName(ECIcon *);
DV_EXPORT int32 ECIcon_Destroy(ECIcon *c);
DV_EXPORT int32 ECIcon_CopyDefined(ECIcon *def, ECIcon *newIcon);
DV_EXPORT ECIcon *ECIcon_Copy(ECIcon *from);
/*
 * Allocate memory for a new ECIcon and copy 
 * the information from an existing structure
 * into it
 */
DV_EXPORT int ECIcons_Differ(ECIcon *a, ECIcon *b);
DV_EXPORT int32 ECIcon_ApplyChanges(ECIcon *orig, ECIcon *changes);
DV_EXPORT ECItem **ECIcon_GetItemListPtr(ECIcon *icon);
DV_EXPORT ECItem *ECIcon_GetItemList(ECIcon *icon);

/* ====================== Light functions ========================= */

DV_EXPORT ECLight *ECLight_Allocate(void);
/* ALlocate and blank space for a ECLight, then set the light colour
 * to default (0.33, 0.33, 0.33) and EC_POINT_LIGHT type (?);
 */
DV_EXPORT int ECLight_Destroy(ECLight *);
DV_EXPORT int ECLight_CopyDefined(ECLight *def, ECLight *newLight);
DV_EXPORT char *ECLight_CheckLibName(ECLight *);
DV_EXPORT ECLight *ECLight_Copy(ECLight *from);
/*
 * Allocate memory for a new ECLight and copy 
 * the information from an existing structure
 * into it
 */
DV_EXPORT int ECLight_NotNull(ECLight *, char *proc);
DV_EXPORT int ECLight_SetName(ECLight *x, char *name);
DV_EXPORT int32 ECLight_SetType(ECLight *, uint32 type);
DV_EXPORT int ECLight_SetColour(ECLight *, float32 *);
DV_EXPORT int ECLight_SetVCAttribute(ECLight *, VCAttribute *);
/* Set the colour of a ECLight */
DV_EXPORT int ECLight_SetState(ECLight *, ECStateType);
DV_EXPORT char *ECLight_GetName(ECLight *);
DV_EXPORT uint32 ECLight_GetType(ECLight *);
DV_EXPORT int ECLight_GetColour(ECLight *, float32 *);
DV_EXPORT VCAttribute *ECLight_GetVCAttribute(ECLight *);
DV_EXPORT float32 *_ECLight_GetColour(ECLight *);
DV_EXPORT ECStateType ECLight_GetState(ECLight *);
DV_EXPORT int ECLight_ColourNotDefault(float32 *);
DV_EXPORT int ECLights_Differ(ECLight *, ECLight *);
DV_EXPORT int ECLight_Destroy(ECLight *l);
DV_EXPORT int ECLight_ApplyChanges(ECLight *orig, ECLight *changes);
DV_EXPORT int ECLightSetAll (ECLight *light, uint32 setMode,
            uint32 clearMode, float32 *colour, float32 *exponent, float32 *theta);
DV_EXPORT uint32 ECLight_GetMode(ECLight *);
DV_EXPORT int ECLight_ModifyMode(ECLight *light, uint32 setMode, uint32 clearMode);
DV_EXPORT int ECLight_SetFrustumState(ECLight *, ECStateType);
DV_EXPORT ECStateType ECLight_GetFrustumState(ECLight *);


/* ==================== Constraints functions ================*/

DV_EXPORT ECConstraints *ECConstraints_Allocate(void);
DV_EXPORT int ECConstraints_CopyDefined(ECConstraints *def, ECConstraints *newCon);
DV_EXPORT ECConstraints *ECConstraints_Copy(ECConstraints *from);
/*
 * Allocate memory for a new ECConstraints and copy 
 * the information from an existing structure
 * into it
 */
DV_EXPORT int ECConstraints_Destroy(ECConstraints *);
DV_EXPORT int ECConstraints_SetName(ECConstraints *c, char *name);
DV_EXPORT int ECConstraints_SetState(ECConstraints *constraints, ECStateType state);
DV_EXPORT int ECConstraints_SetLockPlane(ECConstraints *c, ECVec3 *p, float32 d);
DV_EXPORT int ECConstraints_SetSnapTrans(ECConstraints *, ECVec3 *);
DV_EXPORT int ECConstraints_SetSnapRot(ECConstraints *, ECVec3 *);
DV_EXPORT int ECConstraints_SetSnapScale(ECConstraints *, ECVec3 *);
DV_EXPORT int ECConstraints_SetSnapTransState(ECConstraints *c, 
					   ECStateType state);
DV_EXPORT int ECConstraints_SetSnapRotState(ECConstraints *c, ECStateType state);
DV_EXPORT int ECConstraints_SetSnapScaleState(ECConstraints *c, 
					   ECStateType state);
DV_EXPORT char *ECConstraints_CheckLibName(ECConstraints *);
DV_EXPORT char *ECConstraints_GetName(ECConstraints *c);
DV_EXPORT ECStateType ECConstraints_GetState(ECConstraints *constraints);
DV_EXPORT int ECConstraints_GetLockPlane(ECConstraints *c, ECVec3 **vec, float32 **d);
DV_EXPORT ECVec3 *ECConstraints_GetSnapTrans(ECConstraints *);
DV_EXPORT ECVec3 *ECConstraints_GetSnapRot(ECConstraints *);
DV_EXPORT ECVec3 *ECConstraints_GetSnapScale(ECConstraints *);
DV_EXPORT ECStateType ECConstraints_GetSnapTransState(ECConstraints *);
DV_EXPORT ECStateType ECConstraints_GetSnapRotState(ECConstraints *);
DV_EXPORT ECStateType ECConstraints_GetSnapScaleState(ECConstraints *);
DV_EXPORT int ECConstraints_Differ(ECConstraints *a, ECConstraints *b);
DV_EXPORT int ECConstraints_ApplyChanges(ECConstraints *orig, ECConstraints *changes);
DV_EXPORT int ECConstraints_SetMinX(ECConstraints *constraints, float32 xMin);
DV_EXPORT int ECConstraints_SetMaxX(ECConstraints *constraints, float32 xMax);
DV_EXPORT int ECConstraints_SetMinY(ECConstraints *constraints, float32 yMin);
DV_EXPORT int ECConstraints_SetMaxY(ECConstraints *constraints, float32 yMax);
DV_EXPORT int ECConstraints_SetMinZ(ECConstraints *constraints, float32 zMin);
DV_EXPORT int ECConstraints_SetMaxZ(ECConstraints *constraints, float32 zMax);
DV_EXPORT int ECConstraints_SetMinRoll(ECConstraints *constraints, float32 rollMin);
DV_EXPORT int ECConstraints_SetMaxRoll(ECConstraints *constraints, float32 rollMax);
DV_EXPORT int ECConstraints_SetMinPitch(ECConstraints *constraints, 
				     float32 pitchMin);
DV_EXPORT int ECConstraints_SetMaxPitch(ECConstraints *constraints, 
				     float32 pitchMax);
DV_EXPORT int ECConstraints_SetMinYaw(ECConstraints *constraints, float32 yawMin);
DV_EXPORT int ECConstraints_SetMaxYaw(ECConstraints *constraints, float32 yawMax);
/* Set hinge functions return 1 on succes, 0 on failure.
 * The call will fail if another hinge is already set. 
 */
DV_EXPORT int ECConstraints_SetHingeX(ECConstraints *constraints);
DV_EXPORT int ECConstraints_SetHingeY(ECConstraints *constraints);
DV_EXPORT int ECConstraints_SetHingeZ(ECConstraints *constraints);
DV_EXPORT int ECConstraints_HingeX(ECConstraints *cons, float32 min, float32 max);
DV_EXPORT int ECConstraints_HingeY(ECConstraints *cons, float32 min, float32 max);
DV_EXPORT int ECConstraints_HingeZ(ECConstraints *cons, float32 min, float32 max);
DV_EXPORT float32 ECConstraints_GetMinX(ECConstraints *constraints);
DV_EXPORT float32 ECConstraints_GetMaxX(ECConstraints *constraints);
DV_EXPORT float32 ECConstraints_GetMinY(ECConstraints *constraints);
DV_EXPORT float32 ECConstraints_GetMaxY(ECConstraints *constraints);
DV_EXPORT float32 ECConstraints_GetMinZ(ECConstraints *constraints);
DV_EXPORT float32 ECConstraints_GetMaxZ(ECConstraints *constraints);
DV_EXPORT float32 ECConstraints_GetMinRoll(ECConstraints *constraints);
DV_EXPORT float32 ECConstraints_GetMaxRoll(ECConstraints *constraints);
DV_EXPORT float32 ECConstraints_GetMinPitch(ECConstraints *constraints);
DV_EXPORT float32 ECConstraints_GetMaxPitch(ECConstraints *constraints);
DV_EXPORT float32 ECConstraints_GetMinYaw(ECConstraints *constraints);
DV_EXPORT float32 ECConstraints_GetMaxYaw(ECConstraints *constraints);
DV_EXPORT int ECConstraints_LockFixed(ECConstraints *constraints);
DV_EXPORT int ECConstraints_SetMode(ECConstraints *c, uint32 mode);
DV_EXPORT int ECConstraints_ModifyMode(ECConstraints *c, uint32 setMode, uint32 clearMode);
DV_EXPORT uint32 ECConstraints_GetMode(ECConstraints *c);
DV_EXPORT int ECConstraints_SetFlags(ECConstraints *c, uint32 Flags);
DV_EXPORT int ECConstraints_ModifyFlags(ECConstraints *c, uint32 setFlags, uint32 clearFlags);
DV_EXPORT uint32 ECConstraints_GetFlags(ECConstraints *c);

/* ========================= Assembly functions ========================= */

DV_EXPORT ECAssembly *ECAssembly_Allocate(void);
/* Allocate memory for a ECAssembly, blank it and return a pointer.
 * Note that default values (ie scale=(1,1,1)) are NOT set.
 */
DV_EXPORT int ECAssembly_Destroy(ECAssembly *);
/*
 * Free all the memory allocated to an ECAssembly and its children.
 * The audio, light, visual, locks and eventList structures
 * are freed.
 */
DV_EXPORT int ECClipAssembly_Destroy(ECAssembly *);
/*
 * Similar to ECAssembly_Destroy but for use on clipboards
 */
DV_EXPORT void ECAssembly_PlugRemoveVCFunc(ecappPlugFunc func);
DV_EXPORT int ECAssembly_Delete(ECAssembly *object);
/* as ECAssembly_Destroy but also removes references to this object from
 * any parent or zone.
 */
/*
 * ECAssembly_AddDeleteCallback :
 *      Attaches a delete callback to the given ECAssembly. This is invoked before
 *      any of the ECAssembly or VCEntity structures are deleted. 
 * 
 * ECAssembly_RemoveDeleteCallback :
 *      Removes any delete callbacks from the given ECAssembly that match the given
 *      ECAssemblyCallbackPtr function and the userdata.
 * 
 * ECAssembly_RemoveAllDeleteCallbacks :
 *      Removes all delete callbacks from the given ECAssembly. This function is used 
 *      to clear up any remaining callbacks on the ECAssembly just before it is deleted, 
 *      and obviously after the callback list has been executed!
 */
DV_EXPORT int32 ECAssembly_AddDeleteCallback(ECAssembly *ecAssembly, 
                                       ECAssemblyCallbackPtr callback,
                                       void *userdata);
DV_EXPORT int32 ECAssembly_RemoveDeleteCallback(ECAssembly *ecAssembly,
                                          ECAssemblyCallbackPtr callback, 
                                          void *userdata);
DV_EXPORT int32 ECAssembly_RemoveAllDeleteCallbacks(ECAssembly *ecAssembly);


DV_EXPORT ECAssembly *ECAssembly_Create(char *name);
/*
 * Create a new EC object using ECAssembly_Allocate, set
 * default values and assign the given name (which should not
 * be shared).  The list
 * of defined objects is checked for a match with this name
 * and, if one is found, the object is considered to be an
 * instance of that definition, in which case the definition
 * is copied to the new structure which is renamed
 * definition_name.instance_number
 * Note that children of the definition object are not copied.
 */
DV_EXPORT int ECAssembly_ListDestroy(ECAssembly *);
/* Free all the memory assigned to a linked list of objects
 * and all their children.
 */
DV_EXPORT int ECAssembly_Destroy(ECAssembly *);
/*
 * Free all the memory allocated to a ECAssembly and its children.
 * The audio, light, visual, locks and event_list structures
 * are freed.
 */
DV_EXPORT ECAssembly *ECAssembly_FindNamedAssembly(ECAssembly *top_object,
                                                   char *name, int strictMode);
DV_EXPORT void *ECAssembly_FindNamedEntity(ECAssembly *top_object,
                                           char *name, ECItemType type);
/*
 * ECAssembly_FindNamedAssembly checks the list of object definitions given
 * looking for a name match, returning a pointer to the object if
 * successful.
 */
DV_EXPORT ECAssembly *ECAssembly_FindNamedAssemblyOrDefinition(ECAssembly *top_object, 
						     char *name);
/* As ECNamedAssemblyFindInList except that an instance object whose 
 * definition's name matches the given name will also match.
 */
DV_EXPORT int ECAssemblyList_RemoveAssembly(ECAssembly **list, ECAssembly *);
/*
 * Find an object within a list and alter the links in
 * the list so that the specified object is no longer a
 * member.  It is assumed that the object will not occur
 * more than once, but it may not be a member of the list at
 * all.  As the object may be the first in the list, the list
 * pointer is passed as (ECAssembly **) so that the first pointer
 * value in the list can be altered if need be.
 */
DV_EXPORT int ECAssembly_AddChild(ECAssembly *parent, ECAssembly *child);
DV_EXPORT int ECAssembly_LinkChild(ECAssembly *parent, ECAssembly *child);
DV_EXPORT int ECAssembly_AddChildWithNoNameCheck(ECAssembly *parent, ECAssembly *child);
/*
 * Add a new child to the list of children for a parent object.
 * If that list is null, it is set to point to the child, otherwise
 * the child is added to the end of the list.
 */
DV_EXPORT int ECAssembly_RemoveChild(ECAssembly *parent, ECAssembly *child);
/* Removes the object which should be a child of the given parent, 
 * sets the child's parent pointer to NULL and its zone pointer to NULL.
 */
DV_EXPORT int ECAssembly_RemoveItem(ECAssembly *parent, ECItem *child);
DV_EXPORT int ECAssembly_RemoveAttribute(ECAssembly *parent, void *attr);
DV_EXPORT int ECAssembly_SetStatus(ECAssembly *, ECAssemblyStatus status);
DV_EXPORT int ECAssembly_SetRef(ECAssembly *ass, ECAssembly *ref);
DV_EXPORT int ECAssembly_SetPhysical(ECAssembly *, ECPhysical* physical);
DV_EXPORT int ECAssembly_SetIcon(ECAssembly *, ECIcon *);
DV_EXPORT int ECAssembly_SetInstanceType(ECAssembly *a, ECInstanceType type );
DV_EXPORT void *ECAssembly_GetScratchData(ECAssembly *);
DV_EXPORT int32 ECAssembly_SetScratchData(ECAssembly *, void *);

/* set the icon filename for a EC object */
DV_EXPORT ECAssembly *ECAssembly_CreateInstanceFromDefn(ECAssembly *definition);
/* Create and return an instance of a definition object with default name */
DV_EXPORT int ECAssembly_CopyDefined(ECAssembly *from, ECAssembly *to);
/*
 * Make an instance (copy) of a definition object (not children).
 * The space for the new object must be allocated already.
 * The new object is named: definition_name.instance_number
 * The definition object's number of instances in incremented,
 * the new object is flagged as an instance
 * (to->isinstance==TRUE) and it's definition pointer is set
 * to the definition object (to->definition==from).
 */
DV_EXPORT ECAssembly *ECAssembly_CreateAsInstance(char *libraryName, 
					char *definitionName);
DV_EXPORT ECAssembly *ECAssembly_Copy(ECAssembly *from);
/*
 * Allocate memory for a new ECAssembly and copy 
 * the information from an existing structure
 * into it. Copies children too.
 */
DV_EXPORT ECAssembly *ECAssemblyList_Copy(ECAssembly *from);
DV_EXPORT ECAssembly *ECAssembly_ClipboardCopy(ECAssembly *from, ECZone *z, char *lib);
DV_EXPORT ECAssembly *ECAssemblyList_ClipboardCopy(ECAssembly *from, ECZone *z, char *lib);
DV_EXPORT ECAssembly *ECAssembly_ClipboardPaste(ECAssembly *from, void *tree, ECItemType type);
DV_EXPORT ECAssembly *ECAssemblyList_ClipboardPaste(ECAssembly *from, void *tree, ECItemType type);
DV_EXPORT int ECAssemblyList_AddAssembly(ECAssembly *newObj, ECAssembly *list);
/* Adds the object at an unspecified point in the list */
DV_EXPORT int ECAssemblyList_AddAssemblyToStart(ECAssembly **list, ECAssembly *newObj);
DV_EXPORT int ECAssemblyList_AddAssemblyToEnd(ECAssembly *list, ECAssembly *newObj);
/* Add a ECAssembly onto the end of a non-empty linked list of ECAssemblys */
DV_EXPORT int ECAssemblyLists_Join(ECAssembly **head, ECAssembly *tail);
DV_EXPORT void ECAssemblyTree_FixNameClash( ECAssembly *assem);
/* Join two linked lists of ECAssemblys together.
 * If *a points to a NULL object, it is set to point to
 * b, otherwise the end of the list a is set to point to b
 */

DV_EXPORT ECItem *ECAttribute_ClipboardCopy(ECItem *from);
DV_EXPORT ECItem *ECAttribute_ClipboardPaste(ECItem *from);

/* The next three functions are macros which actually use the fourth fn */
DV_EXPORT int ECAssembly_SetPosition(ECAssembly *, ECVec3 *);
DV_EXPORT int ECAssembly_SetOrientation(ECAssembly *, ECVec3 *);
DV_EXPORT int ECAssembly_SetScale(ECAssembly *, ECVec3 *);

DV_EXPORT int ECAssembly_SetPosOrScale(ECAssembly *object, float32 *p, float32 *o, float32 *s);
DV_EXPORT int ECAssembly_GetPosOrScale(ECAssembly *object, float32 *p, float32 *o, float32 *s);
DV_EXPORT int ECAssembly_SetName(ECAssembly *, char *name);
DV_EXPORT int ECAssembly_SetPathName(ECAssembly *, char *path);
DV_EXPORT int _ECAssembly_SetName(ECAssembly *object, char *name);
DV_EXPORT int _ECAssembly_SetPathName(ECAssembly *object, char *path);
DV_EXPORT int ECAssembly_SetLibraryName(ECAssembly *, char *libName);
DV_EXPORT int ECAssembly_SetDefn(ECAssembly *, ECAssembly *);
DV_EXPORT int ECAssembly_SetDefnName(ECAssembly *, char *);
DV_EXPORT int ECAssembly_SetParent(ECAssembly *, ECAssembly *);
DV_EXPORT int ECAssembly_SetPeer(ECAssembly *, ECAssembly *);
DV_EXPORT int ECAssembly_SetType(ECAssembly *, uint32 typeFlags);
DV_EXPORT int ECAssembly_SetClientData(ECAssembly *, void *data);
DV_EXPORT void *ECAssembly_GetClientData(ECAssembly *);
DV_EXPORT int ECAssembly_SetDistanceData(ECAssembly *, void *data);
DV_EXPORT void *ECAssembly_GetDistanceData(ECAssembly *);
DV_EXPORT int ECAssembly_SetFlags(ECAssembly *, uint32);
DV_EXPORT int ECAssembly_AddFlags(ECAssembly *ass, uint32 flags);
DV_EXPORT int ECAssembly_ClearFlags(ECAssembly *ass, uint32 flags);
DV_EXPORT int ECAssembly_SetVCEntity(ECAssembly *, VCEntity *);
DV_EXPORT int ECAssembly_SetRelocHan(ECAssembly *, void *);
DV_EXPORT int ECAssembly_SetDropAssembly(ECAssembly *, ECAssembly *);
DV_EXPORT int ECAssembly_SetDropEvent(ECAssembly *, uint32 *);
DV_EXPORT int ECAssembly_SetModeFlag(ECAssembly *, int16);
DV_EXPORT int ECAssembly_SetAttributes(ECAssembly *a, ECItem *l);
DV_EXPORT int ECAssembly_ApplyChanges(ECAssembly *orig, ECAssembly *changes);
DV_EXPORT int ECAssembly_AddAttribute(ECAssembly *ass, void *att);
DV_EXPORT int ECAssembly_AddItem(ECAssembly *ass, ECItem *item);
/*
 * This function should be used to add an Action to an event on the 
 * given ECAssembly. The function will ensure that only one ECAction of the
 * given type is present on the given event type. If this Action already
 * exists, a pointer to existing ECAction is returned. If this Action
 * does not exist, a new ECAction is created and added to the given
 * event type (the event is also created if not present). This 'empty'
 * action function should have its parameter list filled in by setting the
 * parameter (void *) pointers to allocated memory containing the necessary
 * values.
 * 
 * Hint:
 *      Use ECEvent_GetIdFromName and ECAction_FindNamedFunc to find the 
 * eventId and the afunc paramters to this function.
 */
DV_EXPORT ECEvent *ECAssembly_AddEvent(ECAssembly *object, int eventId);
DV_EXPORT ECAction *ECAssembly_AddEventActionFunc(ECAssembly *object, 
							 int eventId, ECActionFunc *afunc);
DV_EXPORT ECAction *ECAssembly_PropagateAction(ECAssembly *a, int eventId);
DV_EXPORT int32 ECAssembly_AddEventAction(ECAssembly *object, 
						     int eventId, ECAction *action);
DV_EXPORT int32 ECAssembly_RegisterEvents(ECAssembly *);
DV_EXPORT int32 ECAssembly_DeregisterEvents(ECAssembly *);
DV_EXPORT ECVec3 *ECAssembly_GetPosition(ECAssembly *object);
DV_EXPORT ECVec3 *ECAssembly_GetOrientation(ECAssembly *object);
DV_EXPORT ECVec3 *ECAssembly_GetScale(ECAssembly *object);
DV_EXPORT int ECAssembly_GetLocalPosition(ECAssembly *assembly, dmMatrix localMx);
DV_EXPORT int ECAssembly_GetAbsolutePosition(ECAssembly *assembly, dmMatrix absMx);
DV_EXPORT ECZone *ECAssembly_GetZone(ECAssembly *object);

DV_EXPORT int32 ECAssembly_SetState(ECAssembly *a, ECStateType st);
DV_EXPORT ECStateType ECAssembly_GetState(ECAssembly *a);
DV_EXPORT int32 ECAssembly_SetTickRate(ECAssembly *a, float32 tkr);
DV_EXPORT float32 ECAssembly_GetTickRate(ECAssembly *a);
DV_EXPORT int32 ECAssembly_SetAppZone(ECAssembly *a, void *az);
DV_EXPORT void *ECAssembly_GetAppZone(ECAssembly *a);
DV_EXPORT int32 ECAssembly_FindEventAction(ECAssembly *a, ECEvent **ev, ECAction **act, 
					int eventId, ECActionFunc *afunc);

DV_EXPORT int ECAssembly_IsTemplate(ECAssembly *);
DV_EXPORT int ECAssembly_IsOrContainsTemplate(ECAssembly *);
DV_EXPORT void ECAssembly_SetInstanceAttributes(ECAssembly *object);

/*
 * Below are a set of ECAssemblyCallback list handling routines
 * These are currently used to set up and execute the 
 * 'deleteCbList' on an ECAssembly. 
 */
void 
ECAssemblyCallbackListAddCallback(ECAssemblyCallbackList **callbackList, 
                                 ECAssemblyCallbackPtr callback, 
                                 void *calldata);
void *
ECAssemblyCallbackListGetCalldata(ECAssemblyCallbackList *thisCallbackList);
void 
ECAssemblyCallbackListRemove(ECAssemblyCallbackList **thisList);
void 
ECAssemblyCallbackListRemoveCallback(ECAssemblyCallbackList **listPtr, 
                                    ECAssemblyCallbackPtr callback,
                                    void *userdata);
void 
ECAssemblyCallbackListExecute(ECAssembly *ecAssembly, 
                             ECAssemblyCallbackList *cbList);


/* ================== Assembly collide list functions =================== */
pCLSN ECCreateCollideEntity( ECAssembly *, VCEntity *);
pCLSN ECInitialiseBlockCollideEntity( pCLSN *, pCLSN );
void ECDeleteCollideEntity( ECAssembly *, pCLSN );
pCLSN ECSearchCollideEntity( ECAssembly *, VCEntity *);
pCLSN ECAddCollideEntity( ECAssembly *, VCEntity *);
pCLSN ECFindFreeCollideEntity( ECAssembly * );
pCLSN ECLastCollideEntity( ECAssembly * );
void ECAwaitEventsCollideEntity( ECAssembly * );
void ECGarbageCollectCollideEntity( ECAssembly * );
void ECPrintallCollideEntity( ECAssembly * );
VCEntity *ECGetFirstCollideEntity( ECAssembly *, uint8 *, void ** );
VCEntity *ECGetNextCollideEntity( ECAssembly *, uint8 *, void ** );
/* ============== End of object collide list functions ================= */

DV_EXPORT ECAssemblyStatus ECAssembly_GetStatus(ECAssembly *object);
DV_EXPORT ECAssembly *ECAssembly_GetRef(ECAssembly *ass);
DV_EXPORT uint32 ECAssembly_GetFlags(ECAssembly *a);
DV_EXPORT VCEntity *ECAssembly_GetVCEntity(ECAssembly *a);
DV_EXPORT void *ECAssembly_GetRelocHan(ECAssembly *a);
DV_EXPORT ECAssembly *ECAssembly_GetDropAssembly(ECAssembly *a);
DV_EXPORT uint32 *ECAssembly_GetDropEvent(ECAssembly *a);
DV_EXPORT int16 ECAssembly_GetModeFlag(ECAssembly *a);
DV_EXPORT ECInstanceType ECAssembly_GetInstanceType(ECAssembly *a);
DV_EXPORT ECComment *ECAssembly_GetComment(ECAssembly *object, ECItem **traverse);
DV_EXPORT char *ECAssembly_GetName(ECAssembly *object);
DV_EXPORT char *ECAssembly_GetPathName(ECAssembly *object);
DV_EXPORT char *ECAssembly_GetLibraryName(ECAssembly *a);
DV_EXPORT ECAssembly *ECAssembly_GetDefn(ECAssembly *object);
DV_EXPORT char *ECAssembly_GetDefnName(ECAssembly *object);
DV_EXPORT ECItem *ECAssembly_GetAttributes(ECAssembly *object);
DV_EXPORT ECItem * ECAssembly_GetInstanceList(ECAssembly *assem);
DV_EXPORT void ECAssembly_SetInstanceList(ECAssembly *assem, ECItem* list);
DV_EXPORT ECStateType ECAssembly_GetCollide(ECAssembly *object);
DV_EXPORT ECCollision *ECAssembly_GetCollision(ECAssembly *object, ECItem **traverse);
DV_EXPORT ECCollision *ECAssembly_GetNamedCollision(ECAssembly *object, char *name);
DV_EXPORT ECConstraints *ECAssembly_GetConstraints(ECAssembly *object);
DV_EXPORT ECPivot *ECAssembly_GetPivot(ECAssembly *object);
DV_EXPORT ECIcon *ECAssembly_GetIcon(ECAssembly *object);
DV_EXPORT ECAudio *ECAssembly_GetAudio(ECAssembly *object, ECItem **traverse);
DV_EXPORT ECAudio *ECAssembly_GetNamedAudio(ECAssembly *object, char *name);
DV_EXPORT ECItem *ECAssembly_GetItemList(ECAssembly *object);
DV_EXPORT ECItem **ECAssembly_GetItemListPtr(ECAssembly *object);
DV_EXPORT ECKeyFrames *ECAssembly_GetKeyFrames(ECAssembly *object, ECItem **traverse);
DV_EXPORT ECKeyFrames *ECAssembly_GetNamedKeyFrames(ECAssembly *object, char *name);
DV_EXPORT ECLight *ECAssembly_GetLight(ECAssembly *object, ECItem **traverse);
DV_EXPORT ECLight *ECAssembly_GetNamedLight(ECAssembly *object, char *name);
DV_EXPORT ECPhysical* ECAssembly_GetPhysical(ECAssembly *object);
DV_EXPORT ECPosition *ECAssembly_GetPositionAttribute(ECAssembly *);
DV_EXPORT ECVisual *ECAssembly_GetVisual(ECAssembly *object, ECItem **traverse);
DV_EXPORT ECVisual *ECAssembly_GetNamedVisual(ECAssembly *object, char *name);
DV_EXPORT ECUserData *ECAssembly_GetNamedUserData(ECAssembly *object, char *name);
DV_EXPORT ECUserData *ECAssembly_GetUserData(ECAssembly *object);
DV_EXPORT ECEventList *ECAssembly_GetEventList(ECAssembly *object);
DV_EXPORT ECEvent *ECAssembly_GetEvents(ECAssembly *object);
DV_EXPORT ECVec3 *ECAssembly_GetSnapTrans(ECAssembly *object);
DV_EXPORT ECVec3 *ECAssembly_GetSnapRot(ECAssembly *object);
DV_EXPORT ECAssembly *ECAssembly_GetChild(ECAssembly *object);
DV_EXPORT ECAssembly *ECAssembly_GetParent(ECAssembly *object);
DV_EXPORT ECAssembly *ECAssembly_GetDefinition(ECAssembly *object);
DV_EXPORT int ECAssembly_GetDefinitionInfo(ECAssembly *o,
                      char **libraryName,
                      char **definitionName);
DV_EXPORT ECFile *ECAssembly_GetFile(ECAssembly *a);
DV_EXPORT int32 ECAssembly_SetFile(ECAssembly *a, ECFile *f);
DV_EXPORT char *ECAssembly_GetFileName(ECAssembly *a);
DV_EXPORT int ECAssembly_CheckForMaterials(ECAssembly *lib);
DV_EXPORT int32 ECAssembly_IsMaterialLibrary(ECAssembly *assem);
DV_EXPORT ECLibrary *EC_FindMaterialLibrary(char *name, char *fileName);
DV_EXPORT ECAssembly *ECAssembly_GetPeer(ECAssembly *object);
DV_EXPORT uint32 ECAssembly_GetType(ECAssembly *object);
DV_EXPORT ECItem *ECAssembly_GetItemList(ECAssembly *object);
DV_EXPORT int ECAssembly_MakeNonInstance( ECAssembly *assem );
DV_EXPORT int ECAssembly_IsChildInstance(ECAssembly *object);
DV_EXPORT int ECAssembly_IsRootInstance(ECAssembly *object);
DV_EXPORT ECAssembly *ECAssembly_GetRootInstance(ECAssembly *childInstance);

DV_EXPORT ECEvent *ECAssembly_FindEvent(ECAssembly *object, int eventType);
/* Returns the first matched event by type for this object or NULL if none */
DV_EXPORT ECEvent *ECAssembly_GetNextEvent(ECAssembly *, ECEvent *);

/* If event is NULL this returns the first event in the object's
 * event list, otherwise it returns event->next
 */
DV_EXPORT int ECAssembly_EndDefinition(ECAssembly **, ECZone **);
/* ECAssembly_EndDefinition changes the object pointer, either:
 *     to a parent if one exists,
 *     otherwise to NULL if object wasn't already,
 *     in which case zone is set to NULL
 *     and returns non-zero if and only if both object and zone NULL
 */
DV_EXPORT int ECAssembly_NamesEquate(ECAssembly *, char *name);
/* Check for a match between object names.
 * If the object given is an instance then it checks
 * to see if object->name = name.number
 * otherwise it checks for a simple match.
 */
DV_EXPORT void ECAssemblyList_Operate(ECAssembly *, int (*)(ECAssembly *, void *) /* proc */, void *user_data);
/* Apply procedure proc to each EC object in a non-empty linked list.
 * Executes proc(object, user_data) for each object in the list and all the children
 * in a depth first order
 */
DV_EXPORT void ECAssemblyTree_Operate(ECAssembly *o, int (*proc)(ECAssembly *, void *), 
				void *user_data);
DV_EXPORT void ECAssemblyList_Operate2(ECAssembly *, int (*proc)(ECAssembly *));
DV_EXPORT void ECAssemblyTree_Operate2(ECAssembly *o, int (*proc)(ECAssembly *));
/* As above except without userData:  to avoid prototype whinging.*/
DV_EXPORT void ECAssemblyList_Operate3(ECAssembly *, int (*proc)(ECAssembly *, void *), void *user_data);
DV_EXPORT void ECAssemblyTree_Operate3(ECAssembly *o, int (*proc)(ECAssembly *, void *), void *user_data);
/* As operate except will not operate on children if func returns VC_ERR.*/
DV_EXPORT ECItem *ECAssemblyList_GenerateInstanceList(ECItem *templateAssemlies, ECItem *rootSearchList, 
                                                      int searchChildren, int displayChildren);
/* given list of templates, return instances that exist, if searchChildren then
 * also return instances of templates children, if displayChildren then
 * return instance matches that are children of other instance matches */
DV_EXPORT void EC_DefinitionsOperate(void (*proc)(ECAssembly *, void *), void *data);
/* Operates proc on each (toplevel) definition object from all the
 * defined libraries.
 */
DV_EXPORT void EC_DefinitionsOperate2(void (*proc)(ECAssembly *));
/* Operates proc on each (toplevel) definition object from all the
 * defined libraries.
 */
DV_EXPORT int ECAssembly_DefineUserData(char *name, int type);
/* Set up a definition of a user data item */
DV_EXPORT int ECAssemblyList_DiffersFromDefinition(ECAssembly *o);
DV_EXPORT int ECFile_RegisterUserDataSyntax(char *filename);
DV_EXPORT char *ECAssembly_FixAnyNameClash(ECAssembly *prnt, char *name, 
                                           int modfr, ECItemType type);
DV_EXPORT char *ECAssembly_ForceFixAnyNameClash(ECAssembly *prnt, char *name, 
                                           int modfr, ECItemType type);
DV_EXPORT int ECAssembly_NameClash(ECAssembly *parent, char *name, ECItemType type);

/* ========================= Physical functions ========================= */

DV_EXPORT ECPhysical* ECPhysical_Allocate(void);
DV_EXPORT int32 ECPhysical_Destroy(ECPhysical* );
DV_EXPORT int32 ECPhysical_SetName(ECPhysical* , char *name);
DV_EXPORT int32 ECPhysical_SetDefinition(ECPhysical*, ECPhysical*);
DV_EXPORT int32 ECPhysical_SetLibraryName(ECPhysical* , char *name);
DV_EXPORT char *ECPhysical_CheckLibName(ECPhysical*);
DV_EXPORT int32 ECPhysical_GetDynamicsData(ECPhysical* p, uint32 *mode, float32 *imass, float32 *gmass, 
			  dmPoint centre, float32 *iTensor, float32 *spring, 
			  float32 *damper, float32 *sFriction, float32 *dFriction);
DV_EXPORT int32 ECPhysical_SetDynamicsData(ECPhysical* p, uint32 *mode, float32 *imass, float32 *gmass,
			  dmPoint centre, float32 *iTensor, float32 *spring, 
			  float32 *damper, float32 *sFriction, float32 *dFriction);
DV_EXPORT int32 ECPhysical_GetDynamicsGMass(ECPhysical* p, float32 *mass);
DV_EXPORT int32 ECPhysical_SetDynamicsGMass(ECPhysical* p, float32 mass);
DV_EXPORT ECStateType ECPhysical_GetDynamicsState(ECPhysical*);
DV_EXPORT int ECPhysical_SetDynamicsState(ECPhysical*, ECStateType);
DV_EXPORT ECStateType ECPhysical_GetGravityState(ECPhysical*);
DV_EXPORT int ECPhysical_SetGravityState(ECPhysical*, ECStateType);
DV_EXPORT ECStateType ECPhysical_GetForceState(ECPhysical*);
DV_EXPORT int ECPhysical_SetForceState(ECPhysical*, ECStateType);
DV_EXPORT int ECPhysical_GetForceData(ECPhysical* p, uint32 *mode, dmVector force, dmPoint point);
DV_EXPORT int ECPhysical_SetForceData(ECPhysical* p, uint32 *mode, dmVector force, dmPoint point);
DV_EXPORT int ECPhysical_GetGravityData(ECPhysical* p, uint32 *mode, dmVector direction, float32 *gravity);
DV_EXPORT int ECPhysical_SetGravityData(ECPhysical* p, uint32 *mode, dmVector direction, float32 *gravity);
DV_EXPORT int32 ECPhysical_SetGravityMagnitude(ECPhysical* p, float32 gravity);
DV_EXPORT int32 ECPhysical_GetGravityMagnitude(ECPhysical* p, float32 *gravity);
DV_EXPORT int32 ECPhysical_SetGravityDirection(ECPhysical* p, dmVector dir);
DV_EXPORT int32 ECPhysical_GetGravityDirection(ECPhysical* p, dmVector dir);
DV_EXPORT ECPhysical* ECPhysical_GetDefinition(ECPhysical* c);
DV_EXPORT ECItem * ECPhysical_GetInstanceList(ECPhysical *c);
DV_EXPORT char *ECPhysical_GetName(ECPhysical* c);
DV_EXPORT char *ECPhysical_GetLibraryName(ECPhysical* c);
DV_EXPORT int32 ECPhysical_ApplyChanges(ECPhysical* orig, ECPhysical* changes);
DV_EXPORT int32 ECPhysical_CopyDefined(ECPhysical* def, ECPhysical* newPhys);
DV_EXPORT ECPhysical* ECPhysical_Copy(ECPhysical* from);
DV_EXPORT int32 ECPhysical_SetVCDynamics(ECPhysical* p, VCAttribute *vcAttr);
DV_EXPORT VCAttribute *ECPhysical_GetVCDynamics(ECPhysical* p);
DV_EXPORT int32 ECPhysical_SetVCPseudoGravity(ECPhysical* p, VCPseudoGravity *vcGrav);
DV_EXPORT VCPseudoGravity *ECPhysical_GetVCPseudoGravity(ECPhysical* p);
DV_EXPORT int32 ECPhysical_SetVCForce(ECPhysical* p, VCAttribute *vcAttr);
DV_EXPORT VCAttribute *ECPhysical_GetVCForce(ECPhysical* p);
DV_EXPORT int ECPhysicals_Differ(ECPhysical* a, ECPhysical* b);

/* ========= Old Zone functions (now Assembly functions) =========== */

DV_EXPORT ECZone *EC_GetTopZone(void);
DV_EXPORT void EC_SetTopZone(ECZone *zone);
DV_EXPORT char *EC_GetTopZoneName(void);
DV_EXPORT ECLibrary *EC_GetTopLib(void);
DV_EXPORT void EC_SetTopLib(ECLibrary *lib);
DV_EXPORT char *EC_GetTopLibName(void);

DV_EXPORT char *EC_AssemblyInstanceName(ECZone *zone, char *rootName, char instType);
DV_EXPORT ECAssembly *EC_FindNamedAssembly(char *name);
DV_EXPORT ECAssembly *ECTopZone_FindNamedAssembly(char *name, int strict);
DV_EXPORT int32 ECAssembly_SetTickRate(ECZone *, float32 rate);
/* Sets the frame rate field of a zone structure (used
 * in animation) if the zone pointer is not NULL.
 */

DV_EXPORT float32 ECAssembly_GetTickRate(ECZone *zone);
DV_EXPORT char *EC_GetUniqueAssemblyName(ECZone *z, char *basename);

/* ====================== Position functions======================= */

DV_EXPORT ECPosition *ECPosition_Allocate(void);
DV_EXPORT ECPosition *ECPosition_Copy(ECPosition *def);
DV_EXPORT int32 ECPosition_Destroy(ECPosition *);
DV_EXPORT int32 ECPosition_UpdatePosition(ECPosition **pos, ECPosition *def, 
				     ECVec3 *newPosition);
DV_EXPORT int32 ECPosition_UpdateOrientation(ECPosition **pos, ECPosition *def, 
					ECVec3 *newOrientation); 
DV_EXPORT int32 ECPosition_UpdateScale(ECPosition **pos, ECPosition *def, 
				  ECVec3 *newScale); 
DV_EXPORT int32 ECPosition_ApplyChanges(ECPosition **orig, ECPosition *def, 
				   ECPosition *changes);
DV_EXPORT int ECPositions_Differ(ECPosition *a, ECPosition *b);

/* ======================= Vector functions ======================= */

DV_EXPORT ECVec3 *ECVector_Allocate(void);
/* returns a pointer to a new zero vector */
DV_EXPORT ECVec3 *ECVector_Create(float32 x, float32 y, float32 z);
/* returns a pointer to a new vector (x, y, z) */
DV_EXPORT ECVec3 *ECVector_Copy(ECVec3 *orig);
DV_EXPORT ECColour *ECColour_Allocate(void);
/* returns a pointer to a new zero colour */
DV_EXPORT ECColour *ECColour_Create(float32 r, float32 g, float32 b);
/* returns a pointer to a new colour (r, g, b) */
DV_EXPORT ECColour *ECColour_Copy(ECColour *orig);
DV_EXPORT int32 ECVector_ApplyChanges(ECVec3 *orig, ECVec3 *changes);
DV_EXPORT int32 ECColour_ApplyChanges(ECColour *orig, ECColour *changes);
DV_EXPORT int32 ECVector_Destroy(ECVec3 *);
DV_EXPORT int32 ECColour_Destroy(ECColour *);
DV_EXPORT int ECVector_NotZero(ECVec3 *);
/* is this vector not exactly (0., 0., 0.)? */
DV_EXPORT int ECVector_NotUnit(ECVec3 *);
/* is this vector not exactly (1., 1., 1.)? */
DV_EXPORT int ECVectors_NotEqual(ECVec3 *, ECVec3 *);
/* are these two vectors not identical? */
/* result->x=vec1.x/vec.2; etc */
DV_EXPORT int ECFloatArraysDiffer(float32 *a, float32 *b, int n);
DV_EXPORT int ECVectors_Differ(ECVec3 *vec1, ECVec3 *vec2, float32 val);
/* as ECVectors_NotEqual but a null pointer counts as  vector (val, val, val) */
DV_EXPORT int ECColours_NotEqual(ECColour *, ECColour *);
/* are these two colours not identical? */
DV_EXPORT int ECColours_Differ(ECColour *col1, ECColour *col2, float32 val);
/* as ECColours_NotEqual but a null pointer counts as colour (val, val, val) */
DV_EXPORT int ECColour_NotZero(ECColour *);
/* is this colour not exactly (0., 0., 0.)? */
DV_EXPORT int ECColour_NotDefault(ECColour *);
/* is this colour not exactly (-1., 0., 0.)? */
DV_EXPORT int ECVector_NotNearlyZero(ECVec3 *vec);
DV_EXPORT int ECVector_NotNearlyUnit(ECVec3 *vec);
DV_EXPORT int ECVectors_NotNearlyEqual(ECVec3 *vec1, ECVec3 *vec2);
DV_EXPORT int ECColours_NotNearlyEqual(ECColour *vec1, ECColour *vec2);
DV_EXPORT int32 ECVector_Subtract(ECVec3 *vec1, ECVec3 *vec2, ECVec3 *result);
/* result->x=vec1.x-vec2.x; etc */
DV_EXPORT int32 ECVector_Add(ECVec3 *vec1, ECVec3 *vec2, ECVec3 *result);
/* result->x=vec1.x+vec2.x; etc */
DV_EXPORT int32 ECVector_Divide(ECVec3 *vec1, ECVec3 *vec2, ECVec3 *result);

/* ===================== Visual functions ===================== */

DV_EXPORT ECVisual *ECVisual_Allocate(void);
/* Allocate space for a new ec visual structure.
 * Sets the fColour.r and bColour.r values to -1 and the rest
 * of the memory is blanked.
 */
DV_EXPORT int ECVisual_Destroy(ECVisual *);
DV_EXPORT ECVisual *ECVisual_Copy(ECVisual *from);
/*
 * Allocate memory for a new ECVisual and copy 
 * the information from an existing structure
 * into it
 */
DV_EXPORT int ECVisual_CopyDefined(ECVisual *def, ECVisual *newVis);
DV_EXPORT int ECVisual_SetName(ECVisual *, char *name);
DV_EXPORT int ECVisual_SetFrontMaterial(ECVisual *, char *);
DV_EXPORT int ECVisual_SetBackMaterial(ECVisual *, char *);
DV_EXPORT int ECVisual_OverideFrontMaterial(ECVisual *, char *);
DV_EXPORT int ECVisual_OverideBackMaterial(ECVisual *, char *);
DV_EXPORT int ECVisual_DontOverideFrontMaterial(ECVisual *);
DV_EXPORT int ECVisual_DontOverideBackMaterial(ECVisual *);
DV_EXPORT int ECVisual_SetGeometryFilename(ECVisual *, char *name);
/* For a non-null visual, set the geometry filename */
DV_EXPORT int ECVisual_SetState(ECVisual *, ECStateType);
/* For a non-null visual, set the visibility flag */
DV_EXPORT int ECVisual_SetAll (ECVisual *vis, char *geometry, uint32 setMode,
                         uint32 clearMode, char *lod, char *frontMaterial,
                         char *backMaterial, uint32 *intersectMask);
DV_EXPORT int ECVisual_SetLod(ECVisual *, char *lod);
DV_EXPORT int ECVisual_SetIntersectMask(ECVisual *v, int mask);
DV_EXPORT char *ECVisual_CheckLibName(ECVisual *);
DV_EXPORT char *ECVisual_GetName(ECVisual *);
DV_EXPORT char *ECVisual_GetGeometryFilename(ECVisual *visual);
DV_EXPORT char *ECVisual_GetFrontMaterial(ECVisual *visual);
DV_EXPORT char *ECVisual_GetBackMaterial(ECVisual *visual);
DV_EXPORT char *ECVisual_GetFrontOverideMaterial(ECVisual *visual);
DV_EXPORT char *ECVisual_GetBackOverideMaterial(ECVisual *visual);
DV_EXPORT ECStateType ECVisual_GetState(ECVisual *visual);
DV_EXPORT char *ECVisual_GetLod(ECVisual *);
DV_EXPORT int ECVisual_GetIntersectMask(ECVisual *v, int *mask);
DV_EXPORT int ECVisuals_Differ(ECVisual *a, ECVisual *b);
DV_EXPORT int ECVisual_ApplyChanges(ECVisual *orig, ECVisual *changes);
DV_EXPORT int ECVisual_SetMode(ECVisual *visual, uint32 mode);
DV_EXPORT int ECVisual_ModifyMode(ECVisual *v, uint32 setMode, uint32 clearMode);
DV_EXPORT uint32 ECVisual_GetMode(ECVisual *visual);
DV_EXPORT int ECVisual_SetStatic(ECVisual *, ECStateType);
DV_EXPORT ECStateType ECVisual_GetStatic(ECVisual *);
DV_EXPORT VCAttribute *ECVisual_GetVCAttribute(ECVisual *visual);
DV_EXPORT int ECVisual_SetVCAttribute(ECVisual *visual, VCAttribute *attr);
DV_EXPORT int ECVisualSetVCAttribute(ECVisual *visual, VCAttribute *attr);

/* ========================= List functions ======================== */

DV_EXPORT ECList *ECList_Allocate(void);
DV_EXPORT int32 ECList_Destroy(ECList *);
DV_EXPORT int32 ECList_SetName(ECList *c, char *n);
DV_EXPORT char *ECList_GetName(ECList *);
DV_EXPORT int32 ECList_AddItem(ECList *list, ECItem *item);
DV_EXPORT int32 ECList_CopyDefined(ECList *def, ECList *newList);
DV_EXPORT ECList *ECList_Copy(ECList *from);
/*
 * Allocate memory for a new ECList and copy 
 * the information from an existing structure
 * into it
 */
DV_EXPORT int32 ECList_ApplyChanges(ECList *orig, ECList *changes);

/* ======================= Dynamic List functions ==================== */

DV_EXPORT pCLSN ECdList_CreateEntry(pCLSN *pList, void *data);
DV_EXPORT pCLSN ECdList_FindFreeSlot(pCLSN *pList);
DV_EXPORT pCLSN ECdList_InitialiseBlockOfCells(pCLSN *pList, pCLSN block);
DV_EXPORT void ECdList_DeleteEntry(pCLSN *pList, pCLSN pCell);
DV_EXPORT pCLSN ECdList_FindEntry(pCLSN *pList, void *data);
DV_EXPORT pCLSN ECdList_GetLastEntry(pCLSN *pList);
DV_EXPORT void ECdList_GlobalModifyFlags(pCLSN *pList, uint8 setFlags, uint8 clearFlags);
DV_EXPORT pCLSN ECdList_AddEntry(pCLSN *pList, void *data);
DV_EXPORT pCLSN ECdList_AddEntryToStart(pCLSN *pList, void *data);
DV_EXPORT void ECdList_GarbageCollect(pCLSN *pList);
DV_EXPORT void ECdList_Debug(pCLSN *pList);
DV_EXPORT void *ECdList_GetFirstEntry(pCLSN *pList, uint8 *flags, pCLSN *ppCell);
DV_EXPORT void *ECdList_GetNextEntry(pCLSN *pList, uint8 *flags, pCLSN *ppCell);

/* ================= Assembly chain based functions ================== */

/* A ECAssemblyChain can be used to link ec objects
 * together without affecting their original hierarchies.
 * The chain structure is the head of the list, having a
 * name, a pointer to "next" (so chains can be stored
 * in linked lists) and a pointer to the chains links.
 * Each link is a ECAssemblyLink structure.
 */
DV_EXPORT ECAssemblyChain *ECAssemblyChain_Create(char *name);
DV_EXPORT ECAssemblyLink *ECAssemblyLink_Create(ECAssembly *object);
DV_EXPORT int32 ECAssemblyChain_AddAssembly(ECAssemblyChain *chain, ECAssembly *object);
DV_EXPORT ECAssembly *ECAssemblyChain_FindNamedAssembly(ECAssemblyChain *chain, char *name);
DV_EXPORT int32 ECAssemblyChain_FindAssemblyPtr(ECAssemblyChain *, ECAssembly *);
DV_EXPORT int32 ECAssemblyChain_AddLink(ECAssemblyChain *chain, ECAssemblyLink *link);
DV_EXPORT int32 ECAssemblyChain_AddAssemblyChain(ECAssemblyChain *dest, ECAssemblyChain *src);
/* Concatenate two object chains, storing the new chain in the first given */
DV_EXPORT int32 ECAssemblyChainList_AddAssemblyChain(ECAssemblyChain **head, 
					     ECAssemblyChain *newOC);
/* Adds a new object chain to the end of a list of chains.
 * As the new chain is added to the end, it can be a linked list itself
 * so this function can join two lists of chains.
 */
DV_EXPORT ECAssemblyChain *ECAssemblyChain_FindNamed(char *name, ECAssemblyChain *chainList);
DV_EXPORT int32 ECAssemblyChain_AddAssemblyChain(ECAssemblyChain *dest, ECAssemblyChain *src);
DV_EXPORT ECAssemblyChain *ECAssemblyChains_CopyAssembly(ECAssemblyChain *src);
DV_EXPORT ECAssemblyChain *ECAssemblyChain_BuildFromAssemblyList(char *name, ECAssembly *first,
						       int (*func)(ECAssembly *));
DV_EXPORT ECAssemblyChain *ECAssemblyChain_BuildFromZoneTree(char *name, ECZone *zone,
						     int (*func)(ECAssembly *));
DV_EXPORT ECAssemblyChain *ECAssemblyChain_BuildFromZoneList(char *name, ECZone *zone,
						     int (*func)(ECAssembly *));
DV_EXPORT int ECAssemblyChain_DeleteLink(ECAssemblyChain *chain, ECAssembly *object);
DV_EXPORT int ECNamedAssembly_ChainRemove(char *name, ECAssemblyChain **list);
/* Removes the named chain from a list and destroys it.
 * Returns 1 if the named chain was found and removed, 0 if not.
 */
DV_EXPORT int32 ECAssemblyChain_Destroy(ECAssemblyChain *chain);
DV_EXPORT int ECAssemblyChain_FoundAssembly(ECAssemblyChain *chain, ECAssembly *object);
DV_EXPORT ECAssemblyChain *ECAssemblyChainList_FoundAssembly(ECAssemblyChain *chain,
						   ECAssembly *object);
DV_EXPORT void ECAssemblyChain_Operate(ECAssemblyChain *chain, 
				 void (*func)(ECAssembly *, void *), void *data);

/* ===================== Role chain functions ===================== */

DV_EXPORT ECRoleChain *ECRoleChain_Create(ECRole *role);
DV_EXPORT int32 ECRoleChain_AddRole(ECRoleChain **chain, ECRole *role);
DV_EXPORT ECRole *ECRoleChain_FindNamedRole(ECRoleChain *chain, char *name);
DV_EXPORT int32 ECRoleChain_Destroy(ECRoleChain *chain);
DV_EXPORT int32 ECRoleChain_Operate(ECRoleChain *chain,
			       void (*func)(ECRole *, void *), void *data);

/* ======================== Tools functions ======================= */

DV_EXPORT ECTools *ECTools_Allocate(void);
DV_EXPORT int32 ECTools_Destroy(ECTools *);
DV_EXPORT int32 ECTools_SetName(ECTools *, char *name);
DV_EXPORT int32 ECTools_SetFile(ECTools *, char *file);
DV_EXPORT int32 ECTools_SetState(ECTools *, ECStateType state);
DV_EXPORT char *ECTools_GetName(ECTools *c);
DV_EXPORT char *ECTools_GetFile(ECTools *c);
DV_EXPORT ECStateType ECTools_GetState(ECTools *c);
DV_EXPORT int32 ECTools_CopyDefined(ECTools *def, ECTools *newTools);
DV_EXPORT ECTools *ECTools_Copy(ECTools *from);
/*
 * Allocate memory for a new ECTools and copy 
 * the information from an existing structure
 * into it
 */

/*=============== KeyFrames functions and frames functions ============== */

DV_EXPORT int32 ECKeyFrames_CalculateInitArcLengths(ECKeyFrames *keyFrames);
/* run through the linked list of frames and calculate the length of the 
 * paths between them IF they are using CATMULL ROM path interpolation.
 */
DV_EXPORT float32 ArcIntegrand(float32 u, dmPoint cp0, dmPoint cp1, 
			    dmPoint cp2,  dmPoint cp3);
DV_EXPORT float32 ArcLength(float32 ustart, float32 uend, uint32 n, dmPoint cp0, 
			 dmPoint cp1, dmPoint cp2,  dmPoint cp3);
DV_EXPORT float32 calc_arc_length(dmPoint cp0, dmPoint cp1, dmPoint cp2, dmPoint cp3);
/* The above three fns are utility functions to calculate arc lengths */
DV_EXPORT ECKeyFrames *ECKeyFrames_Allocate(void);
DV_EXPORT ECKeyFrames *ECKeyFrames_CreateFromSplineFile(char *filename);
/* Creates a key frame sequence from a spline path file */
DV_EXPORT char *ECKeyFrames_CheckLibName(ECKeyFrames *);
DV_EXPORT int ECKeyFrames_Differ(ECKeyFrames *a, ECKeyFrames *b);
DV_EXPORT int ECKeyFrames_Destroy(ECKeyFrames *);
DV_EXPORT int ECKeyFrames_CopyDefined(ECKeyFrames *def, ECKeyFrames *newKF);
DV_EXPORT ECKeyFrames *ECKeyFrames_Copy(ECKeyFrames *from);
/*
 * Allocate memory for a new ECKeyFrames and copy 
 * the information from an existing structure
 * into it
 */
DV_EXPORT int ECKeyFrames_AppendFrame(ECKeyFrames *, ECFrame *);
DV_EXPORT int ECKeyFrames_InsertFrame(ECFrame *newFrame, ECFrame *prevFrame);
DV_EXPORT int ECKeyFrames_AddPreStart(ECKeyFrames *, ECFrame *);
DV_EXPORT int ECKeyFrames_AddPostEnd(ECKeyFrames *, ECFrame *);
DV_EXPORT int ECKeyFrames_SetDummyFrames(ECKeyFrames *);
DV_EXPORT int ECKeyFrames_SetUpFrameTimes(ECKeyFrames *keyFrames);
DV_EXPORT int ECKeyFrames_SetUpFrameScales(ECKeyFrames *keyFrames);
DV_EXPORT int ECKeyFrames_AddUpdateCallback(ECKeyFrames *ecKeyFrame, 
                                        ECKeyFrameUpdateCbPtr callback,
                                        void *calldata);
DV_EXPORT int ECKeyFrames_RemoveUpdateCallback(ECKeyFrames *ecKeyFrame,
                                           ECKeyFrameUpdateCbPtr callback, 
                                           void *userdata);
DV_EXPORT int ECKeyFrames_RemoveAllUpdateCallbacks(ECKeyFrames *ecKeyFrame);

DV_EXPORT float32 ECKeyFrames_GetLoopElapsedTime(ECKeyFrames *keyFrames);

/* These functions set any frame times (scales or orientations) for frames within 
 * the linked list of frame structures in this ECKeyFrames that do not have
 * a time specifically set.  The first frame will be set to time 0 
 * (identity scale / orientation) and the last set to the total time as specified
 * in the key frames section (or the last explicitly specified scale / orientation.
 * Any intermediate frames whose times have not been set have their time values set to
 * split the time gaps evenly.
 */
DV_EXPORT void slerp(dmQuaternion p, dmQuaternion q, float32 t, dmQuaternion qt);
/* utility fn for interpolating between two dmQuaternions */

#ifdef COMMENTED_OUT
DV_EXPORT void ECKeyFrames_SetPointOffset(ECKeyFrames *keyFrames, dmPoint pnt);
DV_EXPORT int  ECKeyFrames_GetPointOffset(ECKeyFrames *keyFrames, dmPoint pnt);
DV_EXPORT void ECKeyFrames_SetOrientationOffset(ECKeyFrames *keyFrames, dmQuaternion quat);
DV_EXPORT int  ECKeyFrames_GetOrientationOffset(ECKeyFrames *keyFrames, dmQuaternion quat);
#endif /* COMMENTED_OUT */

DV_EXPORT int ECKeyFrames_SetName(ECKeyFrames *, char *name);
DV_EXPORT char *ECKeyFrames_GetName(ECKeyFrames *);
DV_EXPORT char *ECKeyFrames_GetDefName(ECKeyFrames *);
DV_EXPORT int ECKeyFrames_SetLoop(ECKeyFrames *, int loop);
DV_EXPORT int ECKeyFrames_GetLoop(ECKeyFrames *);
DV_EXPORT int ECKeyFrames_SetTotalTime(ECKeyFrames *, float32 totalTime);
DV_EXPORT float32 ECKeyFrames_GetTotalTime(ECKeyFrames *);
DV_EXPORT int ECKeyFrames_SetTimeOffset(ECKeyFrames *, float32 timeOffset);
DV_EXPORT float32 ECKeyFrames_GetTimeOffset(ECKeyFrames *);
DV_EXPORT int ECKeyFrames_SetTimeStarted(ECKeyFrames *, float32 timeStarted);
DV_EXPORT float32 ECKeyFrames_GetTimeStarted(ECKeyFrames *);
DV_EXPORT int ECKeyFrames_TimeStartedIsValid(ECKeyFrames *);
DV_EXPORT int ECKeyFrames_SetTimeStartedInvalid(ECKeyFrames *);
DV_EXPORT int ECKeyFrames_GetCompleted(ECKeyFrames *keyFrames);
DV_EXPORT int ECKeyFrames_SetCompleted(ECKeyFrames *keyFrames, int newState);
DV_EXPORT int ECKeyFrames_SetTimeElapsed(ECKeyFrames *, float32 timeElapsed);
DV_EXPORT float32 ECKeyFrames_GetTimeElapsed(ECKeyFrames *);
DV_EXPORT int ECKeyFrames_TimeElapsedIsValid(ECKeyFrames *);
DV_EXPORT int ECKeyFrames_SetTimeScalar(ECKeyFrames *, float32 speed);
DV_EXPORT float32 ECKeyFrames_GetTimeScalar(ECKeyFrames *);
DV_EXPORT int ECKeyFrames_SetStartTime(ECKeyFrames *keyFrames, float32 startTime);
DV_EXPORT float32 ECKeyFrames_GetStartTime(ECKeyFrames *keyFrames);
DV_EXPORT int ECKeyFrames_StartTimeIsValid(ECKeyFrames *keyFrames);
DV_EXPORT ECPositionMode ECKeyFrames_GetMode(ECKeyFrames *keyFrames);
DV_EXPORT int ECKeyFrames_SetMode(ECKeyFrames *keyFrames, ECPositionMode mode);
DV_EXPORT int ECKeyFrames_InitialiseState(ECKeyFrames *keyFrames, ECStateType state);
DV_EXPORT ECStateType ECKeyFrames_GetState(ECKeyFrames *keyFrames);
DV_EXPORT int ECKeyFrames_ApplyChanges(ECKeyFrames *orig, ECKeyFrames *changes);
DV_EXPORT int ECKeyFrames_SetPathInterpolationType(ECKeyFrames *, ECPathInterpolationType);
DV_EXPORT int ECKeyFrames_SetSpeedInterpolationType(ECKeyFrames *, ECSpeedInterpolationType);
DV_EXPORT ECPathInterpolationType ECKeyFrames_GetPathInterpolationType(ECKeyFrames *);
DV_EXPORT ECPathInterpolationType ECKeyFrames_GetTruePathInterpolationType(ECKeyFrames *keyFrames);
DV_EXPORT ECSpeedInterpolationType ECKeyFrames_GetSpeedInterpolationType(ECKeyFrames *);
DV_EXPORT ECSpeedInterpolationType ECKeyFrames_GetTrueSpeedInterpolationType(ECKeyFrames *keyFrames);
DV_EXPORT ECFrame *ECKeyFrames_GetFirstFrame(ECKeyFrames *);
DV_EXPORT ECFrame *ECKeyFrames_GetLastFrame(ECKeyFrames *);
DV_EXPORT uint32 ECKeyFrames_GetFlags(ECKeyFrames *keyFrames);
DV_EXPORT int ECKeyFrames_SetFlags(ECKeyFrames *keyFrames, uint32 setBitMask);
DV_EXPORT int ECKeyFrames_ClearFlags(ECKeyFrames *keyFrames, uint32 clearBitMask);
DV_EXPORT ECFrame *ECKeyFrames_GetPreStartFrame(ECKeyFrames *keyFrames);
DV_EXPORT ECFrame *ECKeyFrames_GetPostEndFrame(ECKeyFrames *keyFrames);
DV_EXPORT int ECKeyFrames_GetPostEndFramePoint(ECKeyFrames *keyFrames, dmPoint);
DV_EXPORT int ECKeyFrames_SetPostEndFramePoint(ECKeyFrames *keyFrames, dmPoint);
DV_EXPORT int ECKeyFrames_GetPreStartFramePoint(ECKeyFrames *keyFrames, dmPoint);
DV_EXPORT int ECKeyFrames_SetPreStartFramePoint(ECKeyFrames *keyFrames, dmPoint);
DV_EXPORT int32 ECKeyFrames_SetChangeCallback(void (*func)(ECZone *, ECAssembly *, ECItem *));
DV_EXPORT int32 ECKeyFrames_ExecuteChangeFunc(ECKeyFrames *kf);
DV_EXPORT int ECKeyFrames_GetCorrectForAssSize(ECKeyFrames *keyFrames);
DV_EXPORT void ECKeyFrames_SetCorrectForAssSize(ECKeyFrames *keyFrames, int boolVal);

/*
 * set whether assembly is moved to the end of the keyframe upon completion
 * of the keyframe
 */
DV_EXPORT int ECKeyFrames_GetMoveAssemblyOnCompletion(ECKeyFrames *keyFrames);
DV_EXPORT int ECKeyFrames_SetMoveAssemblyOnCompletion(ECKeyFrames *keyFrames, int move);


/* Simon 21/11/96
 * if visual=null then the visual of the assembly will be used, if not null
 * then that visual will be used
 */
DV_EXPORT int ECKeyFrames_SetVisual(ECKeyFrames *keyFrames, char *visual);

DV_EXPORT char *ECKeyFrames_GetPath(ECKeyFrames *kf);
DV_EXPORT int ECKeyFrames_SetPath(ECKeyFrames *kf, char *path);

/* ======================== Frame Functions ========================= */

DV_EXPORT int ECFrame_Highlight(ECFrame *frame);
DV_EXPORT int ECFrame_Unhighlight(ECFrame *frame);
DV_EXPORT int ECFrame_GetHighlightState(ECFrame *frame);
DV_EXPORT ECFrame *ECFrame_Copy(ECFrame *orig);
DV_EXPORT int32 ECFrame_ApplyChanges(ECFrame *orig, ECFrame *changes);
DV_EXPORT int32 ECKeyFrames_ApplyListChanges(ECKeyFrames *, ECKeyFrames *, int);
DV_EXPORT int32 ECKeyFrames_AddListMember(ECKeyFrames *, ECKeyFrames *, int);
DV_EXPORT int32 ECKeyFrames_RemoveListMember(ECKeyFrames *, int);
DV_EXPORT uint32 ECFrame_GetFlags(ECFrame *frame);
DV_EXPORT int ECFrame_SetFlags(ECFrame *frame, uint32 setBitMask);
DV_EXPORT int ECFrame_ClearFlags(ECFrame *frame, uint32 clearBitMask);
DV_EXPORT int ECFrame_SetPathInterpolationType(ECFrame *, ECPathInterpolationType);
DV_EXPORT int ECFrame_SetSpeedInterpolationType(ECFrame *, ECSpeedInterpolationType);
DV_EXPORT ECPathInterpolationType ECFrame_GetPathInterpolationType(ECFrame *);
DV_EXPORT ECPathInterpolationType ECFrame_GetTruePathInterpolationType(ECFrame *frame);
DV_EXPORT ECSpeedInterpolationType ECFrame_GetSpeedInterpolationType(ECFrame *);
DV_EXPORT ECSpeedInterpolationType ECFrame_GetTrueSpeedInterpolationType(ECFrame *frame);
DV_EXPORT int ECFrame_SetDefaultName(ECFrame *f);
DV_EXPORT int ECFrame_SetTime(ECFrame *, float32 time);
DV_EXPORT float32 ECFrame_GetTime(ECFrame *);
DV_EXPORT int ECFrame_SetSpeed(ECFrame *, float32 time);
DV_EXPORT float32 ECFrame_GetSpeed(ECFrame *);
DV_EXPORT ECEvent *ECFrame_GetEvent(ECFrame *);
DV_EXPORT ECEvent *ECFrame_AddEvent(ECFrame *);
DV_EXPORT ECFrame *ECFrame_GetNextFrame(ECFrame *);
DV_EXPORT ECFrame *ECFrame_GetPreviousFrame(ECFrame *);
DV_EXPORT int ECFrame_SetPoint(ECFrame *f, dmPoint pnt);
DV_EXPORT int ECFrame_GetPoint(ECFrame *, dmPoint pnt);
DV_EXPORT int ECFrame_SetOrientation(ECFrame *f, dmQuaternion quat, int setAllFrames);
DV_EXPORT int  ECFrame_GetOrientation(ECFrame *f, dmQuaternion quat);
DV_EXPORT int ECFrame_SetScale(ECFrame *f, dmScale scale);
DV_EXPORT int  ECFrame_GetScale(ECFrame *f, dmScale scale);
DV_EXPORT int ECFrame_AddUpdateCallback(ECFrame *f, ECFrameUpdateCbPtr callback, void *calldata);
DV_EXPORT int ECFrame_RemoveAllUpdateCallbacks(ECFrame *f);
DV_EXPORT int ECFrame_RemoveUpdateCallback(ECFrame *f, ECFrameUpdateCbPtr callback, void *calldata);
DV_EXPORT int32 ECFrame_RecalculateFrameTimes(ECFrame *frame);
DV_EXPORT int32 ECFrame_CalculateFrameTime(ECFrame *updateFrame);
DV_EXPORT int32 ECFrame_RecalculateArcLengths(ECFrame *frame);
/* recalculates just the arc lengths of those frames which are affected
 * by changes made to 'frame'
 */
DV_EXPORT int32 ECFrame_CalculateArcLength(ECFrame *updateFrame);
/* recalculates just the arc length of 'updateFrame' */
DV_EXPORT ECFrame *ECFrame_Allocate(void);
DV_EXPORT ECKeyFrames *ECFrame_GetKeyFrames(ECFrame *frame);
DV_EXPORT ECFrame *ECKeyFrames_GetFrameAtTime(ECKeyFrames *keyFrames,float32 time);
DV_EXPORT int ECFrame_Destroy(ECFrame *);
DV_EXPORT int32 ECFrameGetIndex(ECFrame *);

DV_EXPORT char *ECFrames_GetPath(ECFrame *frame);
DV_EXPORT int   ECFrames_SetPath(ECFrame *frame, char *path);

/* ======================= UserData functions ======================= */

DV_EXPORT ECUserData *ECUserData_Allocate(void);
DV_EXPORT ECUserData *ECUserData_Create(const char * const name);
DV_EXPORT ECUserData *ECUserData_Copy(ECUserData *from);
DV_EXPORT int         ECUserData_ApplyChanges(ECUserData *orig, ECUserData *changes);
DV_EXPORT int32       ECUserData_Destroy(ECUserData *);
DV_EXPORT int         ECUserData_SetName(ECUserData *ecUD, char *name);
DV_EXPORT char       *ECUserData_GetName(ECUserData *ecUD);
DV_EXPORT int         ECUserData_SetDefn(ECUserData *ecUD, ECUserData *ud);
DV_EXPORT ECUserData *ECUserData_GetDefn(ECUserData *ecUD);
DV_EXPORT int         ECUserData_SetKeyWord(ECUserData *ecUD, char *kw);
DV_EXPORT char       *ECUserData_GetKeyWord(ECUserData *ecUD);
DV_EXPORT ECField    *ECUserData_GetFieldList(ECUserData *);
DV_EXPORT int         ECUserData_AddField(ECUserData *, ECField *);
DV_EXPORT ECField    *ECField_Allocate(void);
DV_EXPORT ECField    *ECField_Create(char *keyWord, ECFieldType type, void *data);
DV_EXPORT int32       ECField_Destroy(ECField *);
DV_EXPORT int32       ECField_SetData(ECField *, void *);
DV_EXPORT void       *ECField_GetData(ECField *);
DV_EXPORT int32       ECField_GetValue(ECField *, void **);
DV_EXPORT ECField    *ECField_GetNext(ECField *);
DV_EXPORT char       *ECField_GetKeyWord(ECField *);
DV_EXPORT ECFieldType ECField_GetType(ECField *);
DV_EXPORT ECField    *ECFieldList_FindField(ECField *list, const char * const keyWord, ECFieldType type);
DV_EXPORT int         ECField_DestroyData(ECField *field);
DV_EXPORT int         ECFieldList_AddFieldToEnd(ECField **list, ECField *newField);
DV_EXPORT ECBinaryData *ECBinaryData_Allocate(void);
DV_EXPORT int32       ECBinaryData_Destroy(ECBinaryData *BinaryData);
DV_EXPORT int         ECUserData_CreateField(ECUserData *ecUD, const char * const kw, 
					     ECFieldType type, void *d, int checkFlag); 
DV_EXPORT ECField    *ECUserData_GetFieldByKeyword(ECUserData *, const char * const);
DV_EXPORT ECUserData *ECUserData_CreateForInt(char *name, char *keyWord, int32 val);
DV_EXPORT int32       ECUserData_ExtractInt(ECUserData *ecUD, char *keyWord);
DV_EXPORT int32       ECUserData_ResetInt(ECUserData *ecUD, char *keyWord, int32 val);
DV_EXPORT int         ECFields_Differ(ECField *a, ECField *b);
DV_EXPORT int         ECUserData_Differ(ECUserData *a, ECUserData *b);

/* ========================= Path functions ========================= */

DV_EXPORT ECPath *ECPath_Allocate(void);
DV_EXPORT int32 ECPath_Destroy(ECPath *);
DV_EXPORT int32 ECPathList_Destroy(ECPath *);
DV_EXPORT int32 ECPathList_AddPath(ECPath **list, char *newPath);
/* Adds the pathname given to the start of the path list */
DV_EXPORT int32 ECPath_SetName(ECPath *c, char *n);
DV_EXPORT char *ECPath_GetName(ECPath *c);

/* ====================== Header functions ====================== */

DV_EXPORT ECHeader *ECHeader_Allocate(void);
DV_EXPORT ECHeader *ECHeader_Create(void);
/* Allocate and fill an ECHeader structure.  The date, time version
 * and default units are set */
DV_EXPORT int32 ECHeader_Destroy(ECHeader *);
DV_EXPORT int32 ECHeader_SetUnit(ECHeader *, VDIUnit unit);
DV_EXPORT int32 ECHeader_SetFileType(ECHeader *, VDIFileType fileType);
DV_EXPORT int32 ECHeader_SetVersion(ECHeader *, int major, int minor);
DV_EXPORT int32 ECHeader_SetDate(ECHeader *, int day, int month, int year);
DV_EXPORT int32 ECHeader_SetTime(ECHeader *, int hours, int minutes);
DV_EXPORT int32 ECHeader_SetScale(ECHeader *, float32 scale);
DV_EXPORT VDIUnit ECHeader_GetUnit(ECHeader *);
DV_EXPORT VDIFileType ECHeader_GetFileType(ECHeader *);
DV_EXPORT int32 ECHeader_GetVersion(ECHeader *, int *major, int *minor);
DV_EXPORT int32 ECHeader_GetDate(ECHeader *, int *day, int *month, int *year);
DV_EXPORT int32 ECHeader_GetTime(ECHeader *, int *hours, int *minutes);
DV_EXPORT float32 *ECHeader_GetScale(ECHeader *);
DV_EXPORT int32 ECHeader_SetFileMode(ECHeader *h, VDIFileMode fileMode);
DV_EXPORT VDIFileMode ECHeader_GetFileMode(ECHeader *h);
DV_EXPORT ECItem **ECHeader_GetItemListPtr(ECHeader *);
DV_EXPORT ECItem *ECHeader_GetItemList(ECHeader *);

/*======================= System functions ====================== */
DV_EXPORT ECSystem *ECSystem_Allocate(void);
/* 
 * Allocate memory for a ECSystem structure, blank it out 
 * and return a pointer to it.
 */
DV_EXPORT int32 ECSystem_Destroy(ECSystem *system);
/* Frees the memory of a system structure and destroys the attribute list
 * and user event structures.
 */
DV_EXPORT int32 ECSystem_AddUserData(ECSystem *system, ECUserData *ecUD);
DV_EXPORT ECUserData *ECSystem_RemoveNamedUserData(ECSystem *system, char *name);
DV_EXPORT ECUserData *ECSystem_FindNamedUserData(ECSystem *system, char *name);
DV_EXPORT int32 ECSystem_AddEventList(ECSystem *system, ECEventList *eventList);
DV_EXPORT int32 ECSystem_AddEventAction(ECSystem *system, int32 eventId, 
				     char *exp, ECAction *act);
DV_EXPORT int32 ECSystem_SetTickRate(ECSystem *system, float32 rate);
DV_EXPORT float32 ECSystem_GetSystemTickRate(ECSystem *system);
DV_EXPORT int32 ECSystem_AddUserEvent(ECSystem *system, ECUserEvent *userEvent);
DV_EXPORT ECUserEvent *ECSystem_GetUserEvents(ECSystem *system);
/* userEvent store user defined event type names for libecapp */
DV_EXPORT ECUserEvent *ECUserEvent_Allocate(void);
DV_EXPORT int32 ECUserEvent_SetName(ECUserEvent *userEvent, char *name);
DV_EXPORT ECItem *ECSystem_GetItemList(ECSystem *system);
DV_EXPORT ECItem **ECSystem_GetItemListPtr(ECSystem *system);
DV_EXPORT int32 ECSystem_AddActionFunctionSyntaxFilename(ECSystem *, char *);
DV_EXPORT int32 ECSystemAddUserDataSyntaxFilename(ECSystem *, char *);

/* ======================= File functions ======================= */
DV_EXPORT void *ECTopFile_FindNamedEntity(char *name, ECItemType type);
DV_EXPORT ECAssembly *ECTopFile_FindNamedAssembly(char *name);
DV_EXPORT ECAssembly *ECTopLib_FindNamedAssembly(char *name, int strictMode);
DV_EXPORT ECFile *ECFile_Allocate(void);
DV_EXPORT int ECFile_LoadFragment(char *filename, ECAssembly *obj, char *editMode);
DV_EXPORT int ECFile_UnloadFragment(char *filename, char *parentPath, char *newName);
/* 
 * Allocate memory for a ECFile structure, blank it out 
 * and return a pointer to it.
 */
DV_EXPORT char *ECFile_DefaultName(void);
DV_EXPORT int32 ECFile_Destroy(ECFile *);
/* Frees the memory of a file structure and destroys the file's attribute list
 * and header structure 
 */
DV_EXPORT ECFile *EC_GetTopFile(void);
DV_EXPORT void EC_SetTopFile(ECFile *file);
DV_EXPORT void ECFile_PlugSearchPathFunc(fileSPfunc func);
DV_EXPORT int32 ECFile_SetSearchPath(ECFile *file);
DV_EXPORT int32 ECFile_SetHeader(ECFile *, ECHeader *header);
DV_EXPORT int32 ECFile_SetSystem(ECFile *, ECSystem *);
DV_EXPORT int32 ECFile_AddLibrary(ECFile *, ECLibrary *library);
DV_EXPORT int32 ECFile_AddLibraryToLibraries(ECFile *, ECLibrary *library);
DV_EXPORT int32 ECFile_AddZone(ECFile *, ECZone *zone);
DV_EXPORT int32 ECFile_AddRole(ECFile *, ECRole *);
DV_EXPORT int32 ECFile_AddList(ECFile *, ECList *);
DV_EXPORT int32 ECFile_AddComment(ECFile *f, ECComment *comment);
DV_EXPORT int32 ECFile_AddPath(ECFile *, ECPath *);
DV_EXPORT ECItem *ECFile_GetItemList(ECFile *file);
DV_EXPORT ECItem **ECFile_GetItemListPtr(ECFile *file);
DV_EXPORT uint32 ECFile_GetFlags(ECFile *file);
DV_EXPORT int ECFile_SetFlags(ECFile *file, uint32 setF, uint32 clearF);
DV_EXPORT int ECFile_UpdateFileUsed(ECFile *file, char *fullPath);
DV_EXPORT ECHeader *ECFile_GetHeader(ECFile *);
DV_EXPORT ECSystem *ECFile_GetSystem(ECFile *);
DV_EXPORT ECLibrary *ECFile_GetLibraryList(ECFile *);
DV_EXPORT ECLibrary *ECFile_FindLibrary(ECFile *, char *name);
DV_EXPORT ECRole *ECFile_GetRoleList(ECFile *);
DV_EXPORT ECZone *ECFile_GetZoneList(ECFile *);
DV_EXPORT ECList *ECFile_GetListList(ECFile *);
DV_EXPORT ECItem *ECFile_GetSystemItemList(ECFile *f);
DV_EXPORT ECItem **ECFile_GetItemListPtr(ECFile *file);
DV_EXPORT ECEventList *ECFile_GetSystemEventList(ECFile *);
DV_EXPORT float32 ECFile_GetSystemTickRate(ECFile *);
DV_EXPORT int32 ECFile_SetName(ECFile *, char *);
DV_EXPORT char *ECFile_GetName(ECFile *);
DV_EXPORT int32 ECFile_SetPathName(ECFile *, char *);
DV_EXPORT char *ECFile_GetPathName(ECFile *);
/* returns NULL if none defined */
DV_EXPORT void ECFile_DetachPlugins(ECFile *file);


/* =================== ECArgReference functions =================== */
DV_EXPORT ECArgReference *ECArgReference_Allocate(void);
DV_EXPORT ECArgReference *ECArgReference_Create(ECParameterType);
DV_EXPORT int ECArgReference_Destroy(ECArgReference *);
DV_EXPORT int ECArgReference_SetData(ECArgReference *, void *);
DV_EXPORT int ECArgReference_SetExp(ECArgReference *, char *);
DV_EXPORT int ECArgReference_SetName(ECArgReference *, char *);
DV_EXPORT int ECArgReference_GetData(ECArgReference *, void **);
DV_EXPORT int ECArgReference_GetExp(ECArgReference *, char **);
DV_EXPORT int ECArgReference_GetName(ECArgReference *, char **);
DV_EXPORT ECParameter *ECParameter_Allocate(void);
DV_EXPORT ECParameter *ECParameter_Create(ECParameterType type, void *data);
DV_EXPORT void **ECParameters_Copy(void **orig, ECActionFunc *af);
DV_EXPORT int32 ECParameterList_AddParameter(ECParameter *list, ECParameter *newP);

/* ====================== String functions ======================== */

DV_EXPORT DCIString *DCIString_Allocate(void);
DV_EXPORT int32 DCIString_Clear(DCIString  *s);
/* Sets the string length to 0 without freeing the buffer */
DV_EXPORT DCIString *DCIString_Reserve(size_t length);
/* Make a DCIString structure big enough for a string of the given length */
DV_EXPORT DCIString *DCIString_Create(char *string);
DV_EXPORT int32 DCIString_Destroy(DCIString *a);
DV_EXPORT int32 DCIString_Cat(DCIString *a, DCIString *b);
/*
 * Cats the string in b onto the string in a, reallocing if nec.
 * then frees the structure b and its string.
 */
DV_EXPORT int32 DCIString_Append(DCIString *a, char *b);
/*
 * Cats the string b onto the string in a, reallocing if nec.
 */
DV_EXPORT int32 DCIString_Prepend(DCIString *a, char *b);
/*
 * Precats the string b onto the string in a, reallocing if nec.
 * Costly operation -- minimise use of.
 */
DV_EXPORT int32 DCIString_RemoveHead(DCIString *a, size_t len);
DV_EXPORT int32 DCIString_AddChar(DCIString *a, char b);
DV_EXPORT int32 DCIString_AddInt(DCIString *a, int val);
DV_EXPORT char *DCIString_GetString(DCIString *str);
DV_EXPORT int32 DCIString_QuoteAppend(DCIString *s, char *b);
/*  
 *  Append a quoted version of b onto the string in s
 */

/* ========================= Input functions ====================== */

DV_EXPORT int EC_FileRead(char *   /* infilename */);              /* ECio.c */
/* read an entire input file (pointers to a previously read file are
 * overwritten and hence should be saved eg myzone=ECZoneGet();
 * see ../Wdlib/wd.h
 */

/* =======================  Output Functions ====================== */

DV_EXPORT FILE *EC_FileWrite(char *filename, ECFile *source);
/* The easiest way to write an output file.
 * Writes out the definition object list followed by the linked
 * list of zones, each with it's object list.
 */
DV_EXPORT FILE *EC_OutputFileOpen(char *outFileName, ECFile *outFile);
/* Returns a file pointer which should be checked for error (==(FILE *)NULL);
 */
DV_EXPORT void EC_OutputFileClose(void);
/* Close the output file */
DV_EXPORT int ECAssemblyTree_WriteAttributes(char *, ECAssembly *, int, int);
DV_EXPORT int ECAssemblyTree_WriteLandmarks(char *filename);

/* ======================  Comment Functions ====================== */

DV_EXPORT ECComment *ECComment_Allocate(void);
DV_EXPORT ECComment *ECComment_Copy(ECComment *from);
DV_EXPORT ECComment *ECComment_Create(char *string);
DV_EXPORT int32      ECComment_Destroy(ECComment *com);
DV_EXPORT int        ECComments_Differ(ECComment *a, ECComment *b);

/* ================== User event functions ================== */
DV_EXPORT int ECEvent_Register(char *en);

/* ================== WMan - User Role Dialog EC functions ======= */
DV_EXPORT char *ECRole_GetList(void);

/* Free data malloced from dvise in xdvise using this */
DV_EXPORT void Xdvise_Free(void *data);


#include "ecmacros.h"
#ifdef _dummyBrace_
{
#endif
#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /* _ECTOOLS_H */
