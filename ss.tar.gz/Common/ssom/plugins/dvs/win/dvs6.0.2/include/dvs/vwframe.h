/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: vwframe.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:08:13 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: vwframe.h,v 1.1 2005/09/13 15:08:13 pukitepa Exp $
 *
 *    FUNCTION: Frame public function prototypes.
 * 
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _Frame_H
#define _Frame_H
#ifdef __cplusplus
extern "C" {
#endif
/* PUBLIC FUNCTIONS ======================================*/


VW_EXPORT VWidget *VWFrame_CreateManaged(VWidget *, char *, VWArg [], int);
VW_EXPORT VWidget *VWFrame_Create(VWidget *, char *, VWArg [], int);


#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /*_Frame_H */
