/*
 *    PROJECT:      DVS
 *    SUBSYSTEM:    vl
 *    MODULE:       divtypes.h
 *
 *    File:         $RCSfile: divtypes.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:07:39 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: divtypes.h,v 1.1 2005/09/13 15:07:39 pukitepa Exp $
 *
 *    FUNCTION:
 *
 *      This file contains standard type definitions used by all higher
 *      levels in the system.
 *
 * Copyright (c) 1994, 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _DIVTYPES_H
#define _DIVTYPES_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef DP_EXPORT
#if defined(_WIN32) && !defined(__EPP__) && !defined (BUILD_STATIC)
/* only  needs this baroque construct.
 * On sensible systems simply use `extern'
 */
#ifdef  _LIB_DIVU
#define DP_EXPORT __declspec(dllexport) extern
#else
#define DP_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define DP_EXPORT  extern
#endif /* ! _WIN32 */
/* #define DP_EXPORT  extern */
#endif /* ndef DP_EXPORT */

/*
 * mangle the divtypes.def file to get machine specific low level
 * definitions for all our basic types.
 */
#define DEF_TYPE(a,b,c) typedef c b;
#include <dsys/divtypes.def>
#undef DEF_TYPE

/*
 * generate an enum list of all the symbolic values for the types.
 */
#define DEF_TYPE(a,b,c) a,
typedef enum  dpDivType {
#include <dsys/divtypes.def>
LAST_TYPE
} dpDivType;
#undef DEF_TYPE
#define BASIC_TYPE_CNT ((int)LAST_TYPE)


/*
 * A structure to define the names etc of the basic types for internal
 * use. 
 * everything in done as byte objects so that these can be passed between machines
 * with no worries about endianess issues. (after all that is what they are used to resolve!)
 */
#define MAX_DIVTYPE_NAMELEN 10
typedef struct dpTypeSpec{
    char8   endian16[3];
    char8   endian32[5];
    struct {
        char8  name[MAX_DIVTYPE_NAMELEN];
        uint8  size;
        uint8  alignment;
    }Sizes[BASIC_TYPE_CNT];
} dpTypeSpec;

typedef struct DP_FTIME
{
  float time;
  float lastTime;
  float nextLast;

#if defined _WIN32
  unsigned long old_mSecs; /* THis is really a DWORD but this is too early to 
                            * include windows.h
                            */
#else
  long old_secs;
  long old_usecs;
#endif
} DP_FTIME, * DP_FTIME_PTR;

DP_EXPORT void dpGenDivTypes(dpTypeSpec *spec);

#ifdef __cplusplus
}
#endif
#endif /* _DIVTYPES_H */



