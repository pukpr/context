/****************************************************************************
 *
 *  			Copyright 1998 Division Ltd.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: querystore.h,v $
 *  Revision      : $Revision: 1.1 $
 *  Date          : $Date: 2005/09/13 15:07:56 $
 *  Author        : $Author: pukitepa $
 *  Created       : Mon May 11 16:59:20 1998
 *  Last Modified : <300798.1101>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 *  $Log: querystore.h,v $
 *  Revision 1.1  2005/09/13 15:07:56  pukitepa
 *  init
 *
 *  Revision 1.3  1998/07/30 13:57:36  simon
 *  Various fixes to query parser - include puting queryeval.* in libecapp
 *
 *  Revision 1.2  1998/06/04 16:30:33  simon
 *  *** empty log message ***
 *
 *  Revision 1.1  1998/05/29 15:53:51  simon
 *  Functions to create a query store, which can hold a list of queries
 *
 *  Revision 1.8  1998/05/28 17:29:12  simon
 *  *** empty log message ***
 *
 *  Revision 1.7  1998/05/27 17:05:51  simon
 *  *** empty log message ***
 *
 *  Revision 1.6  1998/05/22 16:30:11  simon
 *  *** empty log message ***
 *
 *  Revision 1.5  1998/05/21 17:05:52  simon
 *  *** empty log message ***
 *
 *  Revision 1.4  1998/05/19 17:13:20  simon
 *  *** empty log message ***
 *
 *  Revision 1.3  1998/05/15 15:54:49  simon
 *  *** empty log message ***
 *
 *  Revision 1.2  1998/05/14 16:59:55  simon
 *  *** empty log message ***
 *
 *  Revision 1.1  1998/05/11 17:05:39  simon
 *  *** empty log message ***
 *
 *
 ****************************************************************************
 *
 *  Copyright (c) 1998 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 * This  document  may  not, in  whole  or in  part, be  copied,  photocopied,
 * reproduced,  translated,  or  reduced to any  electronic  medium or machine
 * readable form without prior written consent from Division Ltd.
 *
 ****************************************************************************/

#ifndef __QUERYSTORE_H
#define __QUERYSTORE_H

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

#include "queryparser.h"
#include "ectools.h"

struct QueryStore;
typedef struct QueryStore QueryStore;

/* The one and only query store */
DV_EXPORT QueryStore *Store;

/* sets up the query store */
DV_EXPORT void QueryStore_Setup(void);
/* writes out the query store to the system, creating it if necessary -
 * required before a vdi write */
DV_EXPORT void QueryStore_WriteToSystem(void);

/* create a query store which can hold a uniquely named list of queries,
 and parse them in/out of a user data */
DV_EXPORT QueryStore *QueryStore_Create(void);
/* removes all the queries from the store */
DV_EXPORT int QueryStore_Reset(QueryStore *store);
/* returns an item list containing the queries */
DV_EXPORT ECItem *QueryStore_GetQueries(QueryStore *store);
/* parses in queries from a user data - expects named fields of type string 
 * with the query in the string */
DV_EXPORT int QueryStore_ParseInFromUserData(QueryStore *Store, ECUserData *userData);
/* creates a user data, and puts all the queries as strings into it */
DV_EXPORT ECUserData *QueryStore_ParseOutToUserData(QueryStore *store);
/* creates a query, and adds it to the store - the name can be NULL, and may be altered
 to make it unique. The queryString may be NULL */
DV_EXPORT Query *QueryStore_CreateAndAddQuery(QueryStore *store, char *name, char *queryString);
/* copies the given query, and adds it to the store - the name may be altered to make it
 * unique, returns the copy */
DV_EXPORT Query *QueryStore_CopyAndAddQuery(QueryStore *store, Query *query);
/* overwrites the query with the name given to the query given - the name may be altered
 to make it unique, returns the copy */
DV_EXPORT Query *QueryStore_OverwriteQuery(QueryStore *store, char *storedName, Query *query);
/* finds the query with the name given in the store */
DV_EXPORT Query *QueryStore_FindNamedQuery(QueryStore *store, char *name);
/* deletes the given query from the store */
DV_EXPORT int QueryStore_DeleteQuery(QueryStore *store, Query **query);
/* gets a unique name for a query, returns it in a static string */
DV_EXPORT char *QueryStore_GetUniqueName(QueryStore *store, char *name);


#if defined(__cplusplus) || defined(c_plusplus)
}
#endif
#endif /* __QUERYSTORE_H */
