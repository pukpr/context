/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: vworient.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:08:14 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: vworient.h,v 1.1 2005/09/13 15:08:14 pukitepa Exp $
 *
 *    FUNCTION: public function templates for the orient widget
 * 
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _Orient_H
#define _Orient_H
#ifdef __cplusplus
extern "C" {
#endif
/* INCLUDES =============================================== */    
#include "vwborder.h"
/* PUBLIC TYPES ===========================================*/
 
enum VWorientargtypes {
    VWrOrientDragCallback = VW_RESOURCES_ORIENT,
    VWrOrientDragCalldata, 
    VWrOrientDropCallback, 
    VWrOrientDropCalldata, 
    VWrOrientArmCallback, 
    VWrOrientArmCalldata, 
    VWrOrientValueChangedCallback, 
    VWrOrientValueChangedCalldata, 
    VWrOrientPuckVisual,
    VWrOrientPuckHighlightVisual,
    VWrOrientPuckMaterial,
    VWrOrientPuckHighlightMaterial
};

/* PUBLIC FUNCTIONS ======================================*/
VW_EXPORT VWidget *VWOrient_CreateManaged(VWidget *, char *, VWArg [], int);
VW_EXPORT VWidget *VWOrient_Create(VWidget *, char *, VWArg [], int);
VW_EXPORT void VWOrient_GetAbsoluteValue(VWidget *orientWig, dmEuler absOr);
VW_EXPORT void VWOrient_GetLocalValue(VWidget *orientWig, dmEuler localOr);
VW_EXPORT void VWOrient_SetAbsoluteValue(VWidget *, dmEuler, int trigger);
VW_EXPORT void VWOrient_SetLocalValue(VWidget *, dmEuler, int trigger);

VW_EXPORT void VWOrient_AddDropCallback(VWidget *, VWCallback *, void *);
VW_EXPORT void VWOrient_RemoveAllDropCallbacks(VWidget *);

VW_EXPORT void VWOrient_AddDragCallback(VWidget *, VWCallback *, void *);
VW_EXPORT void VWOrient_RemoveAllDragCallbacks(VWidget *);

VW_EXPORT void VWOrient_AddUpdateCallback(VWidget *, VWCallback *, void *);
VW_EXPORT void VWOrient_RemoveAllUpdateCallbacks(VWidget *);

VW_EXPORT void VWOrient_AddArmCallback(VWidget *, VWCallback *, void *);
VW_EXPORT void VWOrient_RemoveAllArmCallbacks(VWidget *);

#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /* _Orient_H */

