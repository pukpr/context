// -!- c++ -!- //////////////////////////////////////////////////////////////
//
//  			Copyright 1998 Division Ltd.
//			      All Rights Reserved
//
//
//  System        : 
//  Module        : 
//  Object Name   : $RCSfile: dalpipe.h,v $
//  Revision      : $Revision: 1.1 $
//  Date          : $Date: 2005/09/13 15:07:38 $
//  Author        : $Author: pukitepa $
//  Created By    : Jon Kennedy
//  Created       : Wed Sep 16 16:40:01 1998
//  Last Modified : <281098.1209>
//
//  Description	
//
//  Notes
//
//  History
//	
//  $Log: dalpipe.h,v $
//  Revision 1.1  2005/09/13 15:07:38  pukitepa
//  init
//
//  Revision 1.1.2.1  1999/01/07 14:15:04  jk
//  Intial entry for dv/venas
//
//
/////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 1998 Division Ltd.
// 
//  All Rights Reserved.
// 
// This  document  may  not, in  whole  or in  part, be  copied,  photocopied,
// reproduced,  translated,  or  reduced to any  electronic  medium or machine
// readable form without prior written consent from Division Ltd.
//
//////////////////////////////////////////////////////////////////////////////

#ifndef __ALIASPIPE_HPP
#define __ALIASPIPE_HPP

#include <dsys/dvcon.h>
#include <stdio.h>
#include <strings.h>
#include <string.h>
#include <unistd.h>

const int32 dalpBuffSize = 1028;
typedef char * char_p;

#define DALPASSYLISTSTART "DALP_ASSY_LIST_START"
#define DALPASSYLISTSTOP  "DALP_ASSY_LIST_STOP"
#define DALPRELOAD        "DALP_RELOAD"
#define DALPRECONVERT     "DALP_RECONVERT"
#define DALPSELECT        "DALP_SELECT"
#define DALPRECEIVING     "DALP_RECEIVING"
#define DALPEXIT          "DALP_EXIT"
#define DALPUSERMESSAGE   "DALP_USER_MESSAGE"

typedef enum {dalpRELOAD, dalpRECONVERT, dalpSELECT, dalpNODATA, 
              dalpERROR, dalpRECEIVING, dalpEXIT, dalpUSERMESSAGE} TOKENS;




/* This is an abstract class which contains most of the info for the sub-classes */
class dalpPipe
{
private:
    int32    _NoAssys ;
    char  ** _Assys ;
    
    TOKENS   _LastToken;
    
    virtual void InitData();
    virtual void Reset();
    
    virtual int32 GetValidLine();
    virtual int32 GetLine() = 0;
    virtual int32 PutLine(char *format, ...) = 0;
    
    virtual int32 GetAssys();
    virtual void FreeAssys();
    
    virtual int32 IsCommandLine();
    
protected:
    int      _In;
    int      _Out;
    char     _Buff[dalpBuffSize];
    
    int      _TAB;
    virtual void dalpEnter(const char * const str){dpgMonitor(0x08,("%*c-- in --- [%s]\n",_TAB++,' ', str));}
    virtual void dalpLeave(const char * const str){dpgMonitor(0x08,("%*c-- out -- [%s]\n",--_TAB,' ', str));}


public:
    dalpPipe(){ _TAB = 0; InitData();}
    
    ~dalpPipe() {Reset();_TAB = 0;}
    
    /* this will free off current assy list, before mallocing more */
    virtual void AddAssys(int32 nassys, char ** assys);
    
    virtual void PutSelect();
    virtual void PutReload();
    virtual void PutReconvert();
    virtual void PutReceiving();
    virtual void PutExit();
    virtual int32 PutAssys();
    virtual void PutUserMessage(char *format, ...);
    
    
    /* returns the last token received */
    virtual TOKENS GetData();
    
    virtual TOKENS LastToken(){return _LastToken;}
    virtual int In(){return _In;}
    virtual int Out(){return _Out;}
    
    virtual int32 NoAssys(){return _NoAssys;}
    virtual char ** Assys(){return _Assys;}
    virtual char * Buff(){return _Buff;}
    virtual int32 Peek();
    
};

class dalpParentPipe: public dalpPipe
{
private:
    dvconProgram * _ChildProgram;
    
    virtual void InitData();
    virtual void Reset();
    virtual int32 GetLine();
    virtual int32 PutLine(char *format, ...);

public:
    dalpParentPipe(){InitData();}
    ~dalpParentPipe() {Reset();}
    
    int32 SpawnChild(char * filename);
    /* Checks the pid of the child to see if it still there */
    int32  IsChildValid();
//    virtual int32 Peek();
};


class dalpChildPipe : public dalpPipe
{
private:
    virtual void InitData();
    virtual void Reset();
    
    virtual int32 GetLine();
    virtual int32 PutLine(char *format, ...);
    
public:
    dalpChildPipe(){InitData();}
    ~dalpChildPipe(){Reset();}
//    virtual int32 Peek();
};


typedef struct dalNameCache
{
    char                  * name;
    struct dalNameCache * next;
}dalNameCache, *dalNameCachePtr;

/* Adds unique names to name cache */
void dalAddToNameCache(dalNameCachePtr * head, const char * itemName);
/* Frees it all of */
void dalFreeNameCache(dalNameCachePtr * head);
/* Returns the number of names in the name cache */
int32 dalCountNameCache(dalNameCachePtr  head);
/* Puts the name cache into a char** format, mallocs all mem used.  
 * Returns the number of names added */
int32 dalNameCacheToCharPP(dalNameCachePtr head, char *** names);
/* Frees off the char** */
int32 dalNameCacheFreeCharPP(char *** names);

#endif // __ALIASPIPE_HPP

