/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1993 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: xddebug.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 28 April 1995
--  Author       : Tony Coombes
--
--  Description	 : Debug stuff
--
--  Modified
--    By         : $Author: pukitepa $
--    Date       : $Date: 2005/09/13 15:08:22 $
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __XDDEBUG_H__
#define __XDDEBUG_H__

#include <dvs/vc.h>

#define XDAPP_DEBUG               0x800
#define XdError     VC_Error
#define XdWarning   VC_Error
#define XdDebug     VC_Debug
#define XdVerbose_Module(lvl, msg) duVerbose_Module(lvl, XdVerbose_GetModuleHandle() ,msg)
#define XdDebug_Module(lvl, msg)   duDebug_Module(lvl, XdDebug_GetModuleHandle() ,msg)

/* Verbose levels */
#define XDVerbose_Verbose       0x00000001
#define XDVerbose_DCI		0x00000002
#define XDVerbose_Selection     0x00000004
#define XDVerbose_Landmark      0x00000008
#define XDVerbose_Hrchy         0x00000010
#define XDVerbose_TreeView      0x00000020
#define XDVerbose_Library       0x00000040
#define XDVerbose_AssyMgr       0x00000080
#define XDVerbose_AssyView      0x00000100
#define XDVerbose_Annotation    0x00000200
#define XDVerbose_Animation     0x00000400
#define XDVerbose_KeyFrame      0x00000800
#define XDVerbose_FrameMgr      0x00001000
#define XDVerbose_Frame         0x00002000
#define XDVerbose_Audio         0x00004000
#define XDVerbose_Base          0x00008000
#define XDVerbose_Behaviour     0x00010000
#define XDVerbose_ActionEdit    0x00020000
#define XDVerbose_Collision     0x00040000
#define XDVerbose_Constraint    0x00080000
#define XDVerbose_Light         0x00100000
#define XDVerbose_Colour        0x00200000
#define XDVerbose_Visual        0x00400000
#define XDVerbose_UserData      0x00800000
#define XDVerbose_Physics       0x01000000
#define XDVerbose_SendEvent     0x02000000
#define XDVerbose_FlightPath    0x04000000

#ifdef __cplusplus
extern "C" {
#endif

#ifndef XDV_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `XDV_EXPORT'
 */
#ifdef  _LIB_XDV
#define XDV_EXPORT __declspec(dllexport) extern
#else
#define XDV_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define XDV_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ifndef XDV_EXPORT */

XDV_EXPORT void XdDebug_init(void);
XDV_EXPORT int  XdVerbose_GetModuleHandle(void);
XDV_EXPORT int  XdDebug_GetModuleHandle(void);

#ifdef __cplusplus
}
#endif

#endif /* __XDDEBUG_H__ */

