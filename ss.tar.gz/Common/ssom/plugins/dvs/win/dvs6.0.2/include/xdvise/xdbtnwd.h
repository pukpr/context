/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1996 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: xdbtnwd.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 26 April 1996
--  Author       : Tony Coombes
--
--  Description	 : Button Widget
--
--  Modified     : 
--    $Log: xdbtnwd.h,v $
--    Revision 1.1  2005/09/13 15:08:21  pukitepa
--    init
--
--    Revision 1.7  1998/07/02 16:10:38  wman
--    Changes for second edit toolbar and functions.
--
--    Revision 1.6  1998/06/25 10:39:26  wman
--    Unix changes for Mark Greening's markup annotation code.
--
--    Revision 1.5  1998/06/23 11:08:05  wman
--    Added second toolbar with selection options.
--
--    Revision 1.4  1998/03/16 17:36:40  tony
--    Correct prototype for XdRadioMenuBtn_Create()
--
--    Revision 1.3  1998/03/13 14:29:02  tony
--    Support to allow users to configure the units
--    used to display distance measurements
--
--    Revision 1.2  1997/10/23 13:31:28  dvs-dev
--    NT changes for the collision and advanced collision dlg.
--    Fixes to get the section code and collision detection code to build on NT.
--    General bug fixes.
--
--    Revision 1.1  1997/07/09 12:30:55  simon
--    *** empty log message ***
--
--    Revision 1.10  1997/04/01 16:49:44  tony
--    General fixes to problems highlighted by Insure
--
--    Revision 1.9  1997/02/25 15:32:58  wman
--    Event editor, viewing keypress is better.
--    General Bug Fixes
--
--    Revision 1.8  1997/02/21 18:32:02  wman
--    Bug Fixes
--    Also, Added rmb functions to frame manager dlg.
--
--    Revision 1.7  1997/01/30 17:49:15  tony
--    *** empty log message ***
--
--    Revision 1.6  1997/01/24 20:54:26  tony
--    *** empty log message ***
--
--    Revision 1.5  1997/01/21 21:35:44  tony
--    *** empty log message ***
--
--    Revision 1.4  1996/11/27 12:06:19  wman
--    Added new event editor dlg.
--    Fixed behaviour dlg for annotations.
--
--    Revision 1.3  1996/11/21 11:51:41  wman
--    New postit icons
--
--    Revision 1.2  1996/10/25 16:55:22  tony
--    *** empty log message ***
--
--    Revision 1.1.1.1  1996/08/29 09:26:10  tony
--    first version of xdvise
--
--    Revision 3.1  1996/08/05 15:06:37  tony
--    Check in prior to starting development for IDP
--
--    Revision 1.1  1996/06/18 11:17:02  tony
--    Mid development revision
--
--
--
-- ----------------------------------------------------------------------------
*/

#ifndef __XDBTNWD_H__
#define __XDBTNWD_H__

#include <dvise/eclicense.h> /* For ECLicensedFeaturesEnum */

#ifdef __cplusplus
extern "C" {
#endif

#ifndef XDV_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `XDV_EXPORT'
 */
#ifdef  _LIB_XDV
#define XDV_EXPORT __declspec(dllexport) extern
#else
#define XDV_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define XDV_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ifndef XDV_EXPORT */

typedef struct _UserMenuT { /* simon 25/6/97 */
    char *name;
    compT menu;
    struct _UserMenuT *next;
} UserMenuT;

typedef struct btnWidgT btnWidgT;

XDV_EXPORT btnWidgT *XdPosndBtnWidgetCreate(compT parent, char *label, int posn, int divns, 
		       void (*activateCB)(btnWidgT *w, void *clientData), 
		       void *clientData);
XDV_EXPORT btnWidgT *XdBtnWidgetCreate(compT parent, char *label, int left, int right, 
		       void (*activateCB)(btnWidgT *w, void *clientData), 
		       void *clientData);
XDV_EXPORT btnWidgT *XdMenuBtnCreate(compT parent, char *label, char *mnemonic,
                       void (*activateCB)(btnWidgT *w, void *clientData), 
		       void *clientData);
XDV_EXPORT btnWidgT *XdMenuBtn_Create(compT parent, char *label, char *mnemonic, char *accelerator,
                       char *acceleratorText, ECLicensedFeaturesEnum licenseFeature,
		       void (*activateCB)(btnWidgT *w, void *clientData), void *clientData);
XDV_EXPORT btnWidgT *XdToggleMenuBtnCreate(compT parent, char *label, char *mnemonic, 
				       void (*activateCB)(btnWidgT *w, void *clientData), 
				       void *clientData);
XDV_EXPORT btnWidgT *XdToggleMenuBtn_Create(compT parent, char *label, char *mnemonic, 
                                        ECLicensedFeaturesEnum licenseFeature,
				        void (*activateCB)(btnWidgT *w, void *clientData), 
				        void *clientData);
XDV_EXPORT btnWidgT *XdRadioMenuBtn_Create(compT parent, char *label, char *mnemonic, 
                       ECLicensedFeaturesEnum licenseFeature,
		       void (*activateCB)(btnWidgT *w, void *clientData), void *clientData);
XDV_EXPORT btnWidgT *XdToolBtn_Create(compT parent, int pixmap, int armPixmap, 
                       int insensativePixmap, 
		       int lockedPixmap, ECLicensedFeaturesEnum licenseFeature,
		       void (*activateCB)(btnWidgT *w, void *clientData),
		       void *clientData);
XDV_EXPORT btnWidgT *XdToolToggleBtn_Create(compT parent, int pixmap, int armPixmap, 
                       int insensativePixmap, 
		       int lockedPixmap, ECLicensedFeaturesEnum licenseFeature,
		       void (*activateCB)(btnWidgT *w, void *clientData),
		       void *clientData);
XDV_EXPORT btnWidgT *XdToolBtn_CreateDynamic(compT parent, char **pixmap, char **armPixmap, 
                                         char **insensativePixmap, char **lockedPixmap, 
                                         ECLicensedFeaturesEnum licenseFeature,
                                         void (*activateCB)(btnWidgT *w, void *clientData), 
                                         void *clientData);

XDV_EXPORT void      XdBtnWidgetActivateCB(void *clientData);
XDV_EXPORT int       XdToggleMenuBtn_GetState(btnWidgT *w);
XDV_EXPORT void      XdToggleMenuBtn_SetState(btnWidgT *w, int state);
XDV_EXPORT int       XdRadioMenuBtn_GetState(btnWidgT *w);
XDV_EXPORT void      XdRadioMenuBtn_SetState(btnWidgT *w, int state);
XDV_EXPORT compT     XdBtnWd_GetBtn(btnWidgT *w);
XDV_EXPORT void      XdMenuBtn_SetSensitive(btnWidgT *w, int sensitive);
XDV_EXPORT void      XdToolbarBtn_SetSensitive(btnWidgT *w, int sensitive);
XDV_EXPORT void		 XdToolbarBtn_SetState(btnWidgT *w, int state);
XDV_EXPORT int		 XdToolbarBtn_GetState(btnWidgT *w);

#ifdef __cplusplus
}
#endif

#endif /* __XDBTNWD_H__ */
