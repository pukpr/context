/*
 *    PROJECT:      dvise
 *    SUBSYSTEM:    ec
 *    MODULE:
 *
 *    File:         $RCSfile: bodyfly.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:07:48 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: bodyfly.h,v 1.1 2005/09/13 15:07:48 pukitepa Exp $
 *
 *    FUNCTION:
 *
 *
 *
 * Copyright (c) 1994 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */

#ifndef _BODYMOVE_H
#define _BODYMOVE_H

#ifdef __cplusplus
extern "C" {
#endif

#include <dvise/ectools.h>

/* PUBLIC DEFINES =======================================*/

#define ECBODYFLY_NULL 0x0
#define ECBODYFLY_MOVEMODE_JUMP 0x1
#define ECBODYFLY_MOVEMODE_LINEAR 0x2

/* Not fully implemented */
#define ECBODYFLY_MOVEMODE_KEYFRAME 0x4
/* ************************ */

#define ECBODYFLY_POSMODE_CENTRE_ABSOLUTE 0x1
#define ECBODYFLY_POSMODE_CENTRE_RELATIVE 0x2
#define ECBODYFLY_POSMODE_FILL_ABSOLUTE 0x4
#define ECBODYFLY_POSMODE_FILL_RELATIVE 0x8

#define ECBODYFLY_ROTATEMODE_ABSOLUTE 0x1
#define ECBODYFLY_ROTATEMODE_RELATIVE 0x2
#define ECBODYFLY_ROTATEMODE_ABSOLUTE_SETDIST 0x4
#define ECBODYFLY_ROTATEMODE_RELATIVE_SETDIST 0x8

#define ECBODYFLY_LINKMODE_LEAVE 0x1
#define ECBODYFLY_LINKMODE_UNLINK 0x2
#define ECBODYFLY_LINKMODE_LINK 0x4
#define ECBODYFLY_LINKMODE_UNTIL_MOVE 0x8

/* PUBLIC TYPES =========================================*/

struct ECBodyFly;

typedef struct ECBodyFly    ECBodyFly;


/* PUBLIC VARIABLES ======================================*/

DV_EXPORT int EC_FlyBodyToPosition(VCBody *body,
                         dmPoint pos, dmEuler orient, float32 distFromPoint);
DV_EXPORT int EC_FlyBodyToAssembly(VCBody *body, ECAssembly *assembly, int useTree);
DV_EXPORT int EC_FlyBodyToCentreAssembly(VCBody *body, ECAssembly *assembly);
DV_EXPORT int EC_FlyBodyToAssemblyList(VCBody *body, ECItem *assemblies, int useTree);

/* PUBLIC FUNCTIONS ======================================*/

DV_EXPORT ECBodyFly *ECBodyFly_Create(VCBody *body, VCAttribute *bodyPart);
DV_EXPORT int ECBodyFly_Delete(ECBodyFly *bodyFly);
DV_EXPORT int ECBodyFly_ToPosition(ECBodyFly *bodyFly, dmPoint pos,
                         dmEuler orient, float32 distFromPoint, 
                         float32 time, int useLogTime, int moveMode,
                         int usePostRot[3],dmEuler postRot, float32 postRotTime);
DV_EXPORT int ECBodyFly_ToAssembly(ECBodyFly *bodyFly, ECItem *assemblys,
                         int maxNumForUpdates,int useTree,int maxAssemblyNum,
                         dmEuler orient, dmVector vector, float32 time, 
                         int useLogTime, int moveMode, int posMode,
                         int link,int flyToInv,
                         int usePostRot[3],dmEuler postRot, float32 postRotTime);
DV_EXPORT int ECBodyFly_AroundAssembly(ECBodyFly *bodyFly, ECItem *assemblys,
                             int maxNumForUpdates,int useTree,int maxAssemblyNum,
                             dmEuler orient, float32 destinDist, float32 time, 
                             int useLogTime,int moveMode, int rotMode,
                             int link,int flyToInv,
                             int usePostRot[3],dmEuler postRot, float32 postRotTime);


DV_EXPORT int ECBodyFly_ToPositionSnap(ECBodyFly *bodyFly, dmPoint pos,
                             dmEuler orient, float32 distFromPoint, 
                             float32 time, int useLogTime, int moveMode,
                             dmPoint xyzLocks,dmEuler rypLocks,
                             int usePostRot[3],dmEuler postRot, float32 postRotTime);
DV_EXPORT int ECBodyFly_ToAssemblySnap(ECBodyFly *bodyFly, ECItem *assemblys,
                             int maxNumForUpdates,int useTree,int maxAssemblyNum,
                             dmEuler orient, dmVector vector, float32 time,
                             int useLogTime,
                             int moveMode, int posMode,int link, int flyToInv,
                             dmEuler rypLocks,
                             int usePostRot[3],dmEuler postRot, float32 postRotTime);
DV_EXPORT int ECBodyFly_AroundAssemblySnap(ECBodyFly *bodyFly, ECItem *assemblys,
                                 int maxNumForUpdates,int useTree,int maxAssemblyNum,
                                 dmEuler orient, float32 destinDist, float32 time, 
                                 int useLogTime,int moveMode, 
                                 int rotMode,
                                 int link, int flyToInv, dmEuler rypLocks,
                                 int usePostRot[3],dmEuler postRot, float32 postRotTime);
DV_EXPORT ECBodyFly *EC_GetBodyFlyUserData(VCBody *body,VCAttribute *bodyPart);

DV_EXPORT int ECBodyFly_OverrideTime(ECBodyFly *bodyFly, float32 newTime, int useLogTime);
/* Will return -1 if time is unknown */
DV_EXPORT float32 ECBodyFly_GetTimeLeft(ECBodyFly *bodyFly);
DV_EXPORT int ECBodyFly_Terminate(ECBodyFly *bodyFly, int moveToDestination);
DV_EXPORT void ECBodyFly_GetFlyToPos(dmPoint pos, dmEuler ori);

DV_EXPORT int ECBodyFly_GetJumpOnly(void);
DV_EXPORT void ECBodyFly_SetJumpOnly(int val);


#ifdef __cplusplus
}
#endif

#endif /* _BODYMOVE_H__ */
