/****************************************************************************
 *
 *  			Copyright 1995 Division Limited.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Assembly Name   : $RCSfile: vwborder.h,v $
 *  Revision      : $Revision: 1.1 $
 *  Date          : $Date: 2005/09/13 15:08:11 $
 *  Author        : $Author: pukitepa $
 *  Last Modified : <220497.1124>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 *  $Log: vwborder.h,v $
 *  Revision 1.1  2005/09/13 15:08:11  pukitepa
 *  init
 *
 *  Revision 1.4  1997/04/22 12:33:46  simon
 *  *** empty log message ***
 *
 *  Revision 1.3  1996/10/08 14:00:57  alex
 *  Tidies up the widget header file interface.
 *  Added some (incomplete) support for toolbox positioning.
 *  Added support for 'Context Sensitive' Area and callbacks around a widget.
 *  Fixed bug with re-sizeing a form widget via the draggable sash widget.
 *
 *  Revision 1.2  1996/09/10 16:05:58  simon
 *  *** empty log message ***
 *
 *  Revision 1.1.1.1  1996/07/25 16:05:40  alex
 *  Initial import of VWidgets
 *
 *  Revision 1.1.1.1  1996/07/24 15:01:40  alex
 *  Initial version we hope.
 *
 * Revision 1.3  96/03/10  18:51:13  alex
 * Dont_You_Just_Hate_These_Messages
 * 
 * Revision 1.2  96/02/23  10:54:20  alex
 * Quick_RCS_Check
 * 
 * Revision 1.1  95/12/04  11:44:55  alex
 * Quick_RCS_Check
 * 
 *
 ****************************************************************************
 *
 *  Copyright (c) 1995 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 *  This Document may not, in whole or in part, be copied,
 *  photocopied, reproduced, translated, or reduced to any
 *  electronic medium or machine readable form without prior
 *  written consent from Division Ltd.
 ****************************************************************************/



#ifndef __VWCOMPOSITE_H__
#define __VWCOMPOSITE_H__
#ifdef __cplusplus
extern "C" {
#endif
enum VWCompositeArgs {
    VWrBorderVisual = VW_RESOURCES_COMPOSITE, 
    VWrBorderMaterial, 
    VWrBorderOrientation
};
    
#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /* __VWCOMPOSITE_H__ */
