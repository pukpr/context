/*
 *      PROJECT:
 *      SUBSYSTEM:
 *      MODULE:
 *
 *      FILE:           $RCSfile: vdi_parse.h,v $
 *      REVISION:       $Revision: 1.1 $
 *      Date:           $Date: 2005/09/13 15:07:59 $
 *      Author:         $Author: pukitepa $
 *      RCS Ident:      $Id: vdi_parse.h,v 1.1 2005/09/13 15:07:59 pukitepa Exp $
 *
 *      FUNCTION:
 *
 * Copyright (c) 1992,1993,1994 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
/*
 *      PROJECT:
 *      SUBSYSTEM:
 *      MODULE:
 *
 *      FILE:           $RCSfile: vdi_parse.h,v $
 *      REVISION:       $Revision: 1.1 $
 *      Date:           $Date: 2005/09/13 15:07:59 $
 *      Author:         $Author: pukitepa $
 *      RCS Ident:      $Id: vdi_parse.h,v 1.1 2005/09/13 15:07:59 pukitepa Exp $
 *
 *      FUNCTION:
 *
 * Copyright (c) 1992,1993,1994 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */

#ifndef VDI_PARSE_H
#define VDI_PARSE_H

#include "ec_parser.h"

typedef enum {
tAssembly = 257,
tZone,
tObject,
tName,
tTemplate,
tState,
tVisual,
tCollision,
tEvent,
tPosition,
tOrientation,
tScale,
tAction,
tApply,
tGeometry,
tAbsolute,
tActionFunctionSyntax,
tAmbient,
tAnnotation,
tAudio,
tBack,
tBackgroundColour,
tBBox,
tBillBoard,
tBitmap,
tBody,
tBounce,
tCamera,
tColour,
tComment,
tCone,
tConstraints,
tCreate,
tDamper,
tDate,
tDefineLibrary,
tDelete,
tDiffuse,
tDirectional,
tDistance,
tDynamicFriction,
tEmissive,
tFarClip,
tFile,
tFileType,
tFilter,
tFlatten,
tFont,
tForce,
tFrame,
tFreeze,
tFront,
tGain,
tGravity,
tGrid,
tHeader,
tHingeX,
tHingeY,
tHingeZ,
tHyperlink,
tIcon,
tIn,
tInch,
tIntersectMask,
tInvQuiet,
tItem,
tKey,
tKeyFrames,
tLandmark,
tSpare1,
tSpare2,
tLength,
tLight,
tLimb,
tLinear,
tList,
tLoad,
tLockPlane,
tLockFixed,
tLockGrid,
tLockPitch,
tLockRoll,
tLockX,
tLockY,
tLockYaw,
tLockZ,
tLoop,
tLod,
tLoops,
tMap,
tMass,
tMassCentre,
tMassDistrib,
tMaterial,
tMaterialsFile,
tMaxFly,
tMeter,
tMinFly,
tMm,
tMod,
tMode,
tNearClip,
tNow,
tOff,
tOn,
tOpacity,
tOriginal,
tOut,
tPath,
tPaused,
tPhysical,
tPickable,
tPicking,
tPlugin,
tPoint,
tPolygonal,
tPolygonal2d,
tPolygonal3d,
tPortal,
tPriority,
tQuiet,
tQuick,
tRadPattern,
tRate,
tRelative,
tRenderMode,
tReport,
tReset,
tRole,
tSearchPath,
tShadow,
tSlowOut,
tSlowIn,
tSlowInSlowOut,
tSnapRot,
tSnapScale,
tSnapTrans,
tSource,
tSpatialised,
tSpatialized,
tSpline,
tSpecular,
tSpeed, 
tSphere,
tSpot,
tSpring,
tStartTime,
tStaticFriction,
tStatic,
tStatus,
tSystem,
tText,
tTexture,
tTextString,
tTickRate,
tTime,
tTimes,
tTimeOffset,
tToggle,
tTools,
tTorque,
tTotalTime,
tTree,
tType,
tUnit,
tUseLibrary,
tUserData,
tUserEvent,
tVelocity,
tVDILib,
tVDIMain,
tVDISrc,
tVDIAny,
tVDIFileFixed,
tVDILocked,
tVDIMaterial,
tVDIAssembly,
tVDIZone,
tVDIRole,
tVDIList,
tVDIUnlocked,
tVector,
tVersion,
tVisible,
tVoice,
tWireFrame,
/* new key frame tokens */
tPreStartFrame,
tPostEndFrame,
tPathInterpolation,
tSpeedInterpolation,
tCatmullRom,
tConstantExplicit,
tConstantImplicit,
tTimeScalar,
/* American spellings */
tBackgroundColor,
tColor,
/* data field types */
tdfInt,
tdfFloat,
tdfString,
tdfColour,
tdfColor,
tdfVector,
tdfRotation,
tdfState,
tdfAxis,
tdfBinaryData,
tdfAssembly,
tdfZone,
tdfAngle,
tdfAction,
tdfSection,
tdfScale,
tdfPosition,
tdfFileName,
tdfURL,
tdfEuler,
tEventData,
tActionData,
tFlightPath,
tSection,
tLightTube,
tDistanceLine,
tDistanceMulti,
tDistanceCircle,
tEnvelope,
tPivot,
tOwner,
tXYZOrientation
/* ... */
} ParseTokens;

#define tStartValue (int)tAssembly
#define tEndValue (int)tOwner
#define tDCITokensOffset 167

typedef struct DCIMessage {
    int inUse;  /* TRUE if we are reading a message from the DCI link */
    int server; /* TRUE if we are in dVISE (not in a client) */
} DCIMessage;

typedef struct {
ECAssembly *object;
ECFile *file;
ECRole *role;
ECLibrary *library;
ECUserData *userData;
} hierarchy;

/*
 * Parser / Writer settings held in ECFile flags
 */
#define EC_SAVE_LOAD_STATES      0x01
#define EC_PLUGIN_FILE           0x02

/*
 * VDI PARSER ROUTINE PROTOTYPES  ===========================================
 */
DV_EXPORT ECFile *parseVDIFile(char *, ECFile *, void *, ECItemType);
DV_EXPORT ECFile *parseVDIFragment(char *fileName);
DV_EXPORT void *dVDIPaths;
DV_EXPORT void *dBMFPaths;
DV_EXPORT int matchMagic( dParseFilePtr );
DV_EXPORT int matchKeyword( dParseFilePtr, int * );
DV_EXPORT int checkKeyword( dParseFilePtr, int );
DV_EXPORT ECHeader *buildHeader( dParseFilePtr, int * );
DV_EXPORT ECSystem *buildSystem( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECFile *useLibrary( dParseFilePtr, int *, void *, ECItemType, hierarchy * );
DV_EXPORT ECFile *parseMaterialsFile(char *filename, ECFile *, char *libraryName, ECLibrary **libCreated);
DV_EXPORT ECFile *loadPlugin(char *filename);
DV_EXPORT ECAssembly *buildAssembly( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECEventList *buildEventList( dParseFilePtr, int *, ECEventList *, hierarchy * );
DV_EXPORT ECEvent *buildEvent( dParseFilePtr, int *, char *, ECEventList *, hierarchy * );
DV_EXPORT ECAction *buildAction( dParseFilePtr, int *, char *, ECEvent *, hierarchy * );
DV_EXPORT ECConstraints *buildConstraints( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECIcon *buildIcon( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECLibrary *defLibrary( dParseFilePtr, int *, void *, ECItemType, hierarchy * );
DV_EXPORT ECList *buildList(  dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECItem *buildItem( dParseFilePtr, int *, hierarchy * );
DV_EXPORT EC_DCI_EventData *buildEventData(dParseFilePtr, int *, hierarchy *);
DV_EXPORT ECPhysical* buildPhysical( dParseFilePtr, ECItemType, int *, hierarchy * );
DV_EXPORT void matchBounce( dParseFilePtr, int *, ECPhysical*  );
DV_EXPORT ECVisual *buildVisual( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECPivot *buildPivot( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECLight *buildLight( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECCollision *buildCollision( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECAudio *buildAudio( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECKeyFrames *buildKeyFrames( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECFrame *buildFrame( dParseFilePtr, int *, ECKeyFrames *, hierarchy * );
DV_EXPORT ECPath *buildPath( dParseFilePtr, int *, hierarchy * );
DV_EXPORT void buildBodyInfo( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECRole *buildRole( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECTools *buildTools( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECUserData *buildUserData( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECBinaryData *buildBinaryData(dParseFilePtr, int *, hierarchy *);
DV_EXPORT ECField *buildUserDataField(dParseFilePtr IS, int *tkIn, hierarchy *pH);
DV_EXPORT int parseSpecifiers(dParseFilePtr, int *, hierarchy *, char **,
			   char **, int *length, int *mode, char **, ECItemType *);
DV_EXPORT void *buildMaterial( dParseFilePtr, int * );
DV_EXPORT void *buildTexture( dParseFilePtr, int * );
DV_EXPORT int skipBlock( dParseFilePtr, int, char, char );
DV_EXPORT int findBlockend( dParseFilePtr, hierarchy *, int, char * );
DV_EXPORT char *matchComment( dParseFilePtr, hierarchy * );
DV_EXPORT float32 matchReal( dParseFilePtr, hierarchy *, int * );
DV_EXPORT int matchNum( dParseFilePtr, hierarchy * );
DV_EXPORT ECVec3 *matchECVec3( dParseFilePtr, hierarchy *, int * );
DV_EXPORT float32 *matchOrient( dParseFilePtr, hierarchy *, int * );
DV_EXPORT float32 *matchXYZOrient( dParseFilePtr, hierarchy *, int * );
DV_EXPORT float32 *matchVector( dParseFilePtr, hierarchy *, int * );
DV_EXPORT float32 *matchQuaternion( dParseFilePtr, hierarchy *, int * );
DV_EXPORT int matchTemplate( dParseFilePtr, hierarchy *, int *, char **, char ** );
DV_EXPORT ECStateType matchOnOff( dParseFilePtr, hierarchy *, int * );
DV_EXPORT int matchSingleLock(dParseFilePtr, hierarchy *, ECConstraints *, int);
DV_EXPORT int matchGridCommands(dParseFilePtr, hierarchy *, ECConstraints *);
DV_EXPORT float32 matchTime( dParseFilePtr, hierarchy *, int * );
DV_EXPORT char *matchName(dParseFilePtr, hierarchy *, int *);
DV_EXPORT char *matchExpression(dParseFilePtr, hierarchy *, int *);
DV_EXPORT DCIMessage *DCIMessageInfoGet(void);
DV_EXPORT void DCIMessageInfoSet(int, int);
DV_EXPORT dParseKeyTab * ECGetVDIKeyTab();
DV_EXPORT void EC_ResolveExtTemplates(int mode);
DV_EXPORT void VDI_ErrorStdOut(void);
DV_EXPORT void VDI_ErrorStdErr(void);

#endif
