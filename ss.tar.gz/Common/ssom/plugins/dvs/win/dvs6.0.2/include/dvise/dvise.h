/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: dvise.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:07:50 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: dvise.h,v 1.1 2005/09/13 15:07:50 pukitepa Exp $
 *
 *    FUNCTION:
 *
 *
 *    $Log: dvise.h,v $
 *    Revision 1.1  2005/09/13 15:07:50  pukitepa
 *    init
 *
 *    Revision 1.13  1998/07/27 17:53:50  john
 *    dvise main executable is now c++ to allow for C++ plugins
 *    Some structures and header files have had to change as a consequence
 *
 *    Revision 1.12  1998/07/22 10:59:12  clives
 *    Options dialogue DCI and EC support.
 *
 *    Revision 1.11  1998/07/16 13:56:09  clives
 *    Further additions to the renderer options support.
 *
 *    Revision 1.10  1998/05/25 09:58:39  hoppy
` *    New file searching stuff incorporated.
 *
 *    Revision 1.9  1997/07/14 10:23:35  mdj
 *    *** empty log message ***
 *
 *    Revision 1.8  1997/03/12 09:30:15  mdj
 *    *** empty log message ***
 *
 *    Revision 1.7  1997/02/18 17:29:06  clives
 *    *** empty log message ***
 *
 *    Revision 1.6  1997/01/21 17:38:53  clives
 *    *** empty log message ***
 *
 *    Revision 1.5  1997/01/16 15:19:53  clives
 *    *** empty log message ***
 *
 *    Revision 1.4  1996/12/20 16:13:34  simon
 *    *** empty log message ***
 *
 *    Revision 1.3  1996/12/17 15:24:46  clives
 *    *** empty log message ***
 *
 *    Revision 1.2  1996/11/11 14:10:55  wman
 *    Fixed hp build warnings.
 *
 *    Revision 1.1.1.1  1996/07/25 16:07:44  alex
 *    Initial import of dVISE
 *
 *    Revision 1.1.1.1  1996/07/24 17:30:18  alex
 *    Initial version of dVISE
 *
 * Revision 1.9  96/02/23  10:57:38  10:57:38  wman (William Man)
 * *** empty log message ***
 * 
 * Revision 1.7  1995/09/12  10:56:51  alex
 * Quick_RCS_Check
 *
 * Revision 1.6  95/07/25  10:22:04  alex
 * Quick_RCS_Check
 * 
 * Revision 1.5  1995/07/12  15:35:13  alex
 * Quick_RCS_Check
 *
 * Revision 1.4  95/04/13  17:10:51  alex
 * Quick_RCS_Check
 * 
 * Revision 1.3  95/04/06  15:12:24  alex
 * Quick_RCS_Check
 * 
 * Revision 1.2  95/03/13  17:02:46  alex
 * *** empty log message ***
 * 
 * Revision 1.1  1995/03/01  13:17:31  alex
 * Initial revision
 *
 * Revision 1.3  1995/02/13  12:55:26  alex
 * *** empty log message ***
 *
 * Revision 1.2  1995/01/20  12:33:09  michael
 * *** empty log message ***
 *
 * Revision 1.1  1995/01/19  17:22:43  alex
 * Initial revision
 *
 *
 * Copyright (c) 1992 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _DVISE_H
#define _DVISE_H

/* PRIVATE DEFINES =======================================*/

#define TOOLBOX

/* PUBLIC INCLUDES ====================================== */

#include <stdlib.h>
#include <stdio.h>
#include <dvs/vc.h>
#ifdef TOOLBOX
#include <dvise/tbtools.h>
#endif
#include <dvise/ecatools.h>
#include <dvise/dcitools.h>
#include <dvise/dvmacro.h>
#include <dvise/event.h>
#include <dvise/camera.h>
#include <dvise/role.h>
#include <dvise/vdi1.h>
#include <dvise/eclicense.h>
#include <dvise/select.h>
#include <dvise/bodyfly.h>

#ifdef __cplusplus
extern "C" {
#endif

/* PUBLIC DEFINES ======================================= */
#define DCI_BLOCKED_WRITE_INTERVAL 2.0 /* seconds */

DV_EXPORT  void *dVDIPaths;
DV_EXPORT  void *dBMFPaths;
DV_EXPORT  void *dTEXPaths;
DV_EXPORT  void *dTOOLBOXPaths;

#if defined _WINDOWS
#define SPL_PATH_LOCAL   ".;./splines"
#define VDI_PATH_LOCAL   ".;./vdifiles"
#define BMF_PATH_LOCAL   ".;./material"
#define TEX_PATH_LOCAL   ".;./texture"
#else
#define SPL_PATH_LOCAL   ".:./splines"
#define VDI_PATH_LOCAL   ".:./vdifiles"
#define BMF_PATH_LOCAL   ".:./material"
#define TEX_PATH_LOCAL   ".:./texture"
#endif

#define VDI_PATH_ENV     "VDI_PATH"
#define VDI_PATH_OFFSET  "vdifiles"

#define BMF_PATH_ENV     "BMF_PATH"
#define BMF_PATH_OFFSET  "material"

/* Added Simon 20/12/96 - Is TEX_PATH correct */
#define TEX_PATH_ENV     "TEX_PATH"
#define TEX_PATH_OFFSET  "texture"

/* PUBLIC TYPES ========================================= */


/* PUBLIC VARIABLES ====================================== */

/* static (global) ints to control the record and replay state 
 * accessed via the camgroup routines prototyped below
 */


/* PUBLIC FUNCTIONS ====================================== */

DV_EXPORT void dviseExit(int32 code);
DV_EXPORT void dVISE_Initialise(int *argc, char **argv);
DV_EXPORT void dviseLibVersion(FILE *fp);
DV_EXPORT void RegisterActionFunctions(void);
DV_EXPORT void dVISE_SetRendererOptions(VCBody *b, VCAttribute *a, ECUserData *options);
DV_EXPORT void dVISE_QueryRendererOptions(VCBody *b, ECUserData *qryOpts);
DV_EXPORT ECUserData *dVISE_ConstructRendOptsQry(char *name, ...);
DV_EXPORT void EC_GetCamGroupState(int *recState, int *replState);
DV_EXPORT void EC_SetCamGroupState(int recState, int replState);

#ifdef __cplusplus
}
#endif
#endif /*_DVISE_H */
