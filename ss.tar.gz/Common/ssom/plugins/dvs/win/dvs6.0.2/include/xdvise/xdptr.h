/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1997 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: xdptr.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 5 March 1997
--  Author       : Tony Coombes
--
--  Description	 : Used to maintain a list of pointers.
--                 
--
--  Modified     : 
--    $Log: xdptr.h,v $
--    Revision 1.1  2005/09/13 15:08:26  pukitepa
--    init
--
--    Revision 1.1  1997/07/09 12:32:27  simon
--    *** empty log message ***
--
--    Revision 1.1  1997/03/05 20:54:30  tony
--    *** empty log message ***
--
--
-- ----------------------------------------------------------------------------
*/

#ifndef __XDPTR_H__
#define __XDPTR_H__

#ifdef __cplusplus
extern "C" {
#endif


typedef struct ptrListT ptrListT;

extern ptrListT *XdPtrList_Create(int initialSize);
extern void      XdPtrList_Destroy(ptrListT *lst);
extern int       XdPtrList_Append(ptrListT *lst, void *ptr);
extern void    **XdPtrList_GetListPtr(ptrListT *lst);
extern int       XdPtrList_GetUsed(ptrListT *lst);
extern void      XdPtrList_Operate(ptrListT *lst, int (*fn)(void *ptr, void *userData), 
                                   void *userData);


#ifdef __cplusplus
}
#endif

#endif /* __XDPTR_H__ */
