/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1995 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : Audio utilities
--  Object Name  : $RCSfile: auverb.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : $Date: 2005/09/13 15:08:01 $
--  Author       : $Author: pukitepa $
--
--  Description	
--	Verbosity and debugging levels for the audio actor.
--
--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __AUVERB_H__
#define __AUVERB_H__

    /*
     * verbosity levels
     */

#define AU_VERB_DESC    0x1     /* VCAudio descriptor  */
#define AU_VERB_RAD     0x2     /* VCRadiator and radiation files */
#define AU_VERB_SOUND   0x4     /* Entity sounds */
#define AU_VERB_USER    0x8     /* Audio user resources */
#define AU_VERB_DEV    0x10     /* Audio devices */
#define AU_VERB_RES    0x20     /* Resource create/allocation etc */
#define AU_VERB_FILE   0x40     /* file searching */
#define AU_VERB_VOI    0x80     /* voice */
#define AU_VERB_CFG   0x100     /* configuration */

    /*
     * debug levels
     */

#define AU_DEB_DESC   0x1       /* VCAudio descriptor */
#define AU_DEB_RAD    0x2       /* VCRadiator and radiation files */
#define AU_DEB_SOUND  0x4       /* Entity sounds */
#define AU_DEB_USER   0x8       /* Audio user resources */
#define AU_DEB_DEV   0x10       /* Audio devices */
#define AU_DEB_RES   0x20       /* Resource create/allocation etc */
#define AU_DEB_FILE  0x40       /* file searching */
#define AU_DEB_VOI   0x80       /* voice  */
#define AU_DEB_CFG  0x100       /* configuration */

#endif /* __AUVERB_H__ */
