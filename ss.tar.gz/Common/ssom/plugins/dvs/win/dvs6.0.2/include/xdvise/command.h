/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1993 Division Limited.
--			      All Rights Reserved
--
--
--  System       : 
--  Module       : 
--  Object Name  : $RCSfile: command.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : $Date: 2005/09/13 15:08:18 $
--  Author       : $Author: pukitepa $
--
--  Description	
--
--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __XDCOMMAND_H__
#define __XDCOMMAND_H__

#ifdef __cplusplus
extern "C" {
#endif

extern void XdRegisterDCICallbacks(void);
extern void DCIregisterInterest(int msg, 
                    void (*proc)(void *dlg, void *callData, void *clientData), 
		    void *dlg, void *clientData);
extern void XdMarkResetUserEvents(void);

#ifdef __cplusplus
}
#endif

#endif /* __XDCOMMAND_H__ */

/*
 * RCS History
 *
 * $Log: command.h,v $
 * Revision 1.1  2005/09/13 15:08:18  pukitepa
 * init
 *
 * Revision 1.2  1997/11/13 17:26:31  simon
 * bug fixes.
 *
 * Revision 1.1  1997/07/09 12:28:39  simon
 * *** empty log message ***
 *
 * Revision 1.2  1996/09/17 16:52:15  tony
 * *** empty log message ***
 *
 * Revision 1.1.1.1  1996/08/29 09:25:59  tony
 * first version of xdvise
 *
 * Revision 3.2  1996/08/05 15:06:37  tony
 * Check in prior to starting development for IDP
 *
 * Revision 3.1  1996/02/26 16:31:06  tony
 * Release 3.0
 *
 * Revision 1.2  1995/01/18  14:43:29  tony
 * *** empty log message ***
 *
 * Revision 1.1  1995/01/05  08:57:19  tony
 * Initial revision
 *
 * Revision 1.1  94/08/31  15:22:29  tony
 * Initial revision
 * 
 * Revision 0.6  1993/10/08  09:23:03  john
 * 2.0.4c
 *
 * Revision 1.2  1993/10/03  16:46:15  john
 * 2.0.4c release
 *
 * Revision 0.4  93/09/24  11:28:18  jon
 * Release 2.0.4
 * 
 * Revision 1.1  93/05/19  13:24:33  mark
 * Initial revision
 * 
 *
 */
