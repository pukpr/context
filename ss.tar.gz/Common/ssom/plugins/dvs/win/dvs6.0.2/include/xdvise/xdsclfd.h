/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1996 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: xdsclfd.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 26 April 1996
--  Author       : Tony Coombes
--
--  Description	 : Scale Vector Field
--
--  Modified     : 
--    $Log: xdsclfd.h,v $
--    Revision 1.1  2005/09/13 15:08:27  pukitepa
--    init
--
--    Revision 1.1  1997/07/09 12:32:35  simon
--    *** empty log message ***
--
--    Revision 1.2  1997/02/11 18:57:56  wman
--    Frame reset for animation dialog.
--
--    Revision 1.1.1.1  1996/08/29 09:26:20  tony
--    first version of xdvise
--
--    Revision 3.1  1996/08/05 15:06:37  tony
--    Check in prior to starting development for IDP
--
--    Revision 1.1  1996/06/18 11:17:02  tony
--    Mid development revision
--
--
--
-- ----------------------------------------------------------------------------
*/

#ifndef __XDSCLFD_H__
#define __XDSCLFD_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct sclVecFieldT sclVecFieldT; /* Prototype */

extern sclVecFieldT *XdSclVecFieldCreate(compT parent, char *label,  
		      void (*changedCallback)(sclVecFieldT *w, void *clientData), 
		      void *clientData);
extern void XdSclVecFieldDestroy(sclVecFieldT *sclVecField);
extern int  XdSclVecFieldGetValue(sclVecFieldT *sclVecField, dmScale value);
extern void XdSclVecFieldSetValue(sclVecFieldT *sclVecField, dmScale value, int explicit);
extern int  XdSclVecFieldGetResetValue(sclVecFieldT *sclVecField, dmScale value);
extern int  XdSclVecFieldHasChanged(sclVecFieldT *sclVecField);

#ifdef __cplusplus
}
#endif

#endif /* __XDSCLFD_H__ */
