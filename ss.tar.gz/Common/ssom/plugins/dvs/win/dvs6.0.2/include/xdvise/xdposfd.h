/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1996 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: xdposfd.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 24 May 1996
--  Author       : Tony Coombes
--
--  Description	 : Position Vector Field
--                 based on 3-Vector Field
--
--  Modified     : 
--    $Log: xdposfd.h,v $
--    Revision 1.1  2005/09/13 15:08:26  pukitepa
--    init
--
--    Revision 1.3  1998/03/13 14:29:06  tony
--    Support to allow users to configure the units
--    used to display distance measurements
--
--    Revision 1.2  1997/10/23 13:31:33  dvs-dev
--    NT changes for the collision and advanced collision dlg.
--    Fixes to get the section code and collision detection code to build on NT.
--    General bug fixes.
--
--    Revision 1.1  1997/07/09 12:32:17  simon
--    *** empty log message ***
--
--    Revision 1.2  1997/02/11 18:57:52  wman
--    Frame reset for animation dialog.
--
--    Revision 1.1.1.1  1996/08/29 09:26:19  tony
--    first version of xdvise
--
--    Revision 3.1  1996/08/05 15:06:37  tony
--    Check in prior to starting development for IDP
--
--    Revision 1.2  1996/06/18 11:17:02  tony
--    Mid development revision
--
--
--
-- ----------------------------------------------------------------------------
*/

#ifndef __XDPOSFD_H__
#define __XDPOSFD_H__

#ifdef __cplusplus
extern "C" {
#endif

#ifndef XDV_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `XDV_EXPORT'
 */
#ifdef  _LIB_XDV
#define XDV_EXPORT __declspec(dllexport) extern
#else
#define XDV_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define XDV_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ifndef XDV_EXPORT */

typedef struct posVecFieldT posVecFieldT; /* Prototype */

XDV_EXPORT posVecFieldT*
XdPosVecFieldCreate(compT parent, char *label,  
		      void (*changedCallback)(posVecFieldT *w, void *clientData), 
		      void *clientData);
XDV_EXPORT void XdPosVecFieldDestroy(posVecFieldT *posVecField);
XDV_EXPORT int  XdPosVecFieldGetValue(posVecFieldT *posVecField, dmPoint value);
XDV_EXPORT void XdPosVecFieldSetValue(posVecFieldT *posVecField, dmPoint value, int explicit);
XDV_EXPORT void XdPosVecFieldReset(posVecFieldT *posVecField);
XDV_EXPORT int  XdPosVecFieldGetResetValue(posVecFieldT *posVecField, dmPoint value);
XDV_EXPORT int  XdPosVecFieldHasChanged(posVecFieldT *posVecField);

#ifdef __cplusplus
}
#endif

#endif /* __XDPOSFD_H__ */
