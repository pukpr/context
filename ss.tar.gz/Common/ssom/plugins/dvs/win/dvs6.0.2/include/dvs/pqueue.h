/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1994 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS 2.1
--  Module       : Audio support library
--  Object Name  : $RCSfile: pqueue.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : $Date: 2005/09/13 15:08:04 $
--  Author       : $Author: pukitepa $
--
--  Description	
--	Priority queue

--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __PQUEUE_H__
#define __PQUEUE_H__

/*
 * ------------------------------------------------------------
 * 
 * An abstract data type for priority queues
 *
 * ------------------------------------------------------------
 */

typedef void *PQueue;
typedef void *PQKey;
typedef void *PQData;

/*
 * ------------------------------------------------------------
 *
 * Function pointer typedefs.
 *
 * PQTotalOrder : an ordering relation on keys.
 * PQEquiv      : an equivalence relation on keys.
 * PQCopy       : an assignemnt function on data.  Copies its
 *                argument into a dynamically allocated object
 *                and returns a pointer to that object.
 * PQExtractKey : a key extraction function.  Returns a pointer
 *                to the part of the data used as the primary
 *                key.
 * PQFree       : a function to free dynamically allocated data
 * PQMapFunc    : a mapping function.  The SLMap function calls
 *                this for each item in the table.
 * 
 * ------------------------------------------------------------
 */

typedef int    (*PQTotalOrder)(PQKey, PQKey);
typedef int    (*PQEquiv)(PQKey, PQKey);
typedef PQData (*PQCopy)(PQData);
typedef PQKey  (*PQExtractKey)(PQData);
typedef void   (*PQFree)(void *);
typedef void   (*PQMapFunc)(PQData);

/*
 * ------------------------------------------------------------
 *
 * Priority queue functions
 *
 * PQNew        : create a new queue
 * PQDeleteAll  : delete all data in a queue
 * PQAnihilate  : delete all data in queue and the queue itself
 * PQInsert     : add an item to the queue.
 * PQRemove     : removes the first item from the queue.
 * PQLook       : retrieves first item without removing.
 * PQDelete     : delete an entry from the queue.
 * PQFind       : find the data which matches the key value,
 *                return NULL if no successful match.
 *
 * ------------------------------------------------------------
 */

extern PQueue PQNew(PQCopy       dataCopy, 
                    PQFree       dataFree, 
                    PQExtractKey extractKey, 
                    PQTotalOrder lt, 
                    PQEquiv      eq);
extern void   PQDeleteAll(PQueue);
extern void   PQAnihilate(PQueue);
extern int    PQInsert(PQueue, PQData);
extern int    PQRemove(PQueue);
extern PQData PQLook(PQueue);
extern int    PQDelete(PQueue, PQKey);
extern PQData PQFind(PQueue, PQKey);

#endif /* __PQUEUE_H__ */
