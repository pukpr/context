/***************************************************************************
 *
 *    PROJECT:      dVS
 *    SUBSYSTEM:    VC Toolkit.
 *    MODULE:       VC Type definitions (dynamic geometry).
 *
 ***************************************************************************
 *
 *    File:         $RCSfile: vcdynam.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:08:06 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: vcdynam.h,v 1.1 2005/09/13 15:08:06 pukitepa Exp $
 *
 *    FUNCTION:
 *
 *
 *
 **************************************************************************
 *                                                                        *
 * Copyright (c) 1992 Division Ltd.                                       *
 *                                                                        *
 * All Rights Reserved.                                                   *
 *                                                                        *
 * This Document may not, in whole  or in part, be copied, photocopied,   *
 * reproduced, translated,  or  reduced  to  any  electronic  medium or   *
 * machine readable  form without  prior written  consent from Division   *
 * Ltd.                                                                   *
 *                                                                        *
 *************************************************************************/

#ifndef	_VCDYNTYPES_H	
#define	_VCDYNTYPES_H

/* defines */


/* typedefs */

typedef struct VCDynamicVisual_CallbackData   VCDynamicVisual_CallbackData;
typedef void	(*VCDynamicVisual_Func)	(VCDynamicVisual_CallbackData *attributeData, void *data);
typedef struct VCLod_CallbackData   VCLod_CallbackData;
typedef void	(*VCLod_Func)	(VCLod_CallbackData *attributeData, void *data);
typedef struct VCGeogroup_CallbackData   VCGeogroup_CallbackData;
typedef void	(*VCGeogroup_Func)	(VCGeogroup_CallbackData *attributeData, void *data);
typedef struct VCGeometry_CallbackData   VCGeometry_CallbackData;
typedef void	(*VCGeometry_Func)	(VCGeometry_CallbackData *attributeData, void *data);
typedef struct VCText_CallbackData   VCText_CallbackData;
typedef void	(*VCText_Func)	(VCText_CallbackData *attributeData, void *data);
typedef struct VCConnectionList_CallbackData   VCConnectionList_CallbackData;
typedef void	(*VCConnectionList_Func)	(VCConnectionList_CallbackData *attributeData, void *data);


typedef struct VCDynamicVisual_Traverse VCDynamicVisual_Traverse;
typedef struct VCLod_Traverse VCLod_Traverse;
typedef struct VCGeogroup_Traverse VCGeogroup_Traverse;
typedef struct VCGeometry_Traverse VCGeometry_Traverse;

typedef enum {
    VC_GEOMETRY_ALL=0x10,
    VC_SPHERELIST=VC_GEOMETRY_TYPE_SPHERELIST,
    VC_TRISTRIP=VC_GEOMETRY_TYPE_TRISTRIP,
    VC_POLYSTRIP=VC_GEOMETRY_TYPE_POLYSTRIP,
    VC_POLYGON=VC_GEOMETRY_TYPE_POLYGON,
    VC_STRING=VC_GEOMETRY_TYPE_TEXT,
    VC_VECTOR=VC_GEOMETRY_TYPE_LINE,
    VC_PMESH=VC_GEOMETRY_TYPE_PMESH,
    VC_POINTLIST=VC_GEOMETRY_TYPE_POINTLIST,
    VC_CONNECTIONLIST=VC_GEOMETRY_PMESH_CONNECTIONLIST,
    VC_STRIPLIST=VC_GEOMETRY_PMESH_STRIPLIST
} VCGeometry_Type;

typedef enum {
    VC_VERTEX_ALL     = 0xff,
    VC_VERTEX_XYZ     = VC_GEOGROUP_VERTEX_ONLY,
    VC_VERTEX_N       =(VC_GEOGROUP_VERTEX_ONLY | VC_GEOGROUP_VERTEX_NORMALS),
    VC_VERTEX_RGBA    =(VC_GEOGROUP_VERTEX_ONLY | VC_GEOGROUP_VERTEX_RGBA),
    VC_VERTEX_LA      =(VC_GEOGROUP_VERTEX_ONLY | VC_GEOGROUP_VERTEX_LUMINANCE),
    VC_VERTEX_UV      =(VC_GEOGROUP_VERTEX_ONLY | VC_GEOGROUP_VERTEX_2D_TEXTURE),
    VC_VERTEX_UVW     =(VC_GEOGROUP_VERTEX_ONLY | VC_GEOGROUP_VERTEX_3D_TEXTURE),
    VC_VERTEX_NUV     =(VC_GEOGROUP_VERTEX_ONLY | VC_GEOGROUP_VERTEX_NORMALS | VC_GEOGROUP_VERTEX_2D_TEXTURE),
    VC_VERTEX_RGBAUV  =(VC_GEOGROUP_VERTEX_ONLY | VC_GEOGROUP_VERTEX_RGBA | VC_GEOGROUP_VERTEX_2D_TEXTURE),
    VC_VERTEX_LAUV    =(VC_GEOGROUP_VERTEX_ONLY | VC_GEOGROUP_VERTEX_LUMINANCE | VC_GEOGROUP_VERTEX_2D_TEXTURE),
    VC_VERTEX_SPHERE  =(VC_GEOGROUP_VERTEX_ONLY | VC_GEOGROUP_VERTEX_RADIUS)
} VCVertex_Type;

typedef float VCVertexXYZ[3];
typedef float VCVertexN[6];
typedef float VCVertexRGBA[7];
typedef float VCVertexLA[5];
typedef float VCVertexUV[5];
typedef float VCVertexUVW[6];
typedef float VCVertexNUV[8];
typedef float VCVertexRGBAUV[9];
typedef float VCVertexLAUV[7];
typedef float VCVertexSphere[4];

typedef float  *VCVertex;  
typedef uint32 *VCConnection;

typedef void    (*VCDynamicVisual_TraverseFunc)    (VCDynamicVisual *item, void *data);
typedef void    (*VCLod_TraverseFunc)        (VCLod           *item, void *data);
typedef void    (*VCGeogroup_TraverseFunc)   (VCGeogroup      *item, void *data);
typedef void    (*VCGeometry_TraverseFunc)   (VCGeometry      *item, void *data);

/* structures */

typedef struct {
    VCGeometry_Type type;
    uint32 faceCount;
    uint32 noConnections;
    VCConnection data;
} VCConnectionData;

typedef struct {
    VCGeometry_Type type;
    VCConnectionList *connection;
    int               currentIndex, size, total, currentConnection;
    VCConnectionData *connectData;
    VCConnection      data;
} VCConnection_Reference;

typedef struct {
    VCGeometry *geometry;
    int         currentIndex, size;
    float       distance;
    VCVertex    data;
} VCVertex_Reference;

typedef struct {
    float min[3];
    float max[3];
    float center[3];
} VCGeometry_BoundBox;

struct VCDynamicVisual
{
    
    InstanceNo		 ino;
    char		*name;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    uint32		 instanceDataSize;
    uint32		 instanceDataCount;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;

    VCLod               *lod;		/* pointer to child LOD */
    void                *octreeData;	/* for future expansion */
    VCGeometry_BoundBox *boundingBox;	/* define extents of attached geometry */
    VCAttribute         *attribute;	/* pointer to parent */

}; 

struct VCLod 
{
    
    InstanceNo		 ino;
    char		*name;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    uint32		 instanceDataSize;
    uint32		 instanceDataCount;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;

    VCLod               *next;		/* LODs implemented as linked list */
    VCGeogroup          *geogroup;	/* pointer to child geogroup */
    void                *octreeData;	/* for future expansion */
    VCGeometry_BoundBox *boundingBox;	/* define extents of attached geometry */
    struct VCDynamicVisual     *dvisual; 	/* pointer to parent */

}; 

struct VCGeogroup 
{
    
    InstanceNo		 ino;
    char		*name;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    uint32		 instanceDataSize;
    uint32		 instanceDataCount;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;

    VCGeogroup          *next;	/* GEOGROUPs implemented as linked list */
    VCGeometry          *geometry;	/* pointer to child geometry */
    void                *octreeData;	/* for future expansion */
    VCGeometry_BoundBox *boundingBox;	/* define extents of attached geometry */
    VCLod               *lod; 		/* pointer to parent */
    VCVertex_Type        vertexFormat;	/* copy of geogroup setting */

}; 

struct VCGeometry 
{
    
    InstanceNo		 ino;
    char		*name;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    uint32		 instanceDataSize;
    uint32		 instanceDataCount;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;

    VCGeometry          *next;	/* GEOMETRY implemented as linked list */
    void                *octreeData;	/* for future expansion */
    VCGeogroup          *geogroup; 	/* pointer to parent */

    VCGeometry_Type	 type;		/* used to extract instanceData */
    VCVertex_Type        vertexFormat;	/* copy of geogroup setting */
    VCGeometry_BoundBox *boundingBox;	/* define extents of attached geometry */
    VCConnectionList    *connectionList; /* linked list for Pmeshes */

}; 

struct VCConnectionList 
{
    
    InstanceNo		 ino;
    char		*name;
    uint32		 status;
    uint32		 cacheMode;
    void		*instanceData;
    uint32		 instanceDataSize;
    uint32		 instanceDataCount;
    VCUserDataList	*userDataList;
    VCCallbackFunctions	*createFunctionList;
    VCCallbackFunctions	*deleteFunctionList;
    VCCallbackFunctions	*updateFunctionList;
    void		*createCallbackHandle;
    void		*updateCallbackHandle;
    void		*deleteCallbackHandle;

    VCConnectionData    *connectData;	
    VCGeometry          *geometry; 	/* pointer to parent */

};

struct VCDynamicVisual_CallbackData {
    VCDynamicVisual *dvisual;
};

struct VCLod_CallbackData {
    VCLod *lod;
};

struct VCGeogroup_CallbackData {
    VCGeogroup *geogroup;
};

struct VCGeometry_CallbackData {
    VCGeometry *geometry;
};

struct VCText_CallbackData {
    VCGeometry *geometry;
};

struct VCConnectionList_CallbackData {
    VCConnectionList *connectionList;
    VCGeometry       *geometry;
};

struct VCDynamicVisual_Traverse {
    VCDynamicVisual *dvisual;
    VCLod           *current;
};

struct VCLod_Traverse {
    VCLod *lod;
    VCGeogroup *current;
    VCVertex_Type search;
};

struct VCGeogroup_Traverse {
    VCGeogroup *geogroup;
    VCGeometry *current;
    VCGeometry_Type search;
};

struct VCGeometry_Traverse {
    VCGeometry       *geometry;
    VCConnectionList *current;
};


/* constants. */

/* VC_FONT definitions are defined in vcdefs.h */

/* macros */


#define VCSphereList_Delete(g)     VCGeometry_Delete(g)
#define VCSphereList_ModifyVertexList(g)     VCGeometry_Modify(g)
#define VCSphereList_Flush(g)     VCGeometry_Flush(g)
#define VCSphereList_Create(n,v) VCGeometry_Create(VC_SPHERELIST, \
						   VC_VERTEX_SPHERE,n,v,0,NULL)
#define VCGeogroup_AddSphereList(g, n,v) VCGeogroup_AddGeometry(g, \
						   VC_SPHERELIST,\
						   VC_VERTEX_SPHERE,n,v,0,NULL)

#define VCPolystrip_Delete(g)     VCGeometry_Delete(g)
#define VCPolystrip_ModifyVertexList(g)     VCGeometry_Modify(g)
#define VCPolystrip_Flush(g)     VCGeometry_Flush(g)
#define VCPolystrip_Create(t,n,v) VCGeometry_Create(VC_POLYSTRIP, \
						   t,n,v,0,NULL)
#define VCGeogroup_AddPolystrip(g,t,n,v) VCGeogroup_AddGeometry(g, \
						   VC_POLYSTRIP,\
						   t,n,v,0,NULL)

#define VCTristrip_Delete(g)     VCGeometry_Delete(g)
#define VCTristrip_ModifyVertexList(g)     VCGeometry_Modify(g)
#define VCTristrip_Flush(g)     VCGeometry_Flush(g)
#define VCTristrip_Create(t,n,v) VCGeometry_Create(VC_TRISTRIP, \
						   t,n,v,0,NULL)
#define VCGeogroup_AddTristrip(g,t,n,v) VCGeogroup_AddGeometry(g, \
						   VC_TRISTRIP,\
						   t,n,v,0,NULL)

#define VCPolygon_Delete(g)     VCGeometry_Delete(g)
#define VCPolygon_ModifyVertexList(g)     VCGeometry_Modify(g)
#define VCPolygon_Flush(g)     VCGeometry_Flush(g)
#define VCPolygon_Create(t,n,v) VCGeometry_Create(VC_POLYGON, \
						   t,n,v,0,NULL)
#define VCGeogroup_AddPolygon(g,t,n,v) VCGeogroup_AddGeometry(g, \
						   VC_POLYGON,\
						   t,n,v,0,NULL)

#define VCVector_Delete(g)     VCGeometry_Delete(g)
#define VCVector_ModifyVertexList(g)     VCGeometry_Modify(g)
#define VCVector_Flush(g)     VCGeometry_Flush(g)
#define VCVector_Create(t,n,v) VCGeometry_Create(VC_VECTOR, \
						   t,n,v,0,NULL)
#define VCGeogroup_AddVector(g,t,n,v) VCGeogroup_AddGeometry(g, \
						   VC_VECTOR,\
						   t,n,v,0,NULL)

#define VCPmesh_Delete(g)     VCGeometry_Delete(g)
#define VCPmesh_ModifyVertexList(g)     VCGeometry_Modify(g)
#define VCPmesh_FlushVertexList(g)     VCGeometry_Flush(g)
#define VCPmesh_Create(t,n,v,c,l) VCGeometry_Create(VC_PMESH, \
						   t,n,v,c,l)
#define VCGeogroup_AddPmesh(g,t,n,v,c,l) VCGeogroup_AddGeometry(g, \
						   VC_PMESH,\
						   t,n,v,c,l)
#define VCPmesh_AttachConnectionList(p,c) VCGeometry_AttachConnectionList(p,c)

#define VCString_Delete(g)          VCText_Delete(g)
#define VCString_Create(s,f,p,o,c) VCText_Create(s,-1,f,p,o,c)
#define VCString_CreateSized(s,z,f,p,o,c) VCText_Create(s,z,f,p,o,c)
#define VCGeogroup_AddString(g,s,z,f,p,o,c) VCGeogroup_AddText(g,s,z,f,p,o,c)
#define VCString_SetMode(g,m)       VCText_ModifyMode(g,m,0)
#define VCString_ModifyMode(g,m,c)  VCText_ModifyMode(g,m,c)
#define VCString_GetMode(g,m)       VCText_GetMode(g,m)
#define VCString_GetFont(g,m)       VCText_GetFont(g,m)
#define VCString_GetText(g,m)       VCText_GetText(g,m)
#define VCString_GetPositionOrientationScale(g,p,o,s) VCText_GetPositionOrientationScale(g,p,o,s)
#define VCString_SetFont(g,m)       VCText_SetFont(g,m)
#define VCString_SetText(g,m)       VCText_SetText(g,m)
#define VCString_SetPositionOrientationScale(g,p,o,s) VCText_SetPositionOrientationScale(g,p,o,s)

#define VCGeogroup_AttachPmesh(g,p)      VCGeogroup_AttachGeometry(g,p)
#define VCGeogroup_AttachTristrip(g,p)   VCGeogroup_AttachGeometry(g,p)
#define VCGeogroup_AttachPolystrip(g,p)  VCGeogroup_AttachGeometry(g,p)
#define VCGeogroup_AttachPolygon(g,p)    VCGeogroup_AttachGeometry(g,p)
#define VCGeogroup_AttachVector(g,p)     VCGeogroup_AttachGeometry(g,p)
#define VCGeogroup_AttachString(g,p)     VCGeogroup_AttachGeometry(g,p)
#define VCGeogroup_AttachSphereList(g,p) VCGeogroup_AttachGeometry(g,p)
#define VCGeogroup_AttachPointList(g,p)  VCGeogroup_AttachGeometry(g,p)

#define VCGeogroup_DetachPmesh(g,p)      VCGeogroup_DetachGeometry(g,p)
#define VCGeogroup_DetachTristrip(g,p)   VCGeogroup_DetachGeometry(g,p)
#define VCGeogroup_DetachPolystrip(g,p)  VCGeogroup_DetachGeometry(g,p)
#define VCGeogroup_DetachPolygon(g,p)    VCGeogroup_DetachGeometry(g,p)
#define VCGeogroup_DetachVector(g,p)     VCGeogroup_DetachGeometry(g,p)
#define VCGeogroup_DetachString(g,p)     VCGeogroup_DetachGeometry(g,p)
#define VCGeogroup_DetachSphereList(g,p) VCGeogroup_DetachGeometry(g,p)
#define VCGeogroup_DetachPointList(g,p)  VCGeogroup_DetachGeometry(g,p)
#define VCEntity_AddDynamicVisual(e,v,f,b) VCEntity_AddVisual(e, NULL, v, \
        		VC_VISIBLE | VC_RMODE_POLYGONAL, NULL, f, b, 0xffffffff)

/* prototypes */

#endif	
