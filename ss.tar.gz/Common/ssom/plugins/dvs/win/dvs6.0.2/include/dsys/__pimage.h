/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: __pimage.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:07:37 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: __pimage.h,v 1.1 2005/09/13 15:07:37 pukitepa Exp $
 *
 *    FUNCTION:
 *
 *
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */

#ifndef ____PIMAGE_H__
#define ____PIMAGE_H__

#include <dsys/filelib.h>
#ifdef _PT_LOCAL
#include "pimage.h"
#else
#include <dsys/pimage.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define VTXIDstrLen  8
#define VTXIDstr     "DIV-VTX2"
#define dpiBSLIDstrLen  8
#define dpiBSLIDstr     "DIV-BSL2"

typedef struct dpiBSLIMGINFOTYPE
{
    uint32  imageType ;
    char   *name ;
    struct dpiBSLIMGINFOTYPE *next ;
} dpiBSLIMGINFO, *dpiBSLIMGINFOPTR ;

typedef struct dpiBSLINFOTYPE
{
    uint32         noImages ;
    dpiBSLIMGINFOPTR  imageInfo ;
} dpiBSLINFO, *dpiBSLINFOPTR ;

typedef struct VTXTEXTURETYPE
{
    uint8     type;
    int32     dataLength;
    int32     texelDataLength;
    VTXIRGBA  bgCol ;
    uint8     width;
    int32     u, v, w ;
    dpiBSLINFOPTR bslInfo ;
    VTXIRGBA *data; /* Indexed : texture->data[v*texture->u+u] */
} VTXTEXTURE;

typedef struct VTXHEADERTYPE 
{
    uint8          verMajor;
    uint8          verMinor;
    uint8          day, month, year ;
    uint8          hours, minutes ;
    VTXPRECISION   precision ;
    float32        scale ;
    int32          dataLength ;
} VTXHEADER ;

typedef struct VTXFILETYPE
{
    VTXHEADER      header ;
    char          *fileName ;
    dflFILEPTR     fp ;
    VTX_IMG_TYPE   imgType ;
    int32          dataLength;

    int32          curtag;
    int32          semint ;
    VTXTEXTUREPTR  vtxTexture ;
} VTXFILE ;


VTX_IMG_TYPE
VTXidentifyFile(dflFILEPTR fp) ;

int32
VTXtestForBMP(dflFILEPTR fp) ;
int32
VTXtestForBSL(dflFILEPTR fp) ;
int32
VTXtestForGIF(dflFILEPTR fp) ;
int32
VTXtestForTGA(dflFILEPTR fp) ;
int32
VTXtestForTIF(dflFILEPTR fp) ;
int32
VTXtestForSGI(dflFILEPTR fp) ;
int32
VTXtestForSVT(dflFILEPTR fp) ;
int32
VTXtestForVTX(dflFILEPTR fp) ;

int32
VTXloadBMP(VTXFILEPTR vtx) ;
int32 
VTXloadBSL(VTXFILEPTR vtx) ;
int32
VTXloadGIF(VTXFILEPTR vtx) ;
int32
VTXloadSGI(VTXFILEPTR vtx) ;
int32
VTXloadTGA(VTXFILEPTR vtx) ;
int32
VTXloadTIF(VTXFILEPTR vtx) ;
int32
VTXloadSVT(VTXFILEPTR vtx) ;
int32
VTXloadVTX(VTXFILEPTR vtx) ;

int32
VTXsaveBMP(VTXFILEPTR Dvtx, VTXFILEPTR Svtx) ;
int32 
VTXsaveBSL(VTXFILEPTR Dvtx, VTXFILEPTR Svtx) ;
int32
VTXsaveSGI(VTXFILEPTR Dvtx, VTXFILEPTR Svtx) ;
int32
VTXsaveSVT(VTXFILEPTR Dvtx, VTXFILEPTR Svtx) ;
int32
VTXsaveTGA(VTXFILEPTR Dvtx, VTXFILEPTR Svtx) ;
int32
VTXsaveVTX(VTXFILEPTR Dvtx, VTXFILEPTR Svtx) ;

void
VTX_DBPALSAVE(char *P, int32 S) ;
void
VTX_DBRAWSAVE(VTXTEXTUREPTR vtx) ;

#ifdef __cplusplus
}
#endif

#endif /* ____PIMAGE_H__ */
