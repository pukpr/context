/****************************************************************************
 *
 *  			Copyright 1998 Division Ltd.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: distance.h,v $
 *  Revision      : $Revision: 1.1 $
 *  Date          : $Date: 2005/09/13 15:07:50 $
 *  Author        : $Author: pukitepa $
 *  Created       : Mon Feb 2 11:44:29 1998
 *  Last Modified : <180398.1216>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 *  $Log: distance.h,v $
 *  Revision 1.1  2005/09/13 15:07:50  pukitepa
 *  init
 *
 *  Revision 1.2  1998/03/19 15:55:24  simon
 *  stuff for distance tool, and stuff to get around (hopefully) temporary
 *  problem of attribute interest.
 *
 *  Revision 1.1  1998/03/17 11:01:56  simon
 *  the dvise side of the distance tool
 *
 *
 ****************************************************************************
 *
 *  Copyright (c) 1998 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 * This  document  may  not, in  whole  or in  part, be  copied,  photocopied,
 * reproduced,  translated,  or  reduced to any  electronic  medium or machine
 * readable form without prior written consent from Division Ltd.
 *
 ****************************************************************************/

#ifndef __DVPLUGIN_H__
#define __DVPLUGIN_H__

typedef enum EDistType {EDistType_Line, EDistType_MultiLine, EDistType_Circle} EDistType;
typedef enum EDistMode {EDistMode_View, EDistMode_Edit, EDistMode_Add} EDistMode;
typedef enum EDistPointSize {EDistPointSize_Small, EDistPointSize_Medium, 
              EDistPointSize_Large} EDistPointSize;
typedef enum EDistLockType {EDistLockType_None, EDistLockType_Global, 
              EDistLockType_Local, EDistLockType_Point} EDistLockType;

static int MaxPointsForType[3] = {2, 1000, 3};

#endif /* __DVPLUGIN_H__ */

