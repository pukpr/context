/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1996 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: dlgpropP.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 12 April 1996
--  Author       : Tony Coombes
--
--  Description	 : Generic Property Dialog
--
--  Modified     : 
--    $Log: dlgpropP.h,v $
--    Revision 1.1  2005/09/13 15:08:19  pukitepa
--    init
--
--    Revision 1.1  1997/07/09 12:30:15  simon
--    *** empty log message ***
--
--    Revision 1.1.1.1  1996/08/29 09:26:05  tony
--    first version of xdvise
--
--    Revision 3.1  1996/08/05 15:06:37  tony
--    Check in prior to starting development for IDP
--
--    Revision 1.2  1996/06/18 11:17:02  tony
--    Mid development revision
--
--    Revision 1.1  1996/04/12 15:42:14  tony
--    Initial development of basic components
--    for constructing property editors
--
--
--
-- ----------------------------------------------------------------------------
*/

struct dlgPropT {
    compT dlg;
    /*
    compT objList;
    compT fieldList;
    compT mainForm;  /* Primarily used when associating components of a 
                        MainWindow, this being the "work_region" */
    compT menuBar;
    compT workArea;
    compT actionArea;

    void (*closeCB)(void *clientData);
    void (*resetCB)(void *clientData);
    void (*cancelCB)(void *clientData);
    void *clientData;
};
