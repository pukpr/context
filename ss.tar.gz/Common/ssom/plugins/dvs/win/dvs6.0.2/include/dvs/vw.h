/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: vw.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:08:10 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: vw.h,v 1.1 2005/09/13 15:08:10 pukitepa Exp $
 *
 *    FUNCTION: Generic widget function templates.
 * 
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _VW_H_
#define _VW_H_
#ifdef __cplusplus
extern "C" {
#endif

#include "vwidgets.h"
#include "vwlabel.h"
#include "vwbutton.h"
#include "vwtoggle.h"
#include "vwscalar.h"
#include "vwradio.h"
#include "vwbound.h"
#include "vworient.h"
#include "vwaxle.h"
#include "vwframe.h"
#include "vwdigit.h"
#include "vwdial.h"
#include "vwrowcol.h"
#include "vwmbox.h"
#include "vwscroll.h"
#include "vwtext.h"
#include "vwtape.h"
#include "vwcircle.h"

#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /* _VW_H_ */
