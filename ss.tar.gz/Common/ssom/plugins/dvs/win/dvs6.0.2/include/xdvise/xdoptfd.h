/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1996 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: xdoptfd.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 12 April 1996
--  Author       : Tony Coombes
--
--  Description	 : Property Editor Option Field
--
--  Modified     : 
--    $Log: xdoptfd.h,v $
--    Revision 1.1  2005/09/13 15:08:25  pukitepa
--    init
--
--    Revision 1.2  1997/10/23 13:31:32  dvs-dev
--    NT changes for the collision and advanced collision dlg.
--    Fixes to get the section code and collision detection code to build on NT.
--    General bug fixes.
--
--    Revision 1.1  1997/07/09 12:32:09  simon
--    *** empty log message ***
--
--    Revision 1.2  1997/02/11 18:57:50  wman
--    Frame reset for animation dialog.
--
--    Revision 1.1.1.1  1996/08/29 09:26:18  tony
--    first version of xdvise
--
--    Revision 3.1  1996/08/05 15:06:37  tony
--    Check in prior to starting development for IDP
--
--    Revision 1.2  1996/06/18 11:17:02  tony
--    Mid development revision
--
--    Revision 1.1  1996/04/12 15:42:23  tony
--    Initial development of basic components
--    for constructing property editors
--
--
--
-- ----------------------------------------------------------------------------
*/

#ifndef __XDOPTFD_H__
#define __XDOPTFD_H__

typedef struct optnFieldT optnFieldT; /* Prototype */
typedef struct {
    char *str;
    int   val;
} optnT;

#ifdef __cplusplus
extern "C" {
#endif

#ifndef XDV_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `XDV_EXPORT'
 */
#ifdef  _LIB_XDV
#define XDV_EXPORT __declspec(dllexport) extern
#else
#define XDV_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define XDV_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ifndef XDV_EXPORT */

XDV_EXPORT optnFieldT *XdOptnFieldCreate(compT parent, char *label, optnT *optns, 
		  void (*changedCallback)(optnFieldT *w, void *clientData), 
		  void *clientData);

XDV_EXPORT void XdOptnFieldDestroy(optnFieldT *optnField);
XDV_EXPORT void XdOptnFieldSetValue(optnFieldT *optnField, int optn, int explicit);
XDV_EXPORT void XdOptnFieldchangedCB(optnFieldT *optnField, compT btn);
XDV_EXPORT int  XdOptnFieldGetValue(optnFieldT *optnField);
XDV_EXPORT int  XdOptnFieldGetResetValue(optnFieldT *optnField);
XDV_EXPORT int  XdOptnField_IsUnchanged(optnFieldT *optnField);

#ifdef __cplusplus
}
#endif

#endif /* __XDOPTFD_H__*/
