/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1996 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: xdstr.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 10 February 1997
--  Author       : Tony Coombes
--
--  Description	 : String Utility Functions
--
--  Modified     : 
--    $Log: xdstr.h,v $
--    Revision 1.1  2005/09/13 15:08:27  pukitepa
--    init
--
--    Revision 1.2  1997/10/23 13:31:34  dvs-dev
--    NT changes for the collision and advanced collision dlg.
--    Fixes to get the section code and collision detection code to build on NT.
--    General bug fixes.
--
--    Revision 1.1  1997/07/09 12:32:40  simon
--    *** empty log message ***
--
--    Revision 1.2  1997/03/05 20:54:31  tony
--    *** empty log message ***
--
--    Revision 1.1  1997/02/10 21:02:24  tony
--    *** empty log message ***
--
--
-- ----------------------------------------------------------------------------
*/

#ifndef __XDSTR_H__
#define __XDSTR_H__

#ifdef __cplusplus
extern "C" {
#endif

#ifndef XDV_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `XDV_EXPORT'
 */
#ifdef  _LIB_XDV
#define XDV_EXPORT __declspec(dllexport) extern
#else
#define XDV_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define XDV_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ifndef XDV_EXPORT */

typedef struct strListT strListT;

XDV_EXPORT strListT *XdStrList_Create(int initialSize);
XDV_EXPORT void      XdStrList_Destroy(strListT *lst);
XDV_EXPORT int       XdStrList_Append(strListT *lst, char *name);
XDV_EXPORT char    **XdStrList_GetListPtr(strListT *lst);
XDV_EXPORT int       XdStrList_GetUsed(strListT *lst);


#ifdef __cplusplus
}
#endif

#endif /* __XDSTR_H__ */
