/*
-- ----------------------------------------------------------------------------
--
--  		     Copyright 1994, 1997 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS 2.1
--  Module       : Audio support library
--  Object Name  : $RCSfile: autils.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : $Date: 2005/09/13 15:08:01 $
--  Author       : $Author: pukitepa $
--
--  Description	
--
--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __AUTILS_H__
#define __AUTILS_H__


typedef void (*AUExitHandler)(void *userData);

extern void AUAddExitHandler(AUExitHandler, void *userData);
extern void AURunExitHandlers(void);

extern char *AUFileBase(const char *fileName);
extern char *AUCopyString(const char * const str);

extern void AUSwapBytes(unsigned char* buf, const int numBytes);
extern void AUSwab(unsigned char* buf, const int numBytes);

#endif /* __AUTILS_H__ */
