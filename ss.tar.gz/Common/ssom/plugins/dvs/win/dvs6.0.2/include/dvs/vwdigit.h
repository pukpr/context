/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: vwdigit.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:08:12 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: vwdigit.h,v 1.1 2005/09/13 15:08:12 pukitepa Exp $
 *
 *    FUNCTION: Button public function prototypes.
 *
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _VWDigit_H
#define _VWDigit_H
#ifdef __cplusplus
extern "C" {
#endif
    
#include "vwidgets.h"
#include "vwborder.h"    
#include "vwvalue.h"

/* PUBLIC FUNCTIONS ======================================*/
VW_EXPORT VWidget *VWDigit_CreateManaged(VWidget *digitWig, char *, VWArg [], int);
VW_EXPORT VWidget *VWDigit_Create(VWidget *digitWig, char *, VWArg [], int);

/* Routines for setting and querying the minimum possible value */
VW_EXPORT void VWDigit_SetMinimumFloatValue(VWidget *digitWig, float32 minValue);
VW_EXPORT float32 VWDigit_GetMinimumFloatValue(VWidget *digitWig);
/* Note, this reoutine returns the equivalent of FLT_MIN in C. The minimum possible
 * value that can be displayed si of course zero
 */
VW_EXPORT float32 VWDigit_GetMinimumPossibleFloatValue(VWidget *digitWig);

/* Routines for setting and querying the maximum possible values */
VW_EXPORT void VWDigit_SetMaximumFloatValue(VWidget *digitWig, float32 minValue);
VW_EXPORT float32 VWDigit_GetMaximumFloatValue(VWidget *digitWig);
VW_EXPORT float32 VWDigit_GetMaximumPossibleFloatValue(VWidget *digitWig);

/* Routines to configure the floating point number format displayed */
VW_EXPORT void VWDigit_SetDisplaySize(VWidget *digitWig, int integerSize, int fractorialSize);
VW_EXPORT void VWDigit_SetFractorialDisplaySize(VWidget *digitWig, int displaySize);
VW_EXPORT int VWDigit_GetFractorialDisplaySize(VWidget *digitWig);
VW_EXPORT void VWDigit_SetIntegerDisplaySize(VWidget *digitWig, int displaySize);
VW_EXPORT int VWDigit_GetIntegerDisplaySize(VWidget *digitWig);

/* Visual appearence routinges */
VW_EXPORT void VWDigit_SetBorderVisual(VWidget *digitWig, char *geomName);
VW_EXPORT void VWDigit_SetBorderMaterial(VWidget *digitWig, char *materialName);
VW_EXPORT void VWDigit_SetNumeralMaterial(VWidget *digitWig, char *materialName);

/* Routines for setting and getting the value displayed on the Digit Widget */
VW_EXPORT float32 VWDigit_GetFloatValue(VWidget *digitWig);
#define VWDigit_SetValue(w,v,t) VWDigit_SetFloatValue((w),(float32)(v),(t))
#define VWDigit_SetIntValue(w,v,t) VWDigit_SetFloatValue((w),(float32)(v),(t))
VW_EXPORT void VWDigit_SetFloatValue(VWidget *digitWig, float32 newValue, int trigger);

/* PUBLIC TYPES ==========================================*/

enum {
    VWrIntegerDisplaySize = VW_RESOURCES_DIGIT, 
    VWrFractorialDisplaySize,
    VWrNumeralMaterial
};


#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /*_VWDigit_H */
