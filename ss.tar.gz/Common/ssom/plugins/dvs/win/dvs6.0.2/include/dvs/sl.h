/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1994 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS 2.1
--  Module       : Audio support library 
--  Object Name  : $RCSfile: sl.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : $Date: 2005/09/13 15:08:04 $
--  Author       : $Author: pukitepa $
--
--  Description	
--	Skip list based table
--
--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __SL_H__
#define __SL_H__

/*
 * ------------------------------------------------------------
 * 
 * An abstract data type for tables.
 *
 * ------------------------------------------------------------
 */

struct _Table;

typedef struct _Table *SLTable;  
typedef void          *SLKey;
typedef void          *SLData;
typedef void          *SLIter;

/*
 * ------------------------------------------------------------
 *
 * Function pointer typedefs.
 *
 * SLTotalOrder  : an ordering relation on keys.
 * SLEquiv       : an equivalence relation on keys.
 * SLCopy        : an assignemnt function on data.  Copies its
 *                 argument into a dynamically allocated object
 *                 and returns a pointer to that object.
 * SLExtractKey  : a key extraction function.  Returns a pointer
 *                 to the part of the data used as the primary
 *                 key.
 * SLFree        : a function to free dynamically allocated data
 * SLMapFunc     : a mapping function.  The SLMap function calls
 *                 this for each item in the table.
 *
 * ------------------------------------------------------------
 */

typedef int    (*SLTotalOrder)(SLKey, SLKey);
typedef int    (*SLEquiv)(SLKey, SLKey);
typedef SLData (*SLCopy)(SLData);
typedef SLKey  (*SLExtractKey)(SLData);
typedef void   (*SLFree)(void *);
typedef void   (*SLMapFunc)(SLData);

/*
 * ------------------------------------------------------------
 *
 * Table functions
 *
 * SLNewTable    : create a new table
 * SLDeleteAll   : delete all data in a table
 * SLAnihilate   : delete all data in table and the table itself
 * SLAdd         : add an item to the table, if the item already
 *                 exists then zero is returned
 * SLUpdate      : update an entry in the table,  if an entry 
 *                 exists with the same key then update the entry
 *                 otherwise a new entry is put into the table
 * SLDelete      : delete an entry from the table.
 * SLFind        : find the data which matches the key value,
 *                 return NULL if no successful match.
 * SLIterate     : create an iterator for a table.
 * SLNext        : returns an element of the table that has not
 *                 been returned in this iteration.  Returns null
 *                 at the end of the iteration.
 * SLEndIterate  : terminate the iterator.
 * SLMap         : Perform an in-order traversal of the table 
 *                 and apply the map function to each element 
 *                 in turn.
 * SLDeleteFirst : delete first item in table
 * SLLoook       : return first item in table.
 *
 * ------------------------------------------------------------
 */

SLTable SLNewTable(SLCopy       dataCopy, 
                   SLFree       dataFree, 
                   SLExtractKey extractKey, 
                   SLTotalOrder lt, 
                   SLEquiv      eq);
void   SLDeleteAll(SLTable);
void   SLAnihilate(SLTable);
int    SLAdd(SLTable, SLData);
int    SLUpdate(SLTable, SLData);
int    SLDelete(SLTable, SLKey);
SLData SLFind(SLTable, SLKey);
SLIter SLIterate(SLTable);
SLData SLNext(SLTable, SLIter);
void   SLEndIterate(SLIter);
void   SLMap(SLTable t, SLMapFunc f);
int    SLDeleteFront(SLTable t);
SLData SLLook(SLTable t);

#endif /* __SL_H__ */

