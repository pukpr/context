/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1996 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: xdlstwd.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 24 June 1996
--  Author       : Tony Coombes
--
--  Description	 : List Widget
--
--  Modified     : 
--    $Log: xdlstwd.h,v $
--    Revision 1.1  2005/09/13 15:08:25  pukitepa
--    init
--
--    Revision 1.2  1997/11/18 18:09:56  simon
--    fix year 2000 problem in annotation dates, and made the animation keyframe
--    list single selection.
--
--    Revision 1.1  1997/07/09 12:31:56  simon
--    *** empty log message ***
--
--    Revision 1.3  1997/05/16 16:38:59  tony
--    Revamp of the Frame Editor support for Actions due to memory problems
--
--    Revision 1.2  1997/03/07 18:55:16  wman
--    Bug fixes
--
--    Revision 1.1.1.1  1996/08/29 09:26:17  tony
--    first version of xdvise
--
--    Revision 3.1  1996/08/05 15:06:37  tony
--    Check in prior to starting development for IDP
--
--    Revision 1.1  1996/06/25 16:40:07  tony
--    Initial revision
--
--
--
-- ----------------------------------------------------------------------------
*/

#ifndef __XDLSTWD_H__
#define __XDLSTWD_H__

#ifdef __cplusplus
extern "C" {
#endif


typedef struct listWidgetT listWidgetT; /* Prototype */

extern listWidgetT *XdListWidgetCreate(compT parent, int isMultipleSelect, int leftType, compT leftW, 
                   int rightType, compT rightW, int topType, compT topW, int bottomType, compT bottomW, 
                   void(*selectionCB)(listWidgetT *w, void *clientData, int itemCount, int *itemPositions), 
		   void(*dfltActnCB)(listWidgetT *w, void *clientData), void *clientData);
extern void  XdListWidgetDestroy(listWidgetT *listWidget);
extern void  XdListWidgetAddItem(listWidgetT *listWidget, char *str);
extern void  XdListWidgetAddSelectedItem(listWidgetT *listWidget, char *str);
extern void  XdListWidgetDeleteAllItems(listWidgetT *listWidget);
extern void  XdListWidgetExtendedSelectionCB(listWidgetT *listWidget, int selectedItemCount, 
                                             int *selectedItemPositions);
extern void  XdListWidgetDefaultActionCB(listWidgetT *listWidget);
extern void  XdListWidgetSelectItem(listWidgetT *listWidget, int itemPosition);

#ifdef __cplusplus
}
#endif

#endif /* __XDLSTWD_H__ */
