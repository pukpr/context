/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: vwidgets.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:08:13 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: vwidgets.h,v 1.1 2005/09/13 15:08:13 pukitepa Exp $
 *
 *    FUNCTION: Generic widget function templates.
 *
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _Widgets_H
#define _Widgets_H
#ifdef __cplusplus
extern "C" {
#endif

#include "vwtypes.h"
#include "vwmacros.h"
#include "vwutils.h"

/* PUBLIC TYPES =============================================*/
/*
 * Version control
 */

VW_EXPORT void vwVersion(FILE *);

    
enum VWEvent_types {
  VW_ENTER,
  VW_LEAVE,
  VW_PRESS,
  VW_DRAG,
  VW_RELEASE,
  VW_DISARMEDRELEASE,
  VW_ARM,
  VW_DISARM,
  VW_RESIZE,
  VW_MANAGE,
  VW_UNMANAGE,
  VW_DESTROY
};


enum {
    VWrName = VW_RESOURCES_CORE,
    VWrBaseMaterial,
    VWrBaseHighlightMaterial,
    VWrOrient,
    VWrOrigin,
    VWrSize,
    
    VWrVirSize,                         /*simon 1/8/96*/
    VWrVirOrigin,                       /*simon 1/8/96*/
    
    VWrBaseVisual,
    VWrIconMaterial,
    VWrIconVisual,
    VWrIconSizeRatio,
    VWrIconGeomSizeRatio,
    VWrIconGeomOffset,
    VWrIconGeomSize,
    VWrIconSizeNonUniform,
    VWrIconSizeUniform,
    VWrIconPositionPolicy, 
    VWrBaseHighlightVisual,
    VWrActivateCallback, 
    VWrActivateCalldata, 
    VWrArmCallback, 
    VWrArmCalldata, 
    VWrDisarmCallback, 
    VWrDisarmCalldata, 
    VWrEnterCallback, 
    VWrEnterCalldata, 
    VWrLeaveCallback, 
    VWrLeaveCalldata, 
    VWrFreeX,
    VWrFreeY,
    VWrFreeZ,
    VWrFreeRoll,
    VWrFreePitch,
    VWrFreeYaw
};

/* 
 *  VW audio environment variable name
 */
#define VW_AUDIO_ENV "DV_WIDGET_AUDIO"

/*
 * Widget Input Handlers...
 */
VW_EXPORT int VW_PickPress(VCBody *, VCAttribute *, uint32, void *);
VW_EXPORT int VW_PickRelease(VCBody *, VCAttribute *, uint32, void *);
VW_EXPORT void VW_CancelFocus(VWidget *ThisWig);
VW_EXPORT void VW_CancelAllFocus(VWidget *thisWig);
    
VW_EXPORT int VW_ForceLeave(VWidget *thisWig,VCAttribute *limb);
VW_EXPORT int VW_ForceEnter(VWidget *thisWig,VCAttribute *limb,VCBody *body);

VW_EXPORT VWtWidgetType VW_GetType(VWidget *widget);
VW_EXPORT int VW_CheckType(VWidget *widget, VWtWidgetType widgetType);
VW_EXPORT void VWArg_Set(VWArg *, int, void *);

VW_EXPORT VWidget *VW_GetChild(VWidget *thisWig);
VW_EXPORT VWidget *VW_GetNextChild(VWidget *thisWig);
VW_EXPORT VWidget *VW_GetPrevChild(VWidget *thisWig);
VW_EXPORT VWidget *VW_GetParent(VWidget *thisWig);

VW_EXPORT void *VW_GetTypeData(VWidget *thisWig);
VW_EXPORT VCEntity *VW_GetFrame(VWidget *thisWig);
VW_EXPORT VCEntity *VW_GetWEntity(VWidget *thisWig);
VW_EXPORT VCEntity *VW_GetHEntity(VWidget *thisWig);
VW_EXPORT VCAttribute *VW_GetWVisual(VWidget *thisWig);
VW_EXPORT VCAttribute *VW_GetHVisual(VWidget *thisWig);
VW_EXPORT VCAttribute *VW_GetIVisual(VWidget *thisWig);
VW_EXPORT VCAttribute *VW_GetBoundary(VWidget *thisWig);
VW_EXPORT VCAttribute *VW_GetConstraints(VWidget *thisWig);
VW_EXPORT void VW_SetBoundary(VWidget *thisWig, VCAttribute *boundary);
VW_EXPORT char *VW_GetName(VWidget *thisWig);
VW_EXPORT int VW_IsMapped(VWidget *thisWig);
VW_EXPORT int VW_IsManaged(VWidget *thisWig);
VW_EXPORT int VW_IsPickable(VWidget *thisWig);

VW_EXPORT void VW_ScaleIconSize(VWidget *thisWig, dmScale scale);
VW_EXPORT void VW_SetIconGeometryRatio(VWidget *thisWig, dmScale scale);
VW_EXPORT void VW_SetIconNonNormalisedGeometry(VWidget *thisWig, dmPoint offset,
                                          dmScale size);

VW_EXPORT void VW_AddChild(VWidget *parent, VWidget *child);
VW_EXPORT void VW_RemoveChild(VWidget *child);
VW_EXPORT void VW_SetSize(VWidget *ThisWig, dmScale newScale);
VW_EXPORT void VW_GetSize(VWidget *thisWig, dmScale size);
VW_EXPORT void VW_SetOrigin(VWidget *, dmPoint);
VW_EXPORT void VW_GetOrigin(VWidget *, dmPoint);
VW_EXPORT void VW_SetOrient(VWidget *, dmEuler);
VW_EXPORT void VW_GetOrient(VWidget *, dmEuler);
VW_EXPORT void VW_GetVCOrient(VWidget *thisWig, dmEuler orient);
VW_EXPORT void VW_SetOrientQ(VWidget *, dmQuaternion);

VW_EXPORT void VW_SetVirSize(VWidget *ThisWig, dmScale newScale);  /*simon 1/8/96*/
VW_EXPORT void VW_SetVirOrigin(VWidget *, dmPoint);                /*simon 1/8/96*/
VW_EXPORT void VW_GetVirOrigin(VWidget *, dmPoint);                /*simon 1/8/96*/
VW_EXPORT void VW_GetVirSize(VWidget *, dmScale);                  /*simon 1/8/96*/

/*
 * VWEventInfo functional interface
 */
VW_EXPORT VWEventInfo *VWEventInfo_Create(void);
VW_EXPORT void VWEventInfo_Delete(VWEventInfo *info);
VW_EXPORT void VWEventInfo_SetBody(VWEventInfo *info, VCBody *body);
VW_EXPORT void VWEventInfo_SetLimb(VWEventInfo *info, VCAttribute *limb);
VW_EXPORT VCBody *VWEventInfo_GetBody(VWEventInfo *info);
VW_EXPORT VCAttribute *VWEventInfo_GetLimb(VWEventInfo *info);
VW_EXPORT char *VWEventInfo_GetLimbName(VWEventInfo *info);    
    
/* Context sensitive area and callback functionality */
VW_EXPORT void VW_SetContextSensitiveArea(VWidget *widget, dmScale innerScale, dmScale outerScale);
VW_EXPORT void VW_AddContextActivateCallback(VWidget *thisWig, VWCallback *cb, void *cd);
VW_EXPORT void VW_AddContextUnactivateCallback(VWidget *thisWig, VWCallback *cb, void *cd);


/*
 * Widget Global Data Structure Access Interafce.
 */

/*
 * Widget Management Functions.
 */
VW_EXPORT void VW_Init(int argc, char **argv);
VW_EXPORT VWidget *VWCore_Create(char *widgetName, VWArg args[], int argc);
VW_EXPORT void VW_Enter(VWidget *thisWig, VWEventInfo *info);
VW_EXPORT void VW_Leave(VWidget *thisWig, VWEventInfo *info);
VW_EXPORT void VW_Press(VWidget *thisWig, VWEventInfo *info);
VW_EXPORT void VW_Release(VWidget *thisWig, VWEventInfo *info);
VW_EXPORT void VW_Manage(VWidget *widget);
VW_EXPORT void VW_Unmanage(VWidget *widget);
VW_EXPORT void VW_Destroy(VWidget *widget);

/* 
 *  Widget audio status functions
 */
VW_EXPORT void VW_AudioSetGlobalMode(uint32 mode);
VW_EXPORT uint32 VW_AudioGetGlobalMode(void);

#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /*_Widgets_H */
