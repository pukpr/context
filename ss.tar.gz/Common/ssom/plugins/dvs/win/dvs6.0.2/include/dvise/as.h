/* 
-- ----------------------------------------------------------------------------
--
--  			Copyright 1998 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVISE
--  Module       : Annotation Service
--  Object Name  : $RCSfile: as.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : $Date: 2005/09/13 15:07:48 $
--  Author       : $Author: pukitepa $
--
--  Description	
--	Annotation Service interface
--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __AS_H__
#define __AS_H__

    /*
     * Error codes
     *
     */

#define AS_ERROR_OK			 1
#define AS_ERROR_FAILURE	        -1
#define AS_ERROR_BAD_DATABASE 		-2
#define AS_ERROR_BAD_VDIFILE  		-3
#define AS_ERROR_ANNOTATION_NOT_FOUND	-4
#define AS_ERROR_BAD_ARGS		-5

    /*
     * Interface functions
     */

extern int AnnotationSevice_Init(void);
extern int AnnotationService_SetContext(const char* const vdifile,
                                        const char* const database);
extern int AnnotationService_ViewAnnotation(const char* const annotation);

#endif /* __AS_H__ */
