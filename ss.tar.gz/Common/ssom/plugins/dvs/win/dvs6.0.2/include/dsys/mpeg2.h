
extern int  mpeg2_setup_encode( char *parameter_file, char *output_file, 
				char *inputfile_format, char *stat_filename,
				int frames_per_second, double bit_rate,
				int hsize, int vsize, int delete_frames, int nframes );

extern int  mpeg2stop_encode(void);

extern int  mpeg2_process_frame(unsigned char *imageData);

extern double *mpeg2_get_ratetable(int *num_rates);
