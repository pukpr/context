/******************************************************************************/
/*									      */
/*	######    ###   #     #   ###    #####    ###   ####### #     #	      */
/*	#     #    #    #     #    #    #     #    #    #     # ##    #	      */
/*	#     #    #    #     #    #    #          #    #     # # #   #	      */
/*	#     #    #    #     #    #     #####     #    #     # #  #  #	      */
/*	#     #    #     #   #     #          #    #    #     # #   # #	      */
/*	#     #    #      # #      #    #     #    #    #     # #    ##	      */
/*	######    ###      #      ###    #####    ###   ####### #     #	      */
/*									      */
/*			   #     #####   #####   #####			      */
/*			  ##    #     # #     # #     #			      */
/*			 # #    #     # #     # #			      */
/*			   #     ######  ###### ######			      */
/*			   #          #       # #     #			      */
/*			   #    #     # #     # #     #			      */
/*			 #####   #####   #####   #####			      */
/*									      */
/* 		Copyright (c) Division Limited. All rights reserved	      */
/*									      */
/* This Document may not, in whole or in part, be copied, photocopied,	      */
/* reproduced, translated, or reduced to any electronic medium or machine     */
/* readable form without prior written consent from Division Ltd.	      */
/*									      */
/******************************************************************************/

#if !defined _INPDEVHD_H_
#define _INPDEVHD_H_


#if defined __cplusplus
extern "C" {
#endif 

#include "inpdev.h"

/* Some  grot that win32 needs to export symbols from a DLL */
/* These are the standard functions that vcinput will be */
/* expecting */
#if defined _WIN32 && !defined __EPP__

#define INPDEVHD_EXPORT __declspec(dllexport) extern

INPDEVHD_EXPORT void	dloadVersionFunction		(int * major, int * minor);
INPDEVHD_EXPORT char *	dloadVersionStringFunction	(void);
INPDEVHD_EXPORT char *	dloadLibraryTypeFunction	(void);
INPDEVHD_EXPORT int	dloadInitFunction		(VCINPUT_DEVICE_PTR device);

#endif /* WIN32 */

#if defined __cplusplus
}
#endif /* __cplusplus */
#endif /* INPDEVHD_H */
