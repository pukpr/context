/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1996 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: dlgasym.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 11 September 1996
--  Author       : Tony Coombes
--
--  Description	 : Assembly Manager Dialog
--
--  Modified     : 
--    $Log: dlgasym.h,v $
--    Revision 1.1  2005/09/13 15:08:18  pukitepa
--    init
--
--    Revision 1.10  1998/08/05 13:29:58  andya
--    initialisation of buttons
--
--    Revision 1.9  1998/08/03 11:42:38  calum
--    Revised menu structure.
--
--    Revision 1.8  1998/06/16 13:06:18  wman
--    Changes for Subtree selection, however not totally working.
--    Bug fix for #5522
--
--    Revision 1.7  1997/10/24 15:15:14  simon
--    bug fixes
--
--    Revision 1.6  1997/10/23 13:31:25  dvs-dev
--    NT changes for the collision and advanced collision dlg.
--    Fixes to get the section code and collision detection code to build on NT.
--    General bug fixes.
--
--    Revision 1.5  1997/10/07 09:48:19  simon
--    Lots of bug fixes, and added the new selection, new question and plugin
--    about dlgs
--
--    Revision 1.4  1997/08/26 11:47:32  simon
--    Mainly changes to library viewer, and additional reset parts stuff
--
--    Revision 1.3  1997/08/21 11:09:52  tony
--    Added XdDlgAssyMgr_Update() to allow the Message dialog
--    to be poped up if required.
--
--    Revision 1.2  1997/07/29 13:53:12  simon
--    *** empty log message ***
--
--    Revision 1.1  1997/07/09 12:29:01  simon
--    *** empty log message ***
--
--    Revision 1.23  1997/04/11 12:53:09  wman
--    Added support for -bodyName and also filtering on bodyName on select/deselect events.
--
--    Revision 1.22  1997/04/01 16:49:35  tony
--    General fixes to problems highlighted by Insure
--
--    Revision 1.21  1997/03/25 14:26:13  tony
--    Generate Exit rather than Close when a Window Manager close
--    event is received for the Assembly Manager main menu bar.
--
--    Revision 1.11  1997/01/09 18:31:29  wman
--    Added two way selection as default on
--    Addded Image Save option to file menu option.
--    Also, Added some to frame manager insert frame
--
--    Revision 1.10  1996/12/04 18:05:19  wman
--    Plumbing for multiple external selection
--    Also for, view dialog selection updates
--
--    Revision 1.9  1996/11/27 20:45:07  tony
--    Added Attributes to the Assembly view
--
--    Revision 1.8  1996/11/27 17:02:39  wman
--    Added File|new and File|open menu functionality
--
--
-- ----------------------------------------------------------------------------
*/

#ifndef __DLGASYM_H__
#define __DLGASYM_H__

#include "xdhrchy.h"  /* For hrchyT */
#include "xddlg.h" /* For dialogInstanceData */
#include "xdbtnwd.h" /* For adding buttons to manager */


#ifdef __cplusplus
extern "C" {
#endif

#ifndef XDV_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `XDV_EXPORT'
 */
#ifdef  _LIB_XDV
#define XDV_EXPORT __declspec(dllexport) extern
#else
#define XDV_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define XDV_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ifndef XDV_EXPORT */

typedef struct dlgAssyMgrT dlgAssyMgrT; /* Prototype */


XDV_EXPORT void XdDlgAssyMgr_Frig_AssyAttributesArrived(ECAssembly *assy);
XDV_EXPORT void XdDlgAssyMgr_Frig_SelectionListInform(dialogInstanceData *inst, EC_DCI_EventData *eventData);
XDV_EXPORT void  XdDlgAssyMgr_InstanceInfoInformCB(dialogInstanceData *inst, ECItem *assList);

XDV_EXPORT dlgAssyMgrT *XdDlgAssyMgr_Create(compT parent);
XDV_EXPORT  int         XdDlgAssyMgr_Update(dialogInstanceData *inst);
XDV_EXPORT void         XdDlgAssyMgrSetMasterAssemblyCB(void *dlg, void *callData, void *clientData);
XDV_EXPORT hrchyT      *XdDlgAssyMgrGetHrchy(dialogInstanceData *inst);
XDV_EXPORT int          XdDlgAssyMgrGetViewNo(dialogInstanceData *inst);
XDV_EXPORT void         XdDlgAssyMgr_UpdateTitle(dlgAssyMgrT *dlgAssyMgr);

XDV_EXPORT void XdDlgAssyMgr_FileNewCB(compT comp, int force);
XDV_EXPORT void XdDlgAssyMgr_FileOpenCB(compT comp, int force);
XDV_EXPORT void XdDlgAssyMgrSetOpenFile(dialogInstanceData *inst, char* str, int fromGUI);
XDV_EXPORT void XdDlgAssyMgrSetSaveFile(dialogInstanceData *inst, char* shortPath, int fromGUI);
XDV_EXPORT void XdDlgAssyMgrSetSaveImage(dialogInstanceData *inst, char* shortPath, int fromGUI);
XDV_EXPORT void XdDlgAssyMgr_SetSaveInfo(dialogInstanceData *inst, uint32 setFlags);
XDV_EXPORT int  XdDlgAssyMgr_Close(dialogInstanceData *inst);
XDV_EXPORT void XdDlgAssyMgr_AddUserMenuOption(dialogInstanceData *wig, 
                                           char *menuName,  char *menuSelectLetter, char *buttonName, 
                                           char *buttonSelectLetter, char *selectKeyCode, 
                                           char *selectKeyCodeText,
                                           ECLicensedFeaturesEnum licenseFeature,
                                           void (callBack)(btnWidgT *w, void *clientData), 
                                           void *callData);
XDV_EXPORT void XdDlgAssyMgr_AddPropertyMenuOption(dialogInstanceData *wig, char *name,  
                                               char *selectLetter, char *selectKeyCode, 
                                               char *selectKeyCodeText,
                                               ECLicensedFeaturesEnum licenseFeature,
                                               void (callBack)(btnWidgT *w, void *clientData), 
                                               void *callData);
XDV_EXPORT void XdDlgAssyMgr_AddToolBarButton(dialogInstanceData *wig, char **pixmap, 
                                          char **armPixmap, char **insensitivePixmap,
                                          char **licenceLockedPixmap,
                                          ECLicensedFeaturesEnum licenseFeature,
                                          void (callBack)(btnWidgT *w, void *clientData), 
                                          void *callData);

/* Assembly Manager other functions */ 
XDV_EXPORT int XdDlgAssyMgr_GetExternalSelectionMode(void);
XDV_EXPORT int XdDlgAssyMgr_GetSubtreeSelectionMode(void);
XDV_EXPORT void XdDlgAssyMgr_SetExternalSelectionMenuSensitivity(int value);
XDV_EXPORT void XdDlgAssyMgr_ChangeUser(void);

XDV_EXPORT void XdDlgAssyMgr_SetTogglePickingInfo(dialogInstanceData *inst, uint32 setFlags);
XDV_EXPORT void XdDlgAssyMgr_SetToggleHighlightModeInfo(dialogInstanceData *inst, uint32 setFlags);

#ifdef __cplusplus
}
#endif

#endif /* __DLGASYM_H__ */
