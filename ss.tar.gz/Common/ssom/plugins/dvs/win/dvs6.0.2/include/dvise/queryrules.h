/****************************************************************************
 *
 *  			Copyright 1998 Division Ltd.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: queryrules.h,v $
 *  Revision      : $Revision: 1.1 $
 *  Date          : $Date: 2005/09/13 15:07:56 $
 *  Author        : $Author: pukitepa $
 *  Created       : Mon Apr 27 13:48:02 1998
 *  Last Modified : <050898.1637>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 *  $Log: queryrules.h,v $
 *  Revision 1.1  2005/09/13 15:07:56  pukitepa
 *  init
 *
 *  Revision 1.9  1998/08/05 15:37:58  simon
 *  turned off all the query debugging.
 *
 *  Revision 1.8  1998/07/29 13:44:20  simon
 *  removed internal use of userdata's of type "colour"
 *
 *  Revision 1.7  1998/07/29 11:01:00  simon
 *  Fixed a few niggly bugs
 *
 *  Revision 1.6  1998/07/02 09:05:55  simon
 *  fixed some niggles in query engine
 *
 *  Revision 1.5  1998/06/18 11:12:38  simon
 *  Upgrades to query engine
 *
 *  Revision 1.4  1998/05/27 17:06:37  simon
 *  *** empty log message ***
 *
 *  Revision 1.3  1998/05/15 15:55:48  simon
 *  *** empty log message ***
 *
 *  Revision 1.2  1998/05/14 17:01:13  simon
 *  *** empty log message ***
 *
 *  Revision 1.1  1998/05/11 17:04:56  simon
 *  *** empty log message ***
 *
 *  Revision 1.3  1998/05/07 13:42:08  simon
 *  *** empty log message ***
 *
 *  Revision 1.2  1998/05/01 15:45:56  simon
 *  *** empty log message ***
 *
 *  Revision 1.1  1998/04/29 17:37:30  simon
 *  New assembly query code - not being built yet.
 *
 *
 ****************************************************************************
 *
 *  Copyright (c) 1998 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 * This  document  may  not, in  whole  or in  part, be  copied,  photocopied,
 * reproduced,  translated,  or  reduced to any  electronic  medium or machine
 * readable form without prior written consent from Division Ltd.
 *
 ****************************************************************************/

#ifndef __QUERYRULES_H
#define __QUERYRULES_H

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

#ifndef DV_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `DV_EXPORT'
 */
#ifdef  _LIB_DV
#define DV_EXPORT __declspec(dllexport) extern
#else
#define DV_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define DV_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ifndef DV_EXPORT */

/*
 * define a list of available tokens
 */
typedef enum {
    qNULL = 0, 
    qSTRING,
    qINT,
    qFLOAT,
    qEND,
    qNOTEND,
    qName, 
    qType, 
    qLoadedState,
    qEnabledState, 
    qProperty, 
    qUserData, 
    qUserDataField,
    qWhichIs,
    qOfType,
    qAny,
    qWithName,
    qAssembly, 
    qCamera, 
    qLandmark, 
    qDistance, 
    qAnnotation,
    qLibrary,
    qFlightPath,
    qSection,
    qOn, 
    qOff,
    qAudio, 
    qBase, 
    qBehavior, 
    qCollision, 
    qConstraint, 
    qLight, 
    qVisual,
    qInt, 
    qFloat, 
    qAngle, 
    qVector, 
    qString, 
    qUrl, 
    qFileName, 
    qColour, 
    qColor, 
    qEuler, 
    qPosition, 
    qRotation, 
    qScale,
    qIcon,
    qState, 
    qAxis, 
    qAction,
    qWhichHas,
    qGain,
    qVelocity,
    qVoice,
    qRadiationPattern,
    qPriority,
    qIterations,
    qOrientation,
    qEventName,
    qVolumeDefinition,
    qGeometryFile,
    qGeometryLOD,
    qTheta,
    qExponent,
    qRenderAs,
    qBillboard,
    qFrontMaterial,
    qBackMaterial,
    qR,
    qG,
    qB,
    qX,
    qY,
    qZ,
    qRoll,
    qYaw,
    qPitch,
    qW,
    qToggle,
    qPaused,
    qDelete,
    qReset,
    qSimple,
    qExplicitBox,
    qPolygonal,
    qBoundingBox,
    qPosAndOrient,
    qFixed,
    qHingeX,
    qHingeY,
    qHingeZ,
    qAmbient,
    qDirectional,
    qPoint,
    qSpot,
    qSolid,
    qWireFrame,    
    qWhichIsNot,
    qEqualTo,
    qNotEqualTo,
    qLessThan,
    qGreaterThan,
    qAnd,
    qOr,
    qKeyFrames,
    qSpeedInterpolation,
    qPathInterpolation,
    qKeyFramesMode,
    qTimeScalar,
    qTotalTime,
    qTimeOffset,
    qSlowIn,
    qSlowOut,
    qSlowInAndOut,
    qConstantImplicit,
    qLinear,
    qCatmullrom,
    qRelative,
    qAbsolute,
    qLastToken  /* this should always be the last token */
} QueryParseToken;

/*
 * _QUERY_DEBUG will catch bogus tokens, duplicate rules, and an incomplete
 * rule base.  An error will be printed in these cases.  If it passes these 
 * tests then you can guarantee the rule base is syntatically correct.
 */
/*#define _QUERY_DEBUG
*/
/* _QUERYPARSING_DEBUG will test that all possible querys can successfully be 
 * turned into a string string1, parsed back in, turned back into a second string2,
 * and string1 == string2
 */
/*#define _QUERYPARSING_DEBUG
*/
/* _QUERYEVALUATOR_DEBUG will test that evaluator test types match the test key table,
 * and that all possible queries produced by parser will produce a valid evaluator
 */
/*#define _QUERYEVALUATOR_DEBUG
*/
/* _QUERY_DEBUG_PRINT should be used in conjunction with the other debugs.  It will
 * print info appropriate to the debug:
 * _QUERY_DEBUG: prints out listing of rules
 * _QUERYPARSING_DEBUG: prints out listing of all possible queries
 */
/*#define _QUERY_DEBUG_PRINT*/

struct QueryRule;
typedef struct QueryRule QueryRule;
typedef void *(QueryCallbackFunc)(QueryRule *, QueryParseToken *, void *);

struct QuerySubstitution;
typedef struct QuerySubstitution QuerySubstitution;

struct QueryRules;
typedef struct QueryRules QueryRules;

/* Functions to create query rules - the function is added to the rule, and can be called
 * on a query being successful */
DV_EXPORT QueryRules *QueryRules_Create(void);
DV_EXPORT int QueryRules_AddRule(QueryRules *rules, QueryParseToken *statement,
                                  QueryCallbackFunc *func, void *callbackData);
/* adds a substitution that on parsing a query and finding part of a list that matches 
 * statement, will restart parsing replacing statement with substitutionStatement */
DV_EXPORT int QueryRules_AddSubstitution(QueryRules *rules, QueryParseToken *statement,
                                     QueryParseToken *substitutionStatement);
/* call this to do test on statement, returns rule on success */
DV_EXPORT QueryRule *QueryRules_FindValidRule(QueryRules *rules,QueryParseToken *statement);
/* call this to do test on statement, executes user function for rule on success, 
   and returns its return value */
DV_EXPORT void *QueryRules_ExecuteValidRule(QueryRules *rules,QueryParseToken *statement);
/* prints all the rules as strings to stdout */
DV_EXPORT void QueryRules_PrintToPrompt(QueryRules *rules);
DV_EXPORT int QueryRules_GetNumRules(QueryRules *rules);
DV_EXPORT QueryRule *QueryRules_GetRule(QueryRules *rules, int i);
/* returns TRUE if rules1 statement's == rules2 statements, errors are printed if not */
DV_EXPORT int QueryRules_CheckStatementsMatch(QueryRules *rules1, QueryRules *rules2);

/* get the statement (qNULL terminated) this rule is checking against */
DV_EXPORT QueryParseToken *QueryRule_GetStatement(QueryRule *rule);
/* get the statement length */
DV_EXPORT int QueryRule_GetStatementLength(QueryRule *rule);
DV_EXPORT void *QueryRule_ExecuteUserFunction(QueryRule *rule, QueryParseToken *statement);

/* turns a token list into its string equivelent.  Each token string is seperated by seperator */
DV_EXPORT char *TokenArray_ToString(QueryParseToken *tokenArray, char *seperator);
DV_EXPORT int TokenArray_GetLength(QueryParseToken *tokenArray);
/* calloc's, and returns a copy of token array */
DV_EXPORT QueryParseToken *TokenArray_Duplicate(QueryParseToken *tokenArray);
/* assumes tooArray is big enough to hold the contents of fromArray */
DV_EXPORT void TokenArray_Copy(QueryParseToken *tooArray, const QueryParseToken *fromArray);
/* checks to see there are no illegal tokens in the array */
DV_EXPORT int TokenArray_Valid(QueryParseToken *tokenArray);
/* checks to see if any tokens in containArray, are in tokenArray */
DV_EXPORT int TokenArray_ContainsGivenTokens(QueryParseToken *tokenArray, QueryParseToken *containsArray);
/* checks to see if containsToken is in tokenArray */
DV_EXPORT int TokenArray_ContainsToken(QueryParseToken *tokenArray, QueryParseToken containsToken);
DV_EXPORT int TokenArray_Delete(QueryParseToken *array);
/* returns TRUE if tokenArray1 == tokenArray2, no wildcards (e.g. qAny) are used */
DV_EXPORT int TokenArray_Compare(QueryParseToken *tokenArray1, QueryParseToken *tokenArray2);

/* returns the parseable string for this token */
DV_EXPORT char *Token_GetString(QueryParseToken token);
/* returns a non-parsable lower case space seperated string for human reading only */
DV_EXPORT char *Token_GetSpacedString(QueryParseToken token);
DV_EXPORT int Token_IsValid(QueryParseToken token);
/* returns TRUE if tokenA == tokenB, or either token == qAny */
DV_EXPORT int Token_IsMatch(QueryParseToken tokenA, QueryParseToken tokenB);
/* checks the tokens match up with the token table - for debug */
DV_EXPORT int Token_CheckTokensValid(void);

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif
#endif /* __QUERYRULES_H */
