/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1995 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: object.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 
--  Author       : Tony Coombes
--
--  Description	
--
--  Modified
--    $Log: object.h,v $
--    Revision 1.1  2005/09/13 15:08:20  pukitepa
--    init
--
--    Revision 1.4  1997/09/19 16:46:50  tony
--    Fix to prevent problems with communicating escape
--    characters (\) and quotes (") over DCI
--
--    Revision 1.3  1997/08/21 09:06:06  tony
--    Removed XdTopFile_FindNamedAssembly() because ECTopFile_FindNamedAssembly()
--    has been corrected to searches the top Zone tree before the top Lib tree.
--
--    Revision 1.2  1997/08/14 17:38:05  tony
--    Introduced XdTopFile_FindNamedAssemby() because ECTopFile_FindNamedAssembly()
--    searches the top Lib tree first if the path name isn't explicit.
--    NB. ECEntity_CalculatePathName() only generates explicit path names
--        for the Lib tree.)
--
--    Revision 1.1  1997/07/09 12:30:48  simon
--    *** empty log message ***
--
--    Revision 1.7  1997/04/15 16:22:36  tony
--    Changes to allow Key Frames to be instanced
--
--    Revision 1.6  1997/01/14 17:40:56  tony
--    *** empty log message ***
--
--    Revision 1.5  1996/11/13 17:59:56  tony
--    *** empty log message ***
--
--    Revision 1.4  1996/10/10 16:46:47  clives
--    *** empty log message ***
--
--    Revision 1.3  1996/09/13 14:37:12  clives
--    *** empty log message ***
--
--    Revision 1.2  1996/09/10 15:39:47  tony
--    Changed "Object" to "Assembly"
--
--    Revision 1.1.1.1  1996/08/29 09:26:09  tony
--    first version of xdvise
--
--    Revision 3.3  1996/08/05 15:06:37  tony
--    Check in prior to starting development for IDP
--
--    Revision 3.2  1996/04/25 14:46:12  tony
--    Added several ECMaterial & ECTexture functions.
--
--    Revision 3.1  1996/02/26 16:31:06  tony
--    Release 3.0
--
--    Revision 1.6  1996/02/01 18:25:36  tony
--    Added ECTextureSetDetail()
--
--    Revision 1.5  1996/01/16 16:09:27  tony
--    Added XdMaterialLibraryRead() and XdMaterialLibraryWrite()
--    virtually identical copies of the EC functions.
--    Added XdActionFuncGetNamedActionComment().
--
--    Revision 1.4  1995/10/05 15:16:54  tony
--    Bug TC11 - Added arguments "treeName" & "treeType" to XdviseSetSelectedAssembly()
--
--
-- ----------------------------------------------------------------------------
*/

#ifndef __OBJECT_H__
#define __OBJECT_H__

#define String VLString
#include <dvs/vc.h>
#include <dvise/ectools.h>
#undef String

#ifdef __cplusplus
extern "C" {
#endif

/*extern void       XdviseSetSelectedAssembly(ECAssembly *obj);
**extern ECAssembly  *XdviseGetSelectedAssembly(void);
**extern void       XdviseSetSelectedZoneAttributes(ECZone *zone);
**extern void       XdviseSetSelectedZoneAssemblys(ECZone *zone);
**extern ECZone    *XdviseGetSelectedZone(void);
**extern void       XdviseSetSelectedLibrary(ECAssembly *library);
**extern ECAssembly *XdviseGetSelectedLibrary(void);
*/

/*
 * EC extensions for XdVISE
 */

extern ECVec3     *ECVector_CreateFromStrings(char *strX, char *strY, char *strZ, float32 defaultValue);
extern int32       ECVectorContainsZero(ECVec3 *ecvec);
extern void        ECVectorDegToRad(ECVec3 *ecvec);
extern void        ECVectorRadToDeg(ECVec3 *ecvec);

extern void        XdColourCreateFromGUI(ECColour **colour, char *red, char *green, char *blue);
extern float      *ECColourGetRed(ECColour *colour);
extern float      *ECColourGetGreen(ECColour *colour);
extern float      *ECColourGetBlue(ECColour *colour);

/* 
 * XdActionList...
 * Extensions to the ECActionList tools
 */
extern void XdActionListAddAction(ECAction **next, ECAction *action);
extern void XdActionListRemoveAction(ECAction **next, ECAction *remove);
extern void XdActionListSubstituteAction(ECAction **next, ECAction *old, ECAction *newAction);
extern void XdActionListShiftActionUp(ECAction **next, ECAction *move);
extern void XdActionListShiftActionDown(ECAction **next, ECAction *move);

/* 
 * XdEventList...
 * Extensions to the ECEvents tools
 * NB. An eventList in EC is not a linked list of events
 *     the word "events" is used for this purpose. However
 *     An ActionList is a linked list of actions.
 */
extern void XdEventListRemoveEvent(ECEvent **next, ECEvent *event);

/*
 * XdParameter...
 * Extensions to the ECParameter tools
 */
extern char              *XdParameterToString(ECParameter *parameter, int quote);
extern ECParameter       *XdParameterCreateFromString(ECParameterType type, char *string);

/*
 * XdAssemblyReference...
 * Extensions to ECOjectReference tools
 */
extern ECAssemblyReference *XdAssemblyReferenceAllocate(void);

/*
 * XdTreeReference...
 * Extensions to ECZoneReference tools
 */
extern ECAssemblyReference   *XdTreeReferenceAllocate(void);

/*
 * XdRoleReference...
 * Extensions to ECRoleReference tools
 */
extern ECRoleReference   *XdRoleReferenceAllocate(void);

/*
 * Dummy routines `cos not available in EC yet !
 */
extern void *XdLibraryFindNamedMaterial(ECAssembly *lib, char *itemName);
extern void *ECAssembly_FindNamedTexture(ECAssembly *lib, char *itemName);
extern void *ECAssembly_FindNamedRamp(ECAssembly *lib, char *itemName);
extern void  ECTextureSetTextureMap(ECTexture* texture, char *str);
extern char *ECTextureGetTextureMap(ECTexture* texture);
extern void  ECTextureSetDetailTexture(ECTexture* texture, char *str);
extern char *ECTextureGetDetailTexture(ECTexture* texture);
extern void  ECTextureSetMinify(ECTexture* texture, uint8 opt);
extern uint8 ECTextureGetMinify(ECTexture* texture);
extern void  ECTextureSetMagnify(ECTexture* texture, uint8 opt);
extern uint8 ECTextureGetMagnify(ECTexture* texture);
extern void  ECTextureSetAlpha(ECTexture* texture, uint8 opt);
extern uint8 ECTextureGetAlpha(ECTexture* texture);
extern void  ECTextureSetWrapU(ECTexture* texture, uint8 opt);
extern uint8 ECTextureGetWrapU(ECTexture* texture);
extern void  ECTextureSetWrapV(ECTexture* texture, uint8 opt);
extern uint8 ECTextureGetWrapV(ECTexture* texture);
/*extern void  ECTextureSetDetailType(ECTexture* texture, uint8 opt);*/
extern uint8 ECTextureGetDetailType(ECTexture* texture);
extern void  ECTextureSetDetail(ECTexture* texture, uint8 detailType, char *detailTexture);
extern void    ECLightSetTheta(ECLight *light, float32 val);
extern float32 ECLightGetTheta(ECLight *light);
extern void    ECLightSetExponent(ECLight *light, float32 val);
extern float32 ECLightGetExponent(ECLight *light);
extern char     *ECMaterialGetEnvironmentName(ECMaterial* material);
extern char     *ECMaterialGetTextureName(ECMaterial* material);
extern char     *ECMaterialGetRampName(ECMaterial* material);
extern ECColour *ECMaterialGetAmbient(ECMaterial* material);
extern ECColour *ECMaterialGetDiffuse(ECMaterial* material);
extern ECColour *ECMaterialGetSpecular(ECMaterial* material, float32 *specularPwr);
extern ECColour *ECMaterialGetEmissive(ECMaterial* material);
extern ECColour *ECMaterialGetOpacity(ECMaterial* material);
extern void      ECMaterialSetTextureName(ECMaterial* material, char *name);
extern void      ECMaterialSetRampName(ECMaterial* material, char *name);
extern void      ECMaterialSetEnvironmentName(ECMaterial* material, char *name);
extern void      ECMaterialSetAmbient(ECMaterial* material, ECColour *col);
extern void      ECMaterialSetDiffuse(ECMaterial* material, ECColour *col);
extern void      ECMaterialSetSpecular(ECMaterial* material, ECColour *col, float32 pwr);
extern void      ECMaterialSetEmissive(ECMaterial* material, ECColour *col);
extern void      ECMaterialSetOpacity(ECMaterial* material, ECColour *col);
extern ECComment    *ECZoneGetComment(ECZone *zone);
extern void          ECZoneSetComment(ECZone *zone, ECComment *comment);
extern ECPhysical* ECZoneGetPhysical(ECZone *zone);
extern char         *ECCommentGetString(ECComment *comment);
extern void          ECCommentSetString(ECComment *comment, char *str);
extern char *ECAssembly_GetIconGeometryFile(ECAssembly *assembly);
extern void  ECAssembly_SetIconGeometryFile(ECAssembly *assembly, char *iconGeometryFile);
extern void  ECIconAddVisual(ECIcon *icon, ECVisual *visual);
extern void  ECAssemblyAddIcon(ECAssembly *assembly, ECIcon *icon);
/*
extern void XdECVisual_SetState(ECVisual *v, ECStateType s);
extern ECStateType XdECVisual_GetState(ECVisual *v);
*/
ECAssembly   *XdMaterialLibraryRead(char *filename);
int32        XdMaterialLibraryWrite(ECAssembly *lib, char *filename);
extern char *XdActionFuncGetNamedActionComment(char *actionName);

#ifdef __cplusplus
}
#endif

#endif /* __OBJECT_H__ */
