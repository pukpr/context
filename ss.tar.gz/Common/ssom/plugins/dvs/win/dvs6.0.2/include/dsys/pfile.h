/****************************************************************************
 *
 *  			Copyright 1995 Division Limited.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: pfile.h,v $
 *  Revision      : $Revision: 1.1 $
 *  Date          : $Date: 2005/09/13 15:07:45 $
 *  Author        : $Author: pukitepa $
 *  Last Modified : <260698.1407>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 ****************************************************************************
 *
 *  Copyright (c) 1995 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 *  This Document may not, in whole or in part, be copied,
 *  photocopied, reproduced, translated, or reduced to any
 *  electronic medium or machine readable form without prior
 *  written consent from Division Ltd.
 ****************************************************************************/

#ifndef __PFILE_H__
#define __PFILE_H__

#ifndef DPF_EXPORT
#if defined (_WIN32) && !defined(BUILD_STATIC)
#ifdef _PF_LOCAL
#define DPF_EXPORT __declspec(dllexport) extern
#else
#define DPF_EXPORT __declspec(dllimport) extern
#endif
#else
#define DPF_EXPORT extern
#endif
#endif

#ifdef _PF_LOCAL
#include "pgeneral.h"
#else
#include <dsys/pgeneral.h>
#endif

#include <float.h>

#ifdef __cplusplus
extern "C" {
#endif
    
/*****************************************************************************/
/* pfile error numbers */
#define dpfENO_ROPEN     0x8001
#define dpfENO_READ      0x8002
#define dpfENO_WOPEN     0x8003
#define dpfENO_WRITE     0x8004
#define dpfENO_CLOSE     0x8005
#define dpfENO_FORM      0x8006
#define dpfENO_VALUE     0x8007
#define dpfENO_USAGE     0x8008
#define dpfENO_NULL      0x8009
#define dpfENO_CONV      0x800A
#define dpfENO_EMPTY     0x800B

/*****************************************************************************/
/* pfile warning levels */
#define dpfWARN_BADFILE  2
#define dpfWARN_PROBLEM  3
/*****************************************************************************/
/* pfile monitor flags */
#define dpfMON_READ      0x00100000
#define dpfMON_WRITE     0x00200000

/*****************************************************************************/
/* Useful constants */
#define dpf_ALLOW_B2Z     1
#define dpf_ALLOW_BMF     2
#define dpf_ALLOW_ALL     3

/* max min ranges for types */
#define dpfRGB_MAX     (float32)   1.0
#define dpfRGB_MIN     (float32)   0.0
#define dpfALPHA_MAX   (float32)   1.0
#define dpfALPHA_MIN   (float32)   0.0
#define dpfV1POWER_MAX (float32)  32.0
#define dpfV1POWER_MIN (float32)   1.0
#define dpfV2POWER_MAX (float32) 128.0
#define dpfV2POWER_MIN (float32)   1.0
#define dpfOPACITY_MAX (float32)   1.0
#define dpfOPACITY_MIN (float32)   0.0
#define dpfDICE_MAX    65565
#define dpfDICE_MIN        3
#define dpfDICE_DETER      0
#define dpfTHICK_MAX     255
#define dpfTHICK_MIN       1

/*****************************************************************************/
/* Different vertex types */
#define dpf_VERT_NONE           (uint8) 0x0000
#define dpf_VERT_NORMALS        (uint8) 0x0001
#define dpf_VERT_RGBA           (uint8) 0x0002
#define dpf_VERT_LUMINANCE      (uint8) 0x0004
#define dpf_VERT_TEXTURE        (uint8) 0x0008
#define dpf_VERT_THREED_TEXTURE (uint8) 0x0010

/*****************************************************************************/
/* Different Geometry Types */
#define dpf_GEOM_UNDEFINED  (int32) 0x0000
#define dpf_GEOM_POLYGON    (int32) 0x0043
#define dpf_GEOM_TRISTRIP   (int32) 0x0044
#define dpf_GEOM_POLYSTRIP  (int32) 0x0045
#define dpf_GEOM_PMESH      (int32) 0x0046
#define dpf_GEOM_SPHERE     (int32) 0x0048
#define dpf_GEOM_LINE       (int32) 0x004A
#define dpf_GEOM_TEXT       (int32) 0x004B
#define dpf_GEOM_POINT      (int32) 0x0050

/*****************************************************************************/
/* Unit conversion scaling factors */
#define dpfINCHtoMM 25.4
#define dpfMMtoINCH (1.0/dpfINCHtoMM)
#define dpfINCHtoM  0.0254
#define dpfMtoINCH  (1.0/dpfINCHtoM)

/*****************************************************************************/
/* types. */
/* must never have double precision without global changes */
/*
#define dpf_DOUBLE_PRECISION
*/

typedef enum 
{ /* used for indexing arrays, identifying axies etc etc */
    dpf_PITCH = 0, dpf_YAW = 1, dpf_ROLL = 2,
    dpfERGBA =  4, dpf_R = 0, dpf_G = 1, dpf_B = 2, 
    dpf_A = 3, dpf_POWER=3, dpf_LUM = 0,
    dpfETEXT   =  2, dpf_U = 0, dpf_V = 1,
    dpfETHREEDTEXT =  3
} coord;

typedef float32    dpfRANGE[2] ;
typedef int32      dpfIVECTOR[3] ;            /* Generic 4 elem vector. */
typedef float32    dpfRGBA[dpfERGBA];
typedef float32    dpfTEXT[dpfETEXT] ;
typedef float32    dpfTHREEDTEXT[dpfETHREEDTEXT] ;

typedef enum {dpf_B2Z_FILE,   dpf_V2Z_FILE,
              dpf_VIZ_FILE,   dpf_BIZ_FILE, 
              dpf_UNKNOWN_FILE } dpfFILETYPE;

typedef enum {dpf_FILE_GEOMETRY=0, dpf_FILE_MATERIAL=1 } dpfFILEFORMAT;

typedef enum {dpfREAD, dpfWRITE} dpfFILEMODE;

/* New enumerated types */
typedef enum { dpf_MIN_DEFAULT=0, dpf_MIN_POINT_SAMPLED=1, 
               dpf_MIN_BILINEAR=2, dpf_MIN_TRILINEAR=3,
               dpf_MIN_MIP_MAP_LINEAR=4, dpf_MIN_MIP_MAP_BILINEAR=5, 
               dpf_MIN_MIP_MAP_TRILINEAR=6, dpf_MIN_MIP_MAP_QUADLINEAR=7, 
               dpf_MIN_MIP_MAP_POINT_SAMPLED=8 } dpfMINIFY;
typedef enum { dpf_MAG_DEFAULT=0, dpf_MAG_POINT_SAMPLED=1, 
               dpf_MAG_BILINEAR=2, dpf_MAG_TRILINEAR=3, 
               dpf_MAG_BICUBIC=4, dpf_MAG_SHARPEN=5 } dpfMAGNIFY;
typedef enum { dpf_ALPHA_BLEND=0, dpf_ALPHA_CUT=1, 
               dpf_ALPHA_BLEND_CUT=2 } dpfALPHA ;
typedef enum { dpf_WRAP_REPEAT=0, dpf_WRAP_CLAMP=1, dpf_WRAP_SELECT=2 } dpfWRAP ;
typedef enum { dpf_DETAIL_NONE=0, dpf_DETAIL_ADD=1, 
               dpf_DETAIL_MODULATE=2 } dpfDETAIL ;
typedef enum { dpf_TRANS_SNAP=0, dpf_TRANS_BLEND=1 } dpfTRANSITION ;
typedef enum { dpf_MAT_NONE=0, dpf_MAT_NAMED=1, 
               dpf_MAT_DEFAULT=2, dpf_MAT_F_MATERIAL=3 } dpfMATTYPE ;
typedef enum { dpf_MATTXT_NONE=0, dpf_MATTXT_DEFAULT=1,
               dpf_MATTXT_NAMED=2 } dpfMATTXTTYPE ;
typedef enum { dpf_ENVIRONMENT_NONE=0, 
               dpf_ENVIRONMENT_STANDARD=1 } dpfENVIRONMENT ;
typedef enum { dpf_PLANE_NORMAL=0, dpf_PLANE_UNDERLAY=1, 
               dpf_PLANE_OVERLAY=2 } dpfPLANE ;
typedef enum { dpf_FACET_NONE=0, dpf_FACET_BACKFACE=1, 
               dpf_FACET_FRONTFACE=2, dpf_FACET_TWOFACED=3 } dpfFACET ;
typedef enum { dpf_DM_FILLED=0, dpf_DM_WIREFRAME=1, dpf_DM_DOTTED=2 } dpfDRAWMODE ;
typedef enum { dpf_PREC_SINGLE=0, dpf_PREC_DOUBLE=1 } dpfPRECISION ;
typedef enum { dpf_UNIT_INCH=0, dpf_UNIT_METRE=1 } dpfUNIT ;
typedef enum { dpf_FONT_QUICK=0, dpf_FONT_BITMAP=1, dpf_FONT_VECTOR=2,
               dpf_FONT_POLY_2D=3, dpf_FONT_POLY_3D=4, dpf_FONT_TEXTURE=5 } dpfFONT ;
typedef enum { dpf_AUTO_OFF=0, dpf_AUTO_ON=1 } dpfAUTO ;
typedef enum { dpf_LOCK_OFF=0, dpf_LOCK_ON=1 } dpfLOCK ;

struct dpfSTRINGTYPE ;
typedef struct dpfSTRINGTYPE *dpfSTRINGPTR ;

struct dpfSURFACETYPE ;
typedef struct dpfSURFACETYPE *dpfSURFACEPTR;

struct dpfBOUNDTYPE ;
typedef struct dpfBOUNDTYPE *dpfBOUNDPTR ; 

struct dpfTEXTURETYPE ;
typedef struct dpfTEXTURETYPE *dpfTEXTUREPTR ; 

struct dpfRAMPTYPE ;
typedef struct dpfRAMPTYPE *dpfRAMPPTR ;

struct dpfMATERIALTYPE ;
typedef struct dpfMATERIALTYPE *dpfMATERIALPTR ;

struct dpfVERTEXTYPE ;
typedef struct dpfVERTEXTYPE *dpfVERTEXPTR ;

struct dpfSLISTTYPE;
typedef struct dpfSLISTTYPE *dpfSLISTPTR ;

struct dpfCLISTTYPE;
typedef struct dpfCLISTTYPE *dpfCLISTPTR ;

struct dpfSPHERENODETYPE ;
typedef struct dpfSPHERENODETYPE *dpfSPHERENODEPTR ;

struct dpfTEXTNODETYPE ;
typedef struct dpfTEXTNODETYPE *dpfTEXTNODEPTR ;

struct dpfPOLYGONTYPE ;
typedef struct dpfPOLYGONTYPE *dpfPOLYGONPTR ;

struct dpfGEOMETRYTYPE ;
typedef struct dpfGEOMETRYTYPE *dpfGEOMETRYPTR ;

struct dpfGEOGROUPTYPE ;
typedef struct dpfGEOGROUPTYPE *dpfGEOGROUPPTR ;

struct dpfLODTYPE ;
typedef struct dpfLODTYPE *dpfLODPTR ;

struct dpfOBJECTTYPE ;
typedef struct dpfOBJECTTYPE *dpfOBJECTPTR ;

struct dpfHEADERTYPE ;
typedef struct dpfHEADERTYPE *dpfHEADERPTR ;

struct dpfFILE_TYPE ;
typedef struct dpfFILE_TYPE *dpfFILEPTR ;

/* ptools declaration */

struct dptTRIANGLETYPE ;
typedef struct dptTRIANGLETYPE *dptTRIANGLEPTR ;
struct dptMESHTYPE ;
typedef struct dptMESHTYPE *dptMESHPTR ;

/*****************************************************************************/
/* Externally callable Functions. */
/*****************************************************************************/
/* Useful macros */

#define dpfRGBCmp(a,b)     memcmp(a, b, sizeof(float32)*3)
#define dpfRGBACmp(a,b)    memcmp(a, b, sizeof(dpfRGBA))
#define dpfTextCmp(a,b)    memcmp(a, b, sizeof(float32)*2)
#define dpfRGBACpy(a,b)    memcpy(a, b, sizeof(dpfRGBA))
#define dpfTextCpy(a,b)    memcpy(a, b, sizeof(dpfTEXT))

#define dpfBadFloat(f) (((*(long *)&(f) & 0x7f800000L)==0x7f800000L))

/*****************************************************************************/
/* pfsurfac Surfaces */
DPF_EXPORT void
dpfInitSurface(dpfSURFACEPTR);       /* Set to dpfINITSURFACE */
DPF_EXPORT void 
dpfReinitSurface(dpfSURFACEPTR surf);
DPF_EXPORT void
dpfCpySurface(dpfSURFACEPTR surf1, dpfSURFACEPTR surf2) ;
DPF_EXPORT int32
dpfCmpSurface(dpfSURFACEPTR s1, dpfSURFACEPTR s2) ;  
/* if s1 == s2 then return 0, else return non-zero */


/* Set surface characturistics */
DPF_EXPORT void 
dpfSetSurface(dpfSURFACEPTR surf, dpfSURFACEPTR source) ;
/* Set material name literally sets the name to the given pointer, 
** so make sure it dynamically allocated and not used by anything else!
** If in doubt use copy name which creates a new dynamically allocated name.
*/
DPF_EXPORT void
dpfSetSurfaceName(dpfSURFACEPTR surf, char *name) ;
DPF_EXPORT void 
dpfSetSurfaceF_Material(dpfSURFACEPTR surf, dpfMATTYPE Material, char *MatName) ;
DPF_EXPORT void 
dpfSetSurfaceB_Material(dpfSURFACEPTR surf, dpfMATTYPE Material, char *MatName) ;
DPF_EXPORT void 
dpfSetSurfaceVertex(dpfSURFACEPTR surf, uint8 Characturistic, uint8 State) ;
DPF_EXPORT void 
dpfSetSurfacePlane(dpfSURFACEPTR surf, dpfPLANE Plane) ;
DPF_EXPORT void 
dpfSetSurfaceFacet(dpfSURFACEPTR surf, dpfFACET Facet) ;
DPF_EXPORT void 
dpfSetSurfaceDecal(dpfSURFACEPTR surf, int32 decal) ;
DPF_EXPORT void 
dpfSetSurfaceDrawMode(dpfSURFACEPTR surf, dpfDRAWMODE DrawMode, uint8 Width) ;
DPF_EXPORT void 
dpfSetSurfaceLock(dpfSURFACEPTR surf, dpfLOCK lock) ;
DPF_EXPORT void 
dpfSetSurfaceSpecial(dpfSURFACEPTR surf, dpfSTRINGPTR Special) ;

/* Get surface characturistics */
/* Returns a pointer to THE name. so don't destroy */
DPF_EXPORT char *
dpfGetSurfaceName(dpfSURFACEPTR surf) ;
DPF_EXPORT dpfMATTYPE
dpfGetSurfaceF_Material(dpfSURFACEPTR surf, char **MatName) ;
DPF_EXPORT dpfMATTYPE
dpfGetSurfaceB_Material(dpfSURFACEPTR surf, char **MatName) ;
DPF_EXPORT uint8 
dpfGetSurfaceVertex(dpfSURFACEPTR surf) ;
DPF_EXPORT dpfPLANE
dpfGetSurfacePlane(dpfSURFACEPTR surf) ;
DPF_EXPORT dpfFACET
dpfGetSurfaceFacet(dpfSURFACEPTR surf) ;
DPF_EXPORT int32
dpfGetSurfaceDecal(dpfSURFACEPTR surf) ;
DPF_EXPORT dpfDRAWMODE
dpfGetSurfaceDrawMode(dpfSURFACEPTR surf, uint8 *Width) ;
DPF_EXPORT dpfLOCK
dpfGetSurfaceLock(dpfSURFACEPTR surf) ;
DPF_EXPORT dpfSTRINGPTR
dpfGetSurfaceSpecial(dpfSURFACEPTR surf) ;


/* pfvertex Vertices & VertLists */
/* Vertices */
DPF_EXPORT void
dpfSetVertexFlag(uint8 vflag, uint8 textCook, uint8 overRide) ;
DPF_EXPORT uint8
dpfCheckVertexFlag(uint8 vflag, uint8 useOverRide) ;
DPF_EXPORT dpfVERTEXPTR
dpfCreateVertex(void);
DPF_EXPORT dpfVERTEXPTR
dpfCreateVertexBlock(int32 numVerts);
DPF_EXPORT int32
dpfCreateVertexTable(dpfGEOMETRYPTR geom, dpfVERTEXPTR **table) ;
DPF_EXPORT int32
dpfAddVertex(dpfGEOMETRYPTR geom, dpfVERTEXPTR vertex) ;
DPF_EXPORT int32
dpfUnlinkVertex(dpfVERTEXPTR);
DPF_EXPORT int32
dpfFreeVertex(dpfVERTEXPTR);
DPF_EXPORT int32
dpfFreeVertexList(dpfVERTEXPTR vert) ;
DPF_EXPORT void
dpfKillVertices(void) ;

/* The following calls are used to loop through all the vertices in a 
** geometry. Get Previous has to search a list to find the previous so it
** can be slow.
*/
DPF_EXPORT int32
dpfGetVertexCount(dpfGEOMETRYPTR geom) ;
DPF_EXPORT dpfVERTEXPTR
dpfGetFrstVertex(dpfGEOMETRYPTR geom) ;
DPF_EXPORT dpfVERTEXPTR
dpfGetNextVertex(dpfVERTEXPTR vertex) ;
DPF_EXPORT dpfVERTEXPTR
dpfGetPrevVertex(dpfVERTEXPTR vertex) ;
DPF_EXPORT dpfVERTEXPTR
dpfGetNthVertex(dpfGEOMETRYPTR geom, int32 Nth) ;


/* Vertex info */
DPF_EXPORT void
dpfGetVertexPoint(dpfVERTEXPTR, dmVector) ;
DPF_EXPORT void
dpfGetVertexNormal(dpfVERTEXPTR, dmVector) ;
DPF_EXPORT void
dpfGetVertexColour(dpfVERTEXPTR, dpfRGBA) ;
DPF_EXPORT void
dpfGetVertexTexture(dpfVERTEXPTR, dpfTEXT) ;

DPF_EXPORT void
dpfSetVertexPoint(dpfVERTEXPTR, dmVector) ;
DPF_EXPORT void
dpfSetVertexNormal(dpfVERTEXPTR, dmVector) ;
DPF_EXPORT void
dpfSetVertexColour(dpfVERTEXPTR, dpfRGBA) ;
DPF_EXPORT void
dpfSetVertexTexture(dpfVERTEXPTR, dpfTEXT) ;

/* Pmesh functions */
/* Connection List's */
DPF_EXPORT dpfCLISTPTR
dpfCreateCList(int32 pcount, int32 fcount);
DPF_EXPORT int32
dpfAddCList(dpfGEOMETRYPTR geom, dpfCLISTPTR cList) ;
DPF_EXPORT int32
dpfUnlinkCList(dpfCLISTPTR);
DPF_EXPORT int32
dpfFreeCList(dpfCLISTPTR);
DPF_EXPORT int32
dpfFreeCListList(dpfCLISTPTR cList) ;

/* The following calls are used to loop through all the vertLists in a 
** geometry. Get Previous has to search a list to find the previous so it
** can be slow.
*/
DPF_EXPORT int32
dpfGetCListCount(dpfGEOMETRYPTR geom) ;
DPF_EXPORT dpfCLISTPTR
dpfGetFrstCList(dpfGEOMETRYPTR geom) ;
DPF_EXPORT dpfCLISTPTR
dpfGetNextCList(dpfCLISTPTR cList) ;
DPF_EXPORT dpfCLISTPTR
dpfGetPrevCList(dpfCLISTPTR cList) ;

/* VertList Info */
DPF_EXPORT int32
dpfGetCListPCount(dpfCLISTPTR cList) ;
DPF_EXPORT int32
dpfGetCListFCount(dpfCLISTPTR cList) ;
DPF_EXPORT int32 *
dpfCreateCListFace(dpfCLISTPTR cList) ;
DPF_EXPORT int32 *
dpfGetCListFace(dpfCLISTPTR cList, int32 fno) ;
DPF_EXPORT void
dpfSetCListFace(dpfCLISTPTR cList, int32 fno, int32 *verts) ;
DPF_EXPORT int32
dpfFreeCListFace(dpfCLISTPTR cList, int32 fno) ;

/* Strip List's */
DPF_EXPORT dpfSLISTPTR
dpfCreateSList(int32 pcount, int32 vcount);
DPF_EXPORT int32
dpfAddSList(dpfGEOMETRYPTR geom, dpfSLISTPTR sList) ;
DPF_EXPORT int32
dpfUnlinkSList(dpfSLISTPTR);
DPF_EXPORT int32
dpfFreeSList(dpfSLISTPTR);
DPF_EXPORT int32
dpfFreeSListList(dpfSLISTPTR sList) ;

/* The following calls are used to loop through all the Strip Lists in a 
** geometry. Get Previous has to search a list to find the previous so it
** can be slow.
*/
DPF_EXPORT int32
dpfGetSListCount(dpfGEOMETRYPTR geom) ;
DPF_EXPORT dpfSLISTPTR
dpfGetFrstSList(dpfGEOMETRYPTR geom) ;
DPF_EXPORT dpfSLISTPTR
dpfGetNextSList(dpfSLISTPTR sList) ;
DPF_EXPORT dpfSLISTPTR
dpfGetPrevSList(dpfSLISTPTR sList) ;

/* Strip List Info */
DPF_EXPORT int32
dpfGetSListPCount(dpfSLISTPTR sList) ;
DPF_EXPORT int32
dpfGetSListVCount(dpfSLISTPTR sList) ;
DPF_EXPORT int32
dpfAddSListVertex(dpfSLISTPTR sList, int32 vertNo) ;
DPF_EXPORT int32 *
dpfGetSListVertex(dpfSLISTPTR sList, int32 vno) ;
DPF_EXPORT void
dpfSetSListVertex(dpfSLISTPTR sList, int32 vno, int32 vertNo) ;


/* Sphere's */
DPF_EXPORT dpfSPHERENODEPTR
dpfCreateSphereNode(void);
DPF_EXPORT dpfSPHERENODEPTR
dpfCreateSphereNodeBlock(int32 numVLists) ;
DPF_EXPORT int32
dpfAddSphereNode(dpfGEOMETRYPTR geom, dpfSPHERENODEPTR vertex) ;
DPF_EXPORT int32
dpfUnlinkSphereNode(dpfSPHERENODEPTR);
DPF_EXPORT int32
dpfFreeSphereNode(dpfSPHERENODEPTR);
DPF_EXPORT int32
dpfFreeSphereNodeList(dpfSPHERENODEPTR vertList) ;


/* The following calls are used to loop through all the spheres in a 
** geometry. Get Previous has to search a list to find the previous so it
** can be slow.
*/
DPF_EXPORT int32
dpfGetSphereNodeCount(dpfGEOMETRYPTR geom) ;
DPF_EXPORT dpfSPHERENODEPTR
dpfGetFrstSphereNode(dpfGEOMETRYPTR geom) ;
DPF_EXPORT dpfSPHERENODEPTR
dpfGetNextSphereNode(dpfSPHERENODEPTR vertList) ;
DPF_EXPORT dpfSPHERENODEPTR
dpfGetPrevSphereNode(dpfSPHERENODEPTR vertList) ;

/* Sphere Info */
DPF_EXPORT void
dpfGetSphereDice(dpfGEOMETRYPTR geom, uint8 *u_dice, uint8 *v_dice) ;
DPF_EXPORT void
dpfSetSphereDice(dpfGEOMETRYPTR geom, uint8 u_dice, uint8 v_dice) ;

DPF_EXPORT float32
dpfGetSphereNodeData(dpfSPHERENODEPTR vertList, dmVector point) ;
DPF_EXPORT void
dpfSetSphereNodeData(dpfSPHERENODEPTR vertList, float32 radius,
                     dmVector point) ;

/* Text */
DPF_EXPORT dpfTEXTNODEPTR
dpfCreateTextNode(void) ;
DPF_EXPORT dpfTEXTNODEPTR
dpfCreateTextNodeBlock(int32 numTexts) ;
DPF_EXPORT int32
dpfUnlinkTextNode(dpfTEXTNODEPTR text) ;
DPF_EXPORT int32 
dpfAddTextNode(dpfGEOMETRYPTR geom, dpfTEXTNODEPTR text) ;
DPF_EXPORT int32
dpfFreeTextNode(dpfTEXTNODEPTR text) ;
DPF_EXPORT int32
dpfFreeTextNodeList(dpfTEXTNODEPTR text) ;

/* move through text list */
DPF_EXPORT int32
dpfGetTextNodeCount(dpfGEOMETRYPTR geom) ;
DPF_EXPORT dpfTEXTNODEPTR
dpfGetFrstTextNode(dpfGEOMETRYPTR geom) ;
DPF_EXPORT dpfTEXTNODEPTR
dpfGetNextTextNode(dpfTEXTNODEPTR text) ;
DPF_EXPORT dpfTEXTNODEPTR
dpfGetPrevTextNode(dpfTEXTNODEPTR text) ;

/* Get and set text global info */
DPF_EXPORT dpfFONT
dpfGetTextFont(dpfGEOMETRYPTR geom) ;
DPF_EXPORT void
dpfGetTextOrientation(dpfGEOMETRYPTR geom, dmVector orn) ;
DPF_EXPORT void
dpfGetTextScale(dpfGEOMETRYPTR geom, dmVector scale) ;
DPF_EXPORT void
dpfSetTextFont(dpfGEOMETRYPTR geom, dpfFONT font) ;
DPF_EXPORT void
dpfSetTextOrientation(dpfGEOMETRYPTR geom, dmVector orn) ;
DPF_EXPORT void
dpfSetTextScale(dpfGEOMETRYPTR geom, dmVector scale) ;

/* get and set text node info */
DPF_EXPORT void
dpfGetTextNodePoint(dpfTEXTNODEPTR text, dmVector point) ;
DPF_EXPORT char *
dpfGetTextNodeString(dpfTEXTNODEPTR text) ;
DPF_EXPORT void
dpfSetTextNodePoint(dpfTEXTNODEPTR text, dmVector point) ;
DPF_EXPORT void
dpfSetTextNodeString(dpfTEXTNODEPTR text, char *str1) ;

/* Get and set line global info */
DPF_EXPORT uint8
dpfGetLineThickness(dpfGEOMETRYPTR geom) ;
DPF_EXPORT void
dpfSetLineThickness(dpfGEOMETRYPTR geom, uint8 thickness) ;

/* Get and set point global info */
DPF_EXPORT float32
dpfGetPointSize(dpfGEOMETRYPTR geom) ;
DPF_EXPORT void
dpfSetPointSize(dpfGEOMETRYPTR geom, float32 size) ;

/* pfgeomet Geometry & strips & pmeshes etc */
DPF_EXPORT dpfGEOMETRYPTR
dpfCreatePoint(void) ;
DPF_EXPORT dpfGEOMETRYPTR
dpfCreatePolygon(void) ;
DPF_EXPORT dpfGEOMETRYPTR
dpfCreateTristrip(void);
DPF_EXPORT dpfGEOMETRYPTR
dpfCreatePolystrip(void);
DPF_EXPORT dpfGEOMETRYPTR
dpfCreatePmesh(void);
DPF_EXPORT dpfGEOMETRYPTR
dpfCreateSphere(void);
DPF_EXPORT dpfGEOMETRYPTR
dpfCreateLine(void) ;
DPF_EXPORT dpfGEOMETRYPTR
dpfCreateText(void) ;
DPF_EXPORT int32
dpfAddGeometry(dpfGEOGROUPPTR geogroup, dpfGEOMETRYPTR geom) ;
DPF_EXPORT int32 
dpfUnlinkGeometry(dpfGEOMETRYPTR geometry) ;
DPF_EXPORT int32
dpfFreeGeometry(dpfGEOMETRYPTR);
DPF_EXPORT int32
dpfFreeFileGeometries(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfTurnGeometry2Pmesh(dpfGEOMETRYPTR geom) ;

/* The following calls are used to loop through all the geometries in a
** file. Get Previous has to search a list to find the previous so it
** can be slow.
*/
DPF_EXPORT dpfGEOGROUPPTR
dpfGetGeometryParent(dpfGEOMETRYPTR geom) ;
DPF_EXPORT dpfGEOMETRYPTR
dpfGetFrstGeometry(dpfGEOGROUPPTR geogroup) ;
DPF_EXPORT dpfGEOMETRYPTR
dpfGetNextGeometry(dpfGEOMETRYPTR geom) ;
DPF_EXPORT dpfGEOMETRYPTR
dpfGetPrevGeometry(dpfGEOMETRYPTR geom) ;

/* Geometry info */
DPF_EXPORT int32
dpfGetGeometryType(dpfGEOMETRYPTR geom) ;

/* pfgeogroup geogroups */
DPF_EXPORT dpfGEOGROUPPTR
dpfCreateGeogroup(void) ;
DPF_EXPORT int32
dpfAddGeogroup(dpfLODPTR lod, dpfGEOGROUPPTR geogroup) ;
DPF_EXPORT dpfGEOGROUPPTR
dpfGetNamedGeogroup(dpfLODPTR lod, char *name) ;
DPF_EXPORT dpfGEOGROUPPTR
dpfFindGeogroup(dpfLODPTR lod, char *name, uint8 vflag, char *fmatName,
                dpfMATTYPE bmatType) ;
DPF_EXPORT int32
dpfJoinGeogroup(dpfGEOGROUPPTR geogroup1, dpfGEOGROUPPTR geogroup2) ;
DPF_EXPORT int32
dpfUnlinkGeogroup(dpfGEOGROUPPTR) ;
DPF_EXPORT int32
dpfFreeGeogroup(dpfGEOGROUPPTR) ;

/* The following calls are used to loop through all the geogroups in an
** LOD. Get Previous has to search a list to find the previous so it
** can be slow.
*/
DPF_EXPORT dpfLODPTR
dpfGetGeogroupParent(dpfGEOGROUPPTR geogroup) ;
DPF_EXPORT dpfGEOGROUPPTR
dpfGetFrstGeogroup(dpfLODPTR object) ;
DPF_EXPORT dpfGEOGROUPPTR
dpfGetNextGeogroup(dpfGEOGROUPPTR geogroup) ;
DPF_EXPORT dpfGEOGROUPPTR
dpfGetPrevGeogroup(dpfGEOGROUPPTR geogroup) ;

/* Get surface pointer for the surface setting and getting calls */
DPF_EXPORT dpfSURFACEPTR
dpfGetGeogroupSurface(dpfGEOGROUPPTR geogroup) ;

/* pflod LODs */
DPF_EXPORT dpfLODPTR
dpfCreateLOD(void) ;
DPF_EXPORT int32
dpfAddLOD(dpfOBJECTPTR object, dpfLODPTR lod) ;
DPF_EXPORT int32
dpfJoinLOD(dpfLODPTR lod1, dpfLODPTR lod2) ;
DPF_EXPORT int32
dpfUnlinkLOD(dpfLODPTR) ;
DPF_EXPORT int32
dpfFreeLOD(dpfLODPTR) ;
DPF_EXPORT int32
dpfCmpLOD(dpfLODPTR lod1, dpfLODPTR lod2) ;

/* The following calls are used to loop through all the lods in a
** file. Get Previous has to search a list to find the previous so it
** can be slow.
*/
DPF_EXPORT dpfOBJECTPTR
dpfGetLODParent(dpfLODPTR) ;
DPF_EXPORT dpfLODPTR
dpfGetFrstLOD(dpfOBJECTPTR) ;
DPF_EXPORT dpfLODPTR
dpfGetNextLOD(dpfLODPTR) ;
DPF_EXPORT dpfLODPTR
dpfGetPrevLOD(dpfLODPTR) ;

/* LOD info */
DPF_EXPORT char *
dpfGetLODName(dpfLODPTR lod) ;
DPF_EXPORT void
dpfGetLODDistance(dpfLODPTR lod, float32 *InDist, float32 *OutDist) ;
DPF_EXPORT dpfTRANSITION
dpfGetLODTransition(dpfLODPTR lod) ;
DPF_EXPORT int32
dpfGetLODReference(dpfLODPTR lod, dmVector reference) ;

DPF_EXPORT void
dpfSetLODName(dpfLODPTR lod, char *name) ;
DPF_EXPORT void
dpfSetLODDistance(dpfLODPTR lod, float32 InDist, float32 OutDist) ;
DPF_EXPORT void
dpfSetLODTransition(dpfLODPTR lod, dpfTRANSITION Transition) ;
DPF_EXPORT void
dpfSetLODReference(dpfLODPTR lod, int32 referenceFlag, dmVector reference) ;


/* pfobject objects */
DPF_EXPORT dpfOBJECTPTR
dpfCreateObject(void) ;
DPF_EXPORT int32
dpfAddObject(dpfFILEPTR file, dpfOBJECTPTR object) ;
DPF_EXPORT int32
dpfJoinObject(dpfOBJECTPTR object1, dpfOBJECTPTR object2) ;
DPF_EXPORT int32
dpfUnlinkObject(dpfOBJECTPTR) ;
DPF_EXPORT int32
dpfFreeObject(dpfOBJECTPTR) ;

/* The following calls are used to loop through all the objects in a
** file. Get Previous has to search a list to find the previous so it
** can be slow.
*/
DPF_EXPORT dpfFILEPTR
dpfGetObjectParent(dpfOBJECTPTR) ;
DPF_EXPORT dpfOBJECTPTR
dpfGetFrstObject(dpfFILEPTR) ;
DPF_EXPORT dpfOBJECTPTR
dpfGetNextObject(dpfOBJECTPTR) ;
DPF_EXPORT dpfOBJECTPTR
dpfGetPrevObject(dpfOBJECTPTR) ;

/* Get surface pointer for the surface setting and getting calls */
DPF_EXPORT dpfSURFACEPTR
dpfGetObjectSurface(dpfOBJECTPTR object) ;

/* pffile file structure */
DPF_EXPORT int32
dpfGetAllFile(char *name, dpfFILEPTR *file, uint8 verMajor, uint8 verMinor,
              char *defTextName) ;
DPF_EXPORT dpfFILEPTR
dpfOpenAllFile(char *name, uint8 verMajor, uint8 verMinor) ;
DPF_EXPORT int32
dpfGetAllFileBody(dpfFILEPTR file, char *defTextName) ;
DPF_EXPORT int32
dpfGetFile(char *name, dpfFILEPTR *file) ;
DPF_EXPORT dpfFILEPTR
dpfOpenFile(char *name) ;
DPF_EXPORT int32
dpfGetFileBody(dpfFILEPTR file) ;

DPF_EXPORT int32
dpfPutAllFile(char *name, dpfFILEPTR Sfile, dpfFILEPTR matFile) ;
DPF_EXPORT int32
dpfPutAllFileBody(dpfFILEPTR Dfile,dpfFILEPTR Sfile, dpfFILEPTR matFile) ;
DPF_EXPORT int32
dpfPutFile(char *name, dpfFILEPTR Sfile) ;
DPF_EXPORT int32
dpfPutFileBody(dpfFILEPTR Dfile,dpfFILEPTR Sfile) ;
DPF_EXPORT dpfFILEPTR
dpfOpenNewFile(char *name, dpfFILEFORMAT form, dpfFILETYPE fileType) ;

DPF_EXPORT dpfFILEPTR
dpfCreateFile(char *name) ;
DPF_EXPORT int32
dpfJoinFile(dpfFILEPTR file1, dpfFILEPTR file2) ;
DPF_EXPORT int32
dpfCloseFile(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfFreeFile(dpfFILEPTR) ;
DPF_EXPORT int32
dpfKillFile(dpfFILEPTR file) ;

/* File info */
DPF_EXPORT dpfFILETYPE
dpfGetFileType(dpfFILEPTR file) ;
DPF_EXPORT dpfFILEFORMAT
dpfGetFileFormat(dpfFILEPTR file) ;
DPF_EXPORT char *
dpfGetFileName(dpfFILEPTR file) ;

/* File info */
DPF_EXPORT void
dpfSetFileType(dpfFILEPTR file, dpfFILETYPE type) ;
DPF_EXPORT void
dpfSetFileFormat(dpfFILEPTR file,dpfFILEFORMAT format) ;

/* pfinfo information on struction, read and written */
DPF_EXPORT int32
dpfCountFileContent(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoMaterials(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoTextures(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoRamps(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoObjects(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoLODs(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoGeogroups(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoGeometries(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoPolystrips(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoTristrips(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoPmeshes(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoSLists(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoSFaces(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileSFtimesP(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoCLists(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoCFaces(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileCFtimesP(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoVertices(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoTriangles(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileTotNoTriangles(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoSphereLists(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoSpheres(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoPointLists(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoPoints(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoLines(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoLineNodes(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoTexts(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoTextStrings(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoPolygons(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetFileNoPolygonVertices(dpfFILEPTR file) ;


/* pfmaterl materials */
DPF_EXPORT dpfMATERIALPTR
dpfCreateMaterial(void) ;
DPF_EXPORT dpfMATERIALPTR
dpfCreateRGBMaterial(dpfRGBA rgb) ;
DPF_EXPORT char *
dpfCreateMaterialName(char *extPath, char *library, char *mname) ;
DPF_EXPORT void
dpfCpyMaterial(dpfMATERIALPTR mat1, dpfMATERIALPTR mat2) ;
DPF_EXPORT int32
dpfCmpMaterial(dpfMATERIALPTR mat1, dpfMATERIALPTR mat2) ;
DPF_EXPORT dpfMATERIALPTR
dpfAddMaterial(dpfFILEPTR file, dpfMATERIALPTR mat) ;
DPF_EXPORT dpfMATERIALPTR
dpfAddV1Material(dpfFILEPTR file, dpfMATERIALPTR mat) ;
DPF_EXPORT dpfMATERIALPTR
dpfAddUnnamedMaterial(dpfFILEPTR file, dpfMATERIALPTR mat) ;
DPF_EXPORT int32
dpfFreeMaterial(dpfMATERIALPTR mat) ;

DPF_EXPORT dpfFILEPTR
dpfGetMaterialParent(dpfMATERIALPTR mat) ;
DPF_EXPORT dpfMATERIALPTR
dpfGetFrstMaterial(dpfFILEPTR file) ;
DPF_EXPORT dpfMATERIALPTR
dpfGetNextMaterial(dpfMATERIALPTR mat) ;
DPF_EXPORT dpfMATERIALPTR
dpfGetPrevMaterial(dpfMATERIALPTR mat) ;
DPF_EXPORT dpfMATERIALPTR
dpfFindMaterial(dpfFILEPTR fp, char *matName) ;

/* Set material name literally sets the name to the given pointer, 
** so make sure it dynamically allocated and not used by anything else!
** If in doubt use copy name which creates a new dynamically allocated name.
*/
DPF_EXPORT void 
dpfSetMaterialName(dpfMATERIALPTR mat, char *name) ;
DPF_EXPORT void
dpfSetMaterialTexture(dpfMATERIALPTR mat, dpfMATTXTTYPE TxtType, char *name) ;
DPF_EXPORT void 
dpfSetMaterialRamp(dpfMATERIALPTR mat, char *name) ;
DPF_EXPORT void 
dpfSetMaterialEnvironment(dpfMATERIALPTR mat, dpfENVIRONMENT envType, 
                          char *name) ;
DPF_EXPORT void 
dpfSetMaterialAmbient(dpfMATERIALPTR mat,dpfRGBA colour) ;
DPF_EXPORT void 
dpfSetMaterialDiffuse(dpfMATERIALPTR mat,dpfRGBA colour) ;
DPF_EXPORT void 
dpfSetMaterialSpecular(dpfMATERIALPTR mat,dpfRGBA colour) ;
DPF_EXPORT void 
dpfSetMaterialEmissive(dpfMATERIALPTR mat,dpfRGBA colour) ;
DPF_EXPORT void 
dpfSetMaterialOpacity(dpfMATERIALPTR mat,dpfRGBA colour) ;

/* Returns a pointer to THE name. so don't destroy */
DPF_EXPORT char *
dpfGetMaterialName(dpfMATERIALPTR mat) ;
DPF_EXPORT dpfMATTXTTYPE
dpfGetMaterialTexture(dpfMATERIALPTR mat, char **name) ;
DPF_EXPORT char *
dpfGetMaterialRamp(dpfMATERIALPTR mat) ;
DPF_EXPORT dpfENVIRONMENT
dpfGetMaterialEnvironment(dpfMATERIALPTR mat, char **name) ;
DPF_EXPORT void 
dpfGetMaterialAmbient(dpfMATERIALPTR mat,dpfRGBA colour) ;
DPF_EXPORT void 
dpfGetMaterialDiffuse(dpfMATERIALPTR mat,dpfRGBA colour) ;
DPF_EXPORT void 
dpfGetMaterialSpecular(dpfMATERIALPTR mat,dpfRGBA colour) ;
DPF_EXPORT void 
dpfGetMaterialEmissive(dpfMATERIALPTR mat,dpfRGBA colour) ;
DPF_EXPORT void 
dpfGetMaterialOpacity(dpfMATERIALPTR mat,dpfRGBA colour) ;


/* pfile General file loading calls */
DPF_EXPORT void
dpfErrorOn(void) ;
DPF_EXPORT void
dpfErrorOff(void) ;
DPF_EXPORT void
dpfDebugOn(void) ;
DPF_EXPORT void
dpfDebugOff(void) ;

/* Names and Strings and things */
/* the return from cmp is similar to strcmp, ie 0 if the same, else non-zero */
DPF_EXPORT int32
dpfCmpName(char *name1, char *name2) ;

/* Strings can have '\0' in them, so the first byte is the string length */
/* Create uses the str as its string, copy mallocs more space and copies
** in the string str 
*/
DPF_EXPORT dpfSTRINGPTR
dpfCreateString(void) ;
DPF_EXPORT dpfSTRINGPTR
dpfDuplicateString(dpfSTRINGPTR str) ;
DPF_EXPORT int32
dpfSetString(dpfSTRINGPTR str, int32 Length, uint8 *theStr) ;
DPF_EXPORT void
dpfFreeString(dpfSTRINGPTR str) ;
/* the return from cmp is similar to strcmp, ie 0 if the same, else non-zero */
DPF_EXPORT int32
dpfCmpString(dpfSTRINGPTR str1, dpfSTRINGPTR str2) ;
DPF_EXPORT int32
dpfGetStringLength(dpfSTRINGPTR str) ;
DPF_EXPORT uint8 *
dpfGetStringString(dpfSTRINGPTR str) ;

/* pfcheck checks input values */
DPF_EXPORT float32
dpfCheckRGB(float32 colour) ;
DPF_EXPORT float32
dpfCheckAlpha(float32 alpha) ;
DPF_EXPORT float32 
dpfCheckV1Power(float32 power) ;
DPF_EXPORT float32
dpfCheckPower(float32 power) ;
DPF_EXPORT float32
dpfCheckOpacity(float32 opacity) ;
DPF_EXPORT uint16
dpfCheckDice(uint16 dice) ;

/* ramp stuff */
DPF_EXPORT dpfRAMPPTR 
dpfCreateRamp(void);
DPF_EXPORT int32
dpfCmpRamp(dpfRAMPPTR r1, dpfRAMPPTR r2) ;
DPF_EXPORT dpfRAMPPTR
dpfAddRamp(dpfFILEPTR file, dpfRAMPPTR r) ;
DPF_EXPORT int32
dpfFreeRamp(dpfRAMPPTR r) ;

DPF_EXPORT dpfFILEPTR
dpfGetRampParent(dpfRAMPPTR mat) ;
DPF_EXPORT dpfRAMPPTR
dpfGetFrstRamp(dpfFILEPTR file) ;
DPF_EXPORT dpfRAMPPTR
dpfGetNextRamp(dpfRAMPPTR mat) ;
DPF_EXPORT dpfRAMPPTR
dpfGetPrevRamp(dpfRAMPPTR mat) ;
DPF_EXPORT dpfRAMPPTR
dpfFindRamp(dpfFILEPTR fp, char *rampName) ;

DPF_EXPORT void
dpfSetRampName(dpfRAMPPTR r, char *a);
DPF_EXPORT void
dpfSetRampData(dpfRAMPPTR r, dpfRGBA a, dpfRGBA b);
DPF_EXPORT char *
dpfGetRampName(dpfRAMPPTR r);
DPF_EXPORT void
dpfGetRampData(dpfRAMPPTR r, dpfRGBA data0, dpfRGBA data1) ;

/* new boundary stuff */
DPF_EXPORT dpfBOUNDPTR
dpfCreateBound(void) ;
DPF_EXPORT int32
dpfUnlinkBound(dpfBOUNDPTR bound) ;
DPF_EXPORT int32
dpfAddFileBound(dpfFILEPTR file, dpfBOUNDPTR bound) ;
DPF_EXPORT int32
dpfAddBoundBound(dpfBOUNDPTR prnt, dpfBOUNDPTR bound) ;
DPF_EXPORT int32
dpfFreeBound(dpfBOUNDPTR bound) ;
DPF_EXPORT dpfFILEPTR
dpfGetBoundFile(dpfBOUNDPTR bound) ;
DPF_EXPORT dpfBOUNDPTR
dpfGetBoundParent(dpfBOUNDPTR bound) ;
DPF_EXPORT dpfBOUNDPTR
dpfGetFileBound(dpfFILEPTR file) ;
DPF_EXPORT dpfBOUNDPTR
dpfGetFrstBound(dpfBOUNDPTR bound) ;
DPF_EXPORT dpfBOUNDPTR
dpfGetNextBound(dpfBOUNDPTR bound) ;
DPF_EXPORT dpfBOUNDPTR
dpfGetPrevBound(dpfBOUNDPTR bound) ;
DPF_EXPORT void
dpfSetBoundSphere(dpfBOUNDPTR bound, int32 present, float32 radius,
                  dmVector point) ;
DPF_EXPORT void
dpfSetBoundBox(dpfBOUNDPTR bound,int32 present,dmVector bMin,dmVector bMax, dmVector orien) ;
DPF_EXPORT void
dpfSetBoundPmesh(dpfBOUNDPTR bound, dpfGEOMETRYPTR pmesh) ;
DPF_EXPORT void
dpfSetBoundAuto(dpfBOUNDPTR bound, dpfAUTO Auto) ;
DPF_EXPORT void
dpfSetBoundLODName(dpfBOUNDPTR bound, char *name) ;
DPF_EXPORT void
dpfSetBoundObjectName(dpfBOUNDPTR bound, char *name) ;
DPF_EXPORT int32
dpfGetBoundSphere(dpfBOUNDPTR bound, float32 *radius, dmVector point) ;
DPF_EXPORT int32
dpfGetBoundBox(dpfBOUNDPTR bound, dmVector bMin, dmVector bMax, dmVector orien) ;
DPF_EXPORT dpfGEOMETRYPTR
dpfGetBoundPmesh(dpfBOUNDPTR bound) ;
DPF_EXPORT uint8
dpfGetBoundAuto(dpfBOUNDPTR bound) ;
DPF_EXPORT void
dpfCalcBBoxInitialize(dpfBOUNDPTR bound) ;
DPF_EXPORT void
dpfCalcPointBBox(dmVector vec, dmVector MinVec, dmVector MaxVec) ;
DPF_EXPORT int32
dpfCalcGeometryBBox(dpfGEOMETRYPTR geom, dpfBOUNDPTR bound) ;
DPF_EXPORT int32
dpfCalcGeogroupBBox(dpfGEOGROUPPTR geogroup, dpfBOUNDPTR bound) ;
DPF_EXPORT int32
dpfCalcLODBBox(dpfLODPTR lod, dpfBOUNDPTR bound) ;
DPF_EXPORT int32
dpfCalcBBox(dpfFILEPTR file, dpfBOUNDPTR bound) ;
DPF_EXPORT void
dpfCalcExtentInitialize(dpfRANGE range) ;
DPF_EXPORT void
dpfCalcPointExtent(dmVector vec, dmVector dir, dpfRANGE range, dmVector min, dmVector max) ;
DPF_EXPORT int32
dpfCalcGeometryExtent(dpfGEOMETRYPTR geom, dmVector dir, dpfRANGE range, dmVector min, dmVector max) ;
DPF_EXPORT int32
dpfCalcGeogroupExtent(dpfGEOGROUPPTR geogroup, dmVector dir, dpfRANGE range, dmVector min, dmVector max) ;
DPF_EXPORT int32
dpfCalcLODExtent(dpfLODPTR lod, dmVector dir, dpfRANGE range, dmVector min, dmVector max) ;
DPF_EXPORT int32
dpfCalcExtent(dpfFILEPTR file, dmVector dir, dpfRANGE range, dmVector min, dmVector max) ;
DPF_EXPORT int32
dpfCalcGeometryBSphere(dpfGEOMETRYPTR geom, dpfBOUNDPTR bound) ;
DPF_EXPORT int32
dpfCalcGeogroupBSphere(dpfGEOGROUPPTR geogroup, dpfBOUNDPTR bound) ;
DPF_EXPORT int32
dpfCalcBSphere(dpfFILEPTR file, dpfBOUNDPTR bound) ;
DPF_EXPORT int32
dpfCheckBound(dpfFILEPTR file) ;

/*** texture stuff ***/
DPF_EXPORT dpfTEXTUREPTR
dpfCreateTexture(void);
DPF_EXPORT int32
dpfCpyTexture(dpfTEXTUREPTR txt1, dpfTEXTUREPTR txt2) ;
DPF_EXPORT int32
dpfCmpTexture(dpfTEXTUREPTR txt1, dpfTEXTUREPTR txt2) ;
DPF_EXPORT dpfTEXTUREPTR
dpfAddTexture(dpfFILEPTR file, dpfTEXTUREPTR txt) ;
DPF_EXPORT int32
dpfUnlinkTexture(dpfTEXTUREPTR txt) ;
DPF_EXPORT int32
dpfFreeTexture(dpfTEXTUREPTR txt) ;

DPF_EXPORT dpfFILEPTR
dpfGetTextureParent(dpfTEXTUREPTR txt) ;
DPF_EXPORT dpfTEXTUREPTR
dpfGetFrstTexture(dpfFILEPTR file) ;
DPF_EXPORT dpfTEXTUREPTR
dpfGetNextTexture(dpfTEXTUREPTR txt) ;
DPF_EXPORT dpfTEXTUREPTR
dpfGetPrevTexture(dpfTEXTUREPTR txt) ;
DPF_EXPORT dpfTEXTUREPTR
dpfFindTexture(dpfFILEPTR fp, char *txtName) ;

DPF_EXPORT void
dpfSetTextureName(dpfTEXTUREPTR t, char *a);
DPF_EXPORT void
dpfSetTextureMap(dpfTEXTUREPTR t, char *a);
DPF_EXPORT void
dpfSetTextureWrap(dpfTEXTUREPTR t, dpfWRAP a);
DPF_EXPORT void
dpfSetTextureUWrap(dpfTEXTUREPTR t, dpfWRAP a);
DPF_EXPORT void
dpfSetTextureVWrap(dpfTEXTUREPTR t, dpfWRAP a);
DPF_EXPORT void
dpfSetTextureDetail(dpfTEXTUREPTR t, dpfDETAIL detail, char *name) ;
DPF_EXPORT void
dpfSetTextureMinify(dpfTEXTUREPTR t, dpfMINIFY a);
DPF_EXPORT void
dpfSetTextureMagnify(dpfTEXTUREPTR t, dpfMAGNIFY a);
DPF_EXPORT void
dpfSetTextureAlpha(dpfTEXTUREPTR t, dpfALPHA a);
DPF_EXPORT void
dpfSetTextureBitslice(dpfTEXTUREPTR t, uint8 a);

DPF_EXPORT char *
dpfGetTextureName(dpfTEXTUREPTR t) ;
DPF_EXPORT char *
dpfGetTextureMap(dpfTEXTUREPTR t) ;
DPF_EXPORT dpfWRAP
dpfGetTextureUWrap(dpfTEXTUREPTR t) ;
DPF_EXPORT dpfWRAP
dpfGetTextureVWrap(dpfTEXTUREPTR t) ;
DPF_EXPORT dpfDETAIL
dpfGetTextureDetail(dpfTEXTUREPTR t, char **name) ;
DPF_EXPORT dpfMINIFY
dpfGetTextureMinify(dpfTEXTUREPTR t) ;
DPF_EXPORT dpfMAGNIFY
dpfGetTextureMagnify(dpfTEXTUREPTR t) ;
DPF_EXPORT dpfALPHA
dpfGetTextureAlpha(dpfTEXTUREPTR t) ;
DPF_EXPORT uint8
dpfGetTextureBitslice(dpfTEXTUREPTR t) ;


/*** header stuff ***/
DPF_EXPORT void
dpfSetFileVersion(dpfFILEPTR f, uint8 i, uint8 j);
DPF_EXPORT void
dpfSetFileDate(dpfFILEPTR f, uint8 i, uint8 j, uint8 k);
DPF_EXPORT void
dpfSetFileTime(dpfFILEPTR f, uint8 i, uint8 j);
DPF_EXPORT void
dpfSetFileUnit(dpfFILEPTR f, dpfUNIT i);
DPF_EXPORT void
dpfSetFileScale(dpfFILEPTR f, float32 i);
DPF_EXPORT void
dpfSetFilePrecision(dpfFILEPTR f, dpfPRECISION i);
DPF_EXPORT void
dpfSetHeaderComment(dpfFILEPTR f, dpfSTRINGPTR i);

DPF_EXPORT void
dpfGetLibraryVersion(uint8 *i, uint8 *j) ;
DPF_EXPORT int32
dpfGetFileVersion(dpfFILEPTR f, uint8 *verMajor, uint8 *verMinor) ;
DPF_EXPORT int32
dpfGetFileDate(dpfFILEPTR f, uint8 *dpfday, uint8 *dpfmonth, uint8 *dpfyear) ;
DPF_EXPORT int32
dpfGetFileTime(dpfFILEPTR f, uint8 *dpfhours, uint8 *dpfminutes) ;
DPF_EXPORT dpfUNIT
dpfGetFileUnit(dpfFILEPTR f) ;
DPF_EXPORT float32
dpfGetFileScale(dpfFILEPTR f) ;
DPF_EXPORT dpfPRECISION
dpfGetFilePrecision(dpfFILEPTR f) ; 
DPF_EXPORT dpfSTRINGPTR
dpfGetFileComment(dpfFILEPTR f) ;

/**************** callbacks *******************/
/* The following functions are used to set callbacks 
 * for each of several structures.  They are called when
 * a structure has been completed and would normally be
 * linked into the file structure.  The procedure is passed
 * a pointer to the structure to do with as it wishes and
 * returns an integer value.  If the return value is 1 the
 * structure is freed, otherwise it is linked into the
 * file structure as usual.
 */


/* new whizzy v1.0 -> v2.0 texture name converter stuff */
struct dpfVISTEXTURETYPE ;
typedef struct dpfVISTEXTURETYPE *dpfVISTEXTUREPTR;

DPF_EXPORT dpfVISTEXTUREPTR
dpfCreateV1TextureList(char *mazName) ;
DPF_EXPORT void
dpfSetFileVisList(dpfFILEPTR file, dpfVISTEXTUREPTR visList) ;
DPF_EXPORT void
dpfConvertV1Texture(dpfFILEPTR Sfp, dpfMATERIALPTR Fmat, dpfMATERIALPTR Bmat) ;
DPF_EXPORT void
dpfFreeV1TextureList(dpfVISTEXTUREPTR visList) ;


DPF_EXPORT int32
dpfCheckFile(dpfFILEPTR file) ;

DPF_EXPORT void
dpfVersion(FILE *fp) ;

#ifdef __cplusplus
}
#endif

#endif /* __PFILE_H__ */
