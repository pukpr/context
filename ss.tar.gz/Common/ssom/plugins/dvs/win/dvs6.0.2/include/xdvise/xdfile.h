/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1993 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVise file
--  Object Name  : $RCSfile: xdfile.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 23 December 1994
--  Author       : Tony Coombes
--
--  Description	 : Maintain XdVISE file info
--
--  Modified     : 
--    $Log: xdfile.h,v $
--    Revision 1.1  2005/09/13 15:08:22  pukitepa
--    init
--
--    Revision 1.13.18.1  1998/11/02 12:02:15  steve
--    modified .vpf file table to read .vpf instead of .vpf.gz (used to provide
--    default extensions to the file dialog)
--
--    Revision 1.13  1998/08/19 14:00:39  simon
--    Fixed up file path shortening and file dlgs.
--
--    Revision 1.12  1998/08/11 11:07:20  john
--    RelativePath and AbsolutePath now return an integer instead of a char * since no-one
--    ever used the char *. The value returns 0 on failure to find file
--    1 if file found and is sensible
--    2 if file found but some problem Ie. Not relative
--
--    Revision 1.11  1998/07/30 17:19:11  iand
--    Made Changes to allow Save Section as Jpeg and Save Section as Iges to have the
--    correct filters automatically enabled in the file dialog
--
--    Revision 1.10  1998/07/15 16:15:28  simon
--    made some changes to the progress dlg, and file dlgs so they could be
--    called from a plugin.  Added a couple of new types for file dlg.
--
--    Revision 1.9  1998/07/10 10:36:44  clives
--    Sorted out a few 5.0.2 glitches.
--
--    Revision 1.8  1998/07/09 15:15:24  clives
--    dvise5.0.2 specific code integrated into Darkstar
--
--    Revision 1.7  1998/06/23 16:21:43  mdj
--    *** empty log message ***
--
--    Revision 1.6  1998/04/20 11:10:58  simon
--    fixed various niggles in units, and distance tool
--
--    Revision 1.5  1997/10/30 14:54:46  mark
--    Changes for PR xdvise/3894
--
--    Added support to allow the section manager plugin to use the
--    file selection dialogue.
--
--    Revision 1.4  1997/10/10 19:14:23  steve
--    modification of fileInfo[] table to include VRML file search defaults (e.g. extension=.wrl).  enum XdFileTypes also modified to include XDFILE_VRML entry, aligned with entry in fileInfo table.
--
--    Revision 1.3  1997/10/10 14:42:06  dvs-dev
--    NT fixes from Simon's Motif changes in XdVISE.
--    General Bug fixing on NT.
--
--    Revision 1.2  1997/08/26 11:47:51  simon
--    Mainly changes to library viewer, and additional reset parts stuff
--
--    Revision 1.1  1997/07/09 12:31:21  simon
--    *** empty log message ***
--
--    Revision 1.7  1997/07/02 13:09:22  dvs-dev
--    Changes for NT build.
--    Modified header files for windows __declspec definitions
--    Added some NON working code for keyboard accelerators.
--
--    Revision 1.6  1997/05/07 15:38:13  wman
--    Added libmfc for windows build
--
--    Revision 1.5  1997/02/19 19:13:12  wman
--    Bug Fixes, and Right Mouse Button popup menu implementation
--
--    Revision 1.4  1997/02/15 17:33:57  wman
--    Bug Fixes.
--
--    Revision 1.3  1997/01/09 18:31:41  wman
--    Added two way selection as default on
--    Addded Image Save option to file menu option.
--    Also, Added some to frame manager insert frame
--
--    Revision 1.2  1996/10/18 17:47:27  wman
--    New annotation stuff!
--
--    Revision 1.1.1.1  1996/08/29 09:26:14  tony
--    first version of xdvise
--
--    Revision 3.3  1996/08/05 15:06:37  tony
--    Check in prior to starting development for IDP
--
--    Revision 3.2  1996/03/08 16:10:21  tony
--    Added support for XDFILE_RADIATION file type
--
--    Revision 3.1  1996/02/26 16:31:06  tony
--    Release 3.0
--
--    Revision 1.6  1996/02/01 18:22:05  tony
--    Added PATH_MAX
--
--    Revision 1.5  1996/01/26 11:16:40  tony
--    General updates.
--
--    Revision 1.4  1996/01/12 17:31:11  tony
--    Changed texture file atrributes
--
--
--
-- ----------------------------------------------------------------------------
*/

#ifndef __XDFILE_H__
#define __XDFILE_H__

#ifdef __cplusplus
extern "C" {
#endif

#ifndef XDV_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `XDV_EXPORT'
 */
#ifdef  _LIB_XDV
#define XDV_EXPORT __declspec(dllexport) extern
#else
#define XDV_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define XDV_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ifndef XDV_EXPORT */

#include <limits.h>    /* for PATH_MAX */
#ifndef PATH_MAX
#define PATH_MAX 1023
#endif /* PATH_MAX */

#define XDFILE_SEARCHPATH   "DIVISIONPATH"
#define XDFILE_DIVISIONROOT "DIVISIONROOT"

/* Data used in calls to XdFileGetPath() & XdFileGetShortPath()
 * NB. make sure the XdFileTypes
 *     are kept in sync.
 */
#ifndef _WIN32
static struct fileData {
    char *dir;
    char *extns;
    char *filter; /* File filter */
} fileInfo[] = {
    "vdifiles", "vdi",     "*.vdi", 
    ".",        "wrl",     "*.wrl", 
    ".",        "vpf",     "*.vpf", 
    "vdifiles", "vdl",     "*.vdl", 
    "geometry", "bgf:flt", "*.bgf", 
    "audio",    "acf:wav", "*.acf|wav", 
    "audio",    "arf",     "*.arf", 
    "material", "bmf",     "*.bmf", 
    "texture",  "int:inta:rgb:rgba:tga:vtx", "*.int|inta|rgb|rgba|tga|vtx",
    ".",        "jpg",     "*.jpg", 
    "plugin",   "so:sl",   "*.s*",
    ".",        "jpg",   "*.jpg",
    ".",        "iges",   "*.iges",
    "geometry", "iges",   "*.iges",
    };
#else
static struct fileData {	/* Should be XDV_EXPORT not static! */
    char *dir;
    char *extns;
    char *filter; /* File filter */
	char *userPrompt;	/* Used in windows file select dialog.  Needs #ifdef _WIN32 */
}

 fileInfo[] = {
    {"vdifiles", "vdi",     "*.vdi",				"Vdi Scripts\0*.vdi\0All\0*.*\0"			},
    {".",        "wrl",     "*.wrl",				"VRML\0*.wrl\0All\0*.*\0"			},
    {".",        "vpf"   "*.vpf",				"VPF\0*.vpf\0All\0*.*\0"			},
    {"vdifiles", "vdl",     "*.vdl",				"Library Files\0*.vdl\0\0All\0*.*\0"		},
    {"geometry", "bgf:flt", "*.bgf",				"Geometry Files\0*.bgf;*.flt\0All\0*.*\0"	},
    {"audio",    "acf:wav", "*.acf;*.wav",			"Audio Files\0*.acf\0*.wav\0All\0*.*\0"			},
    {"audio",    "arf",     "*.arf", 				"Audio Files\0*.arf\0All\0*.*\0"			},
    {"material", "bmf",     "*.bmf",				"Material Files\0*.bmf\0All\0*.*\0"			},
    {"texture",  "vtx:rgb:rgba:int:inta:tga", "*.vtx;*.rgb;*.rgba;*.int;*.inta;*.tga",	"Texture Files\0*.vtx;*.rgb;*.rgba;*.int;*.inta;*.tga\0All\0*.*\0"},
    {".",        "jpg",     "*.jpg",					"Image Files\0*.jpg\0All\0*.*\0"			},
    {"plugin",   "dll",     "*.dll",			         "Plugin Files\0*.dll\0All\0*.*\0"			},
    {".",        "jpg",    "*.jpg",			         "Section Image\0*.jpg\0All\0*.*\0"			},
    {".",        "iges",    "*.iges",			         "Section Image\0*.iges\0All\0*.*\0"                     },

    {".",        "iges",    "*.iges",			         "Iges Files\0*.iges\0All\0*.*\0"			},
    };
#endif


/* These enums are used to index the fileInfo
 * array so make sure they are in sync
 */
typedef enum XdFileTypes {
    XDFILE_VDI, 
    XDFILE_VRML, 
    XDFILE_VPF, 
    XDFILE_VDILIB, 
    XDFILE_GEOMETRY, 
    XDFILE_AUDIO, 
    XDFILE_RADIATION, 
    XDFILE_MATERIAL, 
    XDFILE_TEXTURE, 
    XDFILE_IMAGE,
    XDFILE_PLUGIN,          
    XDFILE_SECIMG_JPEG,
    XDFILE_SECIMG_IGES,
    XDFILE_IGES,
    XDFILE_TYPES    /* DON'T CHANGE!! - Indicates the number of file types */
} XdFileTypes;

XDV_EXPORT void  XdFileInit(void);
XDV_EXPORT void  XdFileSetVDIFileName(char *fileName);
XDV_EXPORT char *XdFileGetVDIFileName(void);
XDV_EXPORT void  XdFileSetAttrFileName(char *fileName);
XDV_EXPORT char *XdFileGetAttrFileName(void);
XDV_EXPORT char *XdFileGetPath(char *directory, char *file, char *extenstions);
XDV_EXPORT char *XdFileGetShortPath(const char *directory, const char *file, char *extensions);
XDV_EXPORT char *XdFileRealPath(const char *path, char *resolvedPath);
XDV_EXPORT int   XdFileIsDirectory(const char *path);
XDV_EXPORT int	 XdFileGetRelativePath(const XdFileTypes fileType, const char *file, char *relPath, int removeExtension);
XDV_EXPORT int	 XdFileGetAbsolutePath(const XdFileTypes fileType, const char *file, char *absPath);

 
#ifdef __cplusplus
}
#endif

#endif /* __XDFILE_H__ */

