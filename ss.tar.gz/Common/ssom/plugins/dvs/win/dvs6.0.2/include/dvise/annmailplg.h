/* 
-- ----------------------------------------------------------------------------
--
--  			Copyright 1998 Division Limited.
--			      All Rights Reserved
--
--
--  System       : 
--  Module       : 
--  Object Name  : $RCSfile: annmailplg.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : $Date: 2005/09/13 15:07:47 $
--  Author       : $Author: pukitepa $
--
--  Description	
--
--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __ANNMAILPLG_H__
#define __ANNMAILPLG_H__

#define ANNOTATION_MAIL_PLUGIN_MAJOR_VERSION 1
#define ANNOTATION_MAIL_PLUGIN_MINOR_VERSION 0

#define ANNOTATION_MAIL_PLUGIN_FUNCTION_NAME "annotation_mail_function"

    /*
     * The AnnotationMailFunction typedef defines the
     * prototype of for the function that is responsible for
     * sending an email version of the annotation to the
     * listed assingee
     */

typedef void (*AnnotationMailFunction)(const char* const name,
                                       const char* const parent,
                                       const char* const date_string,
                                       const char* const time_string,
                                       const char* const audiofile,
                                       const char* const memo,
                                       const char* const trigger_event,
                                       const float32 body_pos[3],
                                       const float32 body_ori[3],
                                       const char* const user_process,
                                       const char* const assignee,
                                       const char* const owner,
                                       const int priority,
                                       const char* const status,
                                       const char* const iconfile,
                                       const char* const markup_file,
                                       const char* const markup_image,
                                       const char* const markup_tool);


    /*
     * Set the mail handling function at runtime
     *
     */

DV_EXPORT AnnotationMailFunction dVISEAnnotation_SetMailFunction(AnnotationMailFunction);

#endif /* __ANNMAILPLG_H__ */
