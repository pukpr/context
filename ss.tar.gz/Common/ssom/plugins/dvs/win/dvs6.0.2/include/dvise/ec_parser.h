/*
 *      PROJECT:
 *      SUBSYSTEM:
 *      MODULE:
 *
 *      FILE:           $RCSfile: ec_parser.h,v $
 *      REVISION:       $Revision: 1.1 $
 *      Date:           $Date: 2005/09/13 15:07:52 $
 *      Author:         $Author: pukitepa $
 *      RCS Ident:      $Id: ec_parser.h,v 1.1 2005/09/13 15:07:52 pukitepa Exp $
 *
 *      FUNCTION:
 *
 * Copyright (c) 1994 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _EC_PARSER_H
#define _EC_PARSER_H
#ifdef __cplusplus
extern "C" {
#endif

#ifndef DV_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `DV_EXPORT'
 */
#ifdef  _LIB_DV
#define DV_EXPORT __declspec(dllexport) extern
#else
#define DV_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define DV_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ifndef DV_EXPORT */

#include <dsys/parser.h> /* Pick up type defs from dparser since they need to be common */

DV_EXPORT dParseFilePtr         ECparserCreate(char *name,
                                          FILE *openfp,
                                          dParseKeyTab *keyTable,
                                          int bufferSize,
                                          FILE *(*fileFinder)(const char *),
                                          const char *startChars,
                                          const char *continueChars,
                                          int seeIncludes);
DV_EXPORT void                 ECparserDestroy(dParseFilePtr fptr);

DV_EXPORT dParseFilePtr       ECparserOpenFile(char *name,
                                          FILE *fp,
                                          dParseKeyTab *keyTable,
                                          int bufferSize,
                                          FILE *(*fileFinder)(const char *),
                                          const char *startChars,
                                          const char *continueChars,
                                          int seeIncludes);
DV_EXPORT void	          ECparserCloseFile(dParseFilePtr fPtr);

DV_EXPORT char	     *ECparserTokenToString(dParseFilePtr fptr, const int token);
DV_EXPORT int	          ECparserPushToken(dParseFilePtr fptr, const int token);
DV_EXPORT int	          ECparserNextToken(dParseFilePtr fptr);

DV_EXPORT char	       *ECparserMatchString(dParseFilePtr fptr);
DV_EXPORT int	           ECparserMatchInt(dParseFilePtr fptr, int *num);
DV_EXPORT int	         ECparserMatchFloat(dParseFilePtr fptr, float32 *num);
DV_EXPORT int	           ECparserMatchIntNoPush(dParseFilePtr fptr, int *num);
DV_EXPORT int	         ECparserMatchFloatNoPush(dParseFilePtr fptr, float32 *num);
DV_EXPORT int	     ECparserMatchCharacter(dParseFilePtr fptr, char c);

DV_EXPORT const char      *ECparserCurrentFile(dParseFilePtr fptr);
DV_EXPORT int              ECparserCurrentLine(dParseFilePtr fptr);
DV_EXPORT void		ECparserSwallowLine(dParseFilePtr fptr);
DV_EXPORT int		ECparserSetCurrentLine(dParseFilePtr fptr, int lineno);
DV_EXPORT void		ECparserNewLine(dParseFilePtr fptr);
DV_EXPORT int            ECparserNextChar(dParseFilePtr fptr);

#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif
