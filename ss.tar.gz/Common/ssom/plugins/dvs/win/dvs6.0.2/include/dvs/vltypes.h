/*
 *    PROJECT:      DVS
 *    SUBSYSTEM:    vl
 *    MODULE:       vltypes.h
 *
 *    File:         $RCSfile: vltypes.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:08:10 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: vltypes.h,v 1.1 2005/09/13 15:08:10 pukitepa Exp $
 *
 *    FUNCTION:
 *    This file contain the definitions of low-level types that are used
 * throughout the vl system. These are all integers under a different
 * guise. 
 *
 * Copyright (c) 1994, 1995Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _VLTYPES_H
#define _VLTYPES_H
#ifdef __cplusplus
extern "C" {
#endif

#include <dsys/dp.h>
#include <dsys/divtypes.h>


/*
 * The basic id type. all the specific id types are typedefed from this.
 */
typedef uint32 IdType;

typedef IdType InstanceNo;
typedef IdType ElementHandle;
typedef int32  EventQ;
typedef IdType AgentId;
typedef uint16 ActorId;

typedef struct ipcCtrlList {
    dpIpcCtl *ipcCtrl;
    struct ipcCtrlList *next;
} ipcCtrlList;

/*the max number of actors is */
#define VL_MAX_ACTORS 65534

/* ... a bad actorid is indicated by */
#define VL_BAD_ACTOR ((ActorId) 65535)

/* ...  'all actors' is indicated by */
#define VL_ALL_ACTORS ((ActorId) 65535)



typedef void (* VLSigFunc)(int32 sig);

typedef IdType VLStreamId;
#ifndef VLSTREAM_MAX
#define VLSTREAM_MAX    21
#endif

typedef dpVtime VLTime;

/*
 * typedef for passing element descriptions around.
 */
typedef uint32 ElementDesc;


/*
 * typedefs containing all of the magic flags that might be passed into
 * vl, or returned as a status.
 */
typedef enum {
    VL_NO_SYNC       = 0x00000001,
     VL_LOCAL        = 0x00000002,
    VL_GLOBAL        = 0x00000004,
    VL_TIME          = 0x00000008
} VLUpdateMode;

typedef enum {
    VL_NOISY         = 0x00000000,
    VL_QUIET_AUTO    = 0x00000010,
    VL_QUIET         = 0x00000100,
    VL_AUDIO_MASK    = 0x00000100
} VLAudibility;

#define    VL_ACTION_NONE      0x00000000
#define    VL_ACTION_CREATE    0x00001000
#define    VL_ACTION_DELETE    0x00002000
#define    VL_ACTION_UPDATE    0x00004000

#define    VL_ACTION_SIGNAL    0x00010000
#define    VL_ACTION_STREAM    0x00020000

#define    VL_ACTION_IREG      0x00030000
#define    VL_ACTION_IDEREG    0x00040000

#define    VL_ACTION_EREG      0x00050000
#define    VL_ACTION_EDEREG    0x00060000

#define    VL_ACTION_ECREATE   0x00070000
#define    VL_ACTION_EDELETE   0x00080000
#define    VL_ACTION_ECONFIRM  0x00090000

#define    VL_ACTION_GROUP     0x000a0000
#define    VL_ACTION_UNGROUP   0x000b0000

#define    VL_ACTION_TIMEOUT   0x000c0000
#define    VL_ACTION_ALARM_REQ 0x000d0000
#define    VL_ACTION_TICK_REQ  0x000e0000

#define    VL_ACTION_PEER      0x000f0000
#define    VL_ACTION_EXIT      0x00100000
#define    VL_ACTION_SYSTEMHANDLE     0x00200000
#define    VL_ACTION_WINDOWS_MSG      0x00400000
#define    VL_ACTION_FILE      0x00500000

#define    VL_ACTION_BAD       0xffff0000
typedef    uint32 VLAction;

/*
 * index used to identify different format rules
 * (endinaess alignment etc)
 */
typedef    int32  VLFormat;

/* update vlerr.c if these are changed */
typedef enum {
    VL_ERR_OK,
    VL_ERR_BAD_AGENT,
    VL_ERR_BAD_DOMAIN,
    VL_ERR_BAD_ELEM,
    VL_ERR_BAD_INST,
    VL_ERR_BAD_STREAM,

    VL_ERR_BAD_QUEUE,
    VL_ERR_BAD_ACTION,
    VL_ERR_NOT_SLAVE,
    VL_ERR_ALREADY_PEERED,
    VL_ERR_TIME,
    VL_ERR_FORMAT,
    VL_ERR_SEMAPHORE,
    VL_ERR_NO_MEM,
    VL_ERR_LAST
}VLStatus;

typedef enum {
    VL_DETACH_ACTOR,
    VL_DETACH_LOCAL,
    VL_DETACH_GLOBAL
}VLExitMode;

typedef enum {
    VL_TIME_ALARM,
    VL_TIME_TICK,
    VL_TIME_OFF
} VLTimerMode;

typedef enum {
    VL_POLL_EVENT,
    VL_WAIT_EVENT,
    VL_SLEEP_EVENT
} VLWaitMode;

typedef enum {
    VL_DONT_SHUTDOWN,
    VL_DO_SHUTDOWN,
    VL_WAIT_FOR_ME
} VLCleanupMode;

#ifdef __cplusplus
}
#endif
#endif /*_VLTYPES_H */
