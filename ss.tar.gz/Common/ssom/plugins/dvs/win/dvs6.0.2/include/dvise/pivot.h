/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: 
 *    Revision:     $Revision: 
 *    Date:         $Date: 
 *    Author:       $Author: 
 *    RCS Ident:    $Id: 
 *
 *    FUNCTION:
 *
 * Copyright (c) 1994 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */

#ifndef _PIVOT_H
#define _PIVOT_H
#ifdef __cplusplus
extern "C" {
#endif

#include <dvise/ecpivot.h>


DV_EXPORT int ECPivot_ToVC(ECPivot *pivot);
DV_EXPORT int ECPivot_Delete(ECPivot *pivot);
DV_EXPORT int ECPivot_Enable(ECPivot *pivot);
DV_EXPORT int ECPivot_Disable(ECPivot *pivot);
DV_EXPORT VCEntity *ECAssembly_GetVCPivot(ECAssembly *obj);
DV_EXPORT int ECPivot_DeleteVisual(ECPivot *pivot);
DV_EXPORT int ECPivot_EnableVisual(ECPivot *pivot);
DV_EXPORT int ECPivot_DisableVisual(ECPivot *pivot);
DV_EXPORT int ECAssembly_UpdatePivotMode(ECAssembly *assembly, VCBody *body);
DV_EXPORT int ECPivot_Disabled(ECPivot *pivot);


#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /*_PIVOT_H */
