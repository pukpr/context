/*
 *    PROJECT:
 *    SUBSYSTEM:
 *    MODULE:
 *
 *    File:         $RCSfile: tbtypes.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:07:58 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: tbtypes.h,v 1.1 2005/09/13 15:07:58 pukitepa Exp $
 *
 *    FUNCTION: generic tool include
 * 
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _TB_TYPES_
#define _TB_TYPES_
#ifdef __cplusplus
extern "C" {
#endif

#ifndef TB_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `DV_EXPORT'
 */
#ifdef  _LIB_TB
#define TB_EXPORT __declspec(dllexport) extern
#else
#define TB_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define TB_EXPORT  DV_EXPORT
#endif /* ! _WIN32 */
#endif /* ifndef VC_EXPORT */

    
    
/* PUBLIC DEFINES =======================================*/

#ifndef FALSE
#define FALSE 0
#define TRUE (!FALSE)
#endif

#define TB_STD_X 0.4
#define TB_STD_Y 0.4
#define TB_STD_Z 0.015

#include <dvs/vwtypes.h>
/* PUBLIC TYPES =========================================*/

typedef struct _TBTool TBTool;
typedef struct _TBToolBox TBToolBox;
/*
 * TBAction function structures
 */
typedef void TBActionFunc(TBTool *tool,VCBody *body, 
                        VCAttribute *limbAttribute, void *); 

/*
 * Some structures used by the Toolbox utility functions.
 */
typedef struct _TBDefaultList {
    ECAssembly		*obj;
    VCAttribute		*visAttr;
    char		*frontMat;
    char		*backMat;
    ECAssembly		*parent;
    struct _TBDefaultList	*next;
} TBDefaultList;


typedef struct _TBUtilityData {
    TBDefaultList   *defaultList;
    char	    *DEFAULT_HIGHLIGHT_MATERIAL;
    char	    *hiMaterial;
    VCEntity	    *hiEntity;
    VCAttribute	    *hiAttr;
    char	    *objMaterial;
    char	    *objBackMaterial;
    int		    highlightOn;
    ECAction        *deleteAction;
    ECActionFunc    *deleteActionFunc;
    int             deleteActionReg;
} TBUtilityData;

/******************************************************************************************
 * Misc Toolbox Functions. 
 */

/* type for tool self-parse & initialisation func */
typedef int  ToolTypeFunc(dParseFilePtr InputStream, TBTool *ToolData); 

/* type for tool activation func */
typedef int TBCallback(TBTool *);

/* type for doing vector intersects */
struct TBIntersect;
typedef struct TBIntersect TBIntersect;

typedef struct _TBCallbackList {
        char			*name;	    /* token name for registered function lists */
        TBCallback		*function;  /* associated function */

        struct _TBCallbackList	*next;	    /* next tool in linked list */
} TBCallbackList;

/* User registered function to be called when a widget it created */
typedef void (TBGenWigCreationCb)(VWidget *createdWidget, TBTool *ToolData, void *calldata);
typedef void (TBGenObjSelCb)(ECAssembly *obj, VCBody *body, VCAttribute *limbAttribute, TBTool *ToolData);

/* User functions for widget callbacks */
/* this uses the normal VWCallback structure */


typedef struct _TBSelectedObjDataList {
    ECAssembly	*object;
    VCEntity	*entity;
    char	*frontMaterial;
    char	*backMaterial;
} TBSelectedObjDataList;

typedef struct _TBAssemblySelectData {
    char		    *defaultHighlightMaterial;
    char		    *highlightMaterial;
    TBSelectedObjDataList   *selectedObjList;
} TBAssemblySelectData;


#define _TBBODYPART_TOOL_EXPLICIT 0X1
#define _TBBODYPART_UNINITIALISED 0x2
#define _TBBODYPART_DEFAULT 0x4

typedef struct _TBBodyPart {
    char        *idName;
    uint32      flags;
    VCAttribute *bodyPart;              /* The body part that this list element refers to */
    char        *bodyPartName;          /* The name of this body part */
    char        *iconGeometry;          /* The iconic geometry used to represent this body part in 
                                         * a visual menu */
    char        *activateAudio;
    dmPoint     toolOrigin;             /* The specified Origin of the tool for this body part */
    dmScale     toolSize;               /* The specified Size of the tool for this body part */
    dmEuler     toolOrient;             /* The specified Orientation of the tool for this body part */
    
    struct _TBBodyPart *derivative;     /* Points to a body part from which this body part was derived */
    struct _TBBodyPart *next;
} TBBodyPart;


    
    
/* used in the TBox.c module but the enum types are also needed elsewhere */
typedef enum {
    TBVerbosity_Low = 0,
    TBVerbosity_Medium,
    TBVerbosity_High
} TBVerbosityType;

/* _TBTOOL_LOCKED flag set when tool is currently locked. This is used internally
 * by the locking code so as not to lock or unlock twice. */
#define _TBTOOL_LOCKED       0x1
/* _TBTOOLLOCKED_SET flag set when tool is configured to stay locked to a body
 * part. This is a user defined flag and is used to note the desired behaviour
 * of the tool, unlike the above flag. */
#define _TBTOOL_LOCKED_SET 0x2
#define _TBTOOL_ICONISED   0x4

#define _TBTOOL_INSTANCED    0x100
#define _TBTOOL_ACTIVE       0x200
#define _TBTOOL_BODYPART_HANDLER_ADDED 0x400
#define _TBTOOL_CACHED 0x800

typedef struct {
    uint32 id;
    VCAttribute *limb;
}TBLimbArray;

struct _TBTool {
    uint32              flags;
    
    TBToolBox           *toolbox;
    TBTool              *next;                  /* Used by ToolBox to chain lists of tools */
    TBTool              **pre_next_ptr;
    char		*name;			/* instance name */
    char		*iname;			/* icon name (used by menu tool) */
    
    VWidget		*toplevel;		/* top level widget shell of tool */
    VWidget		*currentInput;          /* points to the currently 
                                      * selected keyboard input widget */
    
    /* The limb to which the tool should be attached when a toolbox
     * press in invoked. This points to an element either in the
     * explicit body part list for this tool, one in the parent toolbox
     * default list. The element pointed to by this should never be
     * altered by the tool itself if it points to a bodyPartList 
     * element in the parent toolbox as this will upset other toolboxes
     */
    TBBodyPart      *currentBodyPart;
    /*TBBodyPart      *iconiseBodyPart;*/
    /* This is a list of explicitly defined body part attach 
     * statistics that will over-ride those global defaults 
     * in the parent toolbox.
     */
    TBBodyPart      *explicitBodyParts;
    /* This is a list of explicitly set body parts that have not been 
     * recognised by the ststem yet. They will be handled by a body part
     * create handler and placed in the explicitBodyParts list as soon
     * as the corresponding body part is actually created */
    TBBodyPart      *nonRecognisedBodyParts;
    
    int             maxContextLimbs;
    int             totalContextLimbs;
    TBLimbArray     *contextLimbArray;
    char            *contextVisualLeft;
    char            *contextVisualRight;
    
    
    /* TODO - verbosity and detail are to be reviewed and possibly removed
     * altogether (soon).
     */
    TBVerbosityType	verbosity;		/* tool verbosity level */
    TBVerbosityType	detail;			/* tool aesthetic detail */
    
    int		        sustained;		/* tool caches when closed flag */
    int		        active;			/* tool in use flag */
    
    ToolTypeFunc	*parse;			/* tool self parse function */
    TBCallback	        *instance;		/* tool widget instantiation */
    TBCallback	        *invoke;		/* tool invocation */
    /*
     * TO DO
     * These start and stop callbacks need to be put into a callback list
     * with accompanying functions to add to the list and execute it. 
     */
    ECAction            *creationActionList;
    TBCallbackList	*create_cb;
    ECAction            *startActionList;
    TBCallbackList	*start_cb;
    TBCallbackList	*restart_cb;
/*    TBCallbackList	*startUser_cb; */
    ECAction            *stopActionList;
    TBCallbackList	*stop_cb;
    TBCallbackList	*delete_cb;
    TBCallbackList	*instanceDelete_cb;
    /*TBCallbackList	*stopUser_cb;	*/	/* a user callback called when the tool is stopped */
    
    void		*typedata;		/* type specific data */
/* These are now found using the tbBodyPart stuff */   
/*    VCBody		*body;		*/	/* body which invoked the tool */
/*    VCAttribute	        *limbAttribute;	*/	/* limb which invoked the tool */
    
    TBUtilityData    *utilityData;
    
    char		*nextNamedTool;		/* the next tool to be invoked when this tool is    */
    char		*menuStoredNextTool;		/* used by the menu so it knows which tool to start next */
    /* stopped via TBTool_Stop			    */
    
    VCEntity	        *audioEntity;
    char		*startAudioFile;
    VCAttribute	        *startAudioAttr;
    
    void                *createBodyPartHandle;
    int                 manId_i; /* Simon 18/12/96 used by toolbox manager */
    /*
     * this stuff is in here until the lockPDM gets put into 
     * proper pull down menu
     */
    
    VWidget             *lockPDM;       /*simon 30/8/96*/
    int                 isFuncTool_b; /*true if it's a function tool */
};


#define TB_AUDIO_DISABLED	0
#define TB_AUDIO_ENABLED	1

#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /* _TB_TYPES_ */
