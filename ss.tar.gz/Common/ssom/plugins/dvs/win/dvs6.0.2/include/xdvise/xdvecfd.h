/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1996 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: xdvecfd.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 23 May 1996
--  Author       : Tony Coombes
--
--  Description	 : 3-Vector Field
--
--  Modified     : 
--    $Log: xdvecfd.h,v $
--    Revision 1.1  2005/09/13 15:08:28  pukitepa
--    init
--
--    Revision 1.2  1998/03/13 14:29:10  tony
--    Support to allow users to configure the units
--    used to display distance measurements
--
--    Revision 1.1  1997/07/09 12:32:51  simon
--    *** empty log message ***
--
--    Revision 1.2  1997/02/11 18:58:01  wman
--    Frame reset for animation dialog.
--
--    Revision 1.1.1.1  1996/08/29 09:26:22  tony
--    first version of xdvise
--
--    Revision 3.1  1996/08/05 15:06:37  tony
--    Check in prior to starting development for IDP
--
--    Revision 1.1  1996/06/18 11:17:02  tony
--    Mid development revision
--
--
--
-- ----------------------------------------------------------------------------
*/

#ifndef __XDVECFD_H__
#define __XDVECFD_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct vecFieldT vecFieldT; /* Prototype */

extern vecFieldT*XdVecFieldCreate(compT parent, char *label,  
		      int (*changedCallback)(vecFieldT *w, void *clientData), 
		      void *clientData);
extern vecFieldT *XdVecFieldCreatePlus(compT parent, char *label, float min, float max, 
                      float smlInc, float lrgInc, void(*browserCB)(void *clientData), 
		      int (*changedCallback)(vecFieldT *w, void *clientData), 
		      void *clientData);
extern void XdVecFieldDestroy(vecFieldT *vecField);
extern int  XdVecFieldGetValue(vecFieldT *vecField, dmVector value);
extern void XdVecFieldSetValue(vecFieldT *vecField, dmVector value, int explicit);
extern void XdVecFieldSetStatus(vecFieldT *vecField, int status);
extern void XdVecFieldReset(vecFieldT *vecField);
extern int  XdVecFieldGetResetValue(vecFieldT *vecField, dmVector value);
extern int  XdVecFieldHasChanged(vecFieldT *vecField);

#ifdef __cplusplus
}
#endif

#endif /* __XDVECFD_H__ */
