/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1993 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: xdunits.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 23 February 1998
--  Author       : Tony Coombes
--
--  Description	 : Functional interface to set the users
--                 preferred unit for displaying distance
--                 measurements and to convert these
--                 distance measurements to and from
--                 meters (the units used internaly).
--
--  Modified
--    $Log: xdunits.h,v $
--    Revision 1.1  2005/09/13 15:08:28  pukitepa
--    init
--
--    Revision 1.3  1998/04/16 16:54:23  simon
--    Added code so you can get the name of the current units, and used it in
--    the distance dialog
--
--    Revision 1.2  1998/03/18 10:55:26  wman
--    Bug fix #4593.
--    Fixes to get unis working on NT platform.
--
--    Revision 1.1  1998/03/13 14:29:08  tony
--    Support to allow users to configure the units
--    used to display distance measurements
--
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __XDUNITS_H__
#define __XDUNITS_H__

#include <dsys/divtypes.h>
#include <dvise/ectypes.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef XDV_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `XDV_EXPORT'
 */
#ifdef  _LIB_XDV
#define XDV_EXPORT __declspec(dllexport) extern
#else
#define XDV_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define XDV_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ifndef XDV_EXPORT */

XDV_EXPORT void    XdUnits_SetDistanceUnits(dmDistanceUnit units);
XDV_EXPORT dmDistanceUnit XdUnits_GetDistanceUnits(void);
XDV_EXPORT float32 XdUnits_ConvertFromMeters(float32 distance);
XDV_EXPORT float32 XdUnits_ConvertToMeters(float32 distance);
XDV_EXPORT char *XdUnits_ConvertFromMetresAndCreateString(float32 distance);

#ifdef __cplusplus
}
#endif

#endif /* __XDUNITS_H__ */

