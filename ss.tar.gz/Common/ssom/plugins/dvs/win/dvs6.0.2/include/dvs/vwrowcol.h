/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: vwrowcol.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:08:14 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: vwrowcol.h,v 1.1 2005/09/13 15:08:14 pukitepa Exp $
 *
 *    FUNCTION: Frame public function prototypes.
 * 
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _VWRowCol_H
#define _VWRowCol_H
#ifdef __cplusplus
extern "C" {
#endif
#ifdef _dummyBrace_
}
#endif
/* INCLUDES ============================================== */
#include "vwidgets.h"
#include "vwborder.h"
/* PUBLIC FUNCTIONS ====================================== */

#define VWROWCOL_TITLE

typedef enum _VWRowColPositionPolicy {
    VWcROWCOL_COLUMN_DOMINANT = 1, 
              VWcROWCOL_ROW_DOMINANT
          }VWRowColPositionPolicy;

typedef VWRowColPositionPolicy VWtRowColPositionPolicy;

typedef enum _VWRowColPackingPolicy {
    VWcROWCOL_PACK_CENTERED = 1, 
              VWcROWCOL_PACK_TIGHT
          } VWRowColPackingPolicy;
typedef VWRowColPackingPolicy VWtRowColPackingPolicy;

enum {
    VWrNumColumns = VW_RESOURCES_ROWCOL, 
    VWrNumRows, 
    VWrRowSpacing, 
    VWrRowSpacingRatio, 
    VWrColumnSpacing, 
    VWrColumnSpacingRatio, 
    VWrRowMargin, 
    VWrColumnMargin,
    VWrUseRowMarginRatio,
    VWrUseColumnMarginRatio,
    VWrPackingPolicy, 
    VWrPositionPolicy, 
#ifdef VWROWCOL_TITLE
    VWrTitleBaseVisual, 
    VWrTitleBaseMaterial, 
    VWrTitleIconVisual, 
    VWrTitleIconMaterial, 
#endif /* VWROWCOL_TITLE */
    VWrRadioBehaviour, 
    VWrRadioBehavior,
    VWrRadioItemVisual,		    /* specifies the visual name of the item labels */
    VWrRadioItemHighlightVisual,
    VWrRadioItemMaterial,		    /* specifies the materials to be used for the above */
    VWrRadioItemHighlightMaterial,
    VWrRadioItemActiveMaterial, 
    VWrRadioItemActiveHighlightMaterial, 
    VWrRadioActivateCallback
};



VW_EXPORT VWidget *VWRowCol_CreateManaged(VWidget *Parent, char *name, VWArg args[], int argc);
VW_EXPORT VWidget *VWRowCol_Create(VWidget *Parent, char *name, VWArg args[], int argc);

VW_EXPORT void VWRowCol_SetRadioBehaviour(VWidget *RowColWig, int set);
VW_EXPORT VWidget *VWRowCol_GetActiveRadioItem(VWidget *RowColWig);
VW_EXPORT void VWRowCol_SetActiveRadioItem(VWidget *RowColWig, VWidget *ButtonWig, VWEventInfo *info, int trigger);
VW_EXPORT void VWRowCol_HighlightRadioItem(VWidget *RowColWig, VWidget *ButtonWig);
VW_EXPORT VWidget *VWRowCol_AddRadioItem(
                                      VWidget *RowColWig,  
                                      char *IconName, float32 *ItemIconSize, char *ItemIconMat, 
                                      VWCallback *Activate_cb, void *Activate_cd);

/*
 * Setting the Rows or columns explicitly will force the RowColumn
 * widget to fit its children into that many rows or columns.
 */
VW_EXPORT void VWRowCol_SetColumns(VWidget* RowColWig, int columns);
VW_EXPORT void VWRowCol_SetRows(VWidget* RowColWig, int rows);
/*
 * The packing policy determines the patterns of how its children are set out
 * in the rowcol widget.
 */
VW_EXPORT void VWRowCol_SetPackingPolicy(VWidget *RowColWig, VWRowColPackingPolicy packPolicy);
VW_EXPORT VWRowColPackingPolicy VWRowCol_GetPackingPolicy(VWidget *RowColWig);

/*
 * The position policy determines where the ordered sequence of its children will 
 * appear in the rowcol widget according to the sequence that they were added.
 * I.e. they are set out from top-to-bottom-left-to-right == VWcROWCOL_COLUMN_DOMINANT 
 * or vice versa.
 */
VW_EXPORT void VWRowCol_SetPositionPolicy(VWidget *RowColWig, VWRowColPositionPolicy positionPolicy);
VW_EXPORT VWRowColPositionPolicy VWRowCol_GetPositionPolicy(VWidget *RowColWig);
VW_EXPORT void VWRowCol_UseDefaultPositionPolicy(VWidget *RowColWig);
#ifdef _dummyBrace_
{
#endif
#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /*_VWRowCol_H */
