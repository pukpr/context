/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1993 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: xdutils.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 12 January 1995
--  Author       : Tony Coombes
--
--  Description	 : General utilities
--
--  Modified
--    By         : $Author: pukitepa $
--    Date       : $Date: 2005/09/13 15:08:28 $
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __XDUTILS_H__
#define __XDUTILS_H__

#include "wkeys.h"   /* For #define XDD...  and   compT */
#include "xdviewd.h" /* For view widget */

#ifdef __cplusplus
extern "C" {
#endif

#ifndef XDV_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `XDV_EXPORT'
 */
#ifdef  _LIB_XDV
#define XDV_EXPORT __declspec(dllexport) extern
#else
#define XDV_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define XDV_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ifndef XDV_EXPORT */

#ifndef _WIN32
#define _MAX_PATH 1000
#endif

#define XDVISE_REGISTRY_FILE ".dvise.reg"
#define XDVISE_GENERALPREF "generalPref"
#define XDVISE_VIEWPREF "viewPref"
#define XDVISE_SECTIONPREF "sectionPref"

XDV_EXPORT int XdStringIsBlank(char *str);
XDV_EXPORT void XdUtils_CreateAssy(compT dlg, vieWidgT *view, viewSlctnListEnum selectionList,
                               uint32 type, int withLndmk);
/*
#ifdef EPD
*/
XDV_EXPORT void XdUtils_CreateAssyFromMgr(compT dlg, int viewNo, hrchyT *hrchy, 
                               viewSlctnListEnum selectionList,
                               uint32 type, int withLndmk);

/*
#endif 
*/

XDV_EXPORT void _XdUtils_CreateAssy(compT dlg, ECAssembly *parent, 
                               viewSlctnListEnum selectionList,
                               uint32 type, int withLndmk);

XDV_EXPORT void XdUtils_CreateAttr(compT dlg, vieWidgT *view, ECItemType attrType);
XDV_EXPORT char *XdUtils_CalcAssemblyPathToDisplay(ECAssembly *assy);
XDV_EXPORT char *XdUtils_CalcEntityPathToDisplay(void *entity);
XDV_EXPORT void *XdUtils_CreateAttribute(ECAssembly *obj, char *newName, void *entityTemplate,
                                    ECItemType attributeType);
XDV_EXPORT int  XdUtils_ValidateAttributeName(ECAssembly *obj, char *name);
XDV_EXPORT int XdUtils_SaveOption(char *regFile, char *path, char *valName, char *value);

XDV_EXPORT int XdUtils_GetPreferences(void);

#ifdef __cplusplus
}
#endif

#endif /* __XDUTILS_H__ */

