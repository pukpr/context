/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: 
 *    Revision:     $Revision: 
 *    Date:         $Date: 
 *    Author:       $Author: 
 *    RCS Ident:    $Id: 
 *
 *    FUNCTION:
 *
 * Copyright (c) 1994 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */

#ifndef _ECPIVOT_H
#define _ECPIVOT_H
#ifdef __cplusplus
extern "C" {
#endif

struct ECPivot {
    ECItemType          type;
    struct ECAssembly  *owner;
    char               *name;
    char               *pathName;
    void               *clientData;
    struct ECPivot     *definition;
    ECItem             *instanceList;
    uint32              instances;
    dmPoint             origin; /* relative to assembly */
    dmEuler             orient; /* relative to assembly */
    char               *visual;
    uint32              mode;   /* mode=0 => 'normal' operation */
    VCEntity           *vcEnt;
    VCEntity           *tmpEnt;
    ECAssembly         *tmpAssem;
    VCAttribute        *vcConstraints;
    VCAttribute        *vcVisual;
    uint32              internalMode;
};

#define ECPIVOT_MOVE       0x1
#define ECPIVOT_DISPLAY    0x2
#define ECPIVOT_DISABLE    0x4


DV_EXPORT ECPivot *ECPivot_Allocate(void);
DV_EXPORT ECPivot *ECPivot_Create(char *name, dmPoint origin, dmEuler orient);
DV_EXPORT void ECPivot_Destroy(ECPivot *pivot);
DV_EXPORT ECPivot *ECPivot_Copy(ECPivot *from);
DV_EXPORT int ECPivot_CopyDefined(ECPivot *def, ECPivot *newPvt);
DV_EXPORT int ECPivots_Differ(ECPivot *p0, ECPivot *p1);
DV_EXPORT int ECPivot_SetName(ECPivot *pivot, char *name);
DV_EXPORT int ECPivot_SetVisual(ECPivot *pivot, char *vis);
DV_EXPORT char *ECPivot_GetVisual(ECPivot *pivot);
DV_EXPORT int ECPivot_SetOrigin(ECPivot *pivot, dmPoint origin);
DV_EXPORT int ECPivot_GetOrigin(ECPivot *pivot, dmPoint origin);
DV_EXPORT int ECPivot_SetOrient(ECPivot *pivot, dmEuler orient);
DV_EXPORT int ECPivot_GetOrient(ECPivot *pivot, dmEuler orient);
DV_EXPORT int ECPivot_SetVCEntity(ECPivot *p, VCEntity *vce);
DV_EXPORT VCEntity *ECPivot_GetVCEntity(ECPivot *p);
DV_EXPORT VCAttribute *ECPivot_GetVCConstraints(ECPivot *pivot);
DV_EXPORT int ECPivot_SetVCConstraints(ECPivot *pivot, VCAttribute *constraints);
DV_EXPORT int ECPivot_SetMode(ECPivot *p, uint32 m);
DV_EXPORT uint32 ECPivot_GetMode(ECPivot *p);
DV_EXPORT int ECPivot_ApplyChanges(ECPivot *orig, ECPivot *changes);


#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /*_ECPIVOT_H */
