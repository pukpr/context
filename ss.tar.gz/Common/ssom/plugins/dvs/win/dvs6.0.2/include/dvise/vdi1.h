/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: vdi1.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:07:58 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: vdi1.h,v 1.1 2005/09/13 15:07:58 pukitepa Exp $
 *
 *    FUNCTION: defines data structures used in the EC file read/writer
 * 
 *
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */


#ifndef _VDI1_H
#define _VDI1_H

/* PUBLIC DEFINES =======================================*/

/* PUBLIC TYPES =========================================*/

/* FUNCTION DECLARATIONS ================================*/

DV_EXPORT int32 EC_GetVDIVersion(void);
DV_EXPORT void EC_SetVDIVersion(int32);
int32 _ECAction_CheckName(char *func, char *buf);
char *_ECEvent_CheckName(char *eventName);
char *_EC_CheckExpression(char *eventName);
char *_ECArgument_CheckName(char *name);


#endif /* _VDI1_H */
