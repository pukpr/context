/*
 *      PROJECT:
 *      SUBSYSTEM:
 *      MODULE:
 *
 *      FILE:           $RCSfile: pfparser.h,v $
 *      REVISION:       $Revision: 1.1 $
 *      Date:           $Date: 2005/09/13 15:07:45 $
 *      Author:         $Author: pukitepa $
 *      RCS Ident:      $Id: pfparser.h,v 1.1 2005/09/13 15:07:45 pukitepa Exp $
 *
 *      FUNCTION:
 *
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */

#ifndef __PFPARSER_H__
#define __PFPARSER_H__

#ifndef DPF_EXPORT
#if defined ( _WIN32 ) && !defined (BUILD_STATIC)
#ifdef _PF_LOCAL
#define DPF_EXPORT __declspec(dllexport) extern
#else
#define DPF_EXPORT __declspec(dllimport) extern
#endif
#else
#define DPF_EXPORT extern
#endif
#endif

#include <dsys/divtypes.h>
#ifdef _PF_LOCAL
#include "pgeneral.h"
#else
#include <dsys/pgeneral.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif
    
/* error numbers */
#define dppENO_FORM     0x020001

#define dpp_MATCH_CASE  0
#define dpp_ANY_CASE    1

/* On calls which either succeed or fail, dpgSUCCESS (0) or dpgERROR (-1)
 * is returned. On calls to get next token however the following 
 * return values are also used
 */
#define dppSUCCESS       0              /* Same as dpgSUCCESS */
#define dppERROR        -1              /* Same as dpgERROR   */
#define dppEOF          -2
#define dppSTRING       -3
#define dppNUMBER	-4

/* flags */
#define dppFLAG_COMPLEX_STR   0x01      /* use complex c style string extensions */
#define dppFLAG_JOIN_STR      0x02      /* join "a" "b" together, ie "ab"        */

/* ctable is a bit-field class identifier - where the following bits are used */
#define dppBIT_UPPER          0x01
#define dppBIT_WHITE          0x02
#define dppBIT_TOKSTRT        0x04
#define dppBIT_TOKEND         0x08

typedef struct dppKEYTAB 
{
    int32	 tok;
    char 	*name;
    int32	 matchCase;
} dppKEYTAB ;


typedef struct dppFILE 
{
    int32	 lineNo;
    int32	 errorFlag;
    char	*fileName;
    int32	 fileSize;
    FILE	*file;
    char        *ctable ;
    char         comment ;
    uint8        flags ;
    int32	 pushedBackToken;
    float32      number;
    uint32       uiNumber;
    int32	 strLen;
    char	*buffer;
    int32	 bufSize;
    int32	 bufPos;
    dppKEYTAB	*keyTab;
} dppFILE, *dppFILEPTR ;


DPF_EXPORT dppFILEPTR
dppOpenFile(char *name, FILE *fp, uint8 flags, const char *whites,
            const char *tokStrt, const char *tokEnd,
            char comment, dppKEYTAB *keyTable);
DPF_EXPORT void
dppCloseFile (dppFILEPTR fPtr);
DPF_EXPORT char *
dppTokenToString (dppFILEPTR fptr, const int32 token);
DPF_EXPORT int32 
dppPushToken (dppFILEPTR fptr, const int32 token);
DPF_EXPORT int32
dppNextToken (dppFILEPTR fptr);
DPF_EXPORT int32
dppReadToNextChar(dppFILEPTR fPtr, char endChr) ;
DPF_EXPORT int32
dppMatchString(dppFILEPTR fptr);
DPF_EXPORT int32
dppMatchInt (dppFILEPTR fptr, int32 *num);
DPF_EXPORT int32
dppMatchUint (dppFILEPTR fptr, uint32 *num);
DPF_EXPORT int32
dppMatchFloat (dppFILEPTR fptr, float32 *num);
DPF_EXPORT int32
dppMatchCharacter (dppFILEPTR fptr, char c);
DPF_EXPORT void
dppMoveToNextLine(dppFILEPTR fptr) ;

DPF_EXPORT void
dppVersion(FILE *fp) ;
#ifdef __cplusplus
}
#endif

#endif /* __PFPARSER_H__ */

