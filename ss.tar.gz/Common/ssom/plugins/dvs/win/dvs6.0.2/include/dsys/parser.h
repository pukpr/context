/*
 *      PROJECT:
 *      SUBSYSTEM:
 *      MODULE:
 *
 *      FILE:           $RCSfile: parser.h,v $
 *      REVISION:       $Revision: 1.1 $
 *      Date:           $Date: 2005/09/13 15:07:44 $
 *      Author:         $Author: pukitepa $
 *      RCS Ident:      $Id: parser.h,v 1.1 2005/09/13 15:07:44 pukitepa Exp $
 *
 *      FUNCTION:
 *
 * Copyright (c) 1994, 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _PARSER_H
#define _PARSER_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef DPARSER_EXPORT
#if defined(_WIN32) && !defined(__EPP__) && !defined(BUILD_STATIC)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `extern'
 */
#ifdef  _LIB_DIVU
#define DPARSER_EXPORT __declspec(dllexport) extern 
#else
#define DPARSER_EXPORT __declspec(dllimport) extern 
#endif /* IN_A_DIVISION_LIB */
#else
#define DPARSER_EXPORT  extern
#endif /* ! _WIN32 */
/* #define DPARSER_EXPORT  extern */
#endif /* ndef DPARSER_EXPORT */

#define PARSER_MAX_TOKEN_SIZE 2048
#define PARSER_MATCH_CASE     0
#define PARSER_ANY_CASE       1

/*
 * macros for testing char classes
 */
#define PARSER_LEX_START      1
#define PARSER_LEX_CONTINUE   2
#define parserStartChar(f,x)    ((f)->LexClass[(x)] & PARSER_LEX_START )
#define parserContinueChar(f,x) ((f)->LexClass[(x)] & PARSER_LEX_CONTINUE )

/*
 * tokens returned by parser functions
 */
#define PARSER_OK	      0
#define PARSER_ERR	     -1
#define PARSER_EOF           -2
#define PARSER_STRING        -3
#define PARSER_INT	     -4
#define PARSER_FLOAT	     -5
#define PARSER_PUSH          -6
#define PARSER_POP	     -7
#define PARSER_QUOTED_STRING -8

/*
 * used to hold pre-processing state info.
 * Contents are not made public.
 */
typedef struct pprocState pprocState;

typedef struct dParseKeyTab 
{
    int		 tok;
    char 	*name;
    int		 matchCase;
} dParseKeyTab;


typedef struct dParseFile 
{
    int			 errorFlag;
    int                  seeIncludes;
    int			 pushedBackToken;
    float                fpNumber;
    long                 iNumber;
    char		*buffer;
    char		*lbuffer;
    int			 bufSize;
    int			 bufPos;
    dParseKeyTab	*parserKeyTab;
    int			 charNo;
    pprocState          *ppstate;
    char                 LexClass[128];
} dParseFile, *dParseFilePtr;

DPARSER_EXPORT void                  parserVersion(FILE *openfp);
DPARSER_EXPORT dParseFilePtr         parserCreate(char *name,
                                          FILE *openfp,
                                          dParseKeyTab *keyTable,
                                          int bufferSize,
                                          FILE *(*fileFinder)(const char *),
                                          const char *startChars,
                                          const char *continueChars,
                                          int seeIncludes);
DPARSER_EXPORT dParseKeyTab 		*parserFixUpKeyTable(dParseKeyTab *keyTable);
DPARSER_EXPORT dParseKeyTab 		*parserGetKeyTab(dParseFilePtr fptr);
DPARSER_EXPORT int			 parserSetInitedKeyTable(dParseFilePtr fptr, dParseKeyTab *keyTab);
DPARSER_EXPORT int			 parserSetKeyTable(dParseFilePtr fptr, dParseKeyTab *keyTab);
DPARSER_EXPORT void                 parserDestroy(dParseFilePtr fptr);

DPARSER_EXPORT dParseFilePtr       parserOpenFile(char *name,
                                          FILE *fp,
                                          dParseKeyTab *keyTable,
                                          int bufferSize,
                                          FILE *(*fileFinder)(const char *),
                                          const char *startChars,
                                          const char *continueChars,
                                          int seeIncludes);
DPARSER_EXPORT void	          parserCloseFile(dParseFilePtr fPtr);

DPARSER_EXPORT int                     parserGetc(dParseFilePtr fptr);
DPARSER_EXPORT int                  parserUngetc(dParseFilePtr fptr, char c);

DPARSER_EXPORT char	     *parserTokenToString(dParseFilePtr fptr, const int token);
DPARSER_EXPORT int	          parserPushToken(dParseFilePtr fptr, const int token);
DPARSER_EXPORT int	          parserNextToken(dParseFilePtr fptr);

DPARSER_EXPORT char	       *parserMatchString(dParseFilePtr fptr);
DPARSER_EXPORT int	           parserMatchInt(dParseFilePtr fptr, int *num);
DPARSER_EXPORT int	         parserMatchFloat(dParseFilePtr fptr, float *num);
DPARSER_EXPORT int	     parserMatchCharacter(dParseFilePtr fptr, char c);

DPARSER_EXPORT const char      *parserCurrentFile(dParseFilePtr fptr);
DPARSER_EXPORT int              parserCurrentLine(dParseFilePtr fptr);

#ifdef __cplusplus
}
#endif

#endif
