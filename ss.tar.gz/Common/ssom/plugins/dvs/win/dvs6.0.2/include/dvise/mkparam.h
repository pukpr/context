/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1998 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVISE
--  Module       : View and Markup
--  Object Name  : $RCSfile: mkparam.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : $Date: 2005/09/13 15:07:54 $
--  Author       : $Author: pukitepa $
--
--  Description	
--	Parameter support for the markup plugins
--
--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __MARKUPPARM_H__
#define __MARKUPPARM_H__

/*
 * ============================================================
 *
 * PARAMETER TYPES
 *
 * ============================================================
 */

    /*
     * The types of parameters supported
     */

typedef enum 
{
    MARKPLG_PARAM_STRING,
    MARKPLG_PARAM_FLOAT,
    MARKPLG_PARAM_INT
} MarkupPlugParamType;

    /*
     * Representation of a parameter
     */

typedef struct MarkupPlugParam
{
    char *name;
    MarkupPlugParamType type;
    union
    {
        char *string;
        float32 real;
        int32 integer;
    } value;
} MarkupPlugParam;

    /*
     * Structure defining a parameter's name and type
     */

typedef struct MarkupPlugParamsDef
{
    char *name;
    MarkupPlugParamType type;
    char *string;
    float32 real;
    int32 integer;
} MarkupPlugParamsDef;


 /*
  * Structure representing a set of parameters
  */

typedef struct MarkupPlugParams MarkupPlugParams;

/*
 * ============================================================
 *
 * INTERFACE FUNCTIONS
 *
 * ============================================================
 */

    /* -- create a set of parameters */

DV_EXPORT MarkupPlugParams *MarkupPlugParams_Create(void);

    /* -- destroy a set of parameters */

DV_EXPORT void MarkupPlugParams_Destroy(MarkupPlugParams *params);

    /* -- define the parameter names for a parameter set */

DV_EXPORT void MarkupPlugParams_Define(MarkupPlugParams *params, MarkupPlugParamsDef *definitions);

    /* -- set the value of a parameter */

DV_EXPORT int MarkupPlugParams_Set(MarkupPlugParams *params, MarkupPlugParam *param);

    /* -- retrieve a parameter */

DV_EXPORT MarkupPlugParam *MarkupPlugParams_Get(MarkupPlugParams *params, char *parameter);

    /* -- determine if a parameter exists and its type */

DV_EXPORT int MarkupPlugParams_Exists(MarkupPlugParams *params, char *parameter,
                                      MarkupPlugParamType *type);


#endif /* __MARKUPPARM_H__ */
