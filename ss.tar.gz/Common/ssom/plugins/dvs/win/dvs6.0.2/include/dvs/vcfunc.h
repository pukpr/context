#ifndef _VCFUNC_H_
#define _VCFUNC_H_


VC_EXPORT void 		 vcVersion 		(FILE *fp);
VC_EXPORT int	 	 VC_InitActor		(int *argc, char **argv, char *actorName,
                                         VCActorConfig *actorConfig, uint32 mode,
                                         VC_VersionFunc versionFunc);
VC_EXPORT int     	 VC_InitApplication	(int *argc, char **argv, VC_VersionFunc versionFunc);
VC_EXPORT int	    	 VC_ErrorInit		(char *agentName, char *actorName, int verboseLevel, int debugLevel,
                                         int log, char *log_ext);
VC_EXPORT void		 VC_MainLoop		(void);
VC_EXPORT void    	 VC_ProcessEvent 	(VLAction action, VLEventData *eventData);
VC_EXPORT int 		 VC_HandleSignals(int handle);


VC_EXPORT void   *VC_GetCallbackHandle(void);

VC_EXPORT void   *VCSignal_AttachCallback    (int sigNum, VC_SignalFunc callback, void *data);
VC_EXPORT void   *VC_AttachExitCallback(VC_ExitFunc function, void *data);
VC_EXPORT void   *VCTimer_AttachPeriodicCallback (float t, VCTimer_Func function, void *data);
VC_EXPORT void   *VCTimer_AttachExpiringCallback (float t, VCTimer_Func function, void *data)           ;
VC_EXPORT int     VCTimer_DetachCallback(void *callbackHandle);

VC_EXPORT void   *VCTimer_AttachCallback     (VLTime *time, VLTimerMode mode,
                                    VCTimer_Func function, void *data);
VC_EXPORT void   *VCStream_AttachCallback    (int streamId, VC_StreamFunc function, void *data);
VC_EXPORT void   *VC_AttachFileCallback    (dpHandle fd, VC_FileFunc function, void *data);
VC_EXPORT int     VC_DetachFileCallback (dpHandle fd, void *callbackHandle);
VC_EXPORT int     VC_AttachFile(dpHandle fd, int mode);
VC_EXPORT int     VC_DetachFile(dpHandle fd, int mode);
VC_EXPORT void   *_VC_AttachCreateCallback    (ElementHandle elem, InstanceNo inst, VC_CallbackFunc callback, void *data);
VC_EXPORT void   *_VC_AttachDeleteCallback    (ElementHandle elem, InstanceNo inst, VC_CallbackFunc callback, void *data);
VC_EXPORT void   *_VC_AttachUpdateCallback    (ElementHandle elem, InstanceNo inst, VC_CallbackFunc callback, void *data);
VC_EXPORT int     VCSignal_DetachCallback (int sigNum, void *callbackHandle);
VC_EXPORT int	VC_DetachExitCallback(void *callbackHandle);
VC_EXPORT int	VCStream_DetachCallback (int streamId, void *callbackHandle);
VC_EXPORT int     _VC_DetachCreateCallback (void *callbackHandle, ElementHandle Element, InstanceNo inst);
VC_EXPORT int     _VC_DetachUpdateCallback (void *callbackHandle, ElementHandle element, InstanceNo instNo);
VC_EXPORT int	_VC_DetachDeleteCallback (void *callbackHandle, ElementHandle element, InstanceNo inst);

/*
 * Miscellaneous routines
 */
VC_EXPORT int 		VCPosition_MakePointEulerScale (VCPositionData *pos, dmPoint p, dmEuler e, dmScale s);
VC_EXPORT int		VCPosition_ChangePointEulerScale (VCPositionData *pos, dmPoint p, dmEuler e, dmScale s);
VC_EXPORT uint32		VC_GetNewVcId(void);
VC_EXPORT void		vcInitEnvironment(void);


/*
 * Name table stuff
 */
VC_EXPORT duHashTab	*VCInstanceTable_Create(int numEntries);
VC_EXPORT void           VCInstanceTable_Delete(duHashTab *table);
VC_EXPORT void          *VCInstanceTable_Get(duHashTab *table, InstanceNo inst,
                                            int *status);
VC_EXPORT int            VCInstanceTable_Attach(duHashTab *table, InstanceNo inst, void
                                      *data, int flags);
VC_EXPORT void          *VCInstanceTable_Detach(duHashTab *table, InstanceNo inst,
                                      int *status);


VC_EXPORT int		VCActor_InitResource (char *nameExtension, char *type, uint32 mode,
                                      VCResource_AllocateFunc allocateFunc,
                                      VCAttribute_InvalidFunc deAllocateFunc,
                                      VCAttribute_RelocateFunc relocateFunc,
                                      VCAttribute_Func updateFunc, void *data);


/*
 * Body handling functions
 */

VC_EXPORT int VCBody_Link (VCBody *body, VCEntity *entity, uint32 linkMode);
VC_EXPORT int VCBody_Unlink(VCBody *body, uint32 unlinkMode);
VC_EXPORT VCAttribute *VCBody_GetBodyPart (VCBody *body, char *limbName);
VC_EXPORT int	VCBody_Set	(VCBody *body, VCBodyFlyInfoData *flyForward, VCBodyFlyInfoData *flyBackward,
                                 VCBodyFlyInfoData *flyUp, VCBodyFlyInfoData *flyDown, VCBodyFlyInfoData *flyLeft,
                                 VCBodyFlyInfoData *flyRight, VCBodyFlyInfoData *rotLeft, VCBodyFlyInfoData *rotRight,
                                 VCBodyFlyInfoData *rotUp, VCBodyFlyInfoData *rotDown, uint32 *verticalFlyKeyCode,
                                 uint32 *altFlyKeyCode, VCEntity *flyDirectionLimb, VCEntity *altFlyDirectionLimb,
                                 VCEntity *altFlyLimb, uint32 setFlyMode, uint32 clearFlyMode, char *message, dmPoint orbitPoint,
                                 dmDistanceUnit *units, int32 *interruptRate, char *syncName,
                                 char *syncActor, uint32 displayNavigato);
VC_EXPORT int	VCBody_Get	(VCBody *body, uint32 *actorId, VCBodyFlyInfoData *flyForward, VCBodyFlyInfoData *flyBackward,
                                 VCBodyFlyInfoData *flyUp, VCBodyFlyInfoData *flyDown, VCBodyFlyInfoData *flyLeft,
                                 VCBodyFlyInfoData *flyRight, VCBodyFlyInfoData *rotLeft, VCBodyFlyInfoData *rotRight,
                                 VCBodyFlyInfoData *rotUp, VCBodyFlyInfoData *rotDown, uint32 *verticalFlyKeyCode,
                                 uint32 *altFlyKeyCode, VCEntity **flyDirectionLimb, VCEntity **altFlyDirectionLimb,
                                 VCEntity **altFlyLimb, uint32 *flyMode, char **name,
                                 char **user, char **role, char **display, char **message,
                                 float32 *rotateDistance, dmDistanceUnit *units,
                                 int32 *interruptRate, char **syncName,  char **syncActor, uint32 *displayNavigator);
VC_EXPORT int	VCBody_SetData	(VCBody *body, VCBodyData *bodyData);
VC_EXPORT int	VCBody_GetData	(VCBody *body, VCBodyData *bodyData);



VC_EXPORT int	VCBody_GetAbsolutePosition(VCBody *body, dmMatrix mat);
VC_EXPORT int VCBody_SetPosition(VCBody *body, VCAttribute *bodyPart, dmPoint point, dmEuler rotation, dmScale scale,
                       VCEntity *entity, uint32 flags);

VC_EXPORT int VCBody_SetSlowSpeed(VCBody *body, float minSpeed);
VC_EXPORT int VCBody_SetMaxSpeed(VCBody *body, float maxSpeed);
VC_EXPORT int VCBody_SetFastSpeed(VCBody *body, float fastSpeed);
VC_EXPORT int VCBody_SetAcceleration(VCBody *body, float acceleration);
VC_EXPORT int VCBody_SetSlowRotation(VCBody *body, float minRot);
VC_EXPORT int VCBody_SetFastRotation(VCBody *body, float fastRot);
VC_EXPORT int VCBody_SetMaxRotation(VCBody *body, float maxRot);
VC_EXPORT int VCBody_SetRotateAcceleration(VCBody *body, float acceleration);
VC_EXPORT int	VCBody_SetFlyForwardInfo(VCBody *body, VCBodyFlyInfoData *flyData);
VC_EXPORT int	VCBody_SetFlyBackwardInfo(VCBody *body, VCBodyFlyInfoData *flyData);
VC_EXPORT int	VCBody_SetFlyLeftInfo(VCBody *body, VCBodyFlyInfoData *flyData);
VC_EXPORT int	VCBody_SetFlyRightInfo(VCBody *body, VCBodyFlyInfoData *flyData);
VC_EXPORT int	VCBody_SetFlyUpInfo(VCBody *body, VCBodyFlyInfoData *flyData);
VC_EXPORT int	VCBody_SetFlyDownInfo(VCBody *body, VCBodyFlyInfoData *flyData);
VC_EXPORT int	VCBody_SetRotLeftInfo(VCBody *body, VCBodyFlyInfoData *flyData);
VC_EXPORT int	VCBody_SetRotRightInfo(VCBody *body, VCBodyFlyInfoData *flyData);
VC_EXPORT int	VCBody_SetRotUpInfo(VCBody *body, VCBodyFlyInfoData *flyData);
VC_EXPORT int	VCBody_SetRotDownInfo(VCBody *body, VCBodyFlyInfoData *flyData);
VC_EXPORT int	VCBody_SetVerticalFlyKeyCode(VCBody *body, uint32 keyCode);
VC_EXPORT int	VCBody_SetAltFlyKeyCode(VCBody *body, uint32 keyCode);
VC_EXPORT int	VCBody_SetFlyDirectionLimb(VCBody *body, VCEntity *flyLimb);
VC_EXPORT int	VCBody_SetAltFlyDirectionLimb(VCBody *body, VCEntity *flyLimb);
VC_EXPORT int	VCBody_SetAltFlyLimb(VCBody *body, VCEntity *flyLimb);
VC_EXPORT int	VCBody_SetFlyMode(VCBody *body, uint32 flyMode);
VC_EXPORT int   VCBody_SetMessage(VCBody *body, char *message);
VC_EXPORT int	VCBody_SetOrbitPoint(VCBody *body, dmPoint orbitPoint);
VC_EXPORT int	VCBody_SetDistanceUnit(VCBody *body, dmDistanceUnit units);
VC_EXPORT int	VCBody_SetInterruptRate(VCBody *body, int32 interruptRate);
VC_EXPORT int	VCBody_DisplayNavigator(VCBody *body);

VC_EXPORT int	VCBody_ModifyFlyMode(VCBody *body, uint32 setFlyMode, uint32 clearFlyMode);
VC_EXPORT int	VCBody_Exit(VCBody *body);
VC_EXPORT int	VCBody_GetActorId(VCBody *body, uint32 *actorId);
VC_EXPORT int	VCBody_GetFlyForwardInfo(VCBody *body, VCBodyFlyInfoData *flyData);
VC_EXPORT int	VCBody_GetFlyBackwardInfo(VCBody *body, VCBodyFlyInfoData *flyData);
VC_EXPORT int	VCBody_GetFlyLeftInfo(VCBody *body, VCBodyFlyInfoData *flyData);
VC_EXPORT int	VCBody_GetFlyRightInfo(VCBody *body, VCBodyFlyInfoData *flyData);
VC_EXPORT int	VCBody_GetFlyUpInfo(VCBody *body, VCBodyFlyInfoData *flyData);
VC_EXPORT int	VCBody_GetFlyDownInfo(VCBody *body, VCBodyFlyInfoData *flyData);
VC_EXPORT int	VCBody_GetRotLeftInfo(VCBody *body, VCBodyFlyInfoData *flyData);
VC_EXPORT int	VCBody_GetRotRightInfo(VCBody *body, VCBodyFlyInfoData *flyData);
VC_EXPORT int	VCBody_GetRotUpInfo(VCBody *body, VCBodyFlyInfoData *flyData);
VC_EXPORT int	VCBody_GetRotDownInfo(VCBody *body, VCBodyFlyInfoData *flyData);
VC_EXPORT int	VCBody_GetVerticalFlyKeyCode(VCBody *body, uint32 *keyCode);
VC_EXPORT int	VCBody_GetAltFlyKeyCode(VCBody *body, uint32 *keyCode);
VC_EXPORT int	VCBody_GetFlyDirectionLimb(VCBody *body, VCEntity **flyLimb);
VC_EXPORT int	VCBody_GetAltFlyDirectionLimb(VCBody *body, VCEntity **flyLimb);
VC_EXPORT int	VCBody_GetAltFlyLimb(VCBody *body, VCEntity **flyLimb);
VC_EXPORT int	VCBody_GetFlyMode(VCBody *body, uint32 *flyMode);
VC_EXPORT int	VCBody_GetName(VCBody *body, char **name);
VC_EXPORT int	VCBody_GetUser(VCBody *body, char **user);
VC_EXPORT int	VCBody_GetRole(VCBody *body, char **role);
VC_EXPORT int	VCBody_GetDisplay(VCBody *body, char **display);
VC_EXPORT int	VCBody_GetOrbitPoint(VCBody *body, dmPoint orbitPoint);
VC_EXPORT int   VCBody_GetDistanceUnit(VCBody *body, dmDistanceUnit *units);
VC_EXPORT int	VCBody_GetInterruptRate(VCBody *body, int32 *interruptRate);

VC_EXPORT int	VCBody_SetVisualResourceBackgroundColour(VCBody *body, VCColour colour);
VC_EXPORT int	VCBody_SetVisualResourceNearClip(VCBody *body, float32 nearClip);
VC_EXPORT int	VCBody_SetVisualResourceFarClip(VCBody *body, float32 farClip);
VC_EXPORT int	VCBody_SetVisualResourceFogColour(VCBody *body, VCColour colour, uint32 fogType, uint32 fogMode);
VC_EXPORT int	VCBody_SetVisualResourceNearFog(VCBody *body, float32 nearFog);
VC_EXPORT int	VCBody_SetVisualResourceFarFog(VCBody *body, float32 farFog);
VC_EXPORT int	VCBody_SetAudioResourceResourceFile(VCBody *body, char *resourceFile);
VC_EXPORT int	VCBody_SetAudioResourceVolume(VCBody *body, float32 volume);
VC_EXPORT int	VCBody_SetAudioResourceSpreadingRollOff(VCBody *body, float32 spreadingRollOff);
VC_EXPORT int	VCBody_SetAudioResourceAtmosphericAbsorption(VCBody *body, float32 atmosphericAbsorption);


VC_EXPORT void 		*VCBody_AttachAttributeCallback (VCBody *body, char *limbName,
                                                 ElementHandle element, VCBody_AttributeFunc func,
                                                 void *data);
VC_EXPORT int  		 VC_UseBody(char *name);
VC_EXPORT void	      	*VC_AttachBodyCreateCallback(VCBody_CreateFunc func , void *data);
VC_EXPORT void	      	*VC_AttachBodyDeleteCallback(VCBody *body, VCBody_DeleteFunc func , void *data);
VC_EXPORT int		 VC_DetachBodyCreateCallback(void *callbackHandle);
VC_EXPORT int		 VC_DetachBodyDeleteCallback(VCBody *body, void *callbackHandle);

VC_EXPORT void  	*VCBody_AttachInputCallback (VCBody *body, char *limbName, uint32 keyCode, uint32 maxKeyCode,
                                                     VCBody_InputFunc func, void *data);
VC_EXPORT void 		*VCBody_AttachCollisionCallback (VCBody *body, char *limbName, VCBody_CollisionFunc func,
                                                         void *data);
VC_EXPORT void		*VCBody_AttachBodyPartCreateCallback(VCBody *body, VCBody_CreateBodyPartFunc func,
                                                             void *data);
VC_EXPORT void		*VCBody_AttachBodyPartDeleteCallback(VCBody *body, VCBody_DeleteBodyPartFunc func,
                                                             void *data);
VC_EXPORT int		 VCBody_DetachBodyPartCreateCallback(VCBody *body, void *callbackData);
VC_EXPORT int		 VCBody_DetachBodyPartDeleteCallback(VCBody *body, void *callbackData);
VC_EXPORT int 		 VCEntity_Pick (VCEntity *entity , VCAttribute *bodyPart,
                                        VCEntity_DropFunc dropFunc, void *data);
VC_EXPORT int		 VCEntity_Drop(VCEntity *entity, VCAttribute *bodyPart);

/* Hoppy, 11/07/98 */
VC_EXPORT int 		 VCEntity_Select (VCEntity *entity , VCAttribute *bodyPart,
                                        VCEntity_DeselectFunc deselectFunc, void *data);
VC_EXPORT int		 VCEntity_Deselect(VCEntity *entity, VCAttribute *bodyPart);
VC_EXPORT int		VCEntity_DeselectIfConstrained(VCEntity *entity);

VC_EXPORT VCBody 	*VC_GetFirstBody(VC_Traverse *traverseInfo);
VC_EXPORT VCBody 	*VC_GetNextBody(VC_Traverse *traverseInfo);
VC_EXPORT VCBody 		* VCAttribute_GetBody (VCAttribute *attribute);
VC_EXPORT VCAttribute 	*VCBody_GetFirstAttribute (VCBody *body, char *limbName,  ElementHandle elem,
                                           VC_Traverse *traverseInfo);
VC_EXPORT VCAttribute 	*VCBody_GetNextAttribute (VC_Traverse *traverseInfo);


/*
 * Hierarchy function routines
 */

VC_EXPORT int			VC_SetObjectTableSize(int tabsize);
VC_EXPORT int			VCEntity_GetDefaultNumAttributes(void);
VC_EXPORT int			VCEntity_SetDefaultNumAttributes( int numAttributes);
VC_EXPORT void			VCEntityAposInvalid(VCEntity *entity);
VC_EXPORT int			VCAttribute_Get(VCAttribute *attribute, int doExtract);
VC_EXPORT VCAttribute	       *VCAttribute_Create(ElementHandle type, InstanceNo inst);
VC_EXPORT int32			VCAttribute_Delete(VCAttribute *attribute);
VC_EXPORT VCEntity	*VCEntity_Create (VCPositionData *posp, uint32 count );
VC_EXPORT int		 VCEntity_Delete  ( VCEntity *entity , uint32 mode);
VC_EXPORT int 		 VCEntity_SetRelocateMode (VCEntity *entity,int mode);
VC_EXPORT int 		 VCEntity_GetRelocateMode (VCEntity *entity);
VC_EXPORT int		 VCRelocate_ReportingLocalUpdate();
VC_EXPORT int		 VCEntity_AttachAttribute (VCEntity *entity, VCAttribute *attribute);
VC_EXPORT int		 VCEntity_DeleteAttribute(VCEntity *entity, VCAttribute *attribute);
VC_EXPORT int		 VCEntity_DetachAttribute (VCEntity *entity, VCAttribute *attribute);
VC_EXPORT int   	 VCEntity_Link (VCEntity *parent, VCEntity *child, uint32 mode);
VC_EXPORT int   	 VCEntity_Unlink ( VCEntity *child, uint32 mode);
VC_EXPORT VCEntity	*VCEntity_GetRoot ( VCEntity *entity);
VC_EXPORT VCEntity 	*VC_GetFirstEntity ( VCEntity *entity, uint32 incEntity, VC_Traverse *traverse);
VC_EXPORT VCEntity      *VC_GetNextEntity ( VC_Traverse *traverseInfo );
VC_EXPORT int     	 VCEntity_GetAbsolutePosition ( VCEntity *entity, dmMatrix mat) ;
VC_EXPORT void  	 VCEntity_TraverseInOrder(VCEntity *entity, VCEntity_TraverseFunc func, void *data);
VC_EXPORT void		 VCEntity_TraverseTestInOrder (VCEntity * vcEntity, VCEntity_TraverseTestFunc func, void *data);
VC_EXPORT void 		 VCEntity_TraversePostOrder(VCEntity *entity, VCEntity_TraverseFunc func, void *data);
VC_EXPORT void		 VCAttribute_SetCacheMode(VCAttribute *attribute, uint32 newCacheMode);
VC_EXPORT uint32	 VCAttribute_GetCacheMode(VCAttribute *attribute);
VC_EXPORT void 	        *VCAttribute_AttachCreateCallback(VCAttribute *attribute, ElementHandle element,
                                                           VCAttribute_Func func, void *data);
VC_EXPORT void	       	*VCAttribute_AttachDeleteCallback(VCAttribute *attribute, ElementHandle element,
                                                          VCAttribute_Func func, void *data);
VC_EXPORT void 		*VCAttribute_AttachDeleteCallback_mode(VCAttribute *attribute, ElementHandle element,
                                                               uint32 mode, VCAttribute_Func func, void *data);
VC_EXPORT void	       	*VCAttribute_AttachUpdateCallback(VCAttribute *attribute, ElementHandle element,
                                                          VCAttribute_Func func, void *data);
VC_EXPORT int		 VCAttribute_DetachCreateCallback(VCAttribute *attribute, ElementHandle element,
                                                          void *callbackHandle);
VC_EXPORT int		 VCAttribute_DetachUpdateCallback(VCAttribute *attribute, ElementHandle element,
                                                          void *callbackHandle);
VC_EXPORT int		 VCAttribute_DetachDeleteCallback(VCAttribute *attribute, ElementHandle element,
                                                  void *callbackHandle);
VC_EXPORT int		VCEntity_DetachAttributeRelocateCallback(ElementHandle element, VCAttribute *attribute,
                                                         void *callbackHandle);
VC_EXPORT void	       *VCEntity_AttachAttributeRelocateCallback (ElementHandle element, VCAttribute *attribute,
                                                          uint32 mode, VCAttribute_RelocateFunc func,
                                                          VCAttribute_InvalidFunc inValidFunc, void *data);
VC_EXPORT int		VCEntity_DetachAttributeCreateCallback(VCEntity *entity, void *callbackHandle);
VC_EXPORT int		VCEntity_DetachAttributeUpdateCallback(VCEntity *entity, void *callbackHandle);

VC_EXPORT void	       *VCEntity_AttachAttributeCreateCallback(VCEntity *entity, VCEntity_AttributeFunc func,
                                                       void *data);
VC_EXPORT void	       *VCEntity_AttachAttributeUpdateCallback(VCEntity *entity, VCEntity_AttributeFunc func,
                                                       void *data);

VC_EXPORT int 		VCEntity_DetachRelocateCallback(VCEntity *entity,void *callbackHandle);
VC_EXPORT void 	       *VCEntity_AttachRelocateCallback(VCEntity *entity, uint32 mode, VCEntity_RelocateFunc func,
                                                        VCEntity_InvalidFunc invalidFunc, void *data);

VC_EXPORT void 		*VCEntity_AttachDeleteCallback(VCEntity *entity, uint32 mode, VCEntity_DeleteFunc func,
                                                       void *data);

VC_EXPORT VCEntity	*VCAttribute_GetFirstEntity(VCAttribute *attribute, VC_Traverse *traverse);
VC_EXPORT VCEntity      	*VCAttribute_GetNextEntity(VC_Traverse *traverse);

VC_EXPORT int		 _VCList_AttachUserData(VCUserDataList **list, uint32 vcId, void *data);
VC_EXPORT void 		*_VCList_GetUserData(VCUserDataList *list, uint32 vcId);
VC_EXPORT void 		*_VCList_DetachUserData(VCUserDataList **list, uint32 vcId);

VC_EXPORT int		 VCEntity_SetAbsolutePosition(VCEntity *entity, VCPositionData *pos);
VC_EXPORT int      	 VCEntity_SetPosition(VCEntity *entity, VCPositionData *pos);
VC_EXPORT int 		 VCEntity_SetPositionMatrix(VCEntity *entity, dmMatrix mat);
VC_EXPORT int   		 VCEntity_SetPositionPoint(VCEntity *entity, dmPoint p);
VC_EXPORT int		 VCEntity_SetPositionEuler(VCEntity *entity, dmEuler e);
VC_EXPORT int		 VCEntity_SetPositionScale(VCEntity *entity, dmScale s);
VC_EXPORT int		 VCEntity_SetPositionEulerScale(VCEntity *entity, dmEuler e, dmScale s);
VC_EXPORT int		 VCEntity_SetPositionPointEulerScale(VCEntity *entity, dmPoint p, dmEuler e, dmScale s);
VC_EXPORT int		 VCEntity_GetPosition(VCEntity *entity, VCPosition **position);
VC_EXPORT VCPositionData	*VCEntity_GetPositionData(VCEntity *);
VC_EXPORT int 		 VCEntity_GetPositionPointEulerScale(VCEntity *entity, dmPoint p,
                                                           dmEuler e, dmScale s);
VC_EXPORT int		 VCEntity_SetPositionLinearVelocity(VCEntity *entity, const dmVector velocity);
VC_EXPORT int		 VCEntity_SetPositionLinearAcceleration(VCEntity *entity, const dmVector acceleration);
VC_EXPORT int		 VCEntity_SetPositionAngularVelocity(VCEntity *entity, const dmVector velocity);
VC_EXPORT int		 VCEntity_SetPositionAngularAcceleration(VCEntity *entity, const dmVector acceleration);
VC_EXPORT VCAttribute 	*VCEntity_GetFirstAttribute (VCEntity *entity, ElementHandle elem,
                                             VC_Traverse *traverseInfo);
VC_EXPORT VCAttribute 	*VCEntity_GetNextAttribute (VC_Traverse *traverseInfo);
VC_EXPORT VCEntity 	*VCEntity_GetParent(VCEntity *entity);
VC_EXPORT VCEntity 	*VCEntity_GetChild(VCEntity *entity);
VC_EXPORT VCEntity 	*VCEntity_GetSibling(VCEntity *entity);

VC_EXPORT int		 VCEntity_UpdatePosition(VCEntity *entity);

VC_EXPORT void 		*VCCollision_AttachCreateCallback(VCCollision *collision, VCCollision_Func func, void *data);
VC_EXPORT void 		*VCCollision_AttachUpdateCallback(VCCollision *collision, VCCollision_Func func, void *data);
VC_EXPORT void 		*VCCollision_AttachDeleteCallback(VCCollision *collision, VCCollision_Func func, void *data);
VC_EXPORT int		 VCCollision_DetachCreateCallback(VCCollision *collision, void *callbackHandle);
VC_EXPORT int		 VCCollision_DetachUpdateCallback(VCCollision *collision, void *callbackHandle);
VC_EXPORT int		 VCCollision_DetachDeleteCallback(VCCollision *collision, void *callbackHandle);
VC_EXPORT void		 VCCollision_SetCacheMode(VCCollision *collision, uint32 cacheMode);
VC_EXPORT uint32		 VCCollision_GetCacheMode(VCCollision *collision);

VC_EXPORT VCCollision	*VCCollision_Create(VCAttribute *attribute, VCCollisionReportData *collReportData,
                                    int numCollisionsReported, int numCollisions);
VC_EXPORT int		 VCCollision_Get(VCCollision *collision, VCAttribute **attribute, VCCollisionReportData **collReportData,
                                 int *numCollisionsReported, int *numCollisions);
VC_EXPORT VCCollision	*VCCollision_Set(VCAttribute *attribute, VCCollisionReportData *collReportData,
                                    int numCollisionsReported, int *numCollisions);
VC_EXPORT VCCollisionReportData	*VCCollision_GetFirstCollisionReport(VCCollision *collision, VC_Traverse *traverseInfo);
VC_EXPORT VCCollisionReportData	*VCCollision_GetNextCollisionReport(VC_Traverse *traverseInfo);
VC_EXPORT int		 VCCollision_Delete(VCCollision *item);

VC_EXPORT void		 VCIntersection_SetCacheMode(VCIntersection *intersection, uint32 cacheMode);
VC_EXPORT uint32		 VCIntersection_GetCacheMode(VCIntersection *intersection);
VC_EXPORT void 		*VCIntersection_AttachCreateCallback(VCIntersection *intersection, VCIntersection_Func func,
                                                     void *data);
VC_EXPORT void 		*VCIntersection_AttachUpdateCallback(VCIntersection *intersection, VCIntersection_Func func,
                                                      void *data);
VC_EXPORT void 		*VCIntersection_AttachDeleteCallback(VCIntersection *intersection, VCIntersection_Func func,
                                                     void *data);
VC_EXPORT int		 VCIntersection_DetachCreateCallback(VCIntersection *intersection, void *callbackHandle);
VC_EXPORT int		 VCIntersection_DetachUpdateCallback(VCIntersection *intersection, void *callbackHandle);
VC_EXPORT int		 VCIntersection_DetachDeleteCallback(VCIntersection *intersection, void *callbackHandle);
VC_EXPORT VCIntersection 	*VCIntersection_Create(VCAttribute *attribute, VCIntersectionReportData *intersectReportData,
                                       int numIntersectionsReported, int numIntersections);
VC_EXPORT int		 VCIntersection_Get(VCIntersection *intersection, VCAttribute **attribute,
                                    VCIntersectionReportData **intersectReportData,
                                    int *numIntersectionsReported, int *numIntersections);
VC_EXPORT VCIntersectionReportData *VCIntersection_GetFirstIntersectionReport(VCIntersection *intersection,
                                                                    VC_Traverse *traverse);
VC_EXPORT VCIntersectionReportData *VCIntersection_GetNextIntersectionReport(VC_Traverse *traverse);
VC_EXPORT int		 VCIntersection_Delete(VCIntersection *item);




VC_EXPORT void		 VCMaterial_SetCacheMode	(VCMaterial *item, uint32 newCacheMode);
VC_EXPORT uint32		 VCMaterial_GetCacheMode	(VCMaterial *item);
VC_EXPORT void 		*VCMaterial_AttachCreateCallback(VCMaterial *item, VCMaterial_Func func, void *data);
VC_EXPORT void 		*VCMaterial_AttachUpdateCallback(VCMaterial *item, VCMaterial_Func func, void *data);
VC_EXPORT void 		*VCMaterial_AttachDeleteCallback(VCMaterial *item, VCMaterial_Func func, void *data);
VC_EXPORT int		 VCMaterial_DetachCreateCallback(VCMaterial *item, void *callbackHandle);
VC_EXPORT int    		 VCMaterial_DetachUpdateCallback(VCMaterial *item, void *callbackHandle);
VC_EXPORT int		 VCMaterial_DetachDeleteCallback(VCMaterial *item, void *callbackHandle);
VC_EXPORT VCMaterial 	*VCMaterial_Create		(char *name, uint32 mode, VCColor ambient, VCColor diffuse,
                                                         VCSpecular specular, VCColor emissive,
                                                         VCColor opacity, char *textureName, char *ramp, char *environmentMap);
VC_EXPORT VCMaterial 	*VCMaterial_CreateData		(VCMaterialData *materialData);
VC_EXPORT int 		 VCMaterial_Get			(VCMaterial *item, char **name, uint32 *mode,
                                                 VCColor ambient, VCColor diffuse,
                                                 VCSpecular specular, VCColor emissive,
                                                 VCColor opacity, char **textureName,
                                                 char **ramp, char **environmentMap);
VC_EXPORT int	    	 VCMaterial_GetData		(VCMaterial *item, VCMaterialData *materialData);
VC_EXPORT int		 VCMaterial_SetData 		(VCMaterial *item,VCMaterialData *materialData);
VC_EXPORT int 		 VCMaterial_Set			(VCMaterial *item, char *name, uint32 setMode,
                                                         uint32 clearMode, VCColor ambient, VCColor diffuse,
                                                         VCSpecular specular, VCColor emissive, VCColor opacity,
                                                         char *textureName, char *ramp, char *environmentMap);
VC_EXPORT int		VCMaterial_ModifyMode		(VCMaterial *item, uint32 setMode, uint32 clearMode);
VC_EXPORT int		VCMaterial_SetName		(VCMaterial *item, char *name);
VC_EXPORT int		VCMaterial_SetMode		(VCMaterial *item, uint32 mode);
VC_EXPORT int		VCMaterial_SetAmbient		(VCMaterial *item, VCColour ambient);
VC_EXPORT int		VCMaterial_SetDiffuse		(VCMaterial *item, VCColour diffuse);
VC_EXPORT int		VCMaterial_SetSpecular		(VCMaterial *item, VCSpecular specular);
VC_EXPORT int		VCMaterial_SetEmissive		(VCMaterial *item, VCColour emissive);
VC_EXPORT int		VCMaterial_SetOpacity		(VCMaterial *item, VCColour opacity);
VC_EXPORT int		VCMaterial_SetTexture		(VCMaterial *item, char *texture);
VC_EXPORT int		VCMaterial_SetRamp		(VCMaterial *item, char *ramp);
VC_EXPORT int		VCMaterial_SetEnvironmentMap	(VCMaterial *item, char *ramp);


VC_EXPORT int		VCMaterial_GetName		(VCMaterial *item, char **name);
VC_EXPORT int		VCMaterial_GetMode		(VCMaterial *item, uint32 *mode);
VC_EXPORT int		VCMaterial_GetAmbient		(VCMaterial *item, VCColour ambient);
VC_EXPORT int		VCMaterial_GetDiffuse		(VCMaterial *item, VCColour diffuse);
VC_EXPORT int		VCMaterial_GetSpecular		(VCMaterial *item, VCSpecular specular);
VC_EXPORT int		VCMaterial_GetEmissive		(VCMaterial *item, VCColour emissive);
VC_EXPORT int		VCMaterial_GetOpacity		(VCMaterial *item, VCColour opacity);
VC_EXPORT int		VCMaterial_GetTexture		(VCMaterial *item, char **texture);
VC_EXPORT int		VCMaterial_GetRamp		(VCMaterial *item, char **ramp);
VC_EXPORT int		VCMaterial_GetEnvironmentMap	(VCMaterial *item, char **environmentMap);

VC_EXPORT int		VCMaterial_Delete		(VCMaterial *item);


VC_EXPORT void		 VCTexture_SetCacheMode		(VCTexture *item, uint32 newCacheMode);
VC_EXPORT uint32		 VCTexture_GetCacheMode		(VCTexture *item);
VC_EXPORT void 		*VCTexture_AttachCreateCallback	(VCTexture *item, VCTexture_Func func, void *data);
VC_EXPORT void 		*VCTexture_AttachUpdateCallback	(VCTexture *item, VCTexture_Func func, void *data);
VC_EXPORT void 		*VCTexture_AttachDeleteCallback	(VCTexture *item, VCTexture_Func func, void *data);
VC_EXPORT int		 VCTexture_DetachCreateCallback	(VCTexture *item, void *callbackHandle);
VC_EXPORT int		 VCTexture_DetachUpdateCallback	(VCTexture *item, void *callbackHandle);
VC_EXPORT int		 VCTexture_DetachDeleteCallback	(VCTexture *item, void *callbackHandle);
VC_EXPORT VCTexture 	*VCTexture_Create		(char *name, uint32 mode, uint8 minify, uint8 magnify,
                                                         uint8 alpha, uint8 wrapU, uint8 wrapV,
                                                         uint8 detailType, char *textureMap, char *detailMap,
                                                         VCTextureImage *image);
VC_EXPORT VCTexture 	*VCTexture_CreateData		(VCTextureData *textureData);
VC_EXPORT int		 VCTexture_Get			(VCTexture *item, char **name, uint32 *mode, uint8 *minify,
                                                         uint8 *magnify, uint8 *alpha,
                                                         uint8 *wrapU, uint8 *wrapV, uint8 *detailType,
                                                         char **textureMap, char **detailMap, VCTextureImage **image);
VC_EXPORT int		 VCTexture_GetData		(VCTexture *item, VCTextureData *textureData);
VC_EXPORT int		 VCTexture_SetData 		(VCTexture *item,VCTextureData *textureData);
VC_EXPORT int		 VCTexture_Set			(VCTexture *item, char *name, uint32 setMode,
                                                         uint32 clearMode,  uint8 *minify, uint8 *magnify,
                                                         uint8 *alpha, uint8 *wrapU, uint8 *wrapV, uint8 *detailType,
                                                         char *textureMap, char *detailMap, VCTextureImage **image);
VC_EXPORT int		VCTexture_ModifyMode		(VCTexture *item, uint32 setMode, uint32 clearMode);
VC_EXPORT int		VCTexture_SetName		(VCTexture *item, char *name);
VC_EXPORT int		VCTexture_SetMode		(VCTexture *item, uint32 mode);
VC_EXPORT int		VCTexture_SetMinify 		(VCTexture *item, uint8 minify);
VC_EXPORT int		VCTexture_SetMagnify	 	(VCTexture *item, uint8 magnify);
VC_EXPORT int		VCTexture_SetAlpha		(VCTexture *item, uint8 alpha);
VC_EXPORT int		VCTexture_SetWrapU 		(VCTexture *item, uint8 wrapU);
VC_EXPORT int		VCTexture_SetWrapV 		(VCTexture *item, uint8 wrapV);
VC_EXPORT int		VCTexture_SetDetailType 	(VCTexture *item, uint8 detailType);
VC_EXPORT int		VCTexture_SetTextureMap 	(VCTexture *item, char *textureMap);
VC_EXPORT int		VCTexture_SetDetailMap 		(VCTexture *item, char *detailMap);
VC_EXPORT int		VCTexture_SetTextureImage 	(VCTexture *item, VCTextureImage *image);
VC_EXPORT int		VCTexture_GetName		(VCTexture *item, char **name);
VC_EXPORT int		VCTexture_GetMode		(VCTexture *item, uint32 *mode);
VC_EXPORT int		VCTexture_GetMinify 		(VCTexture *item, uint8 *minify);
VC_EXPORT int		VCTexture_GetMagnify 		(VCTexture *item, uint8 *magnify);
VC_EXPORT int		VCTexture_GetAlpha		(VCTexture *item, uint8 *alpha);
VC_EXPORT int		VCTexture_GetWrapU 		(VCTexture *item, uint8 *wrapU);
VC_EXPORT int		VCTexture_GetWrapV 		(VCTexture *item, uint8 *wrapV);
VC_EXPORT int		VCTexture_GetDetailType 	(VCTexture *item, uint8 *detailType);
VC_EXPORT int		VCTexture_GetTextureMap 	(VCTexture *item, char **textureMap);
VC_EXPORT int		VCTexture_GetDetailMap 		(VCTexture *item, char **detailMap);
VC_EXPORT int		VCTexture_GetTextureImage 	(VCTexture *item, VCTextureImage **image);
VC_EXPORT int		VCTexture_Delete		(VCTexture *item);


VC_EXPORT void			 VCTextureImage_SetCacheMode(VCTextureImage *item, uint32 newCacheMode);
VC_EXPORT uint32		 VCTextureImage_GetCacheMode(VCTextureImage *item);
VC_EXPORT VCTextureImage 	*_VC_GetTextureImage (InstanceNo inst);
VC_EXPORT void 			*VCTextureImage_AttachCreateCallback(VCTextureImage *item, VCTextureImage_Func func, void *data);
VC_EXPORT void 			*VCTextureImage_AttachUpdateCallback(VCTextureImage *item, VCTextureImage_Func func, void *data);
VC_EXPORT void 			*VCTextureImage_AttachDeleteCallback(VCTextureImage *item, VCTextureImage_Func func, void *data);
VC_EXPORT int			 VCTextureImage_DetachCreateCallback(VCTextureImage *item, void *callbackHandle);
VC_EXPORT int			 VCTextureImage_DetachUpdateCallback(VCTextureImage *item, void *callbackHandle);
VC_EXPORT int			 VCTextureImage_DetachDeleteCallback(VCTextureImage *item, void *callbackHandle);
VC_EXPORT VCTextureImage 	*VCTextureImage_Create(uint32 mode, uint16 width, uint16 height, uint8 numComponents, uint8 *image);
VC_EXPORT VCTextureImage 	*VCTextureImage_CreateData(VCTextureImageData *imageData);
VC_EXPORT int			 VCTextureImage_Get(VCTextureImage *item, uint32 *mode, uint16 *width, uint16 *height,
                                                    uint8 *numComponents, uint8 **image);
VC_EXPORT int			 VCTextureImage_GetData(VCTextureImage *item, VCTextureImageData *imageData);
VC_EXPORT int			 VCTextureImage_SetData (VCTextureImage *item,VCTextureImageData *imageData);
VC_EXPORT int			 VCTextureImage_Set(VCTextureImage *item, uint32 setMode, uint32 clearMode,  uint16 *width,
                                                    uint16 *height, uint8 *numComponents, uint8 *image);
VC_EXPORT int			 VCTextureImage_ModifyMode(VCTextureImage *item, uint32 setMode, uint32 clearMode);
VC_EXPORT int			 VCTextureImage_SetMode(VCTextureImage *item, uint32 mode);
VC_EXPORT int			 VCTextureImage_SetImage (VCTextureImage *item, uint8 *image);
VC_EXPORT int			 VCTextureImage_Delete(VCTextureImage *item);

VC_EXPORT void			 VCVisualScreenDump_SetCacheMode(VCVisualScreenDump *item, uint32 newCacheMode);
VC_EXPORT uint32		 VCVisualScreenDump_GetCacheMode(VCVisualScreenDump *item);
VC_EXPORT VCVisualScreenDump 	*_VC_GetVisualScreenDump (InstanceNo inst);
VC_EXPORT void 			*VCVisualScreenDump_AttachCreateCallback(VCVisualScreenDump *item,
                                                                         VCVisualScreenDump_Func func, void *data);
VC_EXPORT void 			*VCVisualScreenDump_AttachUpdateCallback(VCVisualScreenDump *item,
                                                                         VCVisualScreenDump_Func func, void *data);
VC_EXPORT void 			*VCVisualScreenDump_AttachDeleteCallback(VCVisualScreenDump *item,
                                                                         VCVisualScreenDump_Func func, void *data);
VC_EXPORT int			 VCVisualScreenDump_DetachCreateCallback(VCVisualScreenDump *item, void *callbackHandle);
VC_EXPORT int			 VCVisualScreenDump_DetachUpdateCallback(VCVisualScreenDump *item, void *callbackHandle);
VC_EXPORT int			 VCVisualScreenDump_DetachDeleteCallback(VCVisualScreenDump *item, void *callbackHandle);
VC_EXPORT VCVisualScreenDump 	*VCVisualScreenDump_Create(int doDump, VCTextureImage *image, int16 width,
                                                           int16 height, char *visualViewName, char *fileName);
VC_EXPORT VCVisualScreenDump 	*VCVisualScreenDump_CreateData(VCVisualScreenDumpData *screenDumpData);
VC_EXPORT int			 VCVisualScreenDump_Get(VCVisualScreenDump *item, uint16 *status, VCTextureImage **image,
                                                        int16 *width, int16 *height, char **visualViewName, char **fileName);
VC_EXPORT int			 VCVisualScreenDump_GetData(VCVisualScreenDump *item, VCVisualScreenDumpData *screenDumpData);
VC_EXPORT int			 VCVisualScreenDump_SetData (VCVisualScreenDump *item,VCVisualScreenDumpData *screenDumpData);
VC_EXPORT int			 VCVisualScreenDump_Set(VCVisualScreenDump *item, int doDump, uint16 *status, VCTextureImage **textureImage,
                                                        int16 *width, int16 *height, char *visualViewName, char *fileName);
VC_EXPORT int			 VCVisualScreenDump_SaveToFile(VCVisualScreenDump *item, char *fileName);
VC_EXPORT int			 VCVisualScreenDump_Save(VCVisualScreenDump *item);
VC_EXPORT int			 VCVisualScreenDump_SetFileName(VCVisualScreenDump *item, char *name);
VC_EXPORT int			 VCVisualScreenDump_SetVisualViewName(VCVisualScreenDump *item, char *name);
VC_EXPORT int			 VCVisualScreenDump_SetImageSize(VCVisualScreenDump *item, int16 width, int16 height);
VC_EXPORT int			 VCVisualScreenDump_SetTextureImage (VCVisualScreenDump *item, VCTextureImage *textureImage);
VC_EXPORT int			 VCVisualScreenDump_GetFileName(VCVisualScreenDump *item, char **name);
VC_EXPORT int			 VCVisualScreenDump_GetVisualViewName(VCVisualScreenDump *item, char **name);
VC_EXPORT int			 VCVisualScreenDump_GetSize(VCVisualScreenDump *item, int16 *width, int16 *height);
VC_EXPORT int			 VCVisualScreenDump_GetTextureImage(VCVisualScreenDump *item, VCTextureImage **image);
VC_EXPORT int			 VCVisualScreenDump_GetStatus(VCVisualScreenDump *item, uint16 *status);
VC_EXPORT int			 VCVisualScreenDump_Delete(VCVisualScreenDump *item);

VC_EXPORT void			 VCAudioRecord_SetCacheMode(VCAudioRecord *item, uint32 newCacheMode);
VC_EXPORT uint32		 VCAudioRecord_GetCacheMode(VCAudioRecord *item);
VC_EXPORT VCAudioRecord 	*_VC_GetAudioRecord (InstanceNo inst);
VC_EXPORT void 			*VCAudioRecord_AttachCreateCallback(VCAudioRecord *item, VCAudioRecord_Func func, void *data);
VC_EXPORT void 			*VCAudioRecord_AttachUpdateCallback(VCAudioRecord *item, VCAudioRecord_Func func, void *data);
VC_EXPORT void 			*VCAudioRecord_AttachDeleteCallback(VCAudioRecord *item, VCAudioRecord_Func func, void *data);
VC_EXPORT int			 VCAudioRecord_DetachCreateCallback(VCAudioRecord *item, void *callbackHandle);
VC_EXPORT int			 VCAudioRecord_DetachUpdateCallback(VCAudioRecord *item, void *callbackHandle);
VC_EXPORT int			 VCAudioRecord_DetachDeleteCallback(VCAudioRecord *item, void *callbackHandle);
VC_EXPORT VCAudioRecord 	*VCAudioRecord_Create(int doRecord, uint16 mode, char *fileName, VCAttribute *audioResource);
VC_EXPORT VCAudioRecord 	*VCAudioRecord_CreateData(VCAudioRecordData *recordData);
VC_EXPORT int			 VCAudioRecord_Get(VCAudioRecord *item, uint16 *mode, char **fileName, VCAttribute **audioResource);
VC_EXPORT int			 VCAudioRecord_GetData(VCAudioRecord *item, VCAudioRecordData *recordData);
VC_EXPORT int			 VCAudioRecord_SetData (VCAudioRecord *item,VCAudioRecordData *recordData);
VC_EXPORT int			 VCAudioRecord_Set(VCAudioRecord *item, int recordStart, int recordStop, uint16 setMode, uint16 clearMode, char *fileName, VCAttribute **audioResource);
VC_EXPORT int			 VCAudioRecord_Delete(VCAudioRecord *item);

VC_EXPORT int			 VCAudioRecord_StartRecord(VCAudioRecord *item);
VC_EXPORT int			 VCAudioRecord_StartRecordFile(VCAudioRecord *item, char *file);
VC_EXPORT int			 VCAudioRecord_StopRecord(VCAudioRecord *item );
VC_EXPORT int			 VCAudioRecord_SetMode(VCAudioRecord *item, uint16 mode);
VC_EXPORT int			 VCAudioRecord_ClearMode(VCAudioRecord *item, uint16 mode);
VC_EXPORT int			 VCAudioRecord_ModifyMode(VCAudioRecord *item, uint16 setMode, uint16 clearMode);
VC_EXPORT int			 VCAudioRecord_GetMode(VCAudioRecord *item, uint16 *mode);
VC_EXPORT int			 VCAudioRecord_GetFileName(VCAudioRecord *item, char **fileName);










VC_EXPORT void		 VCInput_SetCacheMode		(VCInput *item, uint32 newCacheMode);
VC_EXPORT uint32		 VCInput_GetCacheMode		(VCInput *item);
VC_EXPORT VCInput 	*_VC_GetInput 			(InstanceNo inst);
VC_EXPORT void 		*VCInput_AttachCreateCallback	(VCInput *item, VCInput_Func func, void *data);
VC_EXPORT void 		*VCInput_AttachUpdateCallback	(VCInput *item, uint32 minKeyCode, uint32 maxKeyCode,
                                                 VCInput_UpdateFunc func, void *data);
VC_EXPORT void 		*VCInput_AttachDeleteCallback	(VCInput *item, VCInput_Func func, void *data);
VC_EXPORT int		 VCInput_DetachCreateCallback	(VCInput *item, void *callbackHandle);

VC_EXPORT int		 VCInput_DetachUpdateCallback	(VCInput *item, void *callbackHandle);
VC_EXPORT int		 VCInput_DetachDeleteCallback	(VCInput *item, void *callbackHandle);
VC_EXPORT VCInput 	*VCInput_Create			(uint32	size);
VC_EXPORT int		 VCInput_Append(VCInput *item, uint32 keyCode, int doUpdate);
VC_EXPORT int		 VCInput_Update(VCInput *item);
VC_EXPORT int		 VCInput_Delete(VCInput *item);






VC_EXPORT void	VCTracker_SetCacheMode(VCTracker *item, uint32 newCacheMode);
VC_EXPORT uint32	VCTracker_GetCacheMode(VCTracker *item);
VC_EXPORT void *VCTracker_AttachCreateCallback(VCTracker *item, VCTracker_Func func, void *data);
VC_EXPORT void *VCTracker_AttachUpdateCallback(VCTracker *item, VCTracker_Func func, void *data);
VC_EXPORT void *VCTracker_AttachDeleteCallback(VCTracker *item, VCTracker_Func func, void *data);
VC_EXPORT int	VCTracker_DetachCreateCallback(VCTracker *item, void *callbackHandle);
VC_EXPORT int	VCTracker_DetachUpdateCallback(VCTracker *item, void *callbackHandle);
VC_EXPORT int	VCTracker_DetachDeleteCallback(VCTracker *item, void *callbackHandle);
VC_EXPORT VCTracker *VCTracker_Create(char *name, uint32 updateRate, uint32 transmissionDelay, dmPoint sourcePosition,
                            dmEuler sourceEuler, uint32 baudRate, char *deviceType);
VC_EXPORT VCTracker *VCTracker_CreateData(VCTrackerData *trackerData);
VC_EXPORT int VCTracker_Get(VCTracker *item, char **name, uint32 *updateRate, uint32 *transmissionDelay, dmPoint sourcePosition,
                  dmEuler sourceEuler, uint32 *baudRate, char **deviceType);
VC_EXPORT int	VCTracker_GetData(VCTracker *item, VCTrackerData *trackerData);
VC_EXPORT int	VCTracker_SetData (VCTracker *item,VCTrackerData *trackerData);
VC_EXPORT int	VCTracker_Set(VCTracker *item, char *name, uint32 *updateRate, uint32 *transmissionDelay, dmPoint sourcePosition,
                      dmEuler sourceEuler, uint32 *baudRate, char *deviceType);
VC_EXPORT int	VCTracker_SetName(VCTracker *item, char *name);
VC_EXPORT int	VCTracker_SetUpdateRate(VCTracker *item, uint32 updateRate);
VC_EXPORT int	VCTracker_SetTransmissionDelay(VCTracker *item, uint32 transmissionDelay);
VC_EXPORT int	VCTracker_SetSourcePosition(VCTracker *item, dmPoint sourcePosition);
VC_EXPORT int	VCTracker_SetSourceEuler(VCTracker *item, dmPoint sourceEuler);
VC_EXPORT int	VCTracker_SetBaudRate(VCTracker *item, uint32 baudRate);
VC_EXPORT int	VCTracker_SetDeviceType(VCTracker *item, char *deviceType);
VC_EXPORT int	VCTracker_GetName(VCTracker *item, char **name);
VC_EXPORT int	VCTracker_GetUpdateRate(VCTracker *item, uint32 *updateRate);
VC_EXPORT int	VCTracker_GetTransmissionDelay(VCTracker *item, uint32 *transmissionDelay);
VC_EXPORT int	VCTracker_GetSourcePosition(VCTracker *item, dmPoint sourcePosition);
VC_EXPORT int	VCTracker_GetSourceEuler(VCTracker *item, dmPoint sourceEuler);
VC_EXPORT int	VCTracker_GetBaudRate(VCTracker *item, uint32 *baudRate);
VC_EXPORT int	VCTracker_GetDeviceType(VCTracker *item, char **deviceType);
VC_EXPORT int	VCTracker_Delete(VCTracker *item);


VC_EXPORT void		VCPosition_SetCacheMode	(VCPosition *item, uint32 newCacheMode);
VC_EXPORT uint32		VCPosition_GetCacheMode(VCPosition *item);
VC_EXPORT void 		*VCPosition_AttachCreateCallback(VCPosition *item, VCPosition_Func func, void *data);
VC_EXPORT void *VCPosition_AttachUpdateCallback(VCPosition *item, VCPosition_Func func, void *data);
VC_EXPORT void *VCPosition_AttachDeleteCallback(VCPosition *item, VCPosition_Func func, void *data);
VC_EXPORT int	VCPosition_DetachCreateCallback(VCPosition *item, void *callbackHandle);
VC_EXPORT int	VCPosition_DetachUpdateCallback(VCPosition *item, void *callbackHandle);
VC_EXPORT int	VCPosition_DetachDeleteCallback(VCPosition *item, void *callbackHandle);
VC_EXPORT VCPosition *VCPosition_Create(dmPosition *pos, uint32 mode);
VC_EXPORT VCPosition *VCPosition_CreateData(VCPositionData *positionData);
VC_EXPORT int	VCPosition_Get(VCPosition *item, dmPosition *pos, uint32 *mode);
VC_EXPORT int	VCPosition_GetData(VCPosition *item, VCPositionData *positionData);
VC_EXPORT int	VCPosition_SetData (VCPosition *item,VCPositionData *positionData);
VC_EXPORT int	VCPosition_Set(VCPosition *item, dmPosition *pos, uint32 setMode, uint32 clearMode);
VC_EXPORT int	VCPosition_Delete(VCPosition *item);

VC_EXPORT int	VCPosition_ModifyMode(VCPosition *pos, uint32 setMode, uint32 clearMode);
VC_EXPORT int	VCPosition_SetMode(VCPosition *pos, uint32 mode);
VC_EXPORT int	VCPosition_GetMode(VCPosition *pos, uint32 *mode);



VC_EXPORT void    VCXWindowId_SetCacheMode(VCXWindowId *item, uint32 newCacheMode);
VC_EXPORT uint32    VCXWindowId_GetCacheMode(VCXWindowId *item);
VC_EXPORT void *    VCXWindowId_AttachCreateCallback(VCXWindowId *item, VCXWindowId_Func func, void *data);
VC_EXPORT void *    VCXWindowId_AttachUpdateCallback(VCXWindowId *item, VCXWindowId_Func func, void *data);
VC_EXPORT void *    VCXWindowId_AttachDeleteCallback(VCXWindowId *item, VCXWindowId_Func func, void *data);
VC_EXPORT int    VCXWindowId_DetachCreateCallback(VCXWindowId *item, void *callbackHandle);
VC_EXPORT int    VCXWindowId_DetachUpdateCallback(VCXWindowId *item, void *callbackHandle);
VC_EXPORT int    VCXWindowId_DetachDeleteCallback(VCXWindowId *item, void *callbackHandle);
VC_EXPORT VCXWindowId *    VCXWindowId_Create(char *name, uint32 windowId, char *serverName);
VC_EXPORT VCXWindowId *    VCXWindowId_CreateData(VCXWindowIdData *xwindowidData);
VC_EXPORT int    VCXWindowId_Get(VCXWindowId *item, char **name, uint32 *windowId, char **serverName);
VC_EXPORT int    VCXWindowId_GetData(VCXWindowId *item, VCXWindowIdData *xwindowidData);
VC_EXPORT int    VCXWindowId_SetData (VCXWindowId *item,VCXWindowIdData *xwindowidData);
VC_EXPORT int    VCXWindowId_Set(VCXWindowId *item, char *name, uint32 *windowId, char *serverName);
VC_EXPORT int    VCXWindowId_SetName(VCXWindowId *item, char *name);
VC_EXPORT int    VCXWindowId_SetWindowId(VCXWindowId *item, uint32 windowId);
VC_EXPORT int    VCXWindowId_SetServerName(VCXWindowId *item, char *serverName);
VC_EXPORT int    VCXWindowId_GetName(VCXWindowId *item, char **name);
VC_EXPORT int    VCXWindowId_GetWindowId(VCXWindowId *item, uint32 *windowId);
VC_EXPORT int    VCXWindowId_GetServerName(VCXWindowId *item, char **serverName);
VC_EXPORT int    VCXWindowId_Delete(VCXWindowId *item);


VC_EXPORT void    VCPseudoGravity_SetCacheMode(VCPseudoGravity *item, uint32 newCacheMode);

VC_EXPORT uint32    VCPseudoGravity_GetCacheMode(VCPseudoGravity *item);

VC_EXPORT void *    VCPseudoGravity_AttachCreateCallback(VCPseudoGravity *item, VCPseudoGravity_Func func, void *data);

VC_EXPORT void *    VCPseudoGravity_AttachUpdateCallback(VCPseudoGravity *item, VCPseudoGravity_Func func, void *data);

VC_EXPORT void *    VCPseudoGravity_AttachDeleteCallback(VCPseudoGravity *item, VCPseudoGravity_Func func, void *data);

VC_EXPORT int    VCPseudoGravity_DetachCreateCallback(VCPseudoGravity *item, void *callbackHandle);

VC_EXPORT int    VCPseudoGravity_DetachUpdateCallback(VCPseudoGravity *item, void *callbackHandle);

VC_EXPORT int    VCPseudoGravity_DetachDeleteCallback(VCPseudoGravity *item, void *callbackHandle);

VC_EXPORT VCPseudoGravity *    VCPseudoGravity_Create(uint32 mode, dmVector direction, float32 gravity);

VC_EXPORT VCPseudoGravity *    VCPseudoGravity_CreateData(VCPseudoGravityData *pseudoGravityData);

VC_EXPORT int    VCPseudoGravity_Get(VCPseudoGravity *item, uint32 *mode, dmVector direction, float32 *gravity);

VC_EXPORT int    VCPseudoGravity_GetData(VCPseudoGravity *item, VCPseudoGravityData *pseudoGravityData);

VC_EXPORT int    VCPseudoGravity_SetData (VCPseudoGravity *item,VCPseudoGravityData *pseudoGravityData);

VC_EXPORT int VCPseudoGravity_Set(VCPseudoGravity *item, uint32 setMode, uint32 clearMode, dmVector direction,
                    float32 *gravity);

VC_EXPORT int    VCPseudoGravity_ModifyMode(VCPseudoGravity *item, uint32 setMode, uint32 clearMode);
VC_EXPORT int    VCPseudoGravity_SetMode(VCPseudoGravity *item, uint32 mode);

VC_EXPORT int    VCPseudoGravity_SetDirection(VCPseudoGravity *item, dmVector direction);

VC_EXPORT int    VCPseudoGravity_SetGravity(VCPseudoGravity *item, float32 gravity);

VC_EXPORT int    VCPseudoGravity_GetMode(VCPseudoGravity *item, uint32 *mode);

VC_EXPORT int    VCPseudoGravity_GetDirection(VCPseudoGravity *item, dmVector direction);

VC_EXPORT int        VCPseudoGravity_GetGravity(VCPseudoGravity *item, float32 *gravity);

VC_EXPORT int	VCPseudoGravity_Delete(VCPseudoGravity *item);



VC_EXPORT void	VCVisualViewResource_SetCacheMode(VCVisualViewResource *item, uint32 newCacheMode);
VC_EXPORT uint32	VCVisualViewResource_GetCacheMode(VCVisualViewResource *item);
VC_EXPORT VCVisualViewResource *_VCVisualViewResource_GetViewFromAttribute(VCAttribute *attribute);
VC_EXPORT VCAttribute *_VCVisualViewResource_GetAttribute(VCVisualViewResource *view);
VC_EXPORT void	*VCVisualViewResource_AttachCreateCallback(VCVisualViewResource *item, VCVisualViewResource_Func func, void *data);
VC_EXPORT void	*VCVisualViewResource_AttachUpdateCallback(VCVisualViewResource *item, VCVisualViewResource_Func func, void *data);
VC_EXPORT void	*VCVisualViewResource_AttachDeleteCallback(VCVisualViewResource *item, VCVisualViewResource_Func func, void *data);
VC_EXPORT int	VCVisualViewResource_DetachCreateCallback(VCVisualViewResource *item, void *callbackHandle);
VC_EXPORT int	VCVisualViewResource_DetachUpdateCallback(VCVisualViewResource *item, void *callbackHandle);
VC_EXPORT int	VCVisualViewResource_DetachDeleteCallback(VCVisualViewResource *item, void *callbackHandle);
VC_EXPORT VCVisualViewResource *VCVisualViewResource_Create(char *name, VCAttribute *visualResource, uint32 mode,
                                                            dmPoint offset, dmEuler orientation, float32 size[2]);
VC_EXPORT VCVisualViewResource *VCVisualViewResource_CreateData(VCVisualViewResourceData *viewData);
VC_EXPORT int	VCVisualViewResource_Get(VCVisualViewResource *item, char **name, VCAttribute **visualResource,
                                         uint32 *mode, dmPoint offset, dmEuler orientation, float32 size[2]);
VC_EXPORT int	VCVisualViewResource_GetData(VCVisualViewResource *item, VCVisualViewResourceData *viewData);
VC_EXPORT int	VCVisualViewResource_SetData (VCVisualViewResource *item,VCVisualViewResourceData *viewData);
VC_EXPORT int	VCVisualViewResource_Set(VCVisualViewResource *item, VCAttribute *visualResource,
                                         uint32 setMode, uint32 clearMode, dmPoint offset,
                                         dmEuler orientation, float32 size[2]);

VC_EXPORT int	VCVisualViewResource_Delete(VCVisualViewResource *item);
VC_EXPORT int	VCVisualViewResource_SetVisualResource(VCVisualViewResource *item, VCAttribute *visualResource);
VC_EXPORT int	VCVisualViewResource_SetMode(VCVisualViewResource *item, uint32 mode);
VC_EXPORT int	VCVisualViewResource_ModifyMode(VCVisualViewResource *item, uint32 setMode, uint32 clearMode);
VC_EXPORT int	VCVisualViewResource_SetOffset(VCVisualViewResource *item, dmPoint offset);
VC_EXPORT int	VCVisualViewResource_SetOrientation(VCVisualViewResource *item, dmEuler orientation);
VC_EXPORT int	VCVisualViewResource_SetSize(VCVisualViewResource *item, float32 size[2]);
VC_EXPORT int	VCVisualViewResource_GetName(VCVisualViewResource *item, char **name);
VC_EXPORT int	VCVisualViewResource_GetVisualResource(VCVisualViewResource *item, VCAttribute **visualResource);
VC_EXPORT int	VCVisualViewResource_GetMode(VCVisualViewResource *item, uint32 *mode);
VC_EXPORT int	VCVisualViewResource_GetOffset(VCVisualViewResource *item, dmPoint offset);
VC_EXPORT int	VCVisualViewResource_GetOrientation(VCVisualViewResource *item, dmEuler orientation);
VC_EXPORT int	VCVisualViewResource_GetSize(VCVisualViewResource *item, float32 size[2]);

VC_EXPORT VCVisualViewResource  *VCVisualViewResource_GetFirst(VCAttribute *visualResource, VC_Traverse *traverseInfo);
VC_EXPORT VCVisualViewResource *VCVisualViewResource_GetNext(VC_Traverse *traverseInfo);

VC_EXPORT VCAttribute 	*VCVisualSourceResource_Create(char *name);
VC_EXPORT int		 VCVisualSourceResource_Get(VCAttribute *attribute, char **name);
VC_EXPORT VCAttribute 	*VCVisualSourceResource_CreateData(VCVisualSourceResourceData *srcData);
VC_EXPORT int		 VCVisualSourceResource_SetData(VCAttribute *attribute,VCVisualSourceResourceData *srcData);
VC_EXPORT int		 VCVisualSourceResource_GetData(VCAttribute *attribute, VCVisualSourceResourceData *srcData);
VC_EXPORT VCAttribute	*VCEntity_AddVisualSourceResource(VCEntity *entity, char *name);
VC_EXPORT VCAttribute 	*VCEntity_AddVisualSourceResourceData(VCEntity *entity, VCVisualSourceResourceData *srcData);
VC_EXPORT int		 VCVisualSourceResource_GetNAme(VCAttribute *attribute, char **name);

#define VCEntity_DetachVisualSourceResource(e,a) VCEntity_DetachAttribute(e,a)
#define VCVisualSourceResource_Delete(a) VCAttribute_Delete(a)


VC_EXPORT VCEntity *VC_ConstructAudioVoice(char *voice, VCAttribute **audioAttribute);
VC_EXPORT VCEntity *VC_ConstructAudioData(VCAudioData *audioData, VCAttribute **audioAttribute);
VC_EXPORT VCEntity *VC_ConstructLightAmbient(VCColour colour, VCAttribute **lightAttribute);
VC_EXPORT VCEntity *VC_ConstructLightDirectional(VCColour colour, VCAttribute **lightAttribute);
VC_EXPORT VCEntity *VC_ConstructLightPoint(VCColour colour, VCAttribute **lightAttribute);
VC_EXPORT VCEntity *VC_ConstructLightSpot(VCColour colour, float32 exponent, float32 theta,
                                VCAttribute **lightAttribute);
VC_EXPORT VCEntity *VC_ConstructLightData(VCLightData *lightData, VCAttribute **lightAttribute);
VC_EXPORT VCEntity *VC_ConstructVisualGeometry(char *geometry, int collidable, VCAttribute **visualAttribute,
                                     VCAttribute **boundaryAttribute);
VC_EXPORT VCEntity *VC_ConstructVisualData(VCVisualData *visualData, int collidable, VCAttribute **visualAttribute,
                                 VCAttribute **boundaryAttribute);


VC_EXPORT void	VCSync_SetCacheMode(VCSync *item, uint32 newCacheMode);
VC_EXPORT uint32	VCSync_GetCacheMode(VCSync *item);
VC_EXPORT void 	*VC_AttachSyncCallbacks(char *actorName, char *actorType, VCSync_Func updateFunc,
                                VCSync_Func deleteFunc, void *data);
VC_EXPORT int	 VC_DetachSyncCallbacks( void *callbackHandle);
VC_EXPORT VCSync *VCSync_Create(char *name, char *actorType, VCTime *time);
VC_EXPORT int	VCSync_Get(VCSync *item, char **name, char **actorType, VCTime *time);
VC_EXPORT int	VCSync_Set(VCSync *item, VCTime *time);
VC_EXPORT int	VCSync_SetTime(VCSync *item, VCTime *time);
VC_EXPORT int	VCSync_GetName(VCSync *item, char **name);
VC_EXPORT int	VCSync_GetActorType(VCSync *item, char **type);
VC_EXPORT int	VCSync_GetTime(VCSync *item, VCTime *time);
VC_EXPORT int  	VCSync_Delete(VCSync *item);


VC_EXPORT void			 VCCollideMonitor_SetCacheMode		(VCCollideMonitor *item, uint32 newCacheMode);
VC_EXPORT uint32			 VCCollideMonitor_GetCacheMode		(VCCollideMonitor *item);
VC_EXPORT void 			*VCCollideMonitor_AttachCreateCallback	(VCCollideMonitor *item, VCCollideMonitor_Func func, void *data);
VC_EXPORT void 			*VCCollideMonitor_AttachUpdateCallback	(VCCollideMonitor *item, VCCollideMonitor_Func func, void *data);
VC_EXPORT void 			*VCCollideMonitor_AttachDeleteCallback	(VCCollideMonitor *item, VCCollideMonitor_Func func, void *data);
VC_EXPORT int			 VCCollideMonitor_DetachCreateCallback	(VCCollideMonitor *item, void *callbackHandle);
VC_EXPORT int			 VCCollideMonitor_DetachUpdateCallback	(VCCollideMonitor *item, void *callbackHandle);
VC_EXPORT int			 VCCollideMonitor_DetachDeleteCallback	(VCCollideMonitor *item, void *callbackHandle);
VC_EXPORT VCCollideMonitor 	*VCCollideMonitor_CreateData		(VCCollideMonitorData *collideMonitorData);
VC_EXPORT int			 VCCollideMonitor_GetData		(VCCollideMonitor *item, VCCollideMonitorData *collideMonitorData);
VC_EXPORT int			 VCCollideMonitor_SetData 		(VCCollideMonitor *item,VCCollideMonitorData *collideMonitorData);
VC_EXPORT int			 VCCollideMonitor_Delete		(VCCollideMonitor *item);

VC_EXPORT void			 VCTrackerMonitor_SetCacheMode		(VCTrackerMonitor *item, uint32 newCacheMode);
VC_EXPORT uint32			 VCTrackerMonitor_GetCacheMode		(VCTrackerMonitor *item);
VC_EXPORT void 			*VCTrackerMonitor_AttachCreateCallback	(VCTrackerMonitor *item, VCTrackerMonitor_Func func, void *data);
VC_EXPORT void 			*VCTrackerMonitor_AttachUpdateCallback	(VCTrackerMonitor *item, VCTrackerMonitor_Func func, void *data);
VC_EXPORT void 			*VCTrackerMonitor_AttachDeleteCallback	(VCTrackerMonitor *item, VCTrackerMonitor_Func func, void *data);
VC_EXPORT int			 VCTrackerMonitor_DetachCreateCallback	(VCTrackerMonitor *item, void *callbackHandle);
VC_EXPORT int			 VCTrackerMonitor_DetachUpdateCallback	(VCTrackerMonitor *item, void *callbackHandle);
VC_EXPORT int			 VCTrackerMonitor_DetachDeleteCallback	(VCTrackerMonitor *item, void *callbackHandle);
VC_EXPORT VCTrackerMonitor 	*VCTrackerMonitor_CreateData		(VCTrackerMonitorData *trackerMonitorData);
VC_EXPORT int			 VCTrackerMonitor_GetData		(VCTrackerMonitor *item, VCTrackerMonitorData *trackerMonitorData);
VC_EXPORT int			 VCTrackerMonitor_SetData 		(VCTrackerMonitor *item,VCTrackerMonitorData *trackerMonitorData);
VC_EXPORT int			 VCTrackerMonitor_Delete		(VCTrackerMonitor *item);

VC_EXPORT void			 VCVisualMonitor_SetCacheMode		(VCVisualMonitor *item, uint32 newCacheMode);
VC_EXPORT uint32			 VCVisualMonitor_GetCacheMode		(VCVisualMonitor *item);
VC_EXPORT void 			*VCVisualMonitor_AttachCreateCallback	(VCVisualMonitor *item, VCVisualMonitor_Func func, void *data);
VC_EXPORT void 			*VCVisualMonitor_AttachUpdateCallback	(VCVisualMonitor *item, VCVisualMonitor_Func func, void *data);
VC_EXPORT void 			*VCVisualMonitor_AttachDeleteCallback	(VCVisualMonitor *item, VCVisualMonitor_Func func, void *data);
VC_EXPORT int			 VCVisualMonitor_DetachCreateCallback	(VCVisualMonitor *item, void *callbackHandle);
VC_EXPORT int			 VCVisualMonitor_DetachUpdateCallback	(VCVisualMonitor *item, void *callbackHandle);
VC_EXPORT int			 VCVisualMonitor_DetachDeleteCallback	(VCVisualMonitor *item, void *callbackHandle);
VC_EXPORT VCVisualMonitor 	*VCVisualMonitor_CreateData		(VCVisualMonitorData *visualMonitorData);
VC_EXPORT int			 VCVisualMonitor_GetData		(VCVisualMonitor *item, VCVisualMonitorData *visualMonitorData);
VC_EXPORT int			 VCVisualMonitor_SetData 		(VCVisualMonitor *item,VCVisualMonitorData *visualMonitorData);
VC_EXPORT int			 VCVisualMonitor_Delete			(VCVisualMonitor *item);

VC_EXPORT void		 VCRadiator_SetCacheMode(VCRadiator *item, uint32 newCacheMode);
VC_EXPORT uint32		 VCRadiator_GetCacheMode(VCRadiator *item);
VC_EXPORT void 		*VCRadiator_AttachCreateCallback(VCRadiator *item, VCRadiator_Func func, void *data);
VC_EXPORT void 		*VCRadiator_AttachUpdateCallback(VCRadiator *item, VCRadiator_Func func, void *data);
VC_EXPORT void 		*VCRadiator_AttachDeleteCallback(VCRadiator *item, VCRadiator_Func func, void *data);
VC_EXPORT int		 VCRadiator_DetachCreateCallback(VCRadiator *item, void *callbackHandle);
VC_EXPORT int		 VCRadiator_DetachUpdateCallback(VCRadiator *item, void *callbackHandle);
VC_EXPORT int		 VCRadiator_DetachDeleteCallback(VCRadiator *item, void *callbackHandle);
VC_EXPORT VCRadiator 	*VCRadiator_Create (char *name, int32 numPoints, float32 points[VC_RADIATOR_MAX_POINTS]);
VC_EXPORT VCRadiator 	*VCRadiator_CreateData(VCRadiatorData *radiatorData);
VC_EXPORT int		 VCRadiator_Get (VCRadiator *item, char **name, int32 *numPoints, float32 points[VC_RADIATOR_MAX_POINTS]);
VC_EXPORT int		 VCRadiator_GetData(VCRadiator *item, VCRadiatorData *radiatorData);
VC_EXPORT int		 VCRadiator_SetData (VCRadiator *item,VCRadiatorData *radiatorData);
VC_EXPORT int		 VCRadiator_Set (VCRadiator *radiator, char *name, int32 *numPoints, float32 points[VC_RADIATOR_MAX_POINTS]);
VC_EXPORT int		 VCRadiator_SetName(VCRadiator *radiator, char *name);
VC_EXPORT int		 VCRadiator_SetNumPoints(VCRadiator *radiator, int32 numPoints);
VC_EXPORT int		 VCRadiator_SetPoints(VCRadiator *radiator, float32 points[VC_RADIATOR_MAX_POINTS]);
VC_EXPORT int		 VCRadiator_GetName(VCRadiator *radiator, char **name);
VC_EXPORT int		 VCRadiator_GetNumPoints(VCRadiator *radiator, int32 *numPoints);
VC_EXPORT int		 VCRadiator_GetPoints(VCRadiator *radiator, float32 points[VC_RADIATOR_MAX_POINTS]);
VC_EXPORT int		 VCRadiator_Delete(VCRadiator *item);

VC_EXPORT void		 VCRamp_SetCacheMode(VCRamp *item, uint32 newCacheMode);
VC_EXPORT uint32		 VCRamp_GetCacheMode(VCRamp *item);
VC_EXPORT void 		*VCRamp_AttachCreateCallback(VCRamp *item, VCRamp_Func func, void *data);
VC_EXPORT void 		*VCRamp_AttachUpdateCallback(VCRamp *item, VCRamp_Func func, void *data);
VC_EXPORT void 		*VCRamp_AttachDeleteCallback(VCRamp *item, VCRamp_Func func, void *data);
VC_EXPORT int		 VCRamp_DetachCreateCallback(VCRamp *item, void *callbackHandle);
VC_EXPORT int		 VCRamp_DetachUpdateCallback(VCRamp *item, void *callbackHandle);
VC_EXPORT int		 VCRamp_DetachDeleteCallback(VCRamp *item, void *callbackHandle);
VC_EXPORT VCRamp 		*VCRamp_Create(char *name, uint32 mode, VCColour minRgb, VCColour maxRgb);
VC_EXPORT VCRamp 		*VCRamp_CreateData(VCRampData *rampData);
VC_EXPORT int		 VCRamp_Get(VCRamp *item, char **name, uint32 *mode, VCColour minRgb, VCColour maxRgb);
VC_EXPORT int		 VCRamp_GetData(VCRamp *item, VCRampData *rampData);
VC_EXPORT int		 VCRamp_SetData (VCRamp *item,VCRampData *rampData);
VC_EXPORT int		 VCRamp_Set(VCRamp *item, char *name, uint32 setMode, uint32 clearMode,  VCColour minRgb, VCColour maxRgb);
VC_EXPORT int		 VCRamp_ModifyMode(VCRamp *item, uint32 setMode, uint32 clearMode);
VC_EXPORT int		 VCRamp_SetName(VCRamp *item, char *name);
VC_EXPORT int		 VCRamp_SetMode(VCRamp *item, uint32 mode);
VC_EXPORT int		 VCRamp_SetMinRgb (VCRamp *item, VCColour minRgb);
VC_EXPORT int		 VCRamp_SetMaxRgb (VCRamp *item, VCColour maxRgb);
VC_EXPORT int		 VCRamp_GetName(VCRamp *item, char **name);
VC_EXPORT int		 VCRamp_GetMode(VCRamp *item, uint32 *mode);
VC_EXPORT int		 VCRamp_GetMinRgb (VCRamp *item, VCColour minRgb);
VC_EXPORT int		 VCRamp_GetMaxRgb (VCRamp *item, VCColour maxRgb);
VC_EXPORT int		 VCRamp_Delete(VCRamp *item);

VC_EXPORT int		 VC_StartGroup(void);
VC_EXPORT int		 VC_StopGroup(void);
VC_EXPORT int32		 VC_GetGroup(void);

VC_EXPORT int		 VC_DetachGroupCallback(void *callbackHandle);
VC_EXPORT void   		*VC_AttachGroupCallback(VC_GroupFunc function, void *data);

VC_EXPORT char 			*VC_ErrorString(int errno, int errType);
VC_EXPORT void		 VC_Perror(char *message);
VC_EXPORT void		 VCPrintBadMatrixSplit(dmMatrix mat, char *func, char *file, int line);

VC_EXPORT VCAttribute     *VCFindAttribute (const InstanceNo attrIno);
VC_EXPORT VCEntity 	*VCFindObject( const InstanceNo obj_ino);

VC_EXPORT int  	 VCEntity_Rotate (VCEntity *e, dmPoint centre, int axis, float angle);
VC_EXPORT int	 VCEntity_RotateX (VCEntity *e, float angle);
VC_EXPORT int	 VCEntity_RotateY (VCEntity *e, float angle);
VC_EXPORT int 	 VCEntity_RotateZ (VCEntity *e, float angle);


VC_EXPORT int	 VCEntity_Spin (VCEntity *e, int axis, float angle);
VC_EXPORT int	 VCEntity_Scale (VCEntity *e, float sx, float sy, float sz);
VC_EXPORT int	 VCEntity_Resize (VCEntity *entity, float sx, float sy, float sz);
VC_EXPORT int	 VCEntity_Translate (VCEntity *e, float dx, float dy, float dz);


VC_EXPORT VCAttribute 	*VCVisual_Create 	(char *visual_name, VCDynamicVisual *dynamicVIsual, uint32 mode, char *lod,
                                                 char *frontMaterial, char *backMaterial,
                                                 uint32 intersectMask);
VC_EXPORT int		 VCVisual_Set 		(VCAttribute *attribute, char *visual_name, VCDynamicVisual *dynamicVisual,
                                                 uint32 setMode, uint32 clearMode, char *lod, char *frontMaterial,
                                                 char *backMaterial, uint32 setIntersectMask,
                                                 uint32 clearIntersectMask, float32 *boundingBox);
VC_EXPORT int		 VCVisual_Get 		(VCAttribute *attribute, char **visual_name,
                                                 VCDynamicVisual **dynamicVisual,
                                                 uint32 *mode, char **lod, char **frontMaterial, char **backMaterial,
                                                 uint32 *intersectMask, float32 **boundingBox);
VC_EXPORT VCAttribute 	*VCVisual_CreateData	(VCVisualData *visualData);
VC_EXPORT int		 VCVisual_SetData 	(VCAttribute *attribute,VCVisualData *visualData);
VC_EXPORT int		 VCVisual_GetData 	(VCAttribute *attribute, VCVisualData *visualData);

VC_EXPORT VCAttribute	*VCEntity_AddVisual 	(VCEntity *entity, char *visual_name, VCDynamicVisual *DynamicVisual,
                                         uint32 mode, char *lod,
                                         char *frontMaterial, char *backMaterial, uint32 intersectMask);
VC_EXPORT VCAttribute 	*VCEntity_AddVisualData(VCEntity *entity, VCVisualData *visualData);
VC_EXPORT int		 VCVisual_SetGeometry 	(VCAttribute *attribute, char *visual_name);
VC_EXPORT int		 VCVisual_SetDynamicVisual (VCAttribute *attribute, VCDynamicVisual *dynamicVisual);
VC_EXPORT int		 VCVisual_SetMode 	(VCAttribute *attribute, uint32 mode);
VC_EXPORT int 		 VCVisual_ModifyMode 	(VCAttribute *attribute, uint32 setMode, uint32 clearMode);
VC_EXPORT int		 VCVisual_SetFrontMaterial (VCAttribute *attribute, char *frontMaterial);
VC_EXPORT int		 VCVisual_SetBackMaterial (VCAttribute *attribute, char *backMaterial);
VC_EXPORT int		 VCVisual_SetLod 	(VCAttribute *attribute, char *lod);
VC_EXPORT int		 VCVisual_SetIntersectMask (VCAttribute *attribute, uint32 intersectMask);
VC_EXPORT int		 VCVisual_ModifyIntersectMask (VCAttribute *attribute, uint32 setIntersectMask,
                                               uint32 clearIntersectMask);

VC_EXPORT int		 VCVisual_GetGeometry 	(VCAttribute *attribute, char **visual_name);
VC_EXPORT int		 VCVisual_GetDynamicVisual (VCAttribute *attribute, VCDynamicVisual **dynamicVisual);
VC_EXPORT int		 VCVisual_GetMode 	(VCAttribute *attribute, uint32 *mode);
VC_EXPORT int		 VCVisual_GetFrontMaterial (VCAttribute *attribute, char **frontMaterial);
VC_EXPORT int		 VCVisual_GetBackMaterial (VCAttribute *attribute, char **backMaterial);
VC_EXPORT int		 VCVisual_GetLod 	(VCAttribute *attribute, char **lod);
VC_EXPORT int		 VCVisual_GetIntersectMask (VCAttribute *attribute, uint32 *intersectMask);

#define VCEntity_AddVisualGeometry(e,g) VCEntity_AddVisual(e, g, NULL, VC_VISIBLE | VC_RMODE_POLYGONAL, NULL, NULL, NULL, 0xffffffff)
#define VCEntity_DetachVisual(e,a) VCEntity_DetachAttribute(e,a)
#define VCVisual_CreateGeometry(g) VCVisual_Create( g, NULL, VC_VISIBLE|VC_RMODE_POLYGONAL, NULL, NULL, NULL, NULL)
#define VCVisual_Delete(a) VCAttribute_Delete(a)


VC_EXPORT VCAttribute 	*VCBodyPart_Create 	(char *bodyPart_name, uint32 actorId);
VC_EXPORT VCAttribute 	*VCBodyPart_CreateData 	(VCBodyPartData *bodyPart);
VC_EXPORT VCAttribute 	*VCEntity_AddBodyPartData(VCEntity *entity, VCBodyPartData *data);
VC_EXPORT VCAttribute	*VCEntity_AddBodyPart 	(VCEntity *entity, char *bodyPart_name, uint32 actorId);
VC_EXPORT int		 VCBodyPart_Set		(VCAttribute *attribute, char *bodyPart_name,
                                         uint32 *actorId);
VC_EXPORT int		 VCBodyPart_SetData	(VCAttribute *attribute, VCBodyPartData *bodyPart);
VC_EXPORT int		 VCBodyPart_SetName	(VCAttribute *attribute, char *name);
VC_EXPORT int		 VCBodyPart_Get		(VCAttribute *attribute, char **bodyPart_name,
                                         uint32 *actorId);
VC_EXPORT int		 VCBodyPart_GetData	(VCAttribute *attribute, VCBodyPartData *bodyPart);
VC_EXPORT int		 VCBodyPart_GetName	(VCAttribute *attribute, char **name);
VC_EXPORT int		 VCBodyPart_GetActorId	(VCAttribute *attribute, uint32 *actorId);

#define VCEntity_DetachBodyPart(e,a) VCEntity_DetachAttribute(e, a)
#define VCBodyPart_Delete(a) VCAttribute_Delete(a)

VC_EXPORT VCAttribute     *VCPickObject_Create	(VCEntity *entity, uint32 mode, uint32 actorId);
VC_EXPORT VCAttribute 	*VCPickObject_CreateData (VCPickObjectData *pickData);
VC_EXPORT int		 VCPickObject_Set 	(VCAttribute *attribute, VCEntity *entity,
                                         uint32 setMode, uint32 clearMode, uint32 *actorId);
VC_EXPORT int		 VCPickObject_SetData (VCAttribute *attribute, VCPickObjectData *pickData);
VC_EXPORT int		 VCPickObject_Get 	(VCAttribute *attribute, VCEntity **entity,
                                         uint32 *mode, uint32 *actorId);
VC_EXPORT int		 VCPickObject_GetData (VCAttribute *attribute, VCPickObjectData *pickData);
VC_EXPORT VCAttribute 	*VCEntity_AddPickObjectData(VCEntity *entity, VCPickObjectData *data);
VC_EXPORT VCAttribute	*VCEntity_AddPickObject (VCEntity *entity, VCEntity *pickingEntity, uint32 mode,
                                         uint32 pickActorId);

#define VCEntity_DetachPickObject(e,a) VCEntity_DetachAttribute(e,a)
#define VCPickObject_Delete(a) VCAttribute_Delete(a)

VC_EXPORT int		 VCPickObject_SetMode		(VCAttribute *attribute, uint32 mode);
VC_EXPORT int		 VCPickObject_ModifyMode	(VCAttribute *attribute, uint32 setMode, uint32 clearMode);
VC_EXPORT int 		 VCPickObject_SetPickingEntity	(VCAttribute *attribute, VCEntity *entity);
VC_EXPORT int 		 VCPickObject_SetActorId	(VCAttribute *attribute, uint32 actorId);
VC_EXPORT int		 VCPickObject_GetMode		(VCAttribute *attribute, uint32 *mode);
VC_EXPORT int 		 VCPickObject_GetPickingEntity	(VCAttribute *attribute, VCEntity **entity);
VC_EXPORT int 		 VCPickObject_GetActorId	(VCAttribute *attribute, uint32 *actorId);


/* Hoppy, 11/07/98 */
VC_EXPORT VCAttribute     *VCSelectObject_Create	(VCEntity *entity, uint32 mode, uint32 actorId);
VC_EXPORT VCAttribute 	*VCSelectObject_CreateData (VCSelectObjectData *selectData);
VC_EXPORT int		 VCSelectObject_Set 	(VCAttribute *attribute, VCEntity *entity,
                                         uint32 setMode, uint32 clearMode, uint32 *actorId);
VC_EXPORT int		 VCSelectObject_SetData (VCAttribute *attribute, VCSelectObjectData *selectData);
VC_EXPORT int		 VCSelectObject_Get 	(VCAttribute *attribute, VCEntity **entity,
                                         uint32 *mode, uint32 *actorId);
VC_EXPORT int		 VCSelectObject_GetData (VCAttribute *attribute, VCSelectObjectData *selectData);
VC_EXPORT VCAttribute 	*VCEntity_AddSelectObjectData(VCEntity *entity, VCSelectObjectData *data);
VC_EXPORT VCAttribute	*VCEntity_AddSelectObject (VCEntity *entity, VCEntity *selectingEntity, uint32 mode,
                                         uint32 selectActorId);

#define VCEntity_DetachSelectObject(e,a) VCEntity_DetachAttribute(e,a)
#define VCSelectObject_Delete(a) VCAttribute_Delete(a)

VC_EXPORT int		 VCSelectObject_SetMode		(VCAttribute *attribute, uint32 mode);
VC_EXPORT int		 VCSelectObject_ModifyMode	(VCAttribute *attribute, uint32 setMode, uint32 clearMode);
VC_EXPORT int 		 VCSelectObject_SetSelectingEntity	(VCAttribute *attribute, VCEntity *entity);
VC_EXPORT int 		 VCSelectObject_SetActorId	(VCAttribute *attribute, uint32 actorId);
VC_EXPORT int		 VCSelectObject_GetMode		(VCAttribute *attribute, uint32 *mode);
VC_EXPORT int 		 VCSelectObject_GetSelectingEntity	(VCAttribute *attribute, VCEntity **entity);
VC_EXPORT int 		 VCSelectObject_GetActorId	(VCAttribute *attribute, uint32 *actorId);

VC_EXPORT VCAttribute	*VCBoundary_Create 	(char *geometry, VCDynamicVisual *dynamicVisual, float32 bounds[VC_BOUND_SIZE],
                                         uint32 mode, char *lod , int numCollisions);
VC_EXPORT VCAttribute	*VCBoundary_CreateData 	(VCBoundaryData *boundaryData);
VC_EXPORT int		 VCBoundary_Set 	(VCAttribute *attribute, char *geometry, VCDynamicVisual *dynamicVisual,
                                         float32 bounds[VC_BOUND_SIZE], uint32 setMode, uint32 clearMode, char *lod ,
                                         int32 *numberCollisions);
VC_EXPORT int		 VCBoundary_SetData 	(VCAttribute *attribute, VCBoundaryData *boundaryData);
VC_EXPORT int		 VCBoundary_Get		(VCAttribute *attribute, char **geometry, VCDynamicVisual **dynamicVisual,
                                         float32 bounds[VC_BOUND_SIZE], uint32 *mode, char **lod, int32 *numberCollisions,
                                         VCCollision **collision);
VC_EXPORT int		 VCBoundary_GetData	(VCAttribute *attribute, VCBoundaryData *boundaryData);
VC_EXPORT VCAttribute 	*VCEntity_AddBoundaryData(VCEntity *entity, VCBoundaryData *data);
VC_EXPORT VCAttribute	*VCEntity_AddBoundary	(VCEntity *entity, char *geometry, VCDynamicVisual *dynamicVisual,
                                         float32 bounds[VC_BOUND_SIZE], uint32 mode, char *lod, int numCollisions );
#define VCBoundary_Delete(a) VCAttribute_Delete(a)

#define VCEntity_DetachBoundary(e,a) VCEntity_DetachAttribute(e, a)
#define VCBoundary_CreateBbox(g) VCBoundary_Create(g,NULL,NULL, VC_COLLISION_ENABLE | VC_COLLISION_BBOX, NULL, 1)
#define VCBoundary_CreateRadius(g) VCBoundary_Create(g,NULL,NULL, VC_COLLISION_ENABLE | VC_COLLISION_RADIUS, NULL, 1)
#define VCBoundary_CreateGeometry(g) VCBoundary_Create(g,NULL,NULL, VC_COLLISION_ENABLE | VC_COLLISION_GEOMETRY, NULL, 1)
#define VCEntity_AddBoundaryBbox(e,g) VCEntity_AddBoundary(e,g,NULL,NULL, VC_COLLISION_ENABLE | VC_COLLISION_BBOX, NULL, 1)
#define VCEntity_AddBoundaryRadius(e,g) VCEntity_AddBoundary(e, g,NULL,NULL, VC_COLLISION_ENABLE | VC_COLLISION_RADIUS, NULL, 1)
#define VCEntity_AddBoundaryGeometry(e,g) VCEntity_AddBoundary(e, g,NULL,NULL, VC_COLLISION_ENABLE | VC_COLLISION_GEOMETRY, NULL, 1)


VC_EXPORT int	VCBoundary_ModifyMode(VCAttribute *attribute, uint32 setMode, uint32 clearMode);
VC_EXPORT int	VCBoundary_SetGeometry(VCAttribute *attribute, char *geometry);
VC_EXPORT int	VCBoundary_SetDynamicVisual(VCAttribute *attribute, VCDynamicVisual *dynamicGeometry);
VC_EXPORT int	VCBoundary_SetBounds(VCAttribute *attribute, float32 bounds[VC_BOUND_SIZE]);
VC_EXPORT int	VCBoundary_SetMode(VCAttribute *attribute, uint32 mode);
VC_EXPORT int	VCBoundary_SetLod(VCAttribute *attribute, char *lod);
VC_EXPORT int	VCBoundary_SetNumberCollisions(VCAttribute *attribute, int32 numberCollisions);
VC_EXPORT int	VCBoundary_GetGeometry(VCAttribute *attribute, char **geometry);
VC_EXPORT int	VCBoundary_GetBounds(VCAttribute *attribute, float32 bounds[VC_BOUND_SIZE]);
VC_EXPORT int	VCBoundary_GetMode(VCAttribute *attribute, uint32 *mode);
VC_EXPORT int	VCBoundary_GetLod(VCAttribute *attribute, char **lod);
VC_EXPORT int	VCBoundary_GetNumberCollisions(VCAttribute *attribute, int32 *numberCollisions);
VC_EXPORT int	VCBoundary_GetCollision(VCAttribute *attribute, VCCollision **collision);
VC_EXPORT int	VCBoundary_GetDynamicVisual(VCAttribute *attribute, VCDynamicVisual **dynamicGeometry);
VC_EXPORT void 	*VCBoundary_AttachCollisionCreateCallback(VCAttribute *boundary, VCCollision_Func func, void *data);
VC_EXPORT void 	*VCBoundary_AttachCollisionUpdateCallback(VCAttribute *boundary, VCCollision_Func func, void *data);
VC_EXPORT void 	*VCBoundary_AttachCollisionDeleteCallback(VCAttribute *boundary, VCCollision_Func func, void *data);
VC_EXPORT int		VCBoundary_DetachCollisionCreateCallback(VCAttribute *boundary, void *callbackHandle);
VC_EXPORT int		VCBoundary_DetachCollisionUpdateCallback(VCAttribute *boundary, void *callbackHandle);
VC_EXPORT int		VCBoundary_DetachCollisionDeleteCallback(VCAttribute *boundary, void *callbackHandle);

VC_EXPORT VCAttribute 	*VCLight_Create		(uint32 mode, VCColour colour, float exponent, float theta);
VC_EXPORT VCAttribute 	*VCLight_CreateData	(VCLightData *lightData);
VC_EXPORT int		 VCLight_Get 		(VCAttribute *attribute, uint32 *mode, VCColour colour,
                                         float *exponent, float *theta);
VC_EXPORT int		 VCLight_GetData	(VCAttribute *attribute, VCLightData *lightData);
VC_EXPORT VCAttribute 	*VCEntity_AddLightData(VCEntity *entity, VCLightData *data);
VC_EXPORT VCAttribute 	*VCEntity_AddLight	(VCEntity *entity, uint32 mode, float32 *colour,
                                         float exponent, float theta);
VC_EXPORT int		 VCLight_Set 		(VCAttribute *attribute, uint32 setMode, uint32 clearMode,
                                         VCColour colour, float *exponent, float *theta);
VC_EXPORT int		 VCLight_SetData	(VCAttribute *attribute, VCLightData *lightData);
VC_EXPORT int 		 VCLight_SetMode 	(VCAttribute *attribute, uint32 mode);
VC_EXPORT int		 VCLight_ModifyMode 	(VCAttribute *attribute, uint32 setMode, uint32 clearMode);
VC_EXPORT int 		 VCLight_SetColour 	(VCAttribute *attribute, VCColour colour);
VC_EXPORT int 		 VCLight_SetUmbra 	(VCAttribute *attribute, float32 exponent, float theta);

VC_EXPORT int		 VCLight_GetMode	(VCAttribute *attribute, uint32 *mode);
VC_EXPORT int		 VCLight_GetColour	(VCAttribute *attribute, VCColour colour);
VC_EXPORT int		 VCLight_GetUmbra	(VCAttribute *attribute, float32 *exponent, float32 *theta);

#define VCEntity_DetachLight(e,a) VCEntity_DetachAttribute(e,a)
#define VCLight_Delete(a) VCAttribute_Delete(a)
#define VCLight_SetColor(a,c) VCLight_SetColour(a,c)
#define VCLight_GetColor(a,c) VCLight_GetColour(a,c)

#define VCEntity_AddLightDirectional(e,c) VCEntity_AddLight(e, VC_LIGHT_ENABLE | VC_LIGHT_MODE_DIRECTIONAL, c, 0.0f, 0.0f)
#define VCEntity_AddLightAmbient(e,c) VCEntity_AddLight(e, VC_LIGHT_ENABLE | VC_LIGHT_MODE_AMBIENT, c, 0.0f, 0.0f)
#define VCEntity_AddLightPoint(e,c) VCEntity_AddLight(e, VC_LIGHT_ENABLE | VC_LIGHT_MODE_POINT, c, 0.0f, 0.0f)
#define VCEntity_AddLightSpot(e,c,x,t) VCEntity_AddLight(e, VC_LIGHT_ENABLE | VC_LIGHT_MODE_SPOT, c, x, t)

#define VCLight_CreateDirectional(c) VCLight_Create(VC_LIGHT_ENABLE | VC_LIGHT_MODE_DIRECTIONAL, c, 0.0f, 0.0f)
#define VCLight_CreateAmbient(c) VCLight_Create(VC_LIGHT_ENABLE | VC_LIGHT_MODE_AMBIENT, c, 0.0f, 0.0f)
#define VCLight_CreatePoint(c) VCLight_Create(VC_LIGHT_ENABLE | VC_LIGHT_MODE_POINT, c, 0.0f, 0.0f)
#define VCLight_CreateSpot(c,x,t) VCLight_Create(VC_LIGHT_ENABLE | VC_LIGHT_MODE_SPOT, c, x, t)

VC_EXPORT VCAttribute 	*VCAudio_Create 	(char *voice, float32 gain, uint8 velocity,
                                         uint32 mode, int32 loopCnt, int8 priority,
                                         char *radiatorName, char *radiatorFileName);
VC_EXPORT VCAttribute 	*VCEntity_AddAudioData(VCEntity *entity, VCAudioData *data);
VC_EXPORT VCAttribute	*VCEntity_AddAudio	(VCEntity *entity, char *voice, float32 gain, uint8 velocity,
                                         uint32 mode, int32 loopCnt, int8 priority,
                                         char * radiatorName, char *radiatorFileName);
VC_EXPORT int		 VCAudio_Set 		(VCAttribute *attribute, char *voice,
                                         float32 *gain, uint8 *velocity, uint32 setMode,
                                         uint32 clearMode, uint8 play, int32 *loopCnt, int8 *priority,
                                         char *radiatorName, char *radiatorFileName);
VC_EXPORT int		 VCAudio_Get 		(VCAttribute *attribute, char **voice,
                                         float32 *gain, uint8 *velocity, uint32 *mode,
                                         int32 *loopCnt, int8 *priority,
                                         char **radiatorName, char **radiatorFileName);
VC_EXPORT VCAttribute	*VCAudio_CreateData 	(VCAudioData *audioData);
VC_EXPORT int		 VCAudio_GetData 	(VCAttribute *attribute, VCAudioData *audioData);
VC_EXPORT int		 VCAudio_SetData 	(VCAttribute *attribute, VCAudioData *audioData);

VC_EXPORT int		 VCAudio_SetVoice 	(VCAttribute *attribute, char *voice);
VC_EXPORT int		 VCAudio_SetMode	(VCAttribute *attribute, uint32 mode);
VC_EXPORT int		 VCAudio_ModifyMode 	(VCAttribute *attribute, uint32 setMode, uint32 clearMode);
VC_EXPORT int		 VCAudio_SetGain 	(VCAttribute *attribute, float32 gain);
VC_EXPORT int		 VCAudio_SetVelocity 	(VCAttribute *attribute, uint8 velocity);
VC_EXPORT int		 VCAudio_SetLoopCount	(VCAttribute *attribute, int32 loopCnt);
VC_EXPORT int		 VCAudio_SetPriority 	(VCAttribute *attribute, int8 priority);
VC_EXPORT int		 VCAudio_SetRadiatorName(VCAttribute *attribute, char *radiator);
VC_EXPORT int		 VCAudio_SetRadiatorFile(VCAttribute *attribute, char *radiator);
VC_EXPORT int		 VCAudio_Start 		(VCAttribute *attribute);
VC_EXPORT int		 VCAudio_Stop 		(VCAttribute *attribute);

VC_EXPORT int		 VCAudio_GetVoice	(VCAttribute *attribute, char **voice);
VC_EXPORT int		 VCAudio_GetMode	(VCAttribute *attribute, uint32 *mode);
VC_EXPORT int		 VCAudio_GetGain	(VCAttribute *attribute, float32 *gain);
VC_EXPORT int		 VCAudio_GetVelocity	(VCAttribute *attribute, uint8 *velocity);
VC_EXPORT int		 VCAudio_GetLoopCount	(VCAttribute *attribute, int32 *loopCount);
VC_EXPORT int		 VCAudio_GetPriority	(VCAttribute *attribute, int8 *priority);
VC_EXPORT int		 VCAudio_GetRadiatorName(VCAttribute *attribute, char **radiator);
VC_EXPORT int		 VCAudio_GetRadiatorFile(VCAttribute *attribute, char **radiator);


#define VCEntity_AddAudioVoice(e,v) VCEntity_AddAudio(e, v, 0, 80, 0, 1, 0, NULL, NULL)
#define VCEntity_DetachAudio(e,a) VCEntity_DetachAttribute(e,a)
#define VCAudio_CreateVoice(v) VCAudio_Create(  v, 0, 80, 0, 1, 0, NULL, NULL)
#define VCAudio_Delete(a) VCAttribute_Delete(a)

#define VCSection_Delete(a) VCAttribute_Delete(a)

VC_EXPORT VCAttribute 	*VCConstraints_Create 	(uint32 mode, uint32 flags, float32 points[6],
                                         float32 rotation[6]);
VC_EXPORT VCAttribute 	*VCConstraints_CreateData (VCConstraintsData *constraintsData);
VC_EXPORT int		 VCConstraints_Get	(VCAttribute *attribute, uint32 *mode, uint32 *flags,
                                         float32 points[6], float32 rotation[6]);
VC_EXPORT int		 VCConstraints_GetData (VCAttribute *attribute, VCConstraintsData *constraintsData);

VC_EXPORT VCAttribute 	*VCEntity_AddConstraintsData(VCEntity *entity, VCConstraintsData *data);
VC_EXPORT VCAttribute	*VCEntity_AddConstraints(VCEntity *entity, uint32 mode, uint32 flags,
                                         float32 points[6], float32 rotation[6]);
VC_EXPORT int		 VCConstraints_Set 	(VCAttribute *attribute, uint32 setMode,
                                         uint32 clearMode, uint32 setFlags, uint32 clearFlags,
                                         float32 points[6], float32 rotation[6]);
VC_EXPORT int		 VCConstraints_SetData (VCAttribute *attribute, VCConstraintsData *constraintsData);

VC_EXPORT int	VCConstraints_SetMode 		(VCAttribute *attribute, uint32 mode);
VC_EXPORT int	VCConstraints_ModifyMode 	(VCAttribute *attribute, uint32 setMode, uint32 clearMode);
VC_EXPORT int	VCConstraints_ModifyFlags 	(VCAttribute *attribute, uint32 setFlags, uint32 clearFlags);
VC_EXPORT int	VCConstraints_SetFlags 		(VCAttribute *attribute, uint32 flags);
VC_EXPORT int	VCConstraints_SetPoint 		(VCAttribute *attribute, float32 point[6]);
VC_EXPORT int 	VCConstraints_SetRotation 	(VCAttribute *attribute, float32 rotation[6]);
VC_EXPORT int		 VCConstraints_GetMode (VCAttribute *attribute, uint32 *mode);
VC_EXPORT int		 VCConstraints_GetFlags (VCAttribute *attribute, uint32 *flags);
VC_EXPORT int		 VCConstraints_GetPoint (VCAttribute *attribute, float32 point[6]);
VC_EXPORT int		 VCConstraints_GetRotation (VCAttribute *attribute, float32 rotation[6]);





VC_EXPORT VCAttribute	*VCEntity_AddConstraintsHinge(VCEntity *entity, uint32 axis, float32 min, float32 max);
VC_EXPORT VCAttribute	*VCEntity_AddConstraintsHingeX(VCEntity *entity, float32 min, float32 max);
VC_EXPORT VCAttribute	*VCEntity_AddConstraintsHingeY(VCEntity *entity, float32 min, float32 max);
VC_EXPORT VCAttribute	*VCEntity_AddConstraintsHingeZ(VCEntity *entity, float32 min, float32 max);

VC_EXPORT VCAttribute 	*VCEntity_AddConstraintsTranslate(VCEntity *entity, uint32 axis, float32 min, float32 max);
VC_EXPORT VCAttribute	*VCEntity_AddConstraintsTranslateX(VCEntity *entity, float32 min, float32 max);
VC_EXPORT VCAttribute	*VCEntity_AddConstraintsTranslateY(VCEntity *entity, float32 min, float32 max);
VC_EXPORT VCAttribute	*VCEntity_AddConstraintsTranslateZ(VCEntity *entity, float32 min, float32 max);

VC_EXPORT VCAttribute 	*VCEntity_AddConstraintsRotate(VCEntity *entity, uint32 axis, float32 min, float32 max);
VC_EXPORT VCAttribute	*VCEntity_AddConstraintsRotateX(VCEntity *entity, float32 min, float32 max);
VC_EXPORT VCAttribute	*VCEntity_AddConstraintsRotateY(VCEntity *entity, float32 min, float32 max);
VC_EXPORT VCAttribute	*VCEntity_AddConstraintsRotateZ(VCEntity *entity, float32 min, float32 max);

VC_EXPORT VCAttribute *VCConstraints_CreateHinge(uint32 axis, float32 min, float32 max);
VC_EXPORT VCAttribute *VCConstraints_CreateHingeX(float32 min, float32 max);
VC_EXPORT VCAttribute *VCConstraints_CreateHingeY(float32 min, float32 max);
VC_EXPORT VCAttribute *VCConstraints_CreateHingeZ(float32 min, float32 max);
VC_EXPORT VCAttribute *VCConstraints_CreateTranslate(uint32 axis, float32 min, float32 max);
VC_EXPORT VCAttribute *VCConstraints_CreateTranslateX(float32 min, float32 max);
VC_EXPORT VCAttribute *VCConstraints_CreateTranslateY(float32 min, float32 max);
VC_EXPORT VCAttribute *VCConstraints_CreateTranslateZ(float32 min, float32 max);
VC_EXPORT VCAttribute *VCConstraints_CreateRotate(uint32 axis, float32 min, float32 max);
VC_EXPORT VCAttribute *VCConstraints_CreateRotateX(float32 min, float32 max);
VC_EXPORT VCAttribute *VCConstraints_CreateRotateY(float32 min, float32 max);
VC_EXPORT VCAttribute *VCConstraints_CreateRotateZ(float32 min, float32 max);

#define VCEntity_DetachConstraints(e,a) VCEntity_DetachAttribute(e,a)
#define VCConstraints_Delete(a) VCAttribute_Delete(a)

VC_EXPORT VCAttribute *VCVisualResource_Create (char *name, char *renderer, uint32 mode, float32 frameRate, float32 iod,
                                                float32 convergence, VCColour backGround,
                                                float32 nearClip, float32 farClip, VCColour fogColour,
                                                float32 nearFlog, float32 farFog, float32 lodScale,
                                                uint32 frameSyncTime, uint8 statisticsLevel, uint8 maxStatisticsLevel,
                                                uint16 accumSamples, uint32 capability, uint32 actorId);
VC_EXPORT VCAttribute *VCVisualResource_CreateData (VCVisualResourceData *visualResource);
VC_EXPORT int VCVisualResource_Get (VCAttribute *attribute, char **name, char **renderer, uint32 *mode,
                                    float32 *frameRate, float32 *iod, float32 *convergence,
                                    VCColour backGround, float32 *nearClip, float32 *farClip,
                                    VCColour fogColour, float32 *nearFog, float32 *farFog,
                                    float32 *lodScale, uint32 *frameSyncTime, uint8 *statisticsLevel,
                                    uint8 *maxStatisticsLevel, uint16 *accumSamples,
                                    uint32 *capability, uint32 *actorId);
VC_EXPORT int VCVisualResource_GetData (VCAttribute *attribute, VCVisualResourceData *visualResource);
VC_EXPORT int VCVisualResource_Set (VCAttribute *attribute, uint32 setMode,
                                    uint32 clearMode, float32 *frameRate, float32 *iod,
                                    float32 *convergence, VCColour backGround,
                                    float32 *nearClip, float32 *farClip, VCColour fogColour,
                                    float32 *nearFog, float32 *farFog, float32 *lodScale,
                                    uint32 *frameSyncTime, uint8 *statisticsLevel, uint16 *accumSamples, uint8 flatten);
VC_EXPORT int VCVisualResource_SetData (VCAttribute *attribute, VCVisualResourceData *visualResource);
VC_EXPORT VCAttribute *VCEntity_AddVisualResourceData (VCEntity *entity, VCVisualResourceData *data);
VC_EXPORT VCAttribute *VCEntity_AddVisualResource (VCEntity *entity, char *name, char *renderer, uint32 mode,
                                                   float32 frameRate, float32 iod, float32 convergence,
                                                   VCColour backGround, float32 nearClip, float32 farClip,
                                                   VCColour fogColour, float32 nearFlog, float32 farFog,
                                                   float32 lodScale, uint32 frameSyncTime, uint8 statisticsLevel,
                                                   uint8 maxStatisticsLevel, uint16 accumSamples, uint32 capability,
                                                   uint32 actorId);

#define VCEntity_DetachVisualResource(e,a) VCEntity_DetachAttribute(e,a)
#define VCVisualResource_Delete(a) VCAttribute_Delete(a)

VC_EXPORT int VCVisualResource_SetMode (VCAttribute *attribute, uint32 mode);
VC_EXPORT int VCVisualResource_ModifyMode (VCAttribute *attribute, uint32 setMode, uint32 clearMode);
VC_EXPORT int VCVisualResource_SetFrameRate (VCAttribute *attribute, float32 frameRate);
VC_EXPORT int VCVisualResource_SetIod (VCAttribute *attribute, float32 iod);
VC_EXPORT int VCVisualResource_SetConvergence (VCAttribute *attribute, float32 convergence);
VC_EXPORT int VCVisualResource_SetBackground (VCAttribute *attribute, VCColour backGround);
VC_EXPORT int VCVisualResource_SetNearClip (VCAttribute *attribute, float32 nearClip);
VC_EXPORT int VCVisualResource_SetFarClip (VCAttribute *attribute, float32 farClip);
VC_EXPORT int VCVisualResource_SetFogColour (VCAttribute *attribute, VCColour fogColour);
VC_EXPORT int VCVisualResource_SetNearFog (VCAttribute *attribute, float32 nearFog);
VC_EXPORT int VCVisualResource_SetFarFog (VCAttribute *attribute, float32 farFog);
VC_EXPORT int VCVisualResource_SetLodScale (VCAttribute *attribute, float32 lodScale);
VC_EXPORT int VCVisualResource_SetFrameSyncTime (VCAttribute *attribute, uint32 frameSyncTime);
VC_EXPORT int VCVisualResource_SetStatisticsLevel (VCAttribute *attribute, uint8 statisticsLevel);
VC_EXPORT int VCVisualResource_SetAccumSamples (VCAttribute *attribute, uint16 accumSamples);
VC_EXPORT int VCVisualResource_Flatten(VCAttribute *attribute);

VC_EXPORT int VCVisualResource_GetName (VCAttribute *attribute, char **name);
VC_EXPORT int VCVisualResource_GetRenderer (VCAttribute *attribute, char **renderer);
VC_EXPORT int VCVisualResource_GetMode (VCAttribute *attribute, uint32 *mode);
VC_EXPORT int VCVisualResource_GetFrameRate (VCAttribute *attribute, float32 *frameRate);
VC_EXPORT int VCVisualResource_GetIod (VCAttribute *attribute, float32 *iod);
VC_EXPORT int VCVisualResource_GetConvergence (VCAttribute *attribute, float32 *convergence);
VC_EXPORT int VCVisualResource_GetBackground (VCAttribute *attribute, VCColour backGround);
VC_EXPORT int VCVisualResource_GetNearClip (VCAttribute *attribute, float32 *nearClip);
VC_EXPORT int VCVisualResource_GetFarClip (VCAttribute *attribute, float32 *farClip);
VC_EXPORT int VCVisualResource_GetFogColour (VCAttribute *attribute, VCColour fogColour);
VC_EXPORT int VCVisualResource_GetNearFog (VCAttribute *attribute, float32 *nearFog);
VC_EXPORT int VCVisualResource_GetFarFog (VCAttribute *attribute, float32 *farFog);
VC_EXPORT int VCVisualResource_GetLodScale (VCAttribute *attribute, float32 *lodScale);
VC_EXPORT int VCVisualResource_GetFrameSyncTime (VCAttribute *attribute, uint32 *frameSyncTime);
VC_EXPORT int VCVisualResource_GetStatisticsLevel (VCAttribute *attribute, uint8 *statisticsLevel);
VC_EXPORT int VCVisualResource_GetMaxStatisticsLevel (VCAttribute *attribute, uint8 *maxStatisticsLevel);
VC_EXPORT int VCVisualResource_GetAccumSamples (VCAttribute *attribute, uint16 *accumSamples);
VC_EXPORT int VCVisualResource_GetCapability (VCAttribute *attribute, uint32 *capability);
VC_EXPORT int VCVisualResource_GetActorId (VCAttribute *attribute, uint32 *actorId);

#define VCVisualResource_SetFogColor(a,c) VCVisualResource_SetFogColour(a,c)
#define VCVisualResource_GetFogColor(a,c) VCVisualResource_GetFogColour(a,c)


VC_EXPORT VCAttribute 	*VCAudioResource_Create 	(char *name,  uint32 mode, float32 iad, float32 volume,
                                                 float32 spreadingRollOff, float32 atmosAbsorb,char *hrtf,
                                                 char *resourceFileName);
VC_EXPORT VCAttribute 	*VCAudioResource_CreateData 	(VCAudioResourceData *audioData);
VC_EXPORT VCAttribute 	*VCEntity_AddAudioResourceData(VCEntity *entity, VCAudioResourceData *data);
VC_EXPORT VCAttribute 	*VCEntity_ddAudioResource 	(VCEntity *entity, char *name, uint32 mode, float32 iad,
                                                 float32 volume, float32 spreadingRollOff, float32 atmosAbsorb,
                                                 char *hrtf, char *resourceFileName);
VC_EXPORT int		 VCAudioResource_Set 		(VCAttribute *attribute, uint32 setMode,
                                                 uint32 clearMode, float32 *iad, float32 *volume,
                                                 float32 *spreadingRollOff, float32 *atmosphericAbsorption,
                                                 char *hrtf, char *resourceFileName);
VC_EXPORT int		 VCAudioResource_SetData 	(VCAttribute *attribute,VCAudioResourceData *audioData);
VC_EXPORT int		 VCAudioResource_Get 		(VCAttribute *attribute, char **name, uint32 *mode,
                                                 float32 *iad, float32 *volume,
                                                 float32 *spreadingRollOff, float32 *atmosphericAbsorption,
                                                 char **hrtf, char **resourceFileName);
VC_EXPORT int		 VCAudioResource_GetData 	(VCAttribute *attribute,VCAudioResourceData *audioData);
#define VCEntity_DetachAudioResource(e,a) VCEntity_DetachAttribute(e,a)
#define VCAudioResource_Delete(a) VCAttribute_Delete(a)

VC_EXPORT int		 VCAudioResource_SetIad 	(VCAttribute *attribute, float32 iad);
VC_EXPORT int		 VCAudioResource_SetMode (VCAttribute *attribute, uint32 mode);
VC_EXPORT int		 VCAudioResource_ModifyMode (VCAttribute *attribute, uint32 setMode, uint32 clearMode);
VC_EXPORT int		 VCAudioResource_SetVolume 	(VCAttribute *attribute, float32 volume);
VC_EXPORT int		 VCAudioResource_SetHrtf 	(VCAttribute *attribute, char *hrtf);
VC_EXPORT int		 VCAudioResource_SetResourceFileName (VCAttribute *attribute, char *resourceName);
VC_EXPORT int		 VCAudioResource_SetSpreadingRollOff (VCAttribute *attribute, float32 spreadingRollOff);
VC_EXPORT int		 VCAudioResource_SetAtmosphericAbsorption (VCAttribute *attribute,
                                                           float32 atmosphericAbsorption);

VC_EXPORT int		 VCAudioResource_GetName 	(VCAttribute *attribute, char **name);
VC_EXPORT int		 VCAudioResource_GetMode (VCAttribute *attribute, uint32 *mode);
VC_EXPORT int		 VCAudioResource_GetIad 	(VCAttribute *attribute, float32 *iad);
VC_EXPORT int		 VCAudioResource_GetVolume 	(VCAttribute *attribute, float32 *volume);
VC_EXPORT int		 VCAudioResource_GetHrtf 	(VCAttribute *attribute, char **hrtf);
VC_EXPORT int		 VCAudioResource_GetResourceFileName (VCAttribute *attribute, char **resourceName);
VC_EXPORT int 		 VCAudioResource_GetSpreadingRollOff (VCAttribute *attribute,
                                                      float32 *spreadingRollOff);
VC_EXPORT int		 VCAudioResource_GetAtmosphericAbsorption (VCAttribute *attribute,
                                                           float32 *atomsphericAbsorption);



VC_EXPORT VCAttribute 	*VCInputResource_Create 	(char *name, uint32 mode, VCInput *input);
VC_EXPORT VCAttribute 	*VCInputResource_CreateData 	(VCInputResourceData *inputData);
VC_EXPORT VCAttribute 	*VCEntity_AddInputResourceData(VCEntity *entity, VCInputResourceData *data);
VC_EXPORT VCAttribute 	*VCEntity_AddInputResource 	(VCEntity *entity, char *name, uint32 mode, VCInput *input);
VC_EXPORT int		 VCInputResource_Set 		(VCAttribute *attribute, uint32 setMode,
                                                 uint32 clearMode, VCInput *input);
VC_EXPORT int		 VCInputResource_SetData 	(VCAttribute *attribute, VCInputResourceData *inputData);
VC_EXPORT int		 VCInputResource_Get 		(VCAttribute *attribute, char **name,
                                                 uint32 *mode, VCInput **input);
VC_EXPORT int		 VCInputResource_GetData 	(VCAttribute *attribute, VCInputResourceData *inputData);
VC_EXPORT int		 VCInputResource_SetMode 	(VCAttribute *attribute, uint32 mode);
VC_EXPORT int		 VCInputResource_ModifyMode 	(VCAttribute *attribute, uint32 setMode, uint32 clearMode);
VC_EXPORT int		 VCInputResource_GetName 	(VCAttribute *attribute, char **name);
VC_EXPORT int		 VCInputResource_GetMode 	(VCAttribute *attribute, uint32 *mode);
VC_EXPORT int		 VCInputResource_GetInput 	(VCAttribute *attribute, VCInput **input);


#define VCEntity_DetachInputResource(e,a) VCEntity_DetachAttribute(e,a)
#define VCInputResource_Delete(a) VCAttribute_Delete(a)

VC_EXPORT VCAttribute 	*VCSensorResource_Create (char *name, uint32 mode, VCTracker *tracker, uint32 sensorId,
                                          float32 scaleTranslate[3], float32 scaleRotate[3],
                                          float32 translationCurveOrder[3], float32 rotationCurveOrder[3],
                                          dmPoint prePosition, dmPoint postPosition, dmEuler preEuler,
                                          dmEuler postEuler, float32 relativeSphere[6], VCPosition *position,
                                          VCConstraintsData *constraints);
VC_EXPORT VCAttribute 	*VCSensorResource_CreateData (VCSensorResourceData *sensorData);
VC_EXPORT VCAttribute 	*VCEntity_AddSensorResourceData(VCEntity *entity, VCSensorResourceData *data);
VC_EXPORT VCAttribute 	*VCEntity_AddSensorResource (VCEntity *entity, char *name, uint32 mode, VCTracker *tracker,
                                             uint32 sensorId, float32 scaleTranslate[3],
                                             float32 scaleRotate[3],float32  translationCurveOrder[3],
                                             float32 rotationCurveOrder[3], dmPoint prePosition,
                                             dmPoint postPosition, dmEuler preEuler, dmEuler postEuler,
                                             float32 relativeSphere[6],
                                             VCPosition *position, VCConstraintsData *constraints);

VC_EXPORT int		 VCSensorResource_Set (VCAttribute *attribute, uint32 setMode, uint32 clearMode,
                                       float32 scaleTranslate[3],
                                       float32 scaleRotate[3], float32 translationCurveOrder[3],
                                       float32 rotationCurveOrder[3], dmPoint prePosition,
                                       dmPoint postPosition, dmEuler preEuler, dmEuler postEuler,
                                       float32 relativeSphere[6], VCPosition *position,
                                       VCConstraintsData *constraints);
VC_EXPORT int		 VCSensorResource_SetData (VCAttribute *attribute, VCSensorResourceData *sensorData);
VC_EXPORT int		 VCSensorResource_Get (VCAttribute *attribute, char **name,
                                       uint32 *mode, VCTracker **tracker, uint32 *sensorId,
                                       float32 scaleTranslate[3], float32 scaleRotate[3],
                                       float32 translationCurveOrder[3], float32 rotationCurveOrder[3],
                                       dmPoint prePosition, dmPoint postPosition, dmEuler preEuler,
                                       dmEuler postEuler, float32 relativeSphere[6],
                                       VCPosition **position, VCConstraintsData *constraints);
VC_EXPORT int		 VCSensorResource_GetData (VCAttribute *attribute, VCSensorResourceData *sensorData);


#define VCEntity_DetachSensorResource(e,a) VCEntity_DetachAttribute(e,a)
#define VCSensorResource_Delete(a) VCAttribute_Delete(a)

VC_EXPORT int	VCSensorResource_ModifyMode(VCAttribute *attribute, uint32 setMode, uint32 clearMode);
VC_EXPORT int	VCSensorResource_SetMode(VCAttribute *attribute, uint32 mode);
VC_EXPORT int	VCSensorResource_SetTranslationScale(VCAttribute *attribute, float32 scaleTranslate[3]);
VC_EXPORT int	VCSensorResource_SetRotationScale(VCAttribute *attribute, float32 scaleRotate[3]);
VC_EXPORT int	VCSensorResource_SetTranslationCurveOrder(VCAttribute *attribute, float32 curveOrder[3]);
VC_EXPORT int	VCSensorResource_SetRotationCurveOrder(VCAttribute *attribute, float32 curveOrder[3]);
VC_EXPORT int	VCSensorResource_SetPrePosition(VCAttribute *attribute, dmPoint prePosition);
VC_EXPORT int	VCSensorResource_SetPostPosition(VCAttribute *attribute, dmPoint postPosition);
VC_EXPORT int	VCSensorResource_SetPreEuler(VCAttribute *attribute, dmEuler preEuler);
VC_EXPORT int	VCSensorResource_SetPostEuler(VCAttribute *attribute, dmEuler postEuler);
VC_EXPORT int	VCSensorResource_SetRelativeSphere(VCAttribute *attribute, float32 relativeSphere[6]);
VC_EXPORT int	VCSensorResource_SetPosition(VCAttribute *attribute, VCPosition *pos);
VC_EXPORT int	VCSensorResource_SetConstraints(VCAttribute *attribute, VCConstraintsData *constraints);
VC_EXPORT int	VCSensorResource_GetName(VCAttribute *attribute, char **name);
VC_EXPORT int	VCSensorResource_GetMode(VCAttribute *attribute, uint32 *mode);
VC_EXPORT int	VCSensorResource_GetTracker(VCAttribute *attribute, VCTracker **tracker);
VC_EXPORT int	VCSensorResource_GetSensorId(VCAttribute *attribute, uint32 *sensorId);
VC_EXPORT int	VCSensorResource_GetTranslationScale(VCAttribute *attribute, float32 scaleTranslate[3]);
VC_EXPORT int	VCSensorResource_GetRotationScale(VCAttribute *attribute, float32 scaleRotate[3]);
VC_EXPORT int	VCSensorResource_GetTranslationCurveOrder(VCAttribute *attribute, float32 curveOrder[3]);
VC_EXPORT int	VCSensorResource_GetRotationCurveOrder(VCAttribute *attribute, float32 curveOrder[3]);
VC_EXPORT int	VCSensorResource_GetPrePosition(VCAttribute *attribute, dmPoint prePosition);
VC_EXPORT int	VCSensorResource_GetPostPosition(VCAttribute *attribute, dmPoint postPosition);
VC_EXPORT int	VCSensorResource_GetPreEuler(VCAttribute *attribute, dmEuler preEuler);
VC_EXPORT int	VCSensorResource_GetPostEuler(VCAttribute *attribute, dmEuler postEuler);
VC_EXPORT int	VCSensorResource_GetRelativeSphere(VCAttribute *attribute, float32 relativeSphere[6]);
VC_EXPORT int	VCSensorResource_GetPosition(VCAttribute *attribute, VCPosition **pos);
VC_EXPORT int	VCSensorResource_GetConstraints(VCAttribute *attribute, VCConstraintsData *constraints);


VC_EXPORT VCAttribute 	*VCVectorIntersect_Create 	(uint32 mode, float32 length, uint32 mask,
                                                 int32 numIntersections);
VC_EXPORT VCAttribute 	*VCVectorIntersect_CreateData 	(VCVectorIntersectData *intersectData);

VC_EXPORT VCAttribute 	*VCEntity_AddVectorIntersectData(VCEntity *entity, VCVectorIntersectData *data);
VC_EXPORT VCAttribute	*VCEntity_AddVectorIntersect 	(VCEntity *entity, uint32 mode, float32 length,
                                                 uint32 mask, int32 numIntersections);
VC_EXPORT int		 VCVectorIntersect_Set 		(VCAttribute *attribute, uint32 setMode,
                                                 uint32 clearMode, float32 *length, uint32 setMask,
                                                 uint32 clearMaks, int32 *numIntersections);
VC_EXPORT int		 VCVectorIntersect_SetData 	(VCAttribute *attribute, VCVectorIntersectData *intersectData);
VC_EXPORT int		 VCVectorIntersect_Get 		(VCAttribute *attribute, uint32 *mode,
                                                 float32 *length, uint32 *mask, int32 *numIntersections,
                                                 VCIntersection **intersection);
VC_EXPORT int		 VCVectorIntersect_GetData (VCAttribute *attribute, VCVectorIntersectData *intersectData);

#define VCVectorIntersect_Delete(a) VCAttribute_Delete(a)
#define VCEntity_DetachVectorIntersect(e,a) VCEntity_DetachAttribute(e,a)


VC_EXPORT int		VCVectorIntersect_SetMode 	(VCAttribute *attribute, uint32 mode);
VC_EXPORT int		VCVectorIntersect_ModifyMode 	(VCAttribute *attribute, uint32 setMode, uint32 clearMode);
VC_EXPORT int		VCVectorIntersect_SetLength 	(VCAttribute *attribute, float32 kength);
VC_EXPORT int		VCVectorIntersect_SetIntersectMask (VCAttribute *attribute, uint32 mask);
VC_EXPORT int		VCVectorIntersect_ModifyIntersectMask (VCAttribute *attribute, uint32 setMask,
                                                        uint32 clearMask);
VC_EXPORT int		VCVectorIntersect_SetNumberIntersections (VCAttribute *attribute, int32 numIntersections);
VC_EXPORT int		VCVectorIntersect_SetIntersection (VCAttribute *attribute, VCIntersection *intersection);

VC_EXPORT int		VCVectorIntersect_GetMode (VCAttribute *attribute, uint32 *mode);
VC_EXPORT int		VCVectorIntersect_GetLength (VCAttribute *attribute, float32 *length);
VC_EXPORT int		VCVectorIntersect_GetIntersectMask (VCAttribute *attribute, uint32 *mask);
VC_EXPORT int		VCVectorIntersect_GetNumberIntersections (VCAttribute *attribute, int32 numIntersections);
VC_EXPORT int		VCVectorIntersect_GetIntersection (VCAttribute *attribute, VCIntersection **intersection);
VC_EXPORT void 		*VCVectorIntersect_AttachIntersectionCreateCallback(VCAttribute *intersect,
                                                                    VCIntersection_Func func, void *data);
VC_EXPORT void 		*VCVectorIntersect_AttachIntersectionUpdateCallback(VCAttribute *intersect,
                                                                    VCIntersection_Func func, void *data);
VC_EXPORT void 		*VCVectorIntersect_AttachIntersectionDeleteCallback(VCAttribute *intersect,
                                                                    VCIntersection_Func func, void *data);

VC_EXPORT int		VCVectorIntersect_DetachIntersectionCreateCallback(VCAttribute *intersect, void *callbackHandle);
VC_EXPORT int		VCVectorIntersect_DetachIntersectionUpdateCallback(VCAttribute *intersect, void *callbackHandle);

VC_EXPORT int		VCVectorIntersect_DetachIntersectionDeleteCallback(VCAttribute *intersect, void *callbackHandle);






VC_EXPORT VCAttribute 	*VCVisualEffect_Create		(uint32 mode, uint32 type, dmPoint offset, float32 *data,
                                                 char *texture);
VC_EXPORT VCAttribute 	*VCVisualEffect_CreateData	(VCVisualEffectData *visEffectData);
VC_EXPORT VCAttribute 	*VCEntity_AddVisualEffectData(VCEntity *entity, VCVisualEffectData *data);
VC_EXPORT VCAttribute	*VCEntity_AddVisualEffect 	(VCEntity *entity, uint32 mode, uint32 type,
                                                 dmPoint offset, float *data, char *texture);
VC_EXPORT int		 VCVisualEffect_Set		(VCAttribute *attribute, uint32 setMode, uint32 clearMode,
                                                 uint32 *type, dmPoint offset, float data[72], char *texture);
VC_EXPORT int		 VCVisualEffect_SetData		(VCAttribute *attribute,VCVisualEffectData *visEffectData);
VC_EXPORT int		 VCVisualEffect_Get 		(VCAttribute *attribute, uint32 *mode, uint32 *type,
                                                 dmPoint offset, float32 data[72], char **texture);
VC_EXPORT int		 VCVisualEffect_GetData		(VCAttribute *attribute,VCVisualEffectData *visEffectData);
#define VCEntity_DetachVisualEffect(e,a) VCEntity_DetachAttribute(e,a)
#define VCVisualEffect_Delete(a) VCAttribute_Delete(a)
#define VCEntity_AddVisualEffectExplosion(e,t,o,te) VCEntity_AddVisualEffect(e,VC_VISUALEFFECT_MODE_EXPLOSION,t,o,NULL,te)
#define VCVisualEffect_CreateExplosion(t,o,te) VCVisualEffect_Create(VC_VISUALEFFECT_MODE_EXPLOSION,t,o,NULL,te)
#define VCVisualEffect_StartExplosion(a,o) VCVisualEffect_Set(a,VC_VISUALEFFECT_ENABLE,0,NULL,o,NULL,NULL)

VC_EXPORT int		 VCVisualEffect_SetMode		(VCAttribute *attribute, uint32 mode);
VC_EXPORT int		 VCVisualEffect_ModifyMode 	(VCAttribute *attribute, uint32 setMode, uint32 clearMode);
VC_EXPORT int		 VCVisualEffect_SetType		(VCAttribute *attribute, uint32 type);
VC_EXPORT int		 VCVisualEffect_SetOffset 	(VCAttribute *attribute, dmPoint offset);
VC_EXPORT int		 VCVisualEffect_SetInfo		(VCAttribute *attribute, float32 info[72]);
VC_EXPORT int		 VCVisualEffect_SetTexture 	(VCAttribute *attribute, char *texture);

VC_EXPORT int		 VCVisualEffect_GetMode		(VCAttribute *attribute, uint32 *mode);
VC_EXPORT int		 VCVisualEffect_GetType		(VCAttribute *attribute, uint32 *type);
VC_EXPORT int		 VCVisualEffect_GetOffset 	(VCAttribute *attribute, dmPoint offset);
VC_EXPORT int		 VCVisualEffect_GetInfo		(VCAttribute *attribute, float32 info[72]);
VC_EXPORT int		 VCVisualEffect_GetTexture 	(VCAttribute *attribute, char **texture);


VC_EXPORT VCAttribute 	*VCDynamics_Create 	(uint32 mode, float32 imass, float32 gmass, dmPoint centre,
                                         float32 *iTensor, float32 spring, float32 damper,
                                         float32 sFriction, float32 dFriction);
VC_EXPORT VCAttribute 	*VCDynamics_CreateData 	(VCDynamicsData *dynamicData);
VC_EXPORT int		 VCDynamics_Get 	(VCAttribute *attribute, uint32 *mode, float32 *imass,
                                         float32 *gmass, dmPoint centre, float32 itensor[6],
                                         float32 *spring, float32 *damper, float32 *sFriction,
                                         float32 *dFricition);
VC_EXPORT int		 VCDynamics_GetData 	(VCAttribute *attribute, VCDynamicsData *dynamicData);
VC_EXPORT VCAttribute 	*VCEntity_AddDynamicsData(VCEntity *entity, VCDynamicsData *data);
VC_EXPORT VCAttribute 	*VCEntity_AddDynamics	(VCEntity *entity, uint32 mode, float32 imass, float32 gmass,
                                         dmPoint centre, float32 *iTensor, float32 spring,
                                         float32 damper, float32 sFriction, float32 dFriction);
VC_EXPORT int		 VCDynamics_Set 	(VCAttribute *attribute, uint32 setMode,
                                         uint32 clearMode, float32 *imass, float32 *gmass,
                                         dmPoint centre, float32 *iTensor, float32 *spring,
                                         float32 *damper, float32 *sFriction, float32 *dFriction);
VC_EXPORT int		 VCDynamics_SetData 	(VCAttribute *attribute, VCDynamicsData *dynamicData);
#define VCEntity_DetachDynamics(e,a) VCEntity_DetachAttribute(e,a)
#define VCDynamics_Delete(a) VCAttribute_Delete(a)

VC_EXPORT int		 VCDynamics_SetMode	(VCAttribute *attribute, uint32 mode);
VC_EXPORT int		 VCDynamics_ModifyMode 	(VCAttribute *attribute, uint32 setMode, uint32 clearMode);
VC_EXPORT int		 VCDynamics_SetImass 	(VCAttribute *attribute, float32 imass);
VC_EXPORT int		 VCDynamics_SetGmass 	(VCAttribute *attribute, float32 gmass);
VC_EXPORT int		 VCDynamics_SetCentre 	(VCAttribute *attribute, dmPoint centre);
VC_EXPORT int		 VCDynamics_SetItensor 	(VCAttribute *attribute, float32 *itensor);
VC_EXPORT int		 VCDynamics_SetSpring 	(VCAttribute *attribute, float32 spring);
VC_EXPORT int		 VCDynamics_SetDamper 	(VCAttribute *attribute, float32 damper);
VC_EXPORT int		 VCDynamics_SetStaticFriction 	(VCAttribute *attribute, float32 sFriction);
VC_EXPORT int		 VCDynamics_SetDynamicFriction 	(VCAttribute *attribute, float32 dFriction);
VC_EXPORT int		 VCDynamics_GetMode 	(VCAttribute *attribute, uint32 *mode);
VC_EXPORT int		 VCDynamics_GetImass 	(VCAttribute *attribute, float32 *imass);
VC_EXPORT int		 VCDynamics_GetGmass 	(VCAttribute *attribute, float32 *gmass);
VC_EXPORT int		 VCDynamics_GetCentre 	(VCAttribute *attribute, dmPoint centre);
VC_EXPORT int		 VCDynamics_GetItensor 	(VCAttribute *attribute, float32 itensor[6]);
VC_EXPORT int		 VCDynamics_GetSpring 	(VCAttribute *attribute, float32 *spring);
VC_EXPORT int		 VCDynamics_GetDamper 	(VCAttribute *attribute, float32 *damper);
VC_EXPORT int		 VCDynamics_GetStaticFriction 	(VCAttribute *attribute, float32 *sFriction);
VC_EXPORT int		 VCDynamics_GetDynamicFriction 	(VCAttribute *attribute, float32 *dFriction);

/* Higher level physics definitions. */

VC_EXPORT void      VCInertialProps_FromSolidCylinder (VCInertialProps *r,
                                                    float32          mass,
                                                    float32          radius,
                                                    float32          length);

VC_EXPORT void      VCInertialProps_FromThinWalledCylinder (VCInertialProps *r,
                                                         float32         mass,
                                                         float32         radius,
                                                         float32         length);
VC_EXPORT void      VCInertialProps_FromThickWalledCylinder (VCInertialProps *r,
                                                          float32         mass,
                                                          float32         radius1,
                                                          float32         radius2,
                                                          float32         length);

VC_EXPORT void      VCInertialProps_FromSolidBox (VCInertialProps *r,
                                               float32          mass,
                                               float32          xSize,
                                               float32          ySize,
                                               float32          zSize);

VC_EXPORT void      VCInertialProps_FromThinWalledBox (VCInertialProps *r,
                                                    float32          mass,
                                                    float32          xSize,
                                                    float32          ySize,
                                                    float32          zSize);
VC_EXPORT void      VCInertialProps_FromThickWalledBox (VCInertialProps *r,
                                                     float32          mass,
                                                     float32          xSize1,
                                                     float32          xSize2,
                                                     float32          ySize,
                                                     float32          zSize1,
                                                     float32          zSize2);

VC_EXPORT void      VCInertialProps_FromSolidCone (VCInertialProps *r,
                                                float32         mass,
                                                float32         radius,
                                                float32         length);

VC_EXPORT void      VCInertialProps_Translate (VCInertialProps *r,
                                            const VCInertialProps *p,
                                            const dmVector         v);

VC_EXPORT void      VCInertialProps_FromThinWalledCone (VCInertialProps *r,
                                                     float32         mass,
                                                     float32         radius,
                                                     float32         length);
VC_EXPORT void      VCInertialProps_FromThickWalledCone (VCInertialProps *r,
                                                      float32         mass,
                                                      float32         radius1,
                                                      float32         radius2,
                                                      float32         length);
VC_EXPORT void      VCInertialProps_FromSolidSphere (VCInertialProps *r,
                                                  float32         mass,
                                                  float32         radius);
VC_EXPORT void      VCInertialProps_FromThinWalledSphere (VCInertialProps *r,
                                                       float32         mass,
                                                       float32         radius);

VC_EXPORT void      VCInertialProps_FromThickWalledSphere (VCInertialProps *r,
                                                        float32         mass,
                                                        float32         radius1,
                                                        float32         radius2);

VC_EXPORT void      VCInertialProps_Rotate (VCInertialProps *r,
                                         const VCInertialProps *p,
                                         const dmQuaternion     q);

VC_EXPORT void      VCInertialProps_Combine (VCInertialProps *r,
                                          const VCInertialProps *p,
                                          const VCInertialProps *q);

VC_EXPORT void      VCDynamics_SetInertialProps (VCAttribute           *attribute,
                                              const VCInertialProps *p,
                                              int                    flags);
VC_EXPORT void      VCDynamics_SetBounceProps (VCAttribute *attribute,
                                            float32      velocityRatio);

/* Force definitions */

VC_EXPORT VCAttribute 	*VCForce_Create 	(uint32 mode, dmVector force, dmPoint point);
VC_EXPORT VCAttribute 	*VCForce_CreateData 	(VCForceData *forceData);
VC_EXPORT int		 VCForce_Get		(VCAttribute *attribute, uint32 *mode, dmVector force, dmPoint point);
VC_EXPORT int		 VCForce_GetData 	(VCAttribute *attribute, VCForceData *forceData);
VC_EXPORT VCAttribute 	*VCEntity_AddForceData(VCEntity *entity, VCForceData *data);
VC_EXPORT VCAttribute 	*VCEntity_AddForce 	(VCEntity *entity, uint32 mode, dmVector force, dmPoint point);
VC_EXPORT int		 VCForce_Set		(VCAttribute *attribute, uint32 setMode,
                                         uint32 clearMode, dmVector force, dmPoint point);
VC_EXPORT int		 VCForce_SetData 	(VCAttribute *attribute, VCForceData *forceData);



#define VCEntity_DetachForce(e,a) VCEntity_DetachAttribute(e,a)
#define VCForce_Delete(a) VCAttribute_Delete(a)

VC_EXPORT int		 VCForce_SetMode 	(VCAttribute *attribute, uint32 mode);
VC_EXPORT int		 VCForce_ModifyMode	 (VCAttribute *attribute, uint32 setMode, uint32 clearMode);
VC_EXPORT int		 VCForce_SetForce 	(VCAttribute *attribute, dmVector force);
VC_EXPORT int		 VCForce_SetPoint 	(VCAttribute *attribute, dmPoint point);
VC_EXPORT int		 VCForce_GetMode (VCAttribute *attribute, uint32 *mode);
VC_EXPORT int		 VCForce_GetForce (VCAttribute *attribute, dmVector force);
VC_EXPORT int		 VCForce_GetPoint (VCAttribute *attribute, dmPoint point);



VC_EXPORT VCAttribute 	*VCZone_Create 		(uint32 mode, uint32 actorMask);
VC_EXPORT VCAttribute 	*VCZone_CreateData 	(VCZoneData *zoneData);
VC_EXPORT int		 VCZone_Get 		(VCAttribute *attribute, uint32 *mode, uint32 *actorMask);
VC_EXPORT int		 VCZone_GetData 	(VCAttribute *attribute, VCZoneData *zoneData);
VC_EXPORT VCAttribute 	*VCEntity_AddZoneData(VCEntity *entity, VCZoneData *data);
VC_EXPORT VCAttribute 	*VCEntity_AddZone 	(VCEntity *entity, uint32 mode, uint32 actorMask);
VC_EXPORT int32		 VCZone_Set 		(VCAttribute *attribute, uint32 setMode,
                                         uint32 clearMode, uint32 setActorMask, uint32 clearActorMask);
VC_EXPORT int		 VCZone_SetData 	(VCAttribute *attribute, VCZoneData *zoneData);
#define VCEntity_DetachZone(e,a) VCEntity_DetachAttribute(e,a)
#define VCZone_Delete(a) VCAttribute_Delete(a)

VC_EXPORT int		VCZone_SetMode 		(VCAttribute *attribute, uint32 mode);
VC_EXPORT int		VCZone_ModifyMode 	(VCAttribute *attribute, uint32 setMode, uint32 clearMode);
VC_EXPORT int		VCZone_SetActorMask 	(VCAttribute *attribute, uint32 mask);
VC_EXPORT int		VCZone_ModifyActorMask 	(VCAttribute *attribute, uint32 setMask, uint32 clearMask);
VC_EXPORT int		VCZone_GetMode(VCAttribute *attribute, uint32 *mode);
VC_EXPORT int		VCZone_GetActorMask(VCAttribute *attribute, uint32 *mask);
VC_EXPORT void		_vcPrintHelp(int actor);
VC_EXPORT void 		_VCPrintExtraHelp();
VC_EXPORT int		VC_GetKeycode(char *string, uint32 *keyCode);

VC_EXPORT void 		*VC_AttachSystemHandleCallback(VC_SystemHandleFunc function, void *data);
VC_EXPORT int		 VC_AttachSystemHandle(dpHandle handle);
VC_EXPORT int		 VC_DetachSystemHandle(dpHandle handle);



VC_EXPORT VCDynamicVisual	*VCDynamicVisual_Create(char *, uint32);
VC_EXPORT int			 VCDynamicVisual_Delete(VCDynamicVisual *);
VC_EXPORT VCLod 		*VCDynamicVisual_AddLod(VCDynamicVisual *, char *, float, float, dmPoint);
VC_EXPORT int			 VCDynamicVisual_AttachLod(VCDynamicVisual *, VCLod *);
VC_EXPORT int			 VCDynamicVisual_DetachLod(VCDynamicVisual *, VCLod *);
VC_EXPORT VCLod 		*VCDynamicVisual_GetFirstLod(VCDynamicVisual *item, VCDynamicVisual_Traverse *trv);
VC_EXPORT VCLod 		*VCDynamicVisual_GetNextLod(VCDynamicVisual_Traverse *trv);
VC_EXPORT VCLod 		*VCDynamicVisual_GetIndexedLod(VCDynamicVisual *item, int index,
                                                               VCDynamicVisual_Traverse *trv);
VC_EXPORT VCLod 		*VCDynamicVisual_GetNamedLod(VCDynamicVisual *item, char *name,
                                                             VCDynamicVisual_Traverse *trv);
VC_EXPORT int			 VCDynamicVisual_ApplyPerLod(VCDynamicVisual *item, VCLod_TraverseFunc func,
                                                             void *data);
VC_EXPORT int			 VCDynamicVisual_ApplyPerGeogroup(VCDynamicVisual *item, VCGeogroup_TraverseFunc func,
                                                                  void *data);
VC_EXPORT int			 VCDynamicVisual_ApplyPerGeometry(VCDynamicVisual *item, VCGeometry_TraverseFunc func,
                                                                  void *data);
VC_EXPORT int			 VCDynamicVisual_SetBoundBox(VCDynamicVisual *dv, VCGeometry_BoundBox *bbox);
VC_EXPORT int			 VCDynamicVisual_GetBoundBox(VCDynamicVisual *dv, VCGeometry_BoundBox *bbox);
VC_EXPORT int			 VCDynamicVisual_GetNearestVertex(VCDynamicVisual *, dmPoint, float,
                                                                  VCVertex_Reference *);
VC_EXPORT VCDynamicVisual 	*VCDynamicVisual_CreateFromFile(char8 *file);
VC_EXPORT int			 VCDynamicVisual_WriteToFile(VCDynamicVisual *visual, char *file);

VC_EXPORT VCLod 		*VCLod_Create(char *, float, float, dmPoint);
VC_EXPORT int			 VCLod_Delete(VCLod *);
VC_EXPORT int			 VCLod_Get(VCLod *, char **, float *in, float *out, dmPoint reference);
VC_EXPORT int			 VCLod_Set(VCLod *lod, char *, float *in, float *out, dmPoint reference);
VC_EXPORT int			 VCLod_SetInOutDistance(VCLod *lod, float in, float out);
VC_EXPORT int 			 VCLod_SetReference(VCLod *lod, dmPoint reference);
VC_EXPORT int			 VCLod_SetName(VCLod *lod, char *);
VC_EXPORT int			 VCLod_GetName(VCLod *lod, char **);
VC_EXPORT int			 VCLod_GetInOutDistance(VCLod *lod, float *in, float *out);
VC_EXPORT int			 VCLod_GetReference(VCLod *lod, dmPoint reference);
VC_EXPORT int 			 VCLod_GetMode(VCLod *, uint32 *mode);
VC_EXPORT int			 VCLod_ModifyMode(VCLod *, uint32 setMode, uint32 clearMode);
VC_EXPORT int			 VCLod_AttachLod(VCLod *lod, VCLod *child);
VC_EXPORT int			 VCLod_DetachLod(VCLod *lod, VCLod *child);
VC_EXPORT int			 VCLod_AttachGeogroup(VCLod *lod, VCGeogroup *geogroup);
VC_EXPORT int			 VCLod_DetachGeogroup(VCLod *lod, VCGeogroup *geogroup);
VC_EXPORT VCGeogroup 		*VCLod_AddGeogroup(VCLod *lod,
                                                   VCVertex_Type, uint32, uint8, uint8, uint8, uint8,
                                                   char *, char *);
VC_EXPORT VCGeogroup 		*VCLod_GetFirstGeogroup(VCLod *lod, VCVertex_Type search,
                                                        VCLod_Traverse *traverse);
VC_EXPORT VCGeogroup 		*VCLod_GetNextGeogroup(VCLod_Traverse *traverse);
VC_EXPORT int			 VCLod_SetBoundBox(VCLod *lod, VCGeometry_BoundBox *bbox);
VC_EXPORT int			 VCLod_GetBoundBox(VCLod *lod, VCGeometry_BoundBox *bbox);
VC_EXPORT int			 VCLod_GetNearestVertex(VCLod *lod, dmPoint point, float dist,
                                                        VCVertex_Reference *ref);
VC_EXPORT int			 VCLod_ApplyPerGeogroup(VCLod *lod, VCGeogroup_TraverseFunc func,
                                                        void *data);
VC_EXPORT int			 VCLod_ApplyPerGeometry(VCLod *lod, VCGeometry_TraverseFunc func,
                                                        void *data);


VC_EXPORT VCGeogroup 		*VCGeogroup_Create(VCVertex_Type, uint32, uint8, uint8, uint8, uint8,
                                                   char *, char *);
VC_EXPORT int			 VCGeogroup_Delete(VCGeogroup *);
VC_EXPORT VCGeometry 		*VCGeogroup_AddGeometry(VCGeogroup *, VCGeometry_Type,
                                                        VCVertex_Type, uint32,VCVertex,
                                                        uint32, VCConnectionData *);
VC_EXPORT VCGeometry 		*VCGeogroup_AddText(VCGeogroup *group, char *str, uint32 size,
                                                    uint8 font, dmPoint position, dmEuler orientation,
                                                    dmScale scale);

VC_EXPORT VCGeometry 		*VCGeogroup_AddPointList(VCGeogroup *, VCVertex_Type, uint32,
                                              VCVertex, float32);
VC_EXPORT int			 VCGeogroup_Get(VCGeogroup *group, VCVertex_Type *format,
                                                uint32 *decal, uint8 *faceted, uint8 *lock,
                                                uint8 *drawMode, uint8 *drawWidth,
                                                char **fmat, char **bmat);
VC_EXPORT int			 VCGeogroup_Set(VCGeogroup *group,
                                                uint32 *decal, uint8 *faceted, uint8 *lock,
                                                uint8 *drawMode, uint8 *drawWidth,
                                                VCVertex_Type *format, char *fmat, char *bmat);
VC_EXPORT int			 VCGeogroup_SetFrontMaterial(VCGeogroup *group, char *fmat);
VC_EXPORT int			 VCGeogroup_SetBackMaterial(VCGeogroup *group, char *bmat);
VC_EXPORT int			 VCGeogroup_SetMaterialAll(VCGeogroup *group, char *fmat, char *bmat);
VC_EXPORT int			 VCGeogroup_SetVertexFormat(VCGeogroup *group, VCVertex_Type format);
VC_EXPORT int			 VCGeogroup_SetMode(VCGeogroup *group, uint32 mode);
VC_EXPORT int			 VCGeogroup_ModifyMode(VCGeogroup *group, uint32 setMode, uint32 clearMode);
VC_EXPORT int			 VCGeogroup_GetMode(VCGeogroup *group, uint32 *mode);
VC_EXPORT int			 VCGeogroup_GetFrontMaterial(VCGeogroup *group, char **fmat);
VC_EXPORT int			 VCGeogroup_GetBackMaterial(VCGeogroup *group, char **bmat);
VC_EXPORT int			 VCGeogroup_GetMaterialAll(VCGeogroup *group, char **fmat, char **bmat);
VC_EXPORT int			 VCGeogroup_GetVertexFormat(VCGeogroup *group, VCVertex_Type *format);
VC_EXPORT int			 VCGeogroup_AttachGeometry(VCGeogroup *geogroup, VCGeometry *geometry);
VC_EXPORT int			 VCGeogroup_DetachGeometry(VCGeogroup *geogroup, VCGeometry *geometry);
VC_EXPORT VCGeometry		*VCGeogroup_GetFirstGeometry(VCGeogroup *geogroup, VCGeometry_Type search,
                                                             VCGeogroup_Traverse *traverse);
VC_EXPORT VCGeometry 		*VCGeogroup_GetNextGeometry(VCGeogroup_Traverse *traverse);
VC_EXPORT int			 VCGeogroup_SetBoundBox(VCGeogroup *geogroup, VCGeometry_BoundBox *bbox);
VC_EXPORT int			 VCGeogroup_GetBoundBox(VCGeogroup *geogroup, VCGeometry_BoundBox *bbox);
VC_EXPORT int			 VCGeogroup_GetNearestVertex(VCGeogroup *geogroup, dmPoint point, float dist,
                                                             VCVertex_Reference *ref);
VC_EXPORT int			 VCGeogroup_ApplyPerGeometry(VCGeogroup *group, VCGeometry_TraverseFunc func,
                                                             void *data);

VC_EXPORT VCGeometry 		*VCGeometry_Create(VCGeometry_Type, VCVertex_Type, uint32, VCVertex,
                                                   uint32, VCConnectionData *);
VC_EXPORT int			 VCGeometry_Delete(VCGeometry *);
VC_EXPORT int			 VCGeometry_Get(VCGeometry *geometry, uint32 *mode, uint32 *noVertices);
VC_EXPORT int			 VCGeometry_Set(VCGeometry *geometry, uint32 setMode, uint32 clearMode,
                                                uint32 noVertices, VCVertex data);
VC_EXPORT int			 VCPmesh_SetVertexList(VCGeometry *geometry, uint32 noVertices, VCVertex data);
VC_EXPORT int			 VCPmesh_GetNoVertices(VCGeometry *geometry, uint32 *noVertices);
VC_EXPORT int			 VCTristrip_SetVertexList(VCGeometry *geometry, uint32 noVertices, VCVertex data);
VC_EXPORT int			 VCTristrip_GetNoVertices(VCGeometry *geometry, uint32 *noVertices);
VC_EXPORT int			 VCPolystrip_SetVertexList(VCGeometry *geometry, uint32 noVertices, VCVertex data);
VC_EXPORT int			 VCPolystrip_GetNoVertices(VCGeometry *geometry, uint32 *noVertices);
VC_EXPORT int			 VCPolygon_SetVertexList(VCGeometry *geometry, uint32 noVertices, VCVertex data);
VC_EXPORT int			 VCPolygon_GetNoVertices(VCGeometry *geometry, uint32 *noVertices);
VC_EXPORT int			 VCVector_SetVertexList(VCGeometry *geometry, uint32 noVertices, VCVertex data);
VC_EXPORT int			 VCVector_SetThickness(VCGeometry *geometry, uint32 thickness);
VC_EXPORT int			 VCVector_GetThickness(VCGeometry *geometry, uint32 *thick);
VC_EXPORT int			 VCVector_GetNoVertices(VCGeometry *geometry, uint32 *noVertices);
VC_EXPORT int			 VCSphereList_SetVertexList(VCGeometry *geometry, uint32 noVertices, VCVertex data);
VC_EXPORT int			 VCSphereList_SetDicingHints(VCGeometry *geometry, uint32 dice_u, uint32 dice_v);
VC_EXPORT int			 VCSphereList_GetDicingHints(VCGeometry *geometry, uint32 *dice_u, uint32 *dice_v);
VC_EXPORT int			 VCSphereList_GetNoVertices(VCGeometry *geometry, uint32 *noVertices);
VC_EXPORT int			 VCGeometry_Modify(VCGeometry *geometry, uint32 noVertices, VCVertex data);
VC_EXPORT int			 VCGeometry_Flush(VCGeometry *geometry);
VC_EXPORT int			 VCGeometry_AttachConnectionList(VCGeometry *geom, VCConnectionList *connect);
VC_EXPORT int			 VCGeometry_GetFirstVertex(VCGeometry *geometry, VCVertex_Reference *ref);
VC_EXPORT int			 VCGeometry_GetNextVertex(VCVertex_Reference *ref);
VC_EXPORT int			 VCGeometry_GetIndexedVertex(VCGeometry *geometry, uint32 index,
                                                             VCVertex_Reference *ref);
VC_EXPORT VCConnectionList 	*VCGeometry_GetFirstConnectionList(VCGeometry *geometry,
                                                                   VCGeometry_Traverse *traverse);
VC_EXPORT VCConnectionList 	*VCGeometry_GetNextConnectionList(VCGeometry_Traverse *traverse);
VC_EXPORT int			 VCGeometry_SetBoundBox(VCGeometry *geometry, VCGeometry_BoundBox *box);
VC_EXPORT int			 VCGeometry_GetBoundBox(VCGeometry *geometry, VCGeometry_BoundBox *box);
VC_EXPORT int			 VCGeometry_GetNearestVertex(VCGeometry *geometry, dmPoint point, float dist,
                                                             VCVertex_Reference *ref);

VC_EXPORT VCGeometry 		*VCText_Create(char *, uint32, uint8, dmPoint, dmEuler, dmScale);
VC_EXPORT int			 VCText_Delete(VCGeometry *);
VC_EXPORT int			 VCText_ModifyMode(VCGeometry *geometry, uint32 setMode, uint32 clearMode);
VC_EXPORT int			 VCText_Set(VCGeometry *geometry, uint8 *font, dmPoint pos,
                                            dmEuler orient, dmScale scale, char *text);
VC_EXPORT int			 VCText_Get(VCGeometry *geometry, uint8 *font, dmPoint pos, dmEuler orient,
                                            dmScale scale, char **text);
VC_EXPORT int			 VCText_GetMode(VCGeometry *geometry, uint32 *mode);
VC_EXPORT int			 VCText_SetFont(VCGeometry *geometry, uint8 font);
VC_EXPORT int			 VCText_SetPositionOrientationScale(VCGeometry *geometry, dmPoint pos,
                                        dmEuler orient, dmScale scale);
VC_EXPORT int			 VCText_SetText(VCGeometry *geometry, char *text);
VC_EXPORT int			 VCText_GetFont(VCGeometry *geometry, uint8 *font);
VC_EXPORT int			 VCText_GetPositionOrientationScale(VCGeometry *geometry, dmPoint pos,
                                                                    dmEuler orient, dmScale scale);
VC_EXPORT int			 VCText_GetText(VCGeometry *geometry, char **text);

VC_EXPORT VCConnectionList 	*VCConnectionList_Create(uint32, VCConnectionData *);
VC_EXPORT int			 VCConnectionList_Delete(VCConnectionList *);
VC_EXPORT int			 VCConnectionList_Get(VCConnectionList *connect, uint32 *noConnections, VCConnectionData **);
VC_EXPORT VCConnectionList 	*VCPmesh_AddConnectionList(VCGeometry *, uint32, VCConnectionData *);
VC_EXPORT int			 VCConnectionList_GetFirstConnection(VCConnectionList *connect,
                                                                     VCConnection_Reference *ref);
VC_EXPORT int			 VCConnectionList_GetNextConnection(VCConnection_Reference *ref);
VC_EXPORT int			 VCPmesh_GetConnectionData(VCGeometry *, uint32 *, VCConnectionData **);
VC_EXPORT int			 VCPmesh_GetFirstConnection(VCGeometry *, VCConnection_Reference *);
VC_EXPORT int			 VCPmesh_GetNextConnection(VCConnection_Reference *);

VC_EXPORT VCGeometry 		*VCPointList_Create(VCVertex_Type, uint32, VCVertex, float32);
VC_EXPORT int			 VCPointList_Set(VCGeometry *, uint32, uint32,uint32, VCVertex, float32);
VC_EXPORT int			 VCPointList_Get(VCGeometry *, uint32 *, uint32 *, float *);
VC_EXPORT int			 VCPointList_SetVertexList(VCGeometry *, uint32, VCVertex);
VC_EXPORT int			 VCPointList_GetNoVertices(VCGeometry *, uint32 *);
VC_EXPORT int			 VCPointList_SetPointSize(VCGeometry *, float32);
VC_EXPORT int			 VCPointList_GetPointSize(VCGeometry *, float32 *);
VC_EXPORT int			 VCPointList_Flush(VCGeometry *);
VC_EXPORT int			 VCPointList_Modify(VCGeometry *,uint32, VCVertex, float32);

/* callback Function */
VC_EXPORT void			*VCDynamicVisual_AttachCreateCallback(VCDynamicVisual *, VCDynamicVisual_Func, void *);
VC_EXPORT void 			*VCDynamicVisual_AttachUpdateCallback(VCDynamicVisual *, VCDynamicVisual_Func, void *);
VC_EXPORT void 			*VCDynamicVisual_AttachDeleteCallback(VCDynamicVisual *, VCDynamicVisual_Func, void *);
VC_EXPORT int			 VCDynamicVisual_DetachCreateCallback(VCDynamicVisual *, void *);
VC_EXPORT int			 VCDynamicVisual_DetachUpdateCallback(VCDynamicVisual *, void *);
VC_EXPORT int			 VCDynamicVisual_DetachDeleteCallback(VCDynamicVisual *, void *);

VC_EXPORT void 			*VCLod_AttachCreateCallback(VCLod *, VCLod_Func, void *);
VC_EXPORT void 			*VCLod_AttachUpdateCallback(VCLod *, VCLod_Func, void *);
VC_EXPORT void 			*VCLod_AttachDeleteCallback(VCLod *, VCLod_Func, void *);
VC_EXPORT int			 VCLod_DetachCreateCallback(VCLod *, void *);
VC_EXPORT int			 VCLod_DetachUpdateCallback(VCLod *, void *);
VC_EXPORT int			 VCLod_DetachDeleteCallback(VCLod *, void *);

VC_EXPORT void 			*VCGeogroup_AttachCreateCallback(VCGeogroup *, VCGeogroup_Func, void *);
VC_EXPORT void 			*VCGeogroup_AttachUpdateCallback(VCGeogroup *, VCGeogroup_Func, void *);
VC_EXPORT void 			*VCGeogroup_AttachDeleteCallback(VCGeogroup *, VCGeogroup_Func, void *);
VC_EXPORT int			 VCGeogroup_DetachCreateCallback(VCGeogroup *, void *);
VC_EXPORT int			 VCGeogroup_DetachUpdateCallback(VCGeogroup *, void *);
VC_EXPORT int			 VCGeogroup_DetachDeleteCallback(VCGeogroup *, void *);

VC_EXPORT void 			*VCGeometry_AttachCreateCallback(VCGeometry *, VCGeometry_Func, void *);
VC_EXPORT void 			*VCGeometry_AttachUpdateCallback(VCGeometry *, VCGeometry_Func, void *);
VC_EXPORT void			*VCGeometry_AttachDeleteCallback(VCGeometry *, VCGeometry_Func, void *);
VC_EXPORT int			 VCGeometry_DetachCreateCallback(VCGeometry *, void *);
VC_EXPORT int			 VCGeometry_DetachUpdateCallback(VCGeometry *, void *);
VC_EXPORT int			 VCGeometry_DetachDeleteCallback(VCGeometry *, void *);

VC_EXPORT void			*VCConnectionList_AttachCreateCallback(VCConnectionList *, VCConnectionList_Func, void *);
VC_EXPORT void 			*VCConnectionList_AttachUpdateCallback(VCConnectionList *, VCConnectionList_Func, void *);
VC_EXPORT void 			*VCConnectionList_AttachDeleteCallback(VCConnectionList *, VCConnectionList_Func, void *);
VC_EXPORT int			 VCConnectionList_DetachCreateCallback(VCConnectionList *, void *);
VC_EXPORT int			 VCConnectionList_DetachUpdateCallback(VCConnectionList *, void *);
VC_EXPORT int			 VCConnectionList_DetachDeleteCallback(VCConnectionList *, void *);

VC_EXPORT void			 *VCText_AttachCreateCallback(VCGeometry *, VCText_Func, void *);
VC_EXPORT void			 *VCText_AttachUpdateCallback(VCGeometry *, VCText_Func, void *);
VC_EXPORT void			 *VCText_AttachDeleteCallback(VCGeometry *, VCText_Func, void *);
VC_EXPORT int			 VCText_DetachCreateCallback(VCGeometry *, void *);
VC_EXPORT int			 VCText_DetachUpdateCallback(VCGeometry *, void *);
VC_EXPORT int			 VCText_DetachDeleteCallback(VCGeometry *, void *);
VC_EXPORT void 			*VCEntity_AttachIntersectionCallback(VCEntity *entity, VCEntity_IntersectionFunc func, void *data);
VC_EXPORT int			 VCEntity_DetachIntersectionCallback(VCEntity *entity, void *handle);

VC_EXPORT VCMaterialFile	*VCMaterialFile_Open(const char *fileName);
VC_EXPORT void			 VCMaterialFile_Close(VCMaterialFile *matFile);
VC_EXPORT VCMaterialFileData 	*VCMaterialFile_GetFirst(VCMaterialFile *matFile,
                                                         VCMaterialFileType matType,
                                                         const char *matName,
                                                         VCMaterialFile_Traverse *traverse);
VC_EXPORT VCMaterialFileData 	*VCMaterialFile_GetNext(VCMaterialFile_Traverse *traverse);


VC_EXPORT VCAttribute 		*VC2dIntersect_Create (uint32 mode, float32 x, float32 y, uint32 mask, int32 numIntersections, char *pipeName);
VC_EXPORT VCAttribute 		*VC2dIntersect_CreateData (VC2dIntersectData *intersectData);
VC_EXPORT VCAttribute 		*VCEntity_Add2dIntersectData(VCEntity *entity, VC2dIntersectData *data);
VC_EXPORT VCAttribute 		*VCEntity_Add2dIntersect (VCEntity *entity, uint32 mode, float32 x, float32 y, uint32 mask, int32 numIntersections,
                                                          char *pipeName);
VC_EXPORT int			 VC2dIntersect_Set (VCAttribute *attribute, uint32 setMode, uint32 clearMode, float32 *x, float32 *y,
                                                    uint32 setMask, uint32 clearMask, int32 *numIntersections);
VC_EXPORT int			 VC2dIntersect_SetData (VCAttribute *attribute, VC2dIntersectData *intersectData);
VC_EXPORT int			 VC2dIntersect_Get (VCAttribute *attribute, uint32 *mode, float32 *x, float32 *y, uint32 *mask,
                                                    int32 *numIntersections, VCIntersection **intersection, char **pipeName);
VC_EXPORT int			 VC2dIntersect_GetData (VCAttribute *attribute, VC2dIntersectData *intersectData);
VC_EXPORT int			 VC2dIntersect_GetIntersection (VCAttribute *attribute, VCIntersection **intersection);
VC_EXPORT void 			*VC2dIntersect_AttachIntersectionCreateCallback(VCAttribute *intersect, VCIntersection_Func func, void *data);
VC_EXPORT void 			*VC2dIntersect_AttachIntersectionUpdateCallback(VCAttribute *intersect, VCIntersection_Func func, void *data);
VC_EXPORT void 			*VC2dIntersect_AttachIntersectionDeleteCallback(VCAttribute *intersect, VCIntersection_Func func, void *data);
VC_EXPORT int			 VC2dIntersect_DetachIntersectionCreateCallback(VCAttribute *intersect, void *callbackHandle);
VC_EXPORT int			 VC2dIntersect_DetachIntersectionUpdateCallback(VCAttribute *intersect, void *callbackHandle);
VC_EXPORT int			 VC2dIntersect_DetachIntersectionDeleteCallback(VCAttribute *intersect, void *callbackHandle);
VC_EXPORT int			VCIntersection_SetAndReport(VCAttribute *intersect, VCEntity *entity, VCAttribute *visual,
                                                            dmPoint point, dmVector normal);


VC_EXPORT VCAttribute 		*VCReplayResource_Create (char *name,  uint32 mode, uint32 state, int32 loopCount, float32 rate, char *sessionFile);
VC_EXPORT VCAttribute 		*VCReplayResource_CreateData (VCReplayResourceData *replayData);
VC_EXPORT VCAttribute 		*VCEntity_AddReplayResourceData(VCEntity *entity, VCReplayResourceData *data);
VC_EXPORT VCAttribute 		*VCEntity_AddReplayResource (VCEntity *entity, char *name, uint32 mode, uint32 state, int32 loopCount,
                                                             float32 rate, char *sessionFile);
VC_EXPORT int	 		 VCReplayResource_Set (VCAttribute *attribute, uint32 setMode, uint32 clearMode, uint32 setState,
                                                       uint32 clearState, int32 *loopCount, float32 *rate, char *sessionFile);
VC_EXPORT int 			 VCReplayResource_SetData (VCAttribute *attribute, VCReplayResourceData *replayData);
VC_EXPORT int			 VCReplayResource_Get (VCAttribute *attribute, char **name, uint32 *mode, uint32 *state, int32 *loopCount,
                                                       float32 *rate, char **sessionFile);
VC_EXPORT int			 VCReplayResource_GetData (VCAttribute *attribute, VCReplayResourceData *replayData);

#define VCReplayResource_Delete(a) VCAttribute_Delete(a)





VC_EXPORT void			 VCActorResource_SetCacheMode(VCActorResource *item, uint32 newCacheMode);
VC_EXPORT uint32		 VCActorResource_GetCacheMode(VCActorResource *item);
VC_EXPORT VCActorResource 	*_VC_GetActorResource (InstanceNo inst);
VC_EXPORT void 			*VCActorResource_AttachCreateCallback(VCActorResource *item, VCActorResource_Func func, void *data);
VC_EXPORT void 			*VCActorResource_AttachUpdateCallback(VCActorResource *item, VCActorResource_Func func, void *data);
VC_EXPORT void 			*VCActorResource_AttachDeleteCallback(VCActorResource *item, VCActorResource_Func func, void *data);
VC_EXPORT int			 VCActorResource_DetachCreateCallback(VCActorResource *item, void *callbackHandle);
VC_EXPORT int			 VCActorResource_DetachUpdateCallback(VCActorResource *item, void *callbackHandle);
VC_EXPORT int			 VCActorResource_DetachDeleteCallback(VCActorResource *item, void *callbackHandle);
VC_EXPORT VCActorResource 	*VCActorResource_Create(char *name, uint32 mode, uint32 status, char *domainName);
VC_EXPORT VCActorResource 	*VCActorResource_CreateData(VCActorResourceData *actorResourceData);
VC_EXPORT int			 VCActorResource_Get(VCActorResource *item, char **name, uint32 *mode, uint32 *status, char **domainName);
VC_EXPORT int			 VCActorResource_GetData(VCActorResource *item, VCActorResourceData *actorResourceData);
VC_EXPORT int			 VCActorResource_SetData (VCActorResource *item,VCActorResourceData *actorResourceData);
VC_EXPORT int			 VCActorResource_Set(VCActorResource *item, char *name, uint32 setMode, uint32 clearMode,  uint32 setStatus,
                                                     uint32 clearStatus, char *domainName);
VC_EXPORT int			 VCActorResource_ModifyMode(VCActorResource *item, uint32 setMode, uint32 clearMode);
VC_EXPORT int			 VCActorResource_ModifyStatus(VCActorResource *item, uint32 setStatus, uint32 clearStatus);
VC_EXPORT int			 VCActorResource_SetMode(VCActorResource *item, uint32 mode);
VC_EXPORT int			 VCActorResource_SetStatus(VCActorResource *item, uint32 status);
VC_EXPORT int			 VCActorResource_GetName(VCActorResource *item, char **name);
VC_EXPORT int			 VCActorResource_GetMode(VCActorResource *item, uint32 *mode);
VC_EXPORT int			 VCActorResource_GetStatus(VCActorResource *item, uint32 *status);
VC_EXPORT int			 VCActorResource_GetDomainName (VCActorResource *item, char **domainName);
VC_EXPORT int			 VCActorResource_Delete(VCActorResource *item);


VC_EXPORT void			 VCSearchPath_SetCacheMode(VCSearchPath *item, uint32 newCacheMode);
VC_EXPORT uint32		 VCSearchPath_GetCacheMode(VCSearchPath *item);
VC_EXPORT VCSearchPath 		*_VC_GetSearchPath (InstanceNo inst);
VC_EXPORT void 			*VCSearchPath_AttachCreateCallback(VCSearchPath *item, VCSearchPath_Func func, void *data);
VC_EXPORT void 			*VCSearchPath_AttachUpdateCallback(VCSearchPath *item, VCSearchPath_Func func, void *data);
VC_EXPORT void 			*VCSearchPath_AttachDeleteCallback(VCSearchPath *item, VCSearchPath_Func func, void *data);
VC_EXPORT int			 VCSearchPath_DetachCreateCallback(VCSearchPath *item, void *callbackHandle);
VC_EXPORT int			 VCSearchPath_DetachUpdateCallback(VCSearchPath *item, void *callbackHandle);
VC_EXPORT int			 VCSearchPath_DetachDeleteCallback(VCSearchPath *item, void *callbackHandle);
VC_EXPORT VCSearchPath 		*VCSearchPath_Create(char *path1, char *path2, char *path3, char *path4);
VC_EXPORT VCSearchPath 		*VCSearchPath_CreateData(VCSearchPathData *searchPathData);
VC_EXPORT int			 VCSearchPath_Get(VCSearchPath *item, char **path1, char **path2, char **path3, char **path4);
VC_EXPORT int			 VCSearchPath_GetData(VCSearchPath *item, VCSearchPathData *searchPathData);
VC_EXPORT int			 VCSearchPath_SetData (VCSearchPath *item,VCSearchPathData *searchPathData);
VC_EXPORT int			 VCSearchPath_Set(VCSearchPath *item, char *path1, char *path2, char *path3, char *path4);

VC_EXPORT int	VCSearchPath_Delete(VCSearchPath *item);

VC_EXPORT VCCollisionSet 	*_VC_GetCollisionSet (InstanceNo inst);

VC_EXPORT void			 VCCollisionSet_SetCacheMode(VCCollisionSet *item, uint32 newCacheMode);
VC_EXPORT uint32		 VCCollisionSet_GetCacheMode(VCCollisionSet *item);
VC_EXPORT void 			*VCCollisionSet_AttachCreateCallback(VCCollisionSet *item, VCCollisionSet_Func func,
                                                                     void *data);
VC_EXPORT void 			*VCCollisionSet_AttachUpdateCallback(VCCollisionSet *item, VCCollisionSet_Func func,
                                                                     void *data);
VC_EXPORT void 			*VCCollisionSet_AttachDeleteCallback(VCCollisionSet *item, VCCollisionSet_Func func,
                                                                     void *data);


VC_EXPORT VCCollisionSet 	*VCCollisionSet_Create(uint32 colMode, VCEntity **entityList, int numEntities);
VC_EXPORT int			 VCCollisionSet_Get(VCCollisionSet *item, uint32 *collisionMode, VCEntity ***entityList, int *numEntities);
VC_EXPORT int			 VCCollisionSet_Set(VCCollisionSet *item, uint32 setCollisionMode, uint32 clearCollisionMode,
                                                    VCEntity ***entityList, int numEntities);
VC_EXPORT int			 VCCollisionSet_Delete(VCCollisionSet *item);



VC_EXPORT void                   VCCollisionRequest_SetCacheMode(VCCollisionRequest *item, uint32 newCacheMode);
VC_EXPORT uint32                    VCCollisionRequest_GetCacheMode(VCCollisionRequest *item);

VC_EXPORT void           *VCCollisionRequest_AttachCreateCallback(VCCollisionRequest *item, VCCollisionRequest_Func func, void *data);

VC_EXPORT void           *VCCollisionRequest_AttachUpdateCallback(VCCollisionRequest *item, VCCollisionRequest_Func func, void *data);
VC_EXPORT void           *VCCollisionRequest_AttachDeleteCallback(VCCollisionRequest *item, VCCollisionRequest_Func func, void *data);
VC_EXPORT int             VCCollisionRequest_DetachCreateCallback(VCCollisionRequest *item, void *callbackHandle);
VC_EXPORT int             VCCollisionRequest_DetachUpdateCallback(VCCollisionRequest *item, void *callbackHandle);
VC_EXPORT int             VCCollisionRequest_DetachDeleteCallback(VCCollisionRequest *item, void *callbackHandle);
VC_EXPORT VCCollisionRequest *VCCollisionRequest_Create(uint32 cmd, uint32 relation, float32 tolerance, VCCollisionSet *exclusionSet,
                                                        VCCollisionSet **clearenceSets, uint32 numClearenceSets);
VC_EXPORT int             VCCollisionRequest_Get(VCCollisionRequest *item, uint32 *cmd, uint32 *relation,
                                                 float32 *tolerance, VCCollisionSet **exclusionSet,
                                                 VCCollisionSet ***clearenceSets, uint32 *numClearenceSets,
                                                 VCCollisionRequestState **collisionState);
VC_EXPORT int		  VCCollisionRequest_Set(VCCollisionRequest *item, uint32 *cmd, uint32 *relation,
                                                 float32 *tolerance, VCCollisionSet **exclusionSet,
                                                 VCCollisionSet ***clearenceSets, uint32 numClearenceSets);
VC_EXPORT int             VCCollisionRequest_Delete(VCCollisionRequest *item);

VC_EXPORT void		 VCCollisionRequestState_SetCacheMode(VCCollisionRequestState *item, uint32 newCacheMode);
VC_EXPORT uint32	 VCCollisionRequestState_GetCacheMode(VCCollisionRequestState *item);
VC_EXPORT VCCollisionRequestState *_VC_GetCollisionRequestState (InstanceNo inst);
VC_EXPORT void *VCCollisionRequestState_AttachCreateCallback(VCCollisionRequestState *item,
                                                             VCCollisionRequestState_Func func,
                                                             void *data);
VC_EXPORT void *VCCollisionRequestState_AttachUpdateCallback(VCCollisionRequestState *item,
                                                             VCCollisionRequestState_Func func,
                                                             void *data);
VC_EXPORT void *VCCollisionRequestState_AttachDeleteCallback(VCCollisionRequestState *item,
                                                             VCCollisionRequestState_Func func,
                                                             void *data);
VC_EXPORT int		 VCCollisionRequestState_DetachCreateCallback(VCCollisionRequestState *item,
                                                                      void *callbackHandle);
VC_EXPORT int		 VCCollisionRequestState_DetachUpdateCallback(VCCollisionRequestState *item,
                                                                      void *callbackHandle);
VC_EXPORT int		 VCCollisionRequestState_DetachDeleteCallback(VCCollisionRequestState *item,
                                                                      void *callbackHandle);
VC_EXPORT VCCollisionRequestState *VCCollisionRequestState_Create(uint32 mode);
VC_EXPORT int		 VCCollisionRequestState_Get(VCCollisionRequestState *item, uint32 *mode, float32 *tolerance,
                                                         VCCollisionRequestReport ***reportData,
                                                         uint32 *numCollReports);

VC_EXPORT int		 VCCollisionRequestState_Set(VCCollisionRequestState *item, uint32 setMode, uint32 clearMode, float32 *tolerance,
                                                         VCCollisionRequestReport ***reportData,
                                                         uint32 numCollReports);

VC_EXPORT int            VCCollisionRequestState_Delete(VCCollisionRequestState *item);

VC_EXPORT VCCollisionRequestReport * VCCollisionRequestReport_Create( VCAttribute *boundary1,
                             VCAttribute *boundary2, dmMatrix position1, dmMatrix position2, float32 *distance, float32 **polylines );
VC_EXPORT int            VCCollisionRequestReport_Get( VCCollisionRequestReport *item,
                             VCAttribute **boundary1, VCAttribute **boundary2, dmMatrix position1,
                             dmMatrix position2, float32 *distance, float32 **polylines );
VC_EXPORT int            VCCollisionRequestReport_Set(VCCollisionRequestReport *item,
                             VCAttribute *boundary1, VCAttribute *boundary2, dmMatrix position1,
                             dmMatrix position2, float32 *distance, float32 **polylines );
VC_EXPORT void *         VCCollisionRequestReport_AttachCreateCallback(VCCollisionRequestReport *item, VCCollisionRequestReport_Func func, void *data);
VC_EXPORT void *         VCCollisionRequestReport_AttachUpdateCallback(VCCollisionRequestReport *item, VCCollisionRequestReport_Func func, void *data);
VC_EXPORT void *         VCCollisionRequestReport_AttachDeleteCallback(VCCollisionRequestReport *item, VCCollisionRequestReport_Func func, void *data);
VC_EXPORT int            VCCollisionRequestReport_DetachCreateCallback(VCCollisionRequestReport *item, void *callbackHandle);
VC_EXPORT int            VCCollisionRequestReport_DetachUpdateCallback(VCCollisionRequestReport *item, void *callbackHandle);
VC_EXPORT int            VCCollisionRequestReport_DetachDeleteCallback(VCCollisionRequestReport *item, void *callbackHandle);


VC_EXPORT int			 VCEntity_Pick2d (VCEntity *entity, VCAttribute *bodyPart,
                                                  VCEntity_DropFunc dropFunc, void *data);

/* Hoppy, 11/07/98 */
/* XXXXX Need this?? */
VC_EXPORT int			 VCEntity_Select2d (VCEntity *entity, VCAttribute *bodyPart,
                                                  VCEntity_DeselectFunc deselectFunc, void *data);

VC_EXPORT void 			*VCBody_AttachScreenIntersectionCallback (VCBody *body, char *limbName,
                                                                          VCBody_ScreenIntersectionFunc func, void *data);
VC_EXPORT int			 VCBody_DetachScreenIntersectionCallback (VCBody *body, void *callbackHandle);


VC_EXPORT void VC_SetUpdateTime(VCTime *t);
VC_EXPORT void VC_GetExtractTime(VCTime *t);


VC_EXPORT VCAttribute* VCSection_Create(char *name, uint32 mode, uint32 visualMode,uint32 intersectMask);
VC_EXPORT VCAttribute* VCSection_CreateData 	(VCSectionData *sectionData);
VC_EXPORT VCAttribute* VCEntity_AddSectionData(VCEntity *entity, VCSectionData *data);
VC_EXPORT VCAttribute* VCEntity_AddSection(VCEntity *entity, char *name, uint32 mode, uint32 visualMode, uint32 intersectMask);
VC_EXPORT int VCSection_Set(VCAttribute *attribute, char *name, uint32 setMode, uint32 clearMode,
                            uint32 setVisualMode, uint32 clearVisualMode,
                            uint32 setIntersectMask, uint32 clearIntersectMask, float32 *corners);
VC_EXPORT int VCSection_Get(VCAttribute *attribute, char **name, uint32 *mode, uint32 *visualMode, uint32 *intersectMask, float32 **corners);
VC_EXPORT int VCSection_GetData(VCAttribute *attribute, VCSectionData *sectionData);
VC_EXPORT int VCSection_SetData(VCAttribute *attribute, VCSectionData *sectionData);
VC_EXPORT int VCSection_SetName(VCAttribute *attribute, char *name);
VC_EXPORT int VCSection_SetMode(VCAttribute *attribute, uint32 mode);
VC_EXPORT int VCSection_ModifyMode(VCAttribute *attribute, uint32 setMode, uint32 clearMode);
VC_EXPORT int VCSection_SetVisualMode(VCAttribute *attribute, uint32 visualMode);
VC_EXPORT int VCSection_ModifyVisualMode(VCAttribute *attribute, uint32 setVisualMode, uint32 clearVisualMode);
VC_EXPORT int VCSection_SetIntersectMask(VCAttribute *attribute, uint32 intersectMask);
VC_EXPORT int VCSection_ModifyIntersectMask(VCAttribute *attribute, uint32 setIntersectMask, uint32 clearIntersectMask);
VC_EXPORT int VCSection_GetName(VCAttribute *attribute, char **name);
VC_EXPORT int VCSection_GetMode(VCAttribute *attribute, uint32 *mode);
VC_EXPORT int VCSection_GetVisualMode(VCAttribute *attribute, uint32 *visualMode);
VC_EXPORT int VCSection_GetIntersectMask(VCAttribute *attribute, uint32 *intersectMask);

VC_EXPORT void			 VCSectionImageSave_SetCacheMode(VCSectionImageSave *item, uint32 newCacheMode);
VC_EXPORT uint32		 VCSectionImageSave_GetCacheMode(VCSectionImageSave *item);
VC_EXPORT VCSectionImageSave 	*_VC_GetSectionImageSave (InstanceNo inst);
VC_EXPORT void 			*VCSectionImageSave_AttachCreateCallback(VCSectionImageSave *item,
                                                                         VCSectionImageSave_Func func, void *data);
VC_EXPORT void 			*VCSectionImageSave_AttachUpdateCallback(VCSectionImageSave *item,
                                                                         VCSectionImageSave_Func func, void *data);
VC_EXPORT void 			*VCSectionImageSave_AttachDeleteCallback(VCSectionImageSave *item,
                                                                         VCSectionImageSave_Func func, void *data);
VC_EXPORT int			 VCSectionImageSave_DetachCreateCallback(VCSectionImageSave *item, void *callbackHandle);
VC_EXPORT int			 VCSectionImageSave_DetachUpdateCallback(VCSectionImageSave *item, void *callbackHandle);
VC_EXPORT int			 VCSectionImageSave_DetachDeleteCallback(VCSectionImageSave *item, void *callbackHandle);
VC_EXPORT VCSectionImageSave 	*VCSectionImageSave_Create(int doSave, VCAttribute *first, VCAttribute *second, char *fileName);
VC_EXPORT VCSectionImageSave 	*VCSectionImageSave_CreateData(VCSectionImageSaveData *sectionImageSaveData);
VC_EXPORT int			 VCSectionImageSave_Get(VCSectionImageSave *item, int *doSave, VCAttribute**first,
                                                        VCAttribute**second, char **fileName);
VC_EXPORT int			 VCSectionImageSave_GetData(VCSectionImageSave *item, VCSectionImageSaveData *sectionImageSaveData);
VC_EXPORT int			 VCSectionImageSave_SetData(VCSectionImageSave *item, VCSectionImageSaveData *sectionImageSaveData);
VC_EXPORT int			 VCSectionImageSave_Set(VCSectionImageSave *item, int doSave, VCAttribute **first,
                                                        VCAttribute **second, char **fileName);
VC_EXPORT int			 VCSectionImageSave_SaveToFile(VCSectionImageSave *item, char *fileName);
VC_EXPORT int			 VCSectionImageSave_Save(VCSectionImageSave *item);
VC_EXPORT int			 VCSectionImageSave_SetFileName(VCSectionImageSave *item, char *name);
VC_EXPORT int			 VCSectionImageSave_GetFileName(VCSectionImageSave *item, char **name);
VC_EXPORT int			 VCSectionImageSave_Delete(VCSectionImageSave *item);


#define VCLightTube_Delete(a) VCAttribute_Delete(a)
VC_EXPORT VCAttribute *  VCLightTube_Create (uint32 mode, uint16 numberLights, float32 radius,
                                             float32 length, float32 lightWidth, float32 power,
                                             float32 startAngle, float32 endAngle,
                                             float32 *lightColour, float32 *background);
VC_EXPORT VCAttribute *  VCLightTube_CreateData (VCLightTubeData *ltubeData);
VC_EXPORT VCAttribute *  VCEntity_AddLightTube (VCEntity *entity, uint32 mode, uint16 numberLights,
                                                float32 radius, float32 length, float32 lightWidth,
                                                float32 power, float32 startAngle, float32 endAngle,
                                                float32 *lightColour, float32 *background);
VC_EXPORT VCAttribute *  VCEntity_AddLightTubeData (VCEntity *entity, VCLightTubeData *data);
VC_EXPORT int            VCLightTube_Set (VCAttribute *attribute,
                                          uint32 setMode, uint32 clearMode,
                                          uint16 *numberLights,
                                          float32 *radius, float32 *length, float32 *lightWidth,
                                          float32 *power, float32 *startAngle, float32 *endAngle,
                                          float32 *lightColour, float32 *background);
VC_EXPORT int            VCLightTube_SetData (VCAttribute *attribute, VCLightTubeData *ltubeData);
VC_EXPORT int            VCLightTube_Get (VCAttribute *attribute,
                                          uint32 *mode, uint16 *numberLights,
                                          float32 *radius, float32 *length, float32 *lightWidth,
                                          float32 *power, float32 *startAngle, float32 *endAngle,
                                          float32 *lightColour, float32 *background);
VC_EXPORT int            VCLightTube_GetData (VCAttribute *attribute, VCLightTubeData *ltubeData);
VC_EXPORT int            VCLightTube_SetMode (VCAttribute *attribute, uint32 mode);
VC_EXPORT int            VCLightTube_ModifyMode (VCAttribute *attribute,
                                                 uint32 setMode, uint32 clearMode);
VC_EXPORT int            VCLightTube_GetMode (VCAttribute *attribute, uint32 *mode);
VC_EXPORT int            VCLightTube_SetNumberLights (VCAttribute *attribute, uint16 numberLights);
VC_EXPORT int            VCLightTube_GetNumberLights (VCAttribute *attribute, uint16 *numberLights);

VC_EXPORT int            VCLightTube_SetSize (VCAttribute *attribute, float32 radius, float32 length);
VC_EXPORT int            VCLightTube_GetSize (VCAttribute *attribute, float32 *radius, float32 *length);
VC_EXPORT int            VCLightTube_SetLightWidth (VCAttribute *attribute, float32 width);
VC_EXPORT int            VCLightTube_GetLightWidth (VCAttribute *attribute, float32 *width);
VC_EXPORT int            VCLightTube_SetPower (VCAttribute *attribute, float32 power);
VC_EXPORT int            VCLightTube_GetPower (VCAttribute *attribute, float32 *power);
VC_EXPORT int            VCLightTube_SetStartEndAngle (VCAttribute *attribute,
                                                       float32 startAngle, float32 endAngle);
VC_EXPORT int            VCLightTube_GetStartEndAngle (VCAttribute *attribute,
                                                       float32 *startAngle, float32 *endAngle);
VC_EXPORT int            VCLightTube_SetLightColour (VCAttribute *attribute, float32 *colour);
VC_EXPORT int            VCLightTube_GetLightColour (VCAttribute *attribute, float32 *colour);
VC_EXPORT int            VCLightTube_SetBackground (VCAttribute *attribute, float32 *colour);
VC_EXPORT int            VCLightTube_GetBackground (VCAttribute *attribute, float32 *colour);


VC_EXPORT void		 VCWindow_SetCacheMode(VCWindow *item, uint32 newCacheMode);
VC_EXPORT uint32	 VCWindow_GetCacheMode(VCWindow *item);
VC_EXPORT void 		*VCWindow_AttachCreateCallback(VCWindow *item, VCWindow_Func func, void *data);
VC_EXPORT void 		*VCWindow_AttachUpdateCallback(VCWindow *item, VCWindow_Func func, void *data);
VC_EXPORT void 		*VCWindow_AttachDeleteCallback(VCWindow *item, VCWindow_Func func, void *data);
VC_EXPORT int		 VCWindow_DetachCreateCallback(VCWindow *item, void *callbackHandle);
VC_EXPORT int		 VCWindow_DetachUpdateCallback(VCWindow *item, void *callbackHandle);
VC_EXPORT int		 VCWindow_DetachDeleteCallback(VCWindow *item, void *callbackHandle);
VC_EXPORT VCWindow 	*VCWindow_CreateData(VCWindowData *windowData);
VC_EXPORT int		 VCWindow_GetData(VCWindow *item, VCWindowData *windowData);
VC_EXPORT int		 VCWindow_SetData (VCWindow *item,VCWindowData *windowData);
VC_EXPORT int		 VCWindow_Delete(VCWindow *item);
#endif
