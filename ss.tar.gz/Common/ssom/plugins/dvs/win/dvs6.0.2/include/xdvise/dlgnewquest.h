/****************************************************************************
 *
 *  			Copyright 1997 Division Limited.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: dlgnewquest.h,v $
 *  Revision      : $Revision: 1.1 $
 *  Date          : $Date: 2005/09/13 15:08:19 $
 *  Author        : $Author: pukitepa $
 *  Last Modified : <300997.1736>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 *  $Log: dlgnewquest.h,v $
 *  Revision 1.1  2005/09/13 15:08:19  pukitepa
 *  init
 *
 *  Revision 1.2  1997/10/10 14:41:51  dvs-dev
 *  NT fixes from Simon's Motif changes in XdVISE.
 *  General Bug fixing on NT.
 *
 *  Revision 1.1  1997/10/07 09:48:50  simon
 *  Lots of bug fixes, and added the new selection, new question and plugin
 *  about dlgs
 *
 *
 ****************************************************************************
 *
 *  Copyright (c) 1997 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 *  This Document may not, in whole or in part, be copied,
 *  photocopied, reproduced, translated, or reduced to any
 *  electronic medium or machine readable form without prior
 *  written consent from Division Ltd.
 ****************************************************************************/

#ifndef __DLGNEWQUEST_H__
#define __DLGNEWQUEST_H__

/* INCLUDES =================================================*/

#include "wkeys.h"   /* For compT */
#include "xddlg.h"   /* For dialogInstanceData typedef */
#include "xdcallbk.h"

#ifdef __cplusplus
extern "C" {
#endif

/* DATA STRUCTURES ==========================================*/
typedef struct NewQuestDlgInstDataT NewQuestDlgInstDataT; /* Prototype */

/* FUNCTION PROTOTYPES ======================================*/

XDV_EXPORT void *NewQuestDlgCreate(compT parent);
XDV_EXPORT int NewQuestDlgPopUp(dialogInstanceData *inst);
XDV_EXPORT void NewQuestDlgAddYesCb(dialogInstanceData *inst, XdCallBack *callBack, void *callData);
XDV_EXPORT void NewQuestDlgAddNoCb(dialogInstanceData *inst, XdCallBack *callBack, void *callData);
XDV_EXPORT void NewQuestDlgSetTitle(dialogInstanceData *inst, char *message);
XDV_EXPORT void NewQuestDlgSetMessage(dialogInstanceData *inst, char *message);

#ifdef __cplusplus
}
#endif

#endif /* __DLGNEWQUEST_H__ */
