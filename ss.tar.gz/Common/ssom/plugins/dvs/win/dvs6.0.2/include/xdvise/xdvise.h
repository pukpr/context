/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1993 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE specific stuff
--  Object Name  : $RCSfile: xdvise.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 23 December 1994
--  Author       : Tony Coombes
--
--  Description	 : XdVISE info
--
--  Modified
--    By         : $Author: pukitepa $
--    Date       : $Date: 2005/09/13 15:08:29 $
--
--
-- ----------------------------------------------------------------------------
*/

#ifndef __XDVISE_H__
#define __XDVISE_H__

#ifdef __cplusplus
extern "C" {
#endif

#ifndef XDV_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `XDV_EXPORT'
 */
#ifdef  _LIB_XDV
#define XDV_EXPORT __declspec(dllexport) extern
#else
#define XDV_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define XDV_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ifndef XDV_EXPORT */

#define XDVISE_VERSION "dVISE v3.1 Control Panel"
XDV_EXPORT void XdVISEInit(void);
 
#ifdef __cplusplus
}
#endif

#endif /* __XDVISE_H__ */

