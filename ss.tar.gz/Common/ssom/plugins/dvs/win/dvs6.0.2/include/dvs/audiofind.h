/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1993, 1994 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS 2.1
--  Module       : Audio support library
--  Object Name  : $RCSfile: audiofind.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : $Date: 2005/09/13 15:08:00 $
--  Author       : $Author: pukitepa $
--
--  Description	
--	Defines the path searching functions provided 
--
--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __AUDIOFIND_H__
#define __AUDIOFIND_H__

typedef enum
{
    AUDIO_FILE_AUDIO,           /* search for audio files */
    AUDIO_FILE_SYSTEM,          /* search for system bootables etc */
    AUDIO_FILE_CONFIG,          /* search for configuration files */
    AUDIO_FILE_DYNAMIC          /* search for dynamic device libraries */
} AudioSearchType;

extern int AudioFindFile(const char * const fileName,
                         const AudioSearchType type,
                         const char **extensions,
                         const char *fullName,
                         const int fullNameLength);

#endif /* __AUDIOFIND_H__ */
