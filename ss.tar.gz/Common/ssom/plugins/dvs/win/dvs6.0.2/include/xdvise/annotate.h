/**************************** ANNOTATE.H *****************************/

/* Internal Annotation representation */
#include "annotateP.h"

#define TESTCASE "ANNOTATE_NAME=fred1|MEMO=There is a problem in the manifold.\nI suggest we start again from scratch & go home.\nOr give up!|EVENT=Trigger|BODYMATRIX=1.0 2.0 3.0 4.0 5.0 6.0|USER_PROCESS=snapshot|ASSIGNEE=stevep|OWNER=stevep|PRIORITY=1|STATUS=Pending|ICONFILE=misc/redarrow"
#define DELIMITER_DCISTRING "|"
#define DELIMITER_TOKEN '='
#define DELIMITER_TOKEN_STR "="
#define DELIMITER_TOKENDATA " "

/* NB: MAXIMUM LENGTH OF TOKEN = 16 CHARS */
#define NUMBER_ANNOTATEDATA_FIELDS 13
#define ANNOTATE_NAME_TOKEN	"ANNOTATE_NAME"
#define ANNOTATE_PARENT_TOKEN	"ANNOTATE_PARENT"
#define DATE_TOKEN	"DATE"
#define TIME_TOKEN "TIME"
#define AUDIOFILE_TOKEN		"AUDIOFILE"
#define MEMO_TOKEN		"MEMO"
#define EVENT_TOKEN		"EVENT"
#define BODYMATRIX_TOKEN	"BODYMATRIX"
#define USER_PROCESS_TOKEN	"USER_PROCESS"
#define ASSIGNEE_TOKEN		"ASSIGNEE"
#define OWNER_TOKEN		"OWNER"
#define PRIORITY_TOKEN		"PRIORITY"
#define STATUS_TOKEN		"STATUS"
#define ICONFILE_TOKEN		"ICONFILE"
#define MARKUP_TOKEN		"MARKUPFILE"
#define MARKUP_IMAGE_TOKEN	"MARKUPIMAGE"
#define MARKUP_TOOL_TOKEN	"MARKUPTOOL"

#define ANNOTATE_NOTES_DIR	"notes"
#define ANNOTATE_AUDIO_DIR	"audio"
#define ANNOTATE_DEFAULT_ICON	"misc/noteBig.bgf"
#define ANNOTATE_FILE_HEADER	"##################### dVISE Annotator File v0.1 #####################"
#define	ANNOTATE_MAIL_SUBJECT	"dVISEnote:"
#define	ANNOTATE_MAIL_HEADER	"####### Email generated from dVISE Annotator #######"
#define	ANNOTATE_MAIL_FOOTER	"################## End of Message ##################"
#define	ANNOTATE_TMP_MAILFILE	"/tmp/annotate_email.doc"
#define ANNOTATE_ASSEMBLY_HEADER "Note-"
#define ANNOTATE_COMMENT_HEADER  "ANNOTATE_FILE:"

extern AnnotateData *annotate_create_datastructure (void);
extern char *convert_annotate2string (AnnotateData *annodata);
extern void annotate_free_datastructure (AnnotateData *annodata);
extern AnnotateData *convert_string2annotate(char *str);

extern void annotate_create_file (AnnotateData *annodata);
extern AnnotateData *annotate_read_file (char *filename);
extern void annotate_create_assembly (AnnotateData *annodata);

extern void annotate_get_bodymatrix (AnnotateData *annodata); 
extern ECAssembly *annotate_get_ECAssembly (AnnotateData *annodata);
extern void annotate_play_audio (ECAssembly *assembly, AnnotateData *annodata);
extern void annotate_set_bodymatrix (AnnotateData *annodata);
extern void annotate_toggle_icon (ECAssembly *assembly, AnnotateData *annodata);
extern void annotate_sendmail (AnnotateData *annodata);
extern void annotate_trigger_userprocess (AnnotateData *annodata);
extern void annotate_trigger_event (ECAssembly *assembly, AnnotateData *annodata);

extern void annotation_dci_register_comms(void);
extern void annotate_start_recording(char *audiofile);
extern void annotate_pause_recording(void);
extern void annotate_stop_recording(void);
extern void annotate_play_recording(char *audio_filename);
extern void annotate_delete_recording(char *audiofile);
