/*
 *      PROJECT:
 *      SUBSYSTEM:
 *      MODULE:
 *
 *      FILE:           $RCSfile: vc.h,v $
 *      REVISION:       $Revision: 1.1 $
 *      Date:           $Date: 2005/09/13 15:08:04 $
 *      Author:         $Author: pukitepa $
 *      RCS Ident:      $Id: vc.h,v 1.1 2005/09/13 15:08:04 pukitepa Exp $
 *
 *      FUNCTION:
 *
 * Copyright (c) 1992 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine reable form without prior
 * written consent from Division Ltd.
 */
#ifndef _VCTOOLS_H_
#define _VCTOOLS_H_
#ifdef NDEBUG
#define NVCDEBUG 1
#endif
#ifndef VC_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `extern'
 */
#ifdef  _LIB_VC
#define VC_EXPORT __declspec(dllexport) extern
#else
#define VC_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define VC_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ifndef VC_EXPORT */

#include <stdio.h>
#include <stddef.h>
#include <errno.h>
#include <dvs/vl.h>			/* VL definitions */
#include <dsys/dm.h>
#include <dvs/dm.h>
#include <dsys/du.h>
#include <dsys/ds.h>
#include <dsys/divvers.h>

# ifdef __cplusplus
extern "C" {
# endif

#ifdef _LIB_VC

#include <vcdefs.h>		/* VC constant defintions */
#include "_vcdefs.h"
#include "_vctypes.h"
#include <vctypes.h>		/* VC Type definitions */
#include <vcdtypes.h>
#include <vceltype.h>
#include <vcdynam.h>


#if !defined ( __EPP__)  && !defined (_VCELEMEN_C)
#include <vcelemen.h>		/* VC Element definitions */
#endif

#include "_vcstruct.h"
#include "vcstruct.h"
#include <vcvbose.h>            /* Verbose reporting. */
#include <vcerror.h>
#include <vcinpdef.h>
#include <vcbodapp.h>
#include <vcdata.h>
#include "_vctools.h"
#include "vcmacros.h"
#include "vcfunc.h"
#else

#include <dvs/vcdefs.h>		/* VC constant defintions */
#include <dvs/_vctypes.h>
#include <dvs/vctypes.h>		/* VC Type definitions */
#include <dvs/vcdtypes.h>		/* VC Type definitions */
#include <dvs/vceltype.h>
#include <dvs/vcdynam.h>
#if !defined ( __EPP__)  && !defined (_VCELEMEN_C)
#include <dvs/vcelemen.h>		/* VC Element definitions */
#endif
#include <dvs/vcstruct.h>
#include <dvs/_vcstruct.h>
#include <dvs/vcvbose.h>            /* Verbose reporting. */
#include <dvs/vcerror.h>
#include <dvs/vcinpdef.h>
#include <dvs/vcbodapp.h>
#include <dvs/vcdata.h>
#include <dvs/_vctools.h>
#include <dvs/vcmacros.h>
#include <dvs/vcfunc.h>
#endif

VC_EXPORT char 	*VCApplicationName;
VC_EXPORT char 	*VCDomainName;
VC_EXPORT char 	*VCDomainExtName;
VC_EXPORT char 	*VCDomainExtension;
VC_EXPORT FILE 	*VCLogFilePtr;
VC_EXPORT int		 vcerrno;
VC_EXPORT int		 vcErrType;
VC_EXPORT int32	 VCActorId;
VC_EXPORT char		*VCActorHelp;
VC_EXPORT char		*VCActorExtraHelp;
VC_EXPORT void (*VCActorStartFunc)();
#ifdef __cplusplus
}
# endif
#ifdef NOTDEF
#if defined (_SYSV42) || defined (_IRIX5)
 void *myMalloc(int a);
 void myFree(void *a);
#define free(a) myFree(a)
#define malloc(a) myMalloc(a)
#endif
#endif
#endif
