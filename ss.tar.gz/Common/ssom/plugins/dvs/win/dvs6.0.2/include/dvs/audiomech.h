/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1994 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS 2.1
--  Module       : Audio support library
--  Object Name  : $RCSfile: audiomech.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : $Date: 2005/09/13 15:08:00 $
--  Author       : $Author: pukitepa $
--
--  Description	
--	Defines the structure of a voice mechanism
--
--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __AUDIOMECH_H__
#define __AUDIOMECH_H__

/*
 * ------------------------------------------------------------
 *
 * AudioMechSample - defines a sample file.
 *
 * ------------------------------------------------------------
 */

typedef struct AudioMechSample
{
    char *sampFile;             /* sample file name */
} AudioMechSample;

/*
 * ------------------------------------------------------------
 *
 * AudioMechMIDI - defines a MIDI note
 *
 * ------------------------------------------------------------
 */

typedef struct AudioMechMIDI
{
    unsigned int channel;       /* MIDI channel number */
    unsigned int preset;        /* MIDI preset number */
    unsigned int note;          /* MIDI note number */
} AudioMechMIDI;

/*
 * ------------------------------------------------------------
 * 
 * AudioMechSysExcl - defines a system exclusive start and stop
 *                    sequence
 *
 * ------------------------------------------------------------
 */

typedef struct AudioMechSysExcl
{
    char *start;                /* system exclusive start sequence */
    char *stop;                 /* system exclusive stop sequence */
} AudioMechSysExcl;

/*
 * ------------------------------------------------------------
 * 
 * AudioMechSeq - defines a sequence file.
 *
 * ------------------------------------------------------------
 */

typedef struct AudioMechSeq
{
    char *seqFile;              /* sequence file name */
} AudioMechSeq;

/*
 * ------------------------------------------------------------
 *
 * AudioMechTrack - defines a track number
 *
 * ------------------------------------------------------------
 */

typedef struct AudioMechTrack
{
    int32 track;                /* the track number */
} AudioMechTrack;
    

/*
 * ------------------------------------------------------------
 *
 * AudioMechType - defines the types of audio mechanism.
 *
 * Values defined so that they can be or'd together in 
 * a bitmask.
 *
 * ------------------------------------------------------------
*/

typedef enum 
{
    AUDIO_MECH_SAMPLE   = 0x01,
    AUDIO_MECH_MIDI     = 0x02,
    AUDIO_MECH_SYSEXCL  = 0x04,
    AUDIO_MECH_SEQUENCE = 0x08,
    AUDIO_MECH_EXTERNAL = 0x10,
    AUDIO_MECH_TRACK    = 0x20
} AudioMechType;

#define AudioMechMaskInit(m)    (m = 0)
#define AudioMechSetValid(m, v) (m |= v)
#define AudioMechIsValid(m, v)  (m & v) 

#define AUDIO_MECH_ANY_DEVICE 0xffffffff

/*
 * ------------------------------------------------------------
 *
 * AudioMechanism - defines an audio mechanism
 *
 * An audio mechanism is associated with a particular type
 * of hardware device (deviceType). The length of the mechanism 
 * in seconds is also recorded (length).
 *
 * Note that external mechanisms require no additional
 * information to be stored.
 *
 * ------------------------------------------------------------
 */

typedef struct AudioMechanism
{
    uint32 deviceType;          /* type of device for this mechanism */
    float32 length;             /* length of this mechanism  */
    AudioMechType type;         /* type of this mechansim */
    union 
    {
        AudioMechSample sample; /* sample voice data */
        AudioMechMIDI midi;     /* midi voice data */
        AudioMechSysExcl excl;  /* system exclusive */
        AudioMechSeq seq;       /* sequence */
        AudioMechTrack track;   /* track */
    } data;                     /* data describing mechanism  */
} AudioMechanism;


#endif /* __AUDIOMECH_H__ */
