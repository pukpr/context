/* 
-- ----------------------------------------------------------------------------
--
--  			Copyright 1998 Division Limited.
--			      All Rights Reserved
--
--
--  System       : 
--  Module       : 
--  Object Name  : $RCSfile: dbdbplg.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : $Date: 2005/09/13 15:07:49 $
--  Author       : $Author: pukitepa $
--
--  Description	
--
--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __DBDBPLG_H__
#define __DBDBPLG_H__


typedef dbHandle (*dbDBPlugin_Connect)(const char* const key);
typedef dbHandle (*dbDBPlugin_Create)(const char* const key);
typedef int (*dbDBPlugin_Remove)(const char* const key);
typedef int (*dbDBPlugin_Close)(dbHandle dbId);

typedef dbHandle (*dbDBPlugin_Iterate)(dbHandle id, dbElement el);
typedef void (*dbDBPlugin_IterateEnd)(dbHandle iter);
typedef char* (*dbDBPlugin_NextElement)(dbHandle iter);

typedef char* (*dbDBPlugin_GetLastError)(void);

typedef struct dbDBPlugin
{
        /* accessing the db */
    
    dbDBPlugin_Connect connect;
#if 0
    dbDBPlugin_Create create;
    dbDBPlugin_Remove remove;
#endif
    dbDBPlugin_Close close;

        /* iterating over the contents */

    dbDBPlugin_Iterate iterate;
    dbDBPlugin_IterateEnd iterateEnd;
    dbDBPlugin_NextElement nextElement;

    
        /* plus some more stuff for the operations */

    dbDBPlugin_GetLastError getLastError;
} dbDBPlugin;


#endif /* __DBDBPLG_H__ */
