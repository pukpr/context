/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1995 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: xddlg.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 2 Semptember 1994
--  Author       : Tony Coombes
--
--  Description	 : Used to maintain dialogs
--
--  Modified     : 
--    $Log: xddlg.h,v $
--    Revision 1.1  2005/09/13 15:08:22  pukitepa
--    init
--
--    Revision 1.21  1998/08/21 16:23:47  simon
--    Added direct selection toggle to the filter dlg.
--
--    Revision 1.20  1998/08/05 16:19:24  simon
--    fixes to get the action dlg, and selection dlg to pop down correctly.
--
--    Revision 1.19  1998/08/03 14:47:28  simon
--    Added the instWarn dlg, and added stuff to warn user if an instance is about
--    to be un-instanced.
--
--    Revision 1.18  1998/07/31 15:44:43  andya
--    moved toolbar and implemented "pdm mode" for assy browser & save attrs
--
--    Revision 1.17  1998/07/30 17:20:55  iand
--    Made Changes to support Save Section as Jpeg and Save Section as Iges file
--
--    Revision 1.16  1998/07/15 16:15:27  simon
--    made some changes to the progress dlg, and file dlgs so they could be
--    called from a plugin.  Added a couple of new types for file dlg.
--
--    Revision 1.15  1998/06/23 16:21:41  mdj
--    *** empty log message ***
--
--    Revision 1.14  1998/06/12 08:53:28  simon
--    changes for filter tool
--
--    Revision 1.13  1998/05/21 13:21:21  wman
--    Code to Delete Keyframes and frames.
--
--    Revision 1.12  1997/11/12 16:10:19  simon
--    Missed changes for the change to xdcallbk.h
--
--    Revision 1.11  1997/11/11 15:50:36  simon
--    fix to xdcallback which changes definition to get xdvise to compile
--    on hpux boxes
--
--    Revision 1.10  1997/11/11 10:29:24  mark
--    Added export for section manager callback function
--
--    Revision 1.9  1997/11/07 16:54:46  simon
--    bug fixes
--
--    Revision 1.8  1997/10/30 14:54:43  mark
--    Changes for PR xdvise/3894
--
--    Added support to allow the section manager plugin to use the
--    file selection dialogue.
--
--    Revision 1.7  1997/10/10 19:12:41  steve
--    addition of DLGCTX_FILE_SAVE_VRML enum for dialog context when saving VRML files.
--
--    Revision 1.6  1997/10/07 09:49:11  simon
--    Lots of bug fixes, and added the new selection, new question and plugin
--    about dlgs
--
--    Revision 1.5  1997/08/26 11:47:49  simon
--    Mainly changes to library viewer, and additional reset parts stuff
--
--    Revision 1.4  1997/08/12 11:51:46  tony
--    Changed dialog update function to return boolean to indicate success.
--    If the update function was called during an attempted pop-up and the
--    update function was unsuccessful the pop-up will be aborted.
--
--    Revision 1.3  1997/07/25 16:52:03  tony
--    Addition of Play and Edit contexts for Flight Path dialog
--
--    Revision 1.2  1997/07/11 15:56:07  tony
--    Removed #include "xdtree.h"
--
--    Revision 1.1  1997/07/09 12:31:11  simon
--    *** empty log message ***
--
--    Revision 1.24  1997/07/09 10:01:01  dvs-dev
--    Latest improvements for NT.
--    Shortcut toolbar in asembly viewer
--    Annotation Dlgs
--    Behaviour dlgs
--
--    Revision 1.23  1997/07/02 13:09:21  dvs-dev
--    Changes for NT build.
--    Modified header files for windows __declspec definitions
--    Added some NON working code for keyboard accelerators.
--
--    Revision 1.22  1997/03/10 17:57:08  tony
--    *** empty log message ***
--
--    Revision 1.21  1997/03/04 13:11:00  wman
--    Bug Fixes.
--
--    Revision 1.20  1997/02/28 11:53:33  tony
--    *** empty log message ***
--
--    Revision 1.19  1997/02/27 21:06:18  tony
--    *** empty log message ***
--
--    Revision 1.18  1997/02/22 17:34:15  wman
--    Implemented new exponential scale on navigator distance.
--    Message window pops up automatically on first message.
--    General Bug Fixes
--
--    Revision 1.17  1997/02/15 17:33:56  wman
--    Bug Fixes.
--
--    Revision 1.16  1997/02/03 18:25:53  wman
--    Bug fixes to animation dialogs
--
--    Revision 1.15  1997/01/21 21:35:56  tony
--    *** empty log message ***
--
--    Revision 1.14  1997/01/09 18:31:39  wman
--    Added two way selection as default on
--    Addded Image Save option to file menu option.
--    Also, Added some to frame manager insert frame
--
--    Revision 1.13  1996/12/23 17:52:43  wman
--    Animation dialog fixes - mainly the new action function editor of frames
--
--    Revision 1.12  1996/12/19 17:44:41  tony
--    *** empty log message ***
--
--    Revision 1.11  1996/12/06 17:37:54  tony
--    *** empty log message ***
--
--    Revision 1.10  1996/11/27 17:02:48  wman
--    Added File|new and File|open menu functionality
--
--    Revision 1.9  1996/11/13 18:00:07  tony
--    *** empty log message ***
--
--    Revision 1.8  1996/11/06 08:18:35  tony
--    *** empty log message ***
--
--    Revision 1.7  1996/11/05 08:37:23  tony
--    *** empty log message ***
--
--    Revision 1.6  1996/10/24 17:59:31  tony
--    *** empty log message ***
--
--    Revision 1.5  1996/10/21 17:41:11  wman
--    Latest annotation stuff.
--
--    Revision 1.4  1996/10/18 17:47:26  wman
--    New annotation stuff!
--
--    Revision 1.3  1996/10/16 15:36:26  wman
--    UserRoleDialog stuff
--
--    Revision 1.2  1996/09/10 15:40:01  tony
--    Changed "Object" to "Assembly"
--
--    Revision 1.1.1.1  1996/08/29 09:26:13  tony
--    first version of xdvise
--
--    Revision 3.5  1996/08/05 15:06:37  tony
--    Check in prior to starting development for IDP
--
--    Revision 3.4  1996/06/18 11:17:02  tony
--    Mid development revision
--
--    Revision 3.3  1996/03/01 12:11:23  tony
--    Added XdDlgZoneChangesWillBeLost() and renamed
--    XdDlgObjChangesWillBeLostInDlgType() to XdDlgChangesWillBeLostInDlgType()
--    Added DLGCTX_QUEST_ZONE_CLICK & DLGCTX_QUEST_WORLD_BGSELECTED
--
--    Revision 3.2  1996/03/01 09:17:46  tony
--    Add "whatChanged" argument to XdDlgUpdate()
--
--    Revision 3.1  1996/02/26 16:31:06  tony
--    Release 3.0
--
--    Revision 1.9  1996/02/01 18:20:35  tony
--    Added  DLGCTX_LIBED_ENVIRONMENT
--
--    Revision 1.8  1996/01/26 10:55:00  tony
--    Added another confirmation DLGCTX_QUEST_TREEVIEW_DELETE prompt.
--
--    Revision 1.7  1996/01/24 10:27:22  tony
--    General updates
--
--    Revision 1.6  1996/01/16 16:31:19  tony
--    Various updates
--
--
-- ----------------------------------------------------------------------------
*/
 
#ifndef __XDDLG_H__
#define __XDDLG_H__

#include <dvise/eclicense.h> /* For ECLicensedFeaturesEnum */
#include <dvise/dci_parse.h>
#define String VLString
#include <dvs/vc.h>
#include <dvise/ectools.h>
#undef String

#include "wkeys.h"
#include "xdcallbk.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef XDV_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `XDV_EXPORT'
 */
#ifdef  _LIB_XDV
#define XDV_EXPORT __declspec(dllexport) extern
#else
#define XDV_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define XDV_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ifndef XDV_EXPORT */

typedef struct dialogInstanceData dialogInstanceData;

typedef enum _dlgContext {    /*    DIALOG          ( CONTEXT ) */
    CMD_NO_CONTEXT,           /* Obsolete */
    CMD_COL_MATERIAL_AMBIENT, /* Colour dialog (Material Ambient property) */
    CMD_COL_MATERIAL_DIFFUSE, /* Colour Dialog (Material Diffuse property) */
    CMD_COL_MATERIAL_SPECULAR, 
    CMD_COL_MATERIAL_OPACITY, 
    CMD_COL_MATERIAL_EMISSIVE, 
    CMD_COL_LIGHT_COLOUR, 
    DLGCTX_EXIT_CLOSE,        /* Question dialog (for Close) */ 
    DLGCTX_EXIT_EXIT,         /* Question dialog (for Exit) */  
    DLGCTX_QUEST_MATERIAL_FILE_OPEN,    /* Question dialog (Confirmation of ...) */
    DLGCTX_QUEST_MATERIAL_FILE_NEW,     /* Question dialog (Confirmation of ...) */
    DLGCTX_QUEST_MATERIAL_LIBRARY_LOAD, /* Question dialog (Confirmation of ...) */
    DLGCTX_QUEST_VISUAL_FMAT,           /* Question dialog (Confirmation of ...) */
    DLGCTX_QUEST_VISUAL_BMAT,           /* Question dialog (Confirmation of ...) */
    DLGCTX_QUEST_TREEVIEW_NODE_CLICK,   /* Question dialog (Confirmation of ...) */
    DLGCTX_QUEST_ZONE_CLICK,            /* Question dialog (Confirmation of ...) */
    DLGCTX_QUEST_TREEVIEW_BGSELECTED,   /* Question dialog (Confirmation of ...) */
    DLGCTX_QUEST_WORLD_BGSELECTED,      /* Question dialog (Confirmation of ...) */
    DLGCTX_QUEST_TREEVIEW_DELETE,       /* Question dialog (Confirmation of ...) */
    DLGCTX_QUEST_NODELIST_ACCEPT,       /* Question dialog (Confirmation of ...) */
    DLGCTX_QUEST_NODELIST_APPLY,        /* Question dialog (Confirmation of ...) */
    DLGCTX_QUEST_REMOTE_OBJ_SELECT,     /* Question dialog (Confirmation of ...) */
    DLGCTX_QUEST_EVENTLIST_APPLY,       /* Question dialog (Confirmation of ...) */
    DLGCTX_QUEST_EVENTLIST_ACCEPT,      /* Question dialog (Confirmation of ...) */
    DLGCTX_QUEST_ASSYVIEW_DELETE,       /* Question dialog (Confirmation of ...) */
    DLGCTX_QUEST_LIBVIEW_DELETE,        /* Question dialog (Confirmation of ...) */
    DLGCTX_QUEST_CAMERA_DELETE,         /* Question dialog (Confirmation of ...) */
    DLGCTX_MATERIAL_FRONT,    /* Material dialog (Front material) */ 
    DLGCTX_MATERIAL_BACK,     /* Material dialog (Back material) */  
    DLGCTX_ITEM_LST_FRT_MAT,  /* Item List dialog (Front Material) */ 
    DLGCTX_ITEM_LST_BAK_MAT,  /* Item List dialog (Back  Material) */ 
    DLGCTX_ITEM_LST_TEXTURE,  /* Item List dialog (Texture) */ 
    DLGCTX_ITEM_LST_RAMP,     /* Item List dialog (Ramp) */  
    DLGCTX_FILE_TEXTURE,      /* File Dialog (Texture file) */
    DLGCTX_FILE_GEOMETRY,     /* File Dialog (Geometery file) */
    DLGCTX_FILE_LOD,          /* File Dialog (LOD file) */
    DLGCTX_FILE_VOICE,        /* File Dialog (Voice file) */
    DLGCTX_FILE_RADPATTERN,   /* File Dialog (Rad Pattern file) */
    DLGCTX_FILE_NEW_MATERIAL, /* File Dialog (Create a Material file) */
    DLGCTX_FILE_OPEN_MATERIAL,/* File Dialog (Open a Material file) */
    DLGCTX_FILE_SAVE_MATERIAL,/* File Dialog (Save a Material file) */
    DLGCTX_FILE_SAVE_VDI,     /* File Dialog (Save the VDI file) */
    DLGCTX_FILE_SAVE_VRML,    /* File Dialog (Save the VDI file in VRML format) */
    DLGCTX_FILE_SAVE_VPF,     /* File Dialog (Save the VDI file in VPF format) */
    DLGCTX_FILE_SAVE_SECTION_IGES, /* Section mgr save section plane as iges file */
    DLGCTX_FILE_SAVE_SECTION_JPEG, /* Section mgr save section plane as jpeg file */
    DLGCTX_FILE_SELECT_BGF,   /* Select bgf file - used in envelope plugin */
    DLGCTX_FILE_SELECT_IGES,  /* Select iges file - used in envelope plugin */
    DLGCTX_FILE_OPEN_VDI,     /* File Dialog (Open the VDI file) */
    DLGCTX_FILE_SAVE_IMAGE,   /* File Dialog (Save image file */
    DLGCTX_FILE_OBJECT_LIBRARY,    /* File Dialog (Assembly Library) */
    DLGCTX_FILE_MATERIAL_LIBRARY,  /* File Dialog (Material Library) */
    DLGCTX_FILE_ANNOTATE_ICON,  /* Icon File Dialog (Annotatecreate dialog) */
    DLGCTX_FILE_SAVE_VDL,     /* File Dialog (Save the VDL file) */
    DLGCTX_FILE_OPEN_VDL,     /* File Dialog (Open the VDL file) */  
    DLGCTX_FILE_OPEN_PLUGIN,     /* File Dialog (Open a Plugin file) */  
    DLGCTX_FILE_EXPORT_VDL,     /* File Dialog (Export the VDL file) */  
    XDDLG_CTX_TREE_SCENE,     /* Tree Widget (Scene) */
    XDDLG_CTX_TREE_LIBRARY,   /* Tree Widget (Library) */
    DLGCTX_TREE_VIEW,         /* Tree Widget (Tree View) */
    DLGCTX_ACTION_EDIT_EVENT,       /* Action Dialog (Edit) */
    DLGCTX_ACTION_ADD_EVENT,        /* Action Dialog (Insert) */
    DLGCTX_ACTION_EDIT_FRAME,       /* Action Dialog (Edit) */
    DLGCTX_ACTION_ADD_FRAME,        /* Action Dialog (Insert) */
    DLGCTX_EVENT_ACTION_ARG,  /* Event Select Dialog for action argument */
    DLGCTX_BEHAVIOUR_ZONE,    /* Behaviour Dlg (Zone) */
    DLGCTX_BEHAVIOUR_OBJECT,  /* Behaviour Dlg (Assembly) */
    DLGCTX_BEHAVIOUR_FRAME,   /* Behaviour Dlg (Frame) */
    DLGCTX_BEHAVIOUR_ANNOTATION,  /* Behaviour Dlg (Annotation) */
    DLGCTX_SEND_EVENT_SCENE,  /* Send Event Dlg (Scene) */
    DLGCTX_SEND_EVENT_OBJECT, /* Send Event Dlg (Assembly) */
    DLGCTX_WORLD_TREE,        /* Tree Widget (World) */
    DLGCTX_LIBRARIES_TREE,    /* Tree Widget (Libraries) */
    DLGCTX_LIBED_FRONT_MAT,   /* Library Editor (Front Material) */
    DLGCTX_LIBED_BACK_MAT,    /* Library Editor (Back Material) */
    DLGCTX_LIBED_ENVIRONMENT, /* Library Editor (Environment) */
    DLGCTX_LIBED_TEXTURE,     /* Library Editor (Texture) */
    DLGCTX_LIBED_RAMP,        /* Library Editor (Ramp) */
    DLGCTX_LIBED_TOOL_MATERIAL,     /* Library Editor (Tool (Materials)) */
    DLGCTX_LIBED_TOOL_TEXTURE,      /* Library Editor (Tool (Textures)) */
    DLGCTX_LIBED_TOOL_KEYFRAME,     /* Library Editor (Tool (Key Frames)) */
    DLGCTX_NDLST_TREE,        /* Assembly Select (Tree View) */
    DLGCTX_NDLST_EVENT,       /* Assembly Select (Event Dlg) */
    DLGCTX_NDLST_ACTION,      /* Assembly Select (Action Dlg) */
    DLGCTX_ABOUT_INIT,        /* About Dlg (Initialization) */
    DLGCTX_ABOUT_HELP,        /* About Dlg (Help) */
    DLGCTX_SELECTION_USERROLE,/* Selection dialog (userRole) */ /* WMan - Selection dialog contexts */
    DLGCTX_ANNOTATECREATE_NEW, /* annotation create dlg (From new creation) */
    DLGCTX_ANNOTATECREATE_VIEW, /* annotation create dlg (From reply creation */
    DLGCTX_NEW_ASSEMBLY,      /* Create new assembly */
    DLGCTX_NEW_CAMERA,        /* Create new assembly of type Camera */
    DLGCTX_NEW_HYPERLINK,     /* Create new assembly of type Hyperlink */
    DLGCTX_NEW_KEYFRAME,      /* Create new Keyframe on an assembly */
    DLGCTX_ADD_ACTION,        /* Add an action in frame editor */
    DLGCTX_EDIT_ACTION,       /* Edit an action in frame editor */
    DLGCTX_DELETE_ACTION,     /* Delete an action in frame editor */
    DLGCTX_POPUP_MESSAGE_DLG, /* Ask whether the message dialog should be viewed */
    DLGCTX_CREATE_LANDMARK,   /* Ask whether to create a new camera from landmark create dlg */
	DLGCTX_DELETE_FRAME,	  /* Ask whether to delete the selected frame */
	DLGCTX_DELETE_KEYFRAME,	  /* Ask whether to delete the selected keyframe */
    DLGCTX_FILE_NEW,          /* New file in assembly manager */
    DLGCTX_FILE_OPEN,         /* Open file in assembly manager */

    DLGCTX_LNDMK_PROP_DLG,    /* Landmark Property dialog popup */
    DLGCTX_LNDMK_PROP_NEW_FOLDER, /* Landmark Property Dlg Creating Folder */
    DLGCTX_LNDMK_PROP_NEW_LNDMK,  /* Landmark Property Dlg Creating Landmark */
    DLGCTX_LNDMK_PROP_EDIT,       /* Landmark Property Dlg Editing */

    DLGCTX_LICENSE_WARNING,   /* Licensed feature (Warning dialog) */
    DLGCTX_SLCT_LST_VWORLD,   /* Associate Assembly property editor with Virtual World selection list */
    DLGCTX_SLCT_LST_LIB,      /* Associate Assembly property editor with Library selection list */

    DLGCTX_FLTP_PLAY,         /* Flight Path dialog Play mode */
    DLGCTX_FLTP_EDIT,         /* Flight Path dialog Edit mode */
              
    DLGCTX_SELECT_ASSEMBLIES, /* new selection dlg - select assemblies mode */
    DLGCTX_SELECT_ASSEMBLY, /* new selection dlg - select single assembly mode */
    DLGCTX_SELECT_EVENT, /* new selection dlg - select events mode */
    DLGCTX_SELECT_ACTION, /* new selection dlg - select actions mode */
    DLGCTX_SELECT_MATERIAL, /* new selection dlg - select materials mode */
    DLGCTX_SELECT_TEXTURE, /* new selection dlg - select textures mode */
    DLGCTX_SELECT_KEYFRAME, /* new selection dlg - select keyframes mode */
    DLGCTX_SELECT_CAMERA, /* new selection dlg - select cameras mode */
    DLGCTX_SELECT_QUERY, /* new selection dlg - select single query mode */
    DLGCTX_SELECT_QUERYRESULTS, /* new selection dlg - select query result list */
    DLGCTX_SELECT_QUERIES, /* new selection dlg - select queries mode */

    DLGCTX_NO_CONTEXT         /* NO CONTEXT !! */
} dlgContext;

typedef struct FileSelectDlgCbDataT { 
    dialogInstanceData *inst;
    char *fileName;
} FileSelectDlgCbDataT;

XDV_EXPORT void XdDlgInitial(void);
XDV_EXPORT int XdDlg_AddNewDlgType(compT (*instanceAndPopup)(compT parent), 
                               void (*popdown)(dialogInstanceData *inst),
                               int (*popup)(dialogInstanceData *inst), 
                               int (*confirmPopdown)(dialogInstanceData *inst));
XDV_EXPORT dialogInstanceData *XdDlgCreate(dialogType dlgType, dialogInstanceData *parentInst);
XDV_EXPORT void XdDlg_RequestUpdateOfAssemblyDlgs(char *nodeName);
XDV_EXPORT void XdDlgUpdate(dialogType dlgType, uint32 whatChanged);
XDV_EXPORT void XdDlgForceInstUpdate(dialogType dlgType, compT comp);
XDV_EXPORT void XdDlgAccept(dialogType dlgType, compT comp);
XDV_EXPORT void XdDlgApply(dialogType dlgType, compT comp);
XDV_EXPORT int  XdDlgClose(dialogInstanceData *inst);
XDV_EXPORT int  XdDlgClosePhase1(dialogInstanceData *inst);
XDV_EXPORT void XdDlgClosePhase2(dialogInstanceData *inst);
XDV_EXPORT void XdDlgInit(dialogType dlgType, compT comp);
XDV_EXPORT void XdDlgPopdown(dialogType dlgType, compT comp);
XDV_EXPORT void XdDlgForcePopdown(dialogType dlgType, compT comp);
XDV_EXPORT dialogInstanceData *XdDlgPopup(dialogType callDlgType, compT comp, 
                       dialogType dlgType, dlgContext context, void *clientData);
XDV_EXPORT dialogInstanceData *XdDlgRequestPopup(dialogType callDlgType, compT comp, 
                       dialogType dlgType, dlgContext context, void *clientData);

XDV_EXPORT dlgContext XdDlgGetContext(dialogInstanceData *inst);
XDV_EXPORT void *XdDlgGetInstanceData(dialogInstanceData *inst);
XDV_EXPORT void XdDlgSetClientData(dialogType dlgType, void *clientData);
XDV_EXPORT void XdDlgComponentSet(dialogType dlgType, dialogComponent component, void *compPtr);
XDV_EXPORT compT XdDlgComponentGet(dialogType dlgType, dialogComponent comp);
XDV_EXPORT compT XdDlgComponentQry(dialogInstanceData *inst, dialogComponent compType);
XDV_EXPORT dialogComponent XdDlgGetComponentID(dialogType dlgType, dialogInstanceData *inst, compT comp);
XDV_EXPORT void *XdDlgInstanceSpecificDataQry(dialogType dlgType, compT comp);
XDV_EXPORT dialogInstanceData *XdDlgInstanceCallDataQry(dialogType dlgType, compT comp);
XDV_EXPORT void *XdDlgInstanceCallDataSpecificDataQry(dialogType dlgType, compT comp);
XDV_EXPORT void XdDlgSetRequestUpdate(dialogInstanceData *inst, uint8 val);

XDV_EXPORT void XdFileSelectDlg_AddDefaultFileNameCallback(dialogInstanceData *callingInst, XdCallBack *callBack);
XDV_EXPORT void XdFileSelectDlg_RemoveDefaultFileNameCallback(dialogInstanceData *callingInst, XdCallBack *callBack);
XDV_EXPORT void XdFileSelectDlg_AddSelectedFileNameCallback(dialogInstanceData *callingInst, XdCallBack *callBack);
XDV_EXPORT void XdFileSelectDlg_RemoveSelectedFileNameCallback(dialogInstanceData *callingInst, XdCallBack *callBack);
XDV_EXPORT void XdFileSelectDlg_AddClosedCallback(dialogInstanceData *callingInst, XdCallBack *callBack);
XDV_EXPORT void XdFileSelectDlg_RemoveClosedCallback(dialogInstanceData *callingInst, XdCallBack *callBack);
XDV_EXPORT void XdActionDlgCreateActionParameterFields(dialogInstanceData *inst, 
                       ECActionFunc *actionFunc, void **parameters);
XDV_EXPORT void XDActionDlg_MakeSelectionCB(void *contextData, void *callData);
XDV_EXPORT void XDActionDlg_MakeActionSelectionCB(void *contextData, void *callData);
XDV_EXPORT void XDActionDlg_CloseActionSelectionCB(void *contextData, void *callData);
XDV_EXPORT void XdActionDlgSetSelectDlg(dialogInstanceData *actionInst, dialogInstanceData *selectInst);
XDV_EXPORT void XdActionListDlgSetFilter(dialogInstanceData *inst, char *filter, int fromGUI);
XDV_EXPORT void XdEventListDlgSetFilter(dialogInstanceData *inst, char *filter, int fromGUI);
XDV_EXPORT void XdDlgRemoveEventListCb(XdCallBack *cbFunc);
XDV_EXPORT void XdDlgAddEventListCb(XdCallBack cbFunc, void *cbData);
XDV_EXPORT void XdDlgSetEventList(void);
XDV_EXPORT void XdDlgSetActionList(void);
XDV_EXPORT void XdNodeListDlgSetFilter(dialogInstanceData *inst, char *filter, int fromGUI);
XDV_EXPORT dialogInstanceData *XdDlgInstanceQry(dialogType dlgType, compT comp);
XDV_EXPORT void XdDlgAllInstancesOperate(dialogType dlgType, 
                       void (*proc)(dialogInstanceData *, void *), 
                       void *userData);
void XdDlg_InstanceAlterationWarning(DCIParseTokens type, char **instanceList, 
                                     char **rootList, char *linkParentName);

XDV_EXPORT void XdDlgRemoveActionListCb(XdCallBack *cbFunc);
XDV_EXPORT void XdDlgAddActionListCb(XdCallBack cbFunc, void *cbData);

XDV_EXPORT void XdDlgSetPaste(int val);
XDV_EXPORT int  XdDlgGetPaste(void);
XDV_EXPORT void  XdWarningDlgSetMsg(char *msg);
XDV_EXPORT char *XdWarningDlgGetMsg(void);
XDV_EXPORT int  XdDlgObjChangesWillBeLost(void);
XDV_EXPORT int  XdDlgZoneChangesWillBeLost(void);
XDV_EXPORT int  XdDlgChangesWillBeLostInDlgType(dialogType dlgType);
XDV_EXPORT int  XdDlgIsUp(dialogInstanceData *inst);
XDV_EXPORT void XdDlg_AddCreatedCB(dialogType type, void(callBack)(void *contextData, void *callData), 
                               void *callData);

XDV_EXPORT int  XdLicense_Check(dialogType callDlgType, compT comp, char *cmd, 
                      ECLicensedFeaturesEnum feature);
XDV_EXPORT void XdDlg_SetAssyViewMode(int onoff);
XDV_EXPORT int  XdDlg_GetAssyViewMode(void);

/* Regular Expression functions */
char *XdRegExpCompile(char *str);
int   XdRegExpMatch(char *str, char *regExp);
char *XdRegExpCreateErrorMsg(char *msg);


/* section manager support */

XDV_EXPORT void XdSectionSetCallback(void (*cb)(dialogInstanceData *, char *));

#ifdef __cplusplus
}
#endif

#endif /* __XDDLG_H__ */




