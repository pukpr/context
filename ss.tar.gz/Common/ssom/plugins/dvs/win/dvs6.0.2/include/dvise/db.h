/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1998 Division Limited.
--			      All Rights Reserved
--
--
--  System       : 
--  Module       : 
--  Object Name  : $RCSfile: db.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : $Date: 2005/09/13 15:07:48 $
--  Author       : $Author: pukitepa $
--
--  Description	
--
--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __DB_H__
#define __DB_H__

#define DB_PLUGIN_MAJOR_VERSION 1
#define DB_PLUGIN_MINOR_VERSION 0

typedef enum dbElement
{
    DB_ANNOTATION             
} dbElement;

typedef void* dbHandle;         /* handle for plugins to return */

typedef struct dbAction dbAction;
struct dbAction
{
    char* name;
    char** params;
    int numParams;
    dbAction* next;
};
        
typedef struct dbEvent dbEvent;
struct dbEvent
{
    char* name;
    int mod;
    int times;
    char* exp;
    dbAction* actions;
    dbEvent* next;
};

typedef struct dbEventList
{
    dbEvent* events;
} dbEventList;

DV_EXPORT dbEventList* dbCreateEventList(void);
DV_EXPORT dbEvent* dbCreateEvent(const char* const name,
                                 const int mod,
                                 const int times,
                                 const char* const exp);
DV_EXPORT dbAction* dbCreateAction(const char* const name, const int numParams);
DV_EXPORT void dbSetActionParameter(char** param, const char* const value);

DV_EXPORT void dbFreeEventList(dbEventList* eventList);


#endif /* __DB_H__ */
