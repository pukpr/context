/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1994 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS 2.1
--  Module       : libvc
--  Object Name  : $RCSfile: vcerror.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : $Date: 2005/09/13 15:08:06 $
--  Author       : $Author: pukitepa $
--
--  Description	
--	Vcerror routines.
--
--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __VCERROR_H__
#define __VCERROR_H__

#include <dsys/du.h>

#define VC_Warn  duWarn
#define VC_Error duError
#define VC_Fatal duFatal

#endif /* __VCERROR_H__ */
