/****************************************************************************
 *
 *  			Copyright 1998 Division Ltd.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: dlgprogress.h,v $
 *  Revision      : $Revision: 1.1 $
 *  Date          : $Date: 2005/09/13 15:08:19 $
 *  Author        : $Author: pukitepa $
 *  Created       : Thu Mar 5 13:39:11 1998
 *  Last Modified : <130798.1035>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 *  $Log: dlgprogress.h,v $
 *  Revision 1.1  2005/09/13 15:08:19  pukitepa
 *  init
 *
 *  Revision 1.2  1998/07/15 16:15:20  simon
 *  made some changes to the progress dlg, and file dlgs so they could be
 *  called from a plugin.  Added a couple of new types for file dlg.
 *
 *  Revision 1.1  1998/04/01 14:16:49  simon
 *  added progress dlg
 *
 *  Revision 1.1  1998/03/30 15:28:23  simon
 *  Added the dist create dlg
 *
 *  Revision 1.1  1998/03/19 16:20:42  simon
 *  added the new distance tool
 *
 *
 ****************************************************************************
 *
 *  Copyright (c) 1998 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 * This  document  may  not, in  whole  or in  part, be  copied,  photocopied,
 * reproduced,  translated,  or  reduced to any  electronic  medium or machine
 * readable form without prior written consent from Division Ltd.
 *
 ****************************************************************************/

#ifndef __DLGPROGRESS_H
#define __DLGPROGRESS_H

#include "wkeys.h"
#include "xddlg.h"

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

#ifndef XDV_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `XDV_EXPORT'
 */
#ifdef  _LIB_XDV
#define XDV_EXPORT __declspec(dllexport) extern
#else
#define XDV_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define XDV_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ifndef XDV_EXPORT */

typedef struct dlgProgressT dlgProgressT; /* Prototype */

XDV_EXPORT dlgProgressT *XdProgressDlg_Create(compT parent);
XDV_EXPORT int XdProgressDlg_Update(dialogInstanceData *inst);
XDV_EXPORT void XdProgressDlg_Destructor(dialogInstanceData *inst);

XDV_EXPORT void XdProgressDlg_RegisterCancelCb(dialogInstanceData *inst, XdCallBack *callBack,
                               void *callData);
XDV_EXPORT void XdProgressDlg_RegisterCompleteCb(dialogInstanceData *inst, XdCallBack *callBack,
                                 void *callData);
XDV_EXPORT void XdProgressDlg_SetTitle(dialogInstanceData *inst, char *text);
XDV_EXPORT void XdProgressDlg_SetLabel(dialogInstanceData *inst, char *text);
XDV_EXPORT void XdProgressDlg_SetBar(dialogInstanceData *inst, int val);

XDV_EXPORT void XdProgressDlg_Cancel(compT wig);

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif
#endif /* __DLGPROGRESS_H */
