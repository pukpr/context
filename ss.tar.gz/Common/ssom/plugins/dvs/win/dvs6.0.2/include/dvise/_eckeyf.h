/****************************************************************************
 *
 *  			Copyright 1995 Division Limited.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: _eckeyf.h,v $
 *  Revision      : $Revision: 1.1 $
 *  Date          : $Date: 2005/09/13 15:07:47 $
 *  Author        : $Author: pukitepa $
 *  Last Modified : <100898.1521>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 *  $Log: _eckeyf.h,v $
 *  Revision 1.1  2005/09/13 15:07:47  pukitepa
 *  init
 *
 *  Revision 1.18  1998/08/10 14:52:23  simon
 *  added a flag
 *
 *  Revision 1.17  1998/06/16 15:46:06  rajini
 *  Added support for template updates.
 *
 *  Revision 1.16  1997/10/07 09:15:23  simon
 *  Lots of fixes
 *
 *  Revision 1.15  1997/06/13 15:15:49  clives
 *  *** empty log message ***
 *
 *  Revision 1.14  1997/05/09 16:17:49  clives
 *  *** empty log message ***
 *
 *  Revision 1.13  1997/04/22 12:35:12  simon
 *  *** empty log message ***
 *
 *  Revision 1.12  1997/03/19 10:43:33  simon
 *  *** empty log message ***
 *
 *  Revision 1.11  1997/03/13 17:59:26  simon
 *  *** empty log message ***
 *
 *  Revision 1.10  1996/12/17 15:25:12  clives
 *  *** empty log message ***
 *
 *  Revision 1.9  1996/12/06 14:16:14  clives
 *  *** empty log message ***
 *
 *  Revision 1.8  1996/12/04 10:59:16  clives
 *  *** empty log message ***
 *
 *  Revision 1.7  1996/12/04 09:59:26  clives
 *  *** empty log message ***
 *
 *  Revision 1.6  1996/11/07 12:19:32  alex
 *  *** empty log message ***
 *
 *  Revision 1.5  1996/11/05 16:45:56  alex
 *  *** empty log message ***
 *
 *  Revision 1.4  1996/11/05 12:22:44  clives
 *  *** empty log message ***
 *
 *  Revision 1.3  1996/11/04 15:23:34  clives
 *  *** empty log message ***
 *
 *  Revision 1.2  1996/10/31 15:09:14  alex
 *  *** empty log message ***
 *
 *  Revision 1.1  1996/10/09 17:10:37  alex
 *  *** empty log message ***
 *
 *
 ****************************************************************************
 *
 *  Copyright (c) 1995 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 *  This Document may not, in whole or in part, be copied,
 *  photocopied, reproduced, translated, or reduced to any
 *  electronic medium or machine readable form without prior
 *  written consent from Division Ltd.
 ****************************************************************************/

#ifndef ___ECKEYF_H__
#define ___ECKEYF_H__


typedef struct _ECFrameUpdateCbList {
    ECFrameUpdateCbPtr callbackPtr;
    void *userdata;
    struct _ECFrameUpdateCbList *next;
} ECFrameUpdateCbList;

typedef struct _ECKeyFrameUpdateCbList {
    ECKeyFrameUpdateCbPtr callbackPtr;
    void *userdata;
    struct _ECKeyFrameUpdateCbList *next;
} ECKeyFrameUpdateCbList;


typedef struct _ECLinkWrapper ECLinkWrapper;

struct _ECLinkWrapper {
    ECLinkWrapper *prevLink;
    ECLinkWrapper *nextLink;
    VWidget *linkWidget;
    dmPoint linkPoint;
};



/* Internal Flags BITWISE OPERATORS */

#define _ECFRAME_WIDGET_PICKED 0x1
#define _ECFRAME_MAPPED 0x2
#define _ECFRAME_WIDGET_SELECTED 0x4
#define _ECFRAME_WIDGET_BODY_DRAG 0x8

struct ECFrame {
    /* the first four fields MUST remain in the same order */
    ECItemType        itemType;
    ECKeyFrames      *keyFrames;
    char             *name;
    char             *pathName;
    void             *clientData;
    /* ... */
    uint32            flags;
    uint32            iFlags;
    FrameType         type;   
    int               highlighted;
    float32           time;
    float32           frameSpeed;
    float32           arcLength;
    ECPathInterpolationType  pathInterp;
    ECSpeedInterpolationType speedInterp;
    ECFrame          *prev;
    ECFrame          *next;
    dmPoint point;
    dmQuaternion quat;
    dmScale scale;
    ECEvent *event;
    ECFrameUpdateCbList *updateCbList;
    
    /* Widget display stuff */
    VWidget *markerWidget;
    ECLinkWrapper *link;
    VWidget *dummyLink;                 /* Used only on the pre and post frames */
};


typedef struct ECKeyFramesList_ {
    ECKeyFrames *keyFrames;
    struct ECKeyFramesList_ *next;
}ECKeyFramesList;


/* iFlags BITWISE OPERATORS ===================================== */

#define EC_KEYFRAME_MAPPED_OUT 0x1
#define EC_KEYFRAME_MAP_PRE_AND_POST_FRAMES 0x2
#define EC_KEYFRAME_RECORD 0x4

struct ECKeyFrames {
    ECItemType   type;
    ECAssembly  *owner;
    char        *name;
    char        *pathName;
    void        *clientData;
    ECKeyFrames *definition;
    ECItem *instanceList;
/* =========================Don't touch anything above this line in the structure */    
    char *libraryName;
    int instances;
    ECKeyFramesList _instanceList; /* FIXME: Is this used anywhere? */
    unsigned short int completed;
    uint32 flags;
    uint32 iFlags;
    
    ECFrame   *prePreFrame, *preFrame, *thisFrame;
    
    dmMatrix offsetMatrix;
    dmPoint point;
    dmQuaternion quat;
    dmScale scale;
    
    ECStateType state;
    int loop; /* < 0 means forever, No, -1 means forever simon 13/3/97 */
    float32 totalTime;
    float32 timeOffset;
    float32 timeScalar; /* was timeScalar */
    
    float32 startTime; /* if this points to a value equal to EC_NOW_VALUE 
			* then the next field is taken as the start time
			* when set, otherwise set to the current time
			*/
    float32 timeStarted; 
    float32 timeElapsed; /* used to store elapsed time when paused */
    float32 loopElapsedTime; /* simon 18/3/97 holds the running time since start of current loop*/
    
    ECPathInterpolationType pathInterp;
    ECSpeedInterpolationType speedInterp;
    ECPositionMode	mode;
    
    ECFrame preStartFrame;
    ECFrame postEndFrame;
    ECFrame *frames;  /* frame list */
    
    char    *frameSelectMat;
    char    *frameSelectHiMat;
    
    /* Widget display stuff */
    uint32  displayed;
    VWidget *editToplevel;              /* Widget containing all other display widgets */
    char    *markerName;
    char    *markerMat;
    char    *markerHMat;
    int     linkSegments;
    float32 markerGap;
    float32 linkGap;
    float32 adjustedLinkWidth;
    float32 linkWidthForUnitObject;
    dmPoint alignmentVector;
    char    *linkName;
    char    *linkMat;
    char    *linkHMat;
    
    /* Pre adn post frame display related resource info */
    char    *dummyMarkerName;
    char    *dummyMarkerMat;
    char    *dummyMarkerHMat;
    char    *dummyMarkerSelectMat;
    char    *dummyMarkerSelectHMat;
    ECKeyFrameUpdateCbList *updateCbList;
    ECAction *updateAction;

    /* offcentred stuff for entities bbox simon 13/3/97 */
    void *vcBoundBoxHandle;
    dmPoint bboxOffset;
    dmScale bboxScale;
    float32 size;
    
    int correctForAssSize;
    dmScale correctedScale;
} /* ECKeyFrames is prototyped earlier */;

DV_EXPORT void ECFrame_ExecuteUpdateCbList(ECFrame *ecFrame, uint32 eventFlags, ECFrameUpdateCbList *cbList);
DV_EXPORT void ECKeyFrames_ExecuteUpdateCbList(ECKeyFrames *ecKeyFrames, uint32 eventFlags, 
                                             void *eventData, ECKeyFrameUpdateCbList *cbList);
DV_EXPORT int ECFrame_GetIndex(ECFrame *f);
DV_EXPORT ECFrame *ECKeyFrames_GetIndexedFrame(ECKeyFrames *k, int i);


#endif /* ___ECKEYF_H__ */
