/*
 *    PROJECT:      dvise
 *    SUBSYSTEM:    ec
 *    MODULE:
 *
 *    File:         $RCSfile: event.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:07:54 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: event.h,v 1.1 2005/09/13 15:07:54 pukitepa Exp $
 *
 *    FUNCTION:
 *
 *
 *
 * Copyright (c) 1994 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
*/

#ifndef _EVENT_H
#define _EVENT_H

#ifdef __cplusplus
extern "C" {
#endif

#include "ectools.h"

/* PUBLIC DEFINES =======================================*/

#define DVISE_KERNEL_EVENT    0x01
#define CLIENT_EVENT          0x02
#define ANIMATION_LOOP_EVENT  0x03
#define TOOLBOX_EVENT         0x04

#define INTRNL_EVENTS_DISABLE 0x0
#define INTRNL_EVENTS_ENABLE  0x01

#define KF_EVENT_GOTO_FIRST          1
#define KF_EVENT_GOTO_LAST           2
#define KF_EVENT_STOP                3
#define KF_EVENT_PAUSE               4
#define KF_EVENT_UNPAUSE             5 
#define KF_EVENT_PLAY                6
#define KF_EVENT_STEP_FORWARD        7
#define KF_EVENT_DEFAULT_VISUALS_ON  8
#define KF_EVENT_MOVIE_VISUALS_ON    9
#define KF_EVENT_VISUALS_OFF        10
#define KF_EVENT_LOOPING_ON         11
#define KF_EVENT_LOOPING_OFF        12
#define KF_EVENT_RELATIVE_POS       13
#define KF_EVENT_ABSOLUTE_POS       14
#define KF_EVENT_RECORD_ON          15
#define KF_EVENT_RECORD_OFF         16
#define KF_EVENT_QUERY_SELECT       17
#define KF_EVENT_QUERY_RUN          18
#define KF_EVENT_STEP_BACKWARD      19

/* the following index settings are used with ECEventData_GetTemporaryStruc()
 * DON'T reuse the values which are already defined - create new ones up
 * to the value of MAX_TMP_STRUCS for each new use of the function
 */
#define ECEVENT_MAX_TMP_STRUCS      10
#define ECEVENT_TMP_STRUC_1          1
#define ECEVENT_TMP_STRUC_2          2
#define ECEVENT_TMP_STRUC_3          3

/* PUBLIC TYPES =========================================*/

struct ECEvent {
    int 	     type;
    char            *exp;   /* the macro expression which must evaluate 
			     * to TRUE for this event's action functions
			     * to be triggered
			     */
    int 	     mod;
    int 	     times; /* how many times can this event be done? */
    int 	     done;  /* how many times has this event been triggered? */
    struct ECAction *actionList;
    struct ECEvent  *next;
};

struct ECExtraEventData
{
    void   *toolbox;                    /* event came from this toolbox */
    VWidget   *widget;                  /* event came from this widget */
    ECKeyFrames *keyFrames;             /* event came from these keyframes */
};

struct ECEventData
{
    VCBody	   *body;
    VCAttribute	   *bodyPart;
    uint32	    input;
    struct ECItem  *focus;
    int             origin;
    ECUserData     *uData;
    void           *toolbox;            /* event came from this toolbox */
    VWidget        *widget;             /* event came from this widget */
    ECKeyFrames    *keyFrames;          /* event came from these keyframes */
};

/* the following structure is used when event data is parsed, and when event
 * data is used in a client program
 */
struct EC_DCI_EventData {
    char *bodyName;
    char *bodyPartName;
    struct ECItem  *focus;
    uint32 input;
    ECUserData     *uData;
};


/* PUBLIC VARIABLES ======================================*/


/* PUBLIC FUNCTIONS ======================================*/


/* ================== EventList functions ==================== */

DV_EXPORT ECEventList *ECEventList_Allocate(void);
DV_EXPORT int32 ECEventList_Destroy(ECEventList *);
DV_EXPORT ECEventList *ECEventList_Create(int32 eventId, ECAction *actions);
DV_EXPORT int32 ECEventList_CopyDefined(ECEventList *def, ECEventList *newEList);
DV_EXPORT ECEventList *ECEventList_Copy(ECEventList *from);
/*
 * Allocate memory for a new ECEventList and copy 
 * the information from an existing structure
 * into it
 */
DV_EXPORT char *ECEventList_GetName(ECEventList *);
DV_EXPORT ECEvent *ECEventList_GetEvents(ECEventList *);
DV_EXPORT ECEvent **ECEventList_GetEventsPtr(ECEventList *);
DV_EXPORT char *ECEventList_CheckLibName(ECEventList *);
DV_EXPORT int32 ECEventList_SetName(ECEventList *, char *);
DV_EXPORT char *ECEventList_CheckLibName(ECEventList *);
DV_EXPORT int32 ECEventList_AddEvent(ECEventList *, ECEvent *);
DV_EXPORT ECEvent *ECEventList_AddEventAction(ECEventList *, int, char *, ECAction *);
DV_EXPORT int32 ECEventList_ApplyChanges(ECEventList *orig, ECEventList *changes);
DV_EXPORT int ECEventLists_Differ(ECEventList *first,
			      ECEventList *second);
/*
 * Look for any difference between two event lists
 * and their associated action lists.
 */

/* ================== Event functions ===================== */
DV_EXPORT ECEvent *ECEvent_Allocate(void);

/* Extra Data is tagged onto the end of ECActionList_Perform */
DV_EXPORT ECExtraEventData *ECEvent_ExtraDataAllocate(void);
DV_EXPORT void ECEvent_ExtraDataDestroy(ECExtraEventData *extraData);
DV_EXPORT int32 ECEventData_Destroy(ECEventData *Data);

DV_EXPORT ECEvent *ECEvent_Create(int32 eventId);
/*
 * Allocate memory for a ECEvent structure, blank it out and return a pointer
 */
DV_EXPORT ECEvent *ECEvent_Copy(ECEvent *from);
/*
 * Copies a single event.
 */
DV_EXPORT ECEvent *ECEvents_Copy(ECEvent *from);
/*
 * Copies the linked list of events passed.
 */
DV_EXPORT int32 ECEvent_Destroy(ECEvent *);
/* Free off a single event structure, ignoring the linked list */
DV_EXPORT int32 ECEvents_Destroy(ECEvent *);
/* Free off a linked list of event structures */
DV_EXPORT int32 ECEvent_SetType(ECEvent *, int type);
DV_EXPORT int32 ECEvent_SetExpression(ECEvent *, char *exp);
/*
 * Set the event type for a EC event, which should previously
 * have been EC_EVENT_UNDEFINED (i.e. NULL);
 */
DV_EXPORT int32 ECEvent_SetAssemblyName(ECEvent *, char *name);
/*
 * Set the object name for a ECEvent.  This is used in specific
 * collision detection.
 */
DV_EXPORT int32 ECEvent_SetLimb(ECEvent *event, char *name);
DV_EXPORT ECItem *ECEvent_GetItemList(ECEvent *event);
DV_EXPORT ECItem **ECEvent_GetItemListPtr(ECEvent *event);
ECAction *ECEventFindNamedAction(ECEvent *event, char *namedActionFunc);
ECAction *ECEventFindAction(ECEvent *event, ECActionFunc *actionFunc);
DV_EXPORT int32 ECEvent_AddAction(ECEvent *, ECAction *);
DV_EXPORT int32 ECEvent_RemoveAction(ECEvent *, ECAction *);
/*
 * Add an event to the list of actions for a ECEvent
 * or, if the action list pointer is NULL, set it to this one.
 */
DV_EXPORT int32 ECEvent_SetZoneName(ECEvent *event, char *zoneName);
DV_EXPORT int32 ECEvent_SetRoleName(ECEvent *event, char *roleName);
DV_EXPORT int32 ECEvent_SetTime(ECEvent *event, int /* time */);
DV_EXPORT int32 ECEvent_SetTimes(ECEvent *event, int times);
/* set the event times for a EC event (max number of times this event occurs)
 */
DV_EXPORT int32 ECEvent_SetMod(ECEvent *event, int mod);
/* set the event mod for a EC event (event occurs every mod ticks)
 */
DV_EXPORT int32 ECEvent_SetTree(ECEvent *event, int tree);
/* If tree is set actions and attributes are applied to the tree
 * of objects/zones for the event */
DV_EXPORT int ECEvent_GetTree(ECEvent *event);
DV_EXPORT int ECEvent_GetType(ECEvent *event);
DV_EXPORT ECEvent *ECEvent_GetNext(ECEvent *event);
DV_EXPORT char *ECEvent_GetAssemblyName(ECEvent *event);
DV_EXPORT ECAction *ECEvent_GetActionList(ECEvent *event);
DV_EXPORT int ECEvent_GetTime(ECEvent *event);
DV_EXPORT int ECEvent_GetTimes(ECEvent *event);
DV_EXPORT int ECEvent_GetMod(ECEvent *event);
DV_EXPORT float32 *ECEvent_GetRate(ECEvent *event);
DV_EXPORT ECEvent *ECEvent_GetByType(ECEvent *list, int type);
/*
 * Find a match for an event type (integer) within a
 * a linked list of ECEvents by checking event types.
 * No match in action lists or other data is required.
 */
DV_EXPORT ECEvent *ECEvent_GetMatch(ECEvent *, ECEvent *list);
/*
 * Find a match for an event within a linked list of events.
 * The event type must match, animation events must match
 * in the frames value and collision events must match
 * in any collision object names specified for them
 * to be considered the same.  A NULL pointer is returned
 * if no match is found.
 */
DV_EXPORT int32 ECEvent_AddEvent(ECEvent *list, ECEvent *event);
/*
 * Add an event to a non-empty event list.
 * The list is checked for an existing event of
 * the same type, if one is found then the action lists
 * are joined, otherwise the new event is added to the
 * end of the event list.
 */
DV_EXPORT int32 ECEventLists_Join(ECEvent **head, ECEvent *tail);
/*
 * Join two event lists together as efficiently as possible.
 * The first argument is of type (ECEvent **) so that if
 * the first list is NULL it can be changed to point to the
 * second list.
 */
DV_EXPORT int ECEvent_NotInList(ECEvent *, ECEvent *list);
/*
 * Check for a match of an event with an event list.
 * The event type must match (as specified in ECEvent_GetMatch);
 * and the action lists must match (as specified in
 * ECAction_NotInList.
 */
DV_EXPORT ECEventData *ECEventData_Create(ECItem *focus, VCBody *body, 
				       VCAttribute *bodyPart, uint32 keyInput, 
				       ECUserData *uData);
DV_EXPORT EC_DCI_EventData *ECEventData_ToDCI(ECEventData *);
DV_EXPORT ECEventData *ECEventData_FromDCI(EC_DCI_EventData *);
DV_EXPORT VCBody *ECEventData_GetBody(ECEventData *data);
DV_EXPORT VCAttribute *ECEventData_GetBodyPart(ECEventData *data);
DV_EXPORT char *ECEventData_GetBodyName(ECEventData *data);
DV_EXPORT char *ECEventData_GetBodyPartName(ECEventData *data);
DV_EXPORT ECItem *ECEventData_GetFocus(ECEventData *data);

DV_EXPORT int32 _ECEvent_Generate(int32, ECEventData *);
DV_EXPORT int32 ECEvent_Generate(int32, ECEventData *);
DV_EXPORT int32 _ECEvent_GenerateForEntity(int32 eventId, void *entity, void *otherEnt,
                                           VCBody *body, VCAttribute *bodyPart, 
                                           uint32 keyInput, ECUserData *uData);
DV_EXPORT int32 ECEvent_GenerateForEntity(int32 eventId, void *entity, void *otherEnt,
                                          VCBody *body, VCAttribute *bodyPart, 
                                          uint32 keyInput, ECUserData *uData);
DV_EXPORT int32 _ECEvent_GenerateForAssemblyTree(int32 eventId, ECAssembly *a,
                                                 VCBody *body, VCAttribute *bodyPart, 
                                                 uint32 keyInput, ECUserData *uData);
DV_EXPORT int32 ECEvent_GenerateForAssemblyTree(int32 eventId, ECAssembly *a,
                                                VCBody *body, VCAttribute *bodyPart, 
                                                uint32 keyInput, ECUserData *uData);
DV_EXPORT int32 _ECEvent_GenerateForFocus(int32, ECEventData *);
DV_EXPORT int32 ECEvent_GenerateForFocus(int32, ECEventData *);
DV_EXPORT void ECEvent_DisableActions(void);
DV_EXPORT void ECEvent_EnableActions(void);
DV_EXPORT void ECEvent_PlugFilterFunc(int (*func)(ECAssembly *));

/* old ecapp functions */
DV_EXPORT void ECUserEvents_Reset(void);
DV_EXPORT int ECInternalEventIdsInitialise(void);
DV_EXPORT void ECInternalEvents_PushState(int);
DV_EXPORT void ECInternalEvents_PopState(void);
/* Puts id numbers into the internal event array */
DV_EXPORT void ECInternalEvents_FlushClientActions(int clientId);
DV_EXPORT VCEntity *ECPickedEntity_Get(VCAttribute *bodyPartAttribute);

DV_EXPORT int ECPickedEntitySet(VCAttribute *bodyPartAttribute, VCEntity *e);
DV_EXPORT ECAction *ECEvent_RegisterActionFunc(int event_type, char *exp, ECActionFunc *func,
					    ECParameter *params);
DV_EXPORT int ECEvent_RegisterPropagateFunc(int eventId, ECAssembly *a, ECAction *propAct);
DV_EXPORT ECAction *ECEvent_DeregisterPropagateFunc(int eventId, ECAssembly *a);
DV_EXPORT int32 ECEvent_RegisterAction(int event_type, char *exp, ECAction *act);
DV_EXPORT int ECEvent_DeregisterAction(int eventId, ECAction *action);
DV_EXPORT int32 ECEventList_TriggerActions(ECEventList *eventList, int eventId, 
					ECEventData *eventData);
DV_EXPORT int ECActionList_Perform(ECEvent *event, ECAction *action, ECEventData *ed);
DV_EXPORT int ECEvent_TriggerInternalActions(int32 eventId, ECEventData *ed);
DV_EXPORT int ECEvent_TriggerAllActions(int eventId, ECEventData *ed);

DV_EXPORT int32 ECEvent_DefsInitialise(void);
/* Reads the internal event names list creating a linked list of
 * ECEventDef structures to which user defined evetn types can be added.
 */

DV_EXPORT unsigned int ECUserEvent_Create(char *name);
DV_EXPORT unsigned int ECEvent_GetIdFromName(char *name);
DV_EXPORT char *ECEvent_GetNameFromId(unsigned int id);
DV_EXPORT ECEventData *ECEventData_GetTemporaryStruc(int index, void *entity, 
                                                     void *otherEnt, VCBody *body, 
                                                     VCAttribute *bodyPart, uint32 keyInput, 
                                                     ECUserData *uData);
DV_EXPORT void ECEventData_FreeTemporaryStruc(ECEventData *ed);

/*====================== Event data stuff ================================*/

/*====================== Various Action Routines =========================*/

DV_EXPORT int ECAction_SetFunc(ECAction *action, ECActionFunc *func);
DV_EXPORT void ECAction_Debug(ECAction *);
DV_EXPORT void ECActionList_Debug(ECAction *);
DV_EXPORT ECAction *ECActionList_RemoveAction(ECAction **list, ECAction *a);
DV_EXPORT int32 ECAction_IsClientAction(ECAction *, int32);
DV_EXPORT int ECAction_SetParameters(ECAction *action, void **params);
DV_EXPORT void **ECAction_GetParameters(ECAction *action);
DV_EXPORT void ECActionFunc_DoDestructor(ECAction *);
DV_EXPORT int ECAction_Call(ECActionFunction func, ECEvent *event, 
                            ECEventData *data,  ECAction *action);
DV_EXPORT ECAction *ECAction_Adjust(ECAction *);
DV_EXPORT int ECActions_Differ(ECAction *a, ECAction *b);

/* Expression event routines */
DV_EXPORT char *ECEvent_GetExpression(ECEvent *event);
DV_EXPORT int32 ECEvent_SetExpression(ECEvent *event, char *exp);
DV_EXPORT char *EC_UIExpToMacro(char *);
DV_EXPORT char *EC_MacroExpToUI(char *);

#ifdef __cplusplus
}
#endif

#endif /* _EVENT_H__ */
