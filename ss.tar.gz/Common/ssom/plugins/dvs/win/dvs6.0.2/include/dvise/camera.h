/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: camera.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:07:48 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: camera.h,v 1.1 2005/09/13 15:07:48 pukitepa Exp $
 *
 *    FUNCTION: defines data structures used in the EC file read/writer
 * 
 *
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */


#ifndef _CAMERA_H
#define _CAMERA_H

#ifdef __cplusplus
extern "C" {
#endif

#include "ectools.h"

/* PUBLIC DEFINES =======================================*/

#define ECCamera ECAssembly
#define ECHyperlink ECAssembly
#define ECLandmark ECAssembly
#define ECAnnotation ECAssembly
#define ECDistance ECAssembly
#define ECEnvelope ECAssembly

#define EC_ASSEMBLY_TYPE_MASK     0xffffff
#define EC_ASSEMBLY_CAMERA            0x01
#define EC_ASSEMBLY_HYPERLINK         0x02
#define EC_ASSEMBLY_LANDMARK          0x04
#define EC_ASSEMBLY_ANNOTATION        0x08
#define EC_ASSEMBLY_LIBRARY           0x10
#define EC_ASSEMBLY_SPARE_1           0x20
#define EC_ASSEMBLY_SPARE_2           0x40
#define EC_ASSEMBLY_FOLDER            0x80
#define EC_ASSEMBLY_FLIGHT_PATH      0x100
#define EC_ASSEMBLY_SECTION          0x200
#define EC_ASSEMBLY_USE_LIBRARY      0x400
#define EC_ASSEMBLY_DISTANCE         0x800
#define EC_ASSEMBLY_DISTANCE_LINE   0x1000
#define EC_ASSEMBLY_DISTANCE_MULTI  0x2000
#define EC_ASSEMBLY_DISTANCE_CIRCLE 0x4000
#define EC_ASSEMBLY_ENVELOPE        0x8000

    /*
     * flightpath control values */
#define FP_EVENT_PLAY            1
#define FP_EVENT_STOP            2
#define FP_EVENT_REWIND          3
#define FP_EVENT_FFORWARD        4
#define FP_EVENT_PAUSE           5
#define FP_EVENT_FRAME_POS       6
#define FP_EVENT_INSERT_FRAME    7
#define FP_EVENT_RECORD_MODE_ON  8
#define FP_EVENT_RECORD_MODE_OFF 9
#define FP_EVENT_VISUALS_ON     10
#define FP_EVENT_SET_TIME       11
#define FP_EVENT_RUN_DATA       12
#define FP_EVENT_UNPAUSE        13
#define FP_EVENT_AUTO_LEAVE_ON  14
#define FP_EVENT_AUTO_LEAVE_OFF 15
#define FP_EVENT_AUTO_PLAY_ON   16
#define FP_EVENT_AUTO_PLAY_OFF  17
#define FP_EVENT_GOTO_FIRST     18
#define FP_EVENT_GOTO_LAST      19
#define FP_EVENT_VISUALS_OFF    20

    /*
     * flightpath status values for the local tick event */
#define FP_STATUS_PLAYING        0
#define FP_STATUS_RECORDING      1
#define FP_STATUS_STOPPED        2

/* 
 * General Assembly flags */
#define EC_ASSEMBLY_RUNTIME_FLAGS   0x9ff1 /* mask to separate run-time
                                            * flags from savable flags */
#define EC_ASSEMBLY_COLLIDE_HANDLER_ADDED 	0x1
#define EC_ASSEMBLY_CREATE_ABSOLUTE 		0x2
#define EC_ASSEMBLY_FREEZE 			0x4
#define EC_ASSEMBLY_FLATTEN 		0x8
/*
 * EC_ASSEMBLY_SELECTED is a bit mask for the two possible types
 * of object selection.
 */
#define EC_ASSEMBLY_SELECTED		0x10
#define EC_ASSEMBLY_LOADED          0x20
#define EC_ASSEMBLY_ENABLED         0x40
/*
 * The following flags are set if the object has been
 * touched or highlighted
 */
#define EC_ASSEMBLY_HIGHLIGHTED		0x80
#define EC_ASSEMBLY_TOUCHED			0x300
#define EC_ASSEMBLY_TOUCHED_2D		0x100
#define EC_ASSEMBLY_TOUCHED_3D		0x200
/*
 * These are not used...yet....but might be useful
 * to prevent selecting a picked object.
 */
#define EC_ASSEMBLY_PICKED			0xC00
#define EC_ASSEMBLY_2D_PICKED		0x400
#define EC_ASSEMBLY_3D_PICKED		0x800
/*
 * This flag is set in an ECAssembly->flags field whilst the object
 * is begin deleted. 
 */
#define EC_ASSEMBLY_BEING_DELETED   0x1000
    /*
     * flag to force this assembly to be loaded on startup
     */
#define EC_ASSEMBLY_FORCE_LOAD      0x2000
#define EC_ASSEMBLY_LOAD_STATE      0x4000
    /*
     * This flag is set if an assembly is attached to the body,
     * by something other than a pick
     */
#define EC_ASSEMBLY_ATTACHED        0x8000

struct ECAssembly_Traverse {
    ECAssembly *root;
    ECAssembly *here;
    int level;
    int32 *maxOrd;
};

/* PUBLIC TYPES =========================================*/

typedef struct ECAssembly_Traverse ECAssembly_Traverse;
typedef struct ECImage ECImage;

/* FUNCTION DECLARATIONS ================================*/

DV_EXPORT ECCamera *ECCamera_Create(char *name, ECAssembly *parent);
DV_EXPORT int ECCamera_Delete(ECCamera *c);
DV_EXPORT int ECCamera_SetIconImage(ECCamera *c, char *f, int s, 
				 VCBody *b, int w, int h);
DV_EXPORT VCTexture *ECCamera_GetIconImage(ECCamera *c);
DV_EXPORT ECCamera *EC_GetFirstCamera(ECAssembly *, ECAssembly_Traverse *);
DV_EXPORT ECCamera *EC_GetNextCamera(ECAssembly_Traverse *);
DV_EXPORT int ECAssembly_IsCamera(ECAssembly *a);
DV_EXPORT int ECCamera_AddFlightPath(ECCamera *cam, float32 separation);
DV_EXPORT int ECCamera_RemoveFlightPath(ECCamera *cam);
DV_EXPORT int ECAssembly_IsFlightPath(ECAssembly *a);

DV_EXPORT ECLandmark *ECLandmark_Create(char *n, ECCamera *ref);
DV_EXPORT int ECLandmark_Delete(ECLandmark *ref);
DV_EXPORT int ECLandmark_SetReference(ECLandmark *l, ECCamera *ref);
DV_EXPORT ECCamera *ECLandmark_GetReference_Old(ECLandmark *l);
DV_EXPORT int ECLandmark_Link(ECLandmark *parent);
DV_EXPORT int ECLandmark_SetIconImage(ECLandmark *c, char *f, int s, 
				   VCBody *b, int w, int h);
DV_EXPORT VCTexture *ECLandmark_GetIconImage(ECLandmark *c);
DV_EXPORT ECLandmark *EC_GetFirstLandmark(ECAssembly *, ECAssembly_Traverse *);
DV_EXPORT ECLandmark *EC_GetNextLandmark(ECAssembly_Traverse *);
DV_EXPORT int ECAssembly_IsLandmark(ECAssembly *a);

DV_EXPORT ECHyperlink *ECHyperlink_Create(char *name, ECAssembly *parent,
				       ECCamera *reference, int eventId, ECActionFunc *func);
DV_EXPORT int ECHyperlink_Delete(ECHyperlink *ref);
DV_EXPORT int ECAssembly_SetHyperlink(ECAssembly *ref, ECCamera *c, 
				   int eventId, ECActionFunc *func);
DV_EXPORT int ECHyperlink_SetReference(ECHyperlink *h, ECCamera *ref, 
				    int eventId, ECActionFunc *func);
DV_EXPORT ECHyperlink *EC_GetFirstHyperlink(ECAssembly *, ECAssembly_Traverse *);
DV_EXPORT ECHyperlink *EC_GetNextHyperlink(ECAssembly_Traverse *);
DV_EXPORT int ECAssembly_IsHyperlink(ECAssembly *a);

DV_EXPORT ECAnnotation *ECAnnotation_Create(char *name, ECAssembly *parent);
DV_EXPORT int ECAnnotation_Delete(ECAnnotation *c);
DV_EXPORT int ECAnnotation_SetIconImage(ECAnnotation *c, char *f, int s, 
				     VCBody *b, int w, int h);
DV_EXPORT VCTexture *ECAnnotation_GetIconImage(ECAnnotation *c);
DV_EXPORT ECAnnotation *EC_GetFirstAnnotation(ECAssembly *, ECAssembly_Traverse *);
DV_EXPORT ECAnnotation *EC_GetNextAnnotation(ECAssembly_Traverse *);
DV_EXPORT int ECAssembly_IsAnnotation(ECAssembly *a);

DV_EXPORT ECAssembly *ECSection_Create(char *name, ECAssembly *parent);
DV_EXPORT int ECSection_Delete(ECAssembly *c);
DV_EXPORT int ECAssembly_IsSection(ECAssembly *a);

DV_EXPORT ECDistance *ECDistance_CreateLine(char *name, ECAssembly *parent);
DV_EXPORT ECDistance *ECDistance_CreateMulti(char *name, ECAssembly *parent);
DV_EXPORT ECDistance *ECDistance_CreateCircle(char *name, ECAssembly *parent);
DV_EXPORT int ECDistance_Delete(ECDistance *c);
DV_EXPORT int ECAssembly_IsDistance(ECAssembly *a);
DV_EXPORT int ECAssembly_IsDistanceLine(ECAssembly *a);
DV_EXPORT int ECAssembly_IsDistanceMulti(ECAssembly *a);
DV_EXPORT int ECAssembly_IsDistanceCircle(ECAssembly *a);
DV_EXPORT int ECAssembly_IsLight(ECAssembly *a);
DV_EXPORT int ECAssembly_HasPivot(ECAssembly *a);
DV_EXPORT int ECAssembly_IsEnvelope(ECAssembly *a);

/*****************************************************************************
 * Generic assembly routines for cameras etc
 *****************************************************************************/

DV_EXPORT ECAssembly *ECAssembly_GetFirst(ECAssembly *a, ECAssembly_Traverse *t);
DV_EXPORT ECAssembly *ECAssembly_GetNext(ECAssembly_Traverse *t);
DV_EXPORT int32 ECAssembly_GetRelativeDepth(ECAssembly *a, ECAssembly *root);
DV_EXPORT int ECAssembly_SetIconImage(ECAssembly *c, char *f, int s, 
				   VCBody *b, int w, int h);
DV_EXPORT VCTexture *ECAssembly_GetIconImage(ECAssembly *c);
DV_EXPORT int ECAssembly_IsSelected(ECAssembly *a);
DV_EXPORT int ECAssembly_IsLoaded(ECAssembly *a);
DV_EXPORT int ECAssembly_IsEnabled(ECAssembly *a);
DV_EXPORT int ECAssembly_IsHighlighted(ECAssembly *a);
DV_EXPORT int ECAssembly_IsPicked(ECAssembly *a);
DV_EXPORT int ECAssembly_IsLibrary(ECAssembly *a);
DV_EXPORT int ECAssembly_IsInLibrary(ECAssembly *a);
DV_EXPORT int ECAssembly_IsSpare1(ECAssembly *a);
DV_EXPORT int ECAssembly_IsSpare2(ECAssembly *a);
DV_EXPORT int ECAssembly_IsAttached(ECAssembly *a);
DV_EXPORT int ECAssembly_CanFlyTo(ECAssembly *a);
DV_EXPORT ECAssembly *ECAssembly_GetIncludeNode(ECAssembly *obj);

/******************************************************************************
 * Icon routines for handling camera images
 ******************************************************************************/

DV_EXPORT VCTexture *ECIcon_GetTextureImage(ECIcon *i);
DV_EXPORT char *ECIcon_GetTextureName(ECIcon *i);
DV_EXPORT char *ECIcon_GetTextureFileName(ECIcon *i);
DV_EXPORT int32 ECIcon_SetTextureFromSnap(ECIcon *icon, VCBody *bod, int wid, int hgt);
DV_EXPORT int32 ECIcon_SetTextureFromFile(ECIcon *icon, char *filename);
DV_EXPORT int32 ECIcon_Delete(ECIcon *c);
DV_EXPORT int32 ECIcon_ToFile(ECIcon *c);

#ifdef __cplusplus
}
#endif

#endif /* _CAMERA.H__ */
