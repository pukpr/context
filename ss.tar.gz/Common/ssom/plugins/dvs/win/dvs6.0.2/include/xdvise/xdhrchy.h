/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1996 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: xdhrchy.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 7 October 1996
--  Author       : Tony Coombes
--
--  Description	 : Hierarchy management
--
--  Modified     : 
--    $Log: xdhrchy.h,v $
--    Revision 1.1  2005/09/13 15:08:24  pukitepa
--    init
--
--    Revision 1.11  1998/07/02 16:10:42  wman
--    Changes for second edit toolbar and functions.
--
--    Revision 1.10  1998/06/16 13:06:20  wman
--    Changes for Subtree selection, however not totally working.
--    Bug fix for #5522
--
--    Revision 1.9  1998/05/20 11:38:01  rajini
--    Added support for multiple material libraries.
--
--    Revision 1.8  1997/12/02 17:44:23  simon
--    bug fixes
--
--    Revision 1.7  1997/11/14 17:20:52  tony
--    Convert AssyPostSelectionCB to a more generic EntityPostSelectionCallback
--    so that Attribute editors can be updated properly.
--
--    Revision 1.6  1997/11/12 20:14:53  tony
--    Introduced facility to handle Attribute name changes properly.
--
--    Revision 1.5  1997/10/28 17:54:35  simon
--    bug fixes - added assembly status change callback to view widget,
--    and made use of it in library viewer.
--
--    Revision 1.4  1997/10/23 13:31:30  dvs-dev
--    NT changes for the collision and advanced collision dlg.
--    Fixes to get the section code and collision detection code to build on NT.
--    General bug fixes.
--
--    Revision 1.3  1997/10/09 16:19:45  simon
--    bug fixes
--
--    Revision 1.2  1997/08/14 17:38:11  tony
--    Introduced XdTopFile_FindNamedAssemby() because ECTopFile_FindNamedAssembly()
--    searches the top Lib tree first if the path name isn't explicit.
--    NB. ECEntity_CalculatePathName() only generates explicit path names
--        for the Lib tree.)
--
--    Revision 1.1  1997/07/09 12:31:42  simon
--    *** empty log message ***
--
--    Revision 1.41  1997/03/24 21:53:04  tony
--    Changes to allow the create event to be used properly
--
--    Revision 1.40  1997/03/24 20:26:18  wman
--    Bug Fixes
--
--    Revision 1.39  1997/03/22 12:13:40  tony
--    Moved the responsability for querying Assembly Attributes when an
--    editor is poped up to each of the editors _Update (popup) routines,
--    thus giving them far more control over what they edit.
--
--    Revision 1.38  1997/03/21 12:12:58  tony
--    *** empty log message ***
--
--    Revision 1.37  1997/03/18 19:48:20  tony
--    *** empty log message ***
--
--    Revision 1.36  1997/03/17 16:52:32  wman
--    Added selection sensitive menus
--
--    Revision 1.35  1997/03/14 15:45:12  wman
--    Bug Fixes
--
--    Revision 1.34  1997/03/13 17:47:55  tony
--    *** empty log message ***
--
--    Revision 1.33  1997/03/07 20:50:21  tony
--    *** empty log message ***
--
--    Revision 1.32  1997/03/05 16:29:36  tony
--    *** empty log message ***
--
--    Revision 1.31  1997/02/27 21:06:25  tony
--    *** empty log message ***
--
--    Revision 1.30  1997/02/18 17:38:00  tony
--    *** empty log message ***
--
--    Revision 1.29  1997/02/17 17:49:27  tony
--    *** empty log message ***
--
--    Revision 1.28  1997/02/16 17:19:55  tony
--    Cjor VS:
--
--    Revision 1.27  1997/02/10 21:02:20  tony
--    *** empty log message ***
--
--    Revision 1.26  1997/02/04 20:47:35  tony
--    *** empty log message ***
--
--    Revision 1.25  1997/01/30 17:49:20  tony
--    *** empty log message ***
--
--    Revision 1.24  1997/01/09 15:57:17  tony
--    *** empty log message ***
--
--    Revision 1.23  1996/12/13 18:02:22  tony
--    *** empty log message ***
--
--    Revision 1.22  1996/12/09 18:32:38  tony
--    *** empty log message ***
--
--    Revision 1.21  1996/12/06 17:37:59  tony
--    *** empty log message ***
--
--    Revision 1.20  1996/12/05 21:44:56  tony
--    *** empty log message ***
--
--    Revision 1.19  1996/12/03 11:27:51  wman
--    *** empty log message ***
--
--    Revision 1.18  1996/11/29 21:35:55  tony
--    *** empty log message ***
--
--    Revision 1.17  1996/11/27 20:45:29  tony
--    Added Attributes to the Assembly view
--
--    Revision 1.16  1996/11/15 17:21:10  tony
--    *** empty log message ***
--
--    Revision 1.15  1996/11/08 16:48:54  tony
--    *** empty log message ***
--
--    Revision 1.14  1996/11/07 18:02:17  tony
--    *** empty log message ***
--
-- ----------------------------------------------------------------------------
*/

#ifndef __XDHRCHY_H__
#define __XDHRCHY_H__

typedef struct hrchyT hrchyT;
#include <dvise/ectypes.h> /* For ECAssembly */
#include "xdviewd.h"       /* For vieWidgT */


/* This Enum is used to identify the Selection
 * List that a view belongs to. */
typedef enum {
    XDHRCHY_SLCT_LST_PRIVATE, /* Doesn't belong to any Selection List.
                              ** The Selection List of this view is
			      ** independent of all other views. */
    XDHRCHY_SLCT_LST_VWORLD,  /* Virtual World selection list */
    XDHRCHY_SLCT_LST_LIB      /* Libraries selection list */
} hrchySlctnListEnum;

/* This Enum is used to identify the Assembly
 * Hierarchy that a view uses. */
typedef enum {
    XDHRCHY_ZONE, /* Zone hierarchy */
    XDHRCHY_LIB   /* Library hierarchy */
} hrchyEnum;


#ifdef __cplusplus
extern "C" {
#endif

#ifndef XDV_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `XDV_EXPORT'
 */
#ifdef  _LIB_XDV
#define XDV_EXPORT __declspec(dllexport) extern
#else
#define XDV_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define XDV_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ifndef XDV_EXPORT */

XDV_EXPORT hrchyT *XdHrchyCreate(void);
XDV_EXPORT void    XdHrchySetAssy(hrchyT *view, ECAssembly *assembly);
XDV_EXPORT int     XdHrchy_AddView(hrchyT *hrchy, void *userData,
			hrchyEnum whichSubHrchy, int initialDepth, 
			int (*assyFilterCB)(ECAssembly *assy, void *userData), 
			int (*itemFilterCB)(ECItem *item, void *userData), 
			void *filterUserData, 
			void (*hrchyChangedCB)(hrchyT *hrchy, int viewNo, void *userData), 
			void (*assyCreatedCB)(hrchyT *hrchy, int viewNo, ECAssembly *newAssy, 
		            void *userData), 
			void (*entityDeleteCB)(hrchyT *hrchy, int viewNo, void *entity, 
		            void *userData), 
			void (*assySelectedCB)(hrchyT *hrchy, int viewNo, ECAssembly *assy,
			    int row, int selectionCount, void *userData), 
			void (*assyDeselectedCB)(hrchyT *hrchy, int viewNo, ECAssembly *assy, 
		            int row, int selectionCount, void *userData), 
			void (*assyPostSelectionCB)(hrchyT *hrchy, int viewNo, ECAssembly *lastSelected, 
				    int selectionCount, void *userData), 
			void (*assyExposedCB)(hrchyT *hrchy, int viewNo, ECAssembly *assy,
			    int row, int level, int expands, int selected, void *userData), 
			void (*assyRenamedCB)(hrchyT *hrchy, int viewNo, ECAssembly *assy, 
		            int row, void *userData), 
			void (*assyConcealCB)(hrchyT *hrchy, int viewNo, ECAssembly *assy, 
		            ECItem *item, int row, int qty, void *userData), 
			void (*assyExpandedStatusChangeCB)(hrchyT *hrchy, int viewNo, 
		            int row, int expands, int expanded, void *userData), 
                                   void (*assyStatusChangeCB)(hrchyT *hrchy, int viewNo, int row, ECAssembly *assy, 
                            uint32 type, int loaded, int enabled, void *userData), 
			void (*assyUpdatedCB)(hrchyT *hrchy, int viewNo, ECAssembly *assy, 
			    int row, void *userData), 
			void (*itemSelectedCB)(hrchyT *hrchy, int viewNo, ECAssembly *assy, 
			    ECItem *item, int row, int selectionCount, void *userData), 
			void (*itemDeselectedCB)(hrchyT *hrchy, int viewNo, ECAssembly *assy, 
			    ECItem *item, int row, int selectionCount, void *userData)
		);
XDV_EXPORT void    XdHrchyView_RegisterEntityRenameCB(hrchyT *hrchy, int viewNo,
	                void (*entityRenamedCB)(hrchyT *hrchy, int viewNo, void *entity, 
		            void *userData));
XDV_EXPORT void    XdHrchyView_RegisterEntityPostSelectionCB(hrchyT *hrchy, int viewNo,
	                void (*entityPostSelectionCB)(hrchyT *hrchy, int viewNo, void *firstSelectedEntity, 
		            int selectionCount, void *userData));
XDV_EXPORT void    XdHrchy_RemoveView(hrchyT *hrchy, int viewNo);
XDV_EXPORT void    XdHrchy_ExposeChildrenOfSelectedNodes(hrchyT *hrchy, int viewNum, int depth, int expose);
XDV_EXPORT int     XdHrchy_ExposeSpecificAssembly(hrchyT *hrchy, int vNum, ECAssembly *assy);
XDV_EXPORT void    XdHrchy_ExposeChildrenOfRow(hrchyT *hrchy, int viewNum, int row, int level, int expose);
XDV_EXPORT void    XdHrchy_SetSelectedStatusOfRow(hrchyT *hrchy, int viewNum, int row, int selected);
XDV_EXPORT void    XdHrchy_SelectPath(hrchyT *hrchy, int viewNo, char *path, int cumulative, 
                                  int selected, int notify);
XDV_EXPORT void    XdHrchy_DeletePath(hrchyT *hrchy, char *path);
XDV_EXPORT void    XdHrchy_LinkPath(hrchyT *hrchy, char *parentPath, char *childPath);
/*XDV_EXPORT void    XdHrchy_LinkPath(hrchyT *hrchy, char *parentPath, char *childPath); Twice? */
/*XDV_EXPORT void    XdHrchy_SelectedOperate(hrchyT *hrchy, int viewNo, 
                        int (*fn)(ECAssembly *assy, void *userData), void *userData);*/
XDV_EXPORT void    XdHrchy_SelectionListOperate(hrchyT *hrchy, int viewNo, 
                        int representedNodesOnly, 
                        int (*fn)(ECAssembly *assy, void *userData), void *userData);
XDV_EXPORT void    XdHrchy_VirtualWorldAssyOperate(hrchyT *hrchy, 
                        int (*fn)(ECAssembly *assy, void *userData), void *userData);
XDV_EXPORT void    XdHrchy_GivenAssyOperate(ECAssembly *assy,
                        int (*fn)(ECAssembly *assy, void *userData), void *userData);
XDV_EXPORT void   *XdHrchy_GetSelectedNode(hrchyT *hrchy, int viewNo, int exposed, int *isAssy, int *row);
XDV_EXPORT void    XdHrchy_SetAssemblyLoadedStatus(hrchyT *hrchy, char *path, int loaded);
XDV_EXPORT void    XdHrchy_SetAssemblyEnabledStatus(hrchyT *hrchy, char *path, int enabled);
XDV_EXPORT void    XdHrchy_CreatedAssembly(hrchyT *hrchy, ECAssembly *assy);
XDV_EXPORT void    XdHrchy_UpdateAssembly(hrchyT *hrchy, ECAssembly *assy);
XDV_EXPORT void    XdHrchy_RenameAssembly(hrchyT *hrchy, char *path, char *newName);
XDV_EXPORT void    XdHrchy_RenameEntity(hrchyT *hrchy, char *path, ECItemType type, char *newName);
XDV_EXPORT void    XdHrchy_SelectAll(hrchyT *hrchy, int viewNo, int notify);
XDV_EXPORT void    XdHrchy_UnselectAll(hrchyT *hrchy, int viewNo, int notify);
XDV_EXPORT void    XdHrchy_InvertSelection(hrchyT *hrchy, int viewNo, int notify);
XDV_EXPORT void    XdHrchy_SelectRows(hrchyT *hrchy, int viewNo, int *position, int count);
XDV_EXPORT void    XdHrchy_QrySelectedAssyAttributes(hrchyT *hrchy, int viewNo);
XDV_EXPORT void    XdHrchy_ForcePostSelect(hrchyT *hrchy);

XDV_EXPORT int     XdHrchyView_GetSelectedCount(hrchyT *hrchy, int viewNo);
XDV_EXPORT void   *XdHrchyView_GetSelectedEntity(hrchyT *hrchy, int viewNo);
XDV_EXPORT int     XdHrchyView_IsEntityRepresented(hrchyT *hrchy, int viewNo, void *entity);
XDV_EXPORT void    XdHrchyView_SetSelectionList(hrchyT *hrchy, int viewNo, int master, 
                                            hrchySlctnListEnum selectionList);
XDV_EXPORT void    XdHrchyView_LinkOpInProgress(hrchyT *hrchy, int viewNum);
XDV_EXPORT int     XdHrchyView_GetPosOfEntity(hrchyT *hrchy, int viewNum, void *entity, 
                        int *row, int *level);
XDV_EXPORT void   *XdHrchy_GetEntityAtRow(hrchyT *hrchy, int viewNum, int row);
XDV_EXPORT int     XdAssemblyView_GetPosOfAssy(ECAssembly *subAssy, int viewNum, 
                        ECAssembly *assy, int *row, int *level);
XDV_EXPORT void    XdSubAssy_StripFullNames(ECAssembly *subAssy);

XDV_EXPORT int     XdHrchyView_GetPasteFlag(hrchyT *hrchy);
XDV_EXPORT void    XdHrchyView_SetPasteFlag(hrchyT *hrchy, int newValue);

XDV_EXPORT int     XdHrchyView_IsChanged(hrchyT *hrchy);
XDV_EXPORT void    XdHrchyView_SetChanged(hrchyT *hrchy, int newValue);

XDV_EXPORT void    XdHrchyView_SetSelectNodeState(int viewNo, ECAssembly *assy, int state);

XDV_EXPORT void    XdHrchy_LoadChildrenOfRow(hrchyT *hrchy, int viewNum, int row, int level, int load);
XDV_EXPORT void    XdHrchy_EnableChildrenOfRow(hrchyT *hrchy, int viewNum, int row, int level, int enable);

XDV_EXPORT ECAssembly *XdHrchy_GetAssemblyAtRow(hrchyT *hrchy, int viewNum, int row);

#ifdef __cplusplus
}
#endif

#endif /* __XDHRCHY_H__ */
