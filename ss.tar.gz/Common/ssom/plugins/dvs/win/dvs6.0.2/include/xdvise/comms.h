
/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1993 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: comms.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 6 October 1994
--  Author       : Tony Coombes
--
--  Description	 : Communication stuff
--
--  Modified
--    $Log: comms.h,v $
--    Revision 1.1  2005/09/13 15:08:18  pukitepa
--    init
--
--    Revision 1.27  1998/09/09 14:14:35  wman
--    Fixes for multiple screen resolutions on NT.
--
--    Revision 1.26  1998/08/27 16:27:33  wman
--    Fix for bug #6050
--
--    Revision 1.25  1998/08/05 17:31:53  mark
--    Added menu item to delete an annotation
--
--    Revision 1.24  1998/08/03 14:47:25  simon
--    Added the instWarn dlg, and added stuff to warn user if an instance is about
--    to be un-instanced.
--
--    Revision 1.23  1998/07/30 14:11:30  simon
--    Fixed toggle menu's, and added case sensitive menu option
--
--    Revision 1.22  1998/07/28 11:11:54  wman
--    Initial code for the preferences dialogs.  Commed so that it can be tested by Clive for the DCI end.
--
--    Revision 1.21  1998/07/22 10:26:31  simon
--    Added a new user dci send message that stops dci altering the message.
--
--    Revision 1.20  1998/07/15 15:22:16  wman
--    Fixes to reduce the number of warnings on NT.
--
--    Revision 1.19  1998/07/15 10:50:09  wman
--    Addition of Enable Only selected functionality
--
--    Revision 1.18  1998/07/13 16:14:09  mark
--    Handling annotation updates from dVISE
--
--    Revision 1.17  1998/07/09 15:15:10  clives
--    dvise5.0.2 specific code integrated into Darkstar
--
--    Revision 1.16  1998/07/02 16:10:20  wman
--    Changes for second edit toolbar and functions.
--
--    Revision 1.15  1998/06/16 13:06:15  wman
--    Changes for Subtree selection, however not totally working.
--    Bug fix for #5522
--
--    Revision 1.14  1998/06/12 08:53:05  simon
--    changes for filter tool
--
--    Revision 1.13  1998/05/21 13:21:17  wman
--    Code to Delete Keyframes and frames.
--
--    Revision 1.12  1998/05/11 13:54:02  mark
--    Changes for annotation markups
--
--    Revision 1.11  1998/03/13 14:28:43  tony
--    Support to allow users to configure the units
--    used to display distance measurements
--
--    Revision 1.10  1998/01/05 14:08:03  simon
--    lots of bug fixes.
--
--    Revision 1.9  1997/11/05 17:28:57  tony
--    Various changes to allow Key Frame suite of editors to work with
--    LIBRARY Key Frames along with some general tidying of code.
--
--    Revision 1.8  1997/10/15 17:23:46  simon
--    bug fixes
--
--    Revision 1.7  1997/09/09 15:02:11  clives
--    Annotation create facility now uses the new standard DCI message, rather
--    than the old customised one.
--
--    Revision 1.6  1997/08/26 11:47:29  simon
--    Mainly changes to library viewer, and additional reset parts stuff
--
--    Revision 1.5  1997/07/23 17:33:29  tony
--    Addition of XdComms_SendFlightPathRecordEventInform()
--              & XdComms_SendFlightPathSetTimeEventInform()
--
--    Revision 1.4  1997/07/21 18:36:15  tony
--    Addition of XdComms_SendAssemblyActivateEventInform()
--    to allow the "playOff" and "leaveOff" arguments to be used.
--
--    Revision 1.3  1997/07/11 15:54:07  tony
--    Removed some redundant functions and #include "xdtree.h"
--
--    Revision 1.2  1997/07/09 16:03:49  tony
--    Continued Flight Path development
--
--    Revision 1.1  1997/07/09 12:28:42  simon
--    *** empty log message ***
--
--    Revision 1.56  1997/07/08 09:02:13  tony
--    Rationalised the sending of Key Frame events with
--    XdComms_SendKeyFrameEventInform()
--
--    Revision 1.55  1997/07/02 13:09:15  dvs-dev
--    Changes for NT build.
--    Modified header files for windows __declspec definitions
--    Added some NON working code for keyboard accelerators.
--
--    Revision 1.54  1997/07/02 08:05:26  tony
--    Renamed XdComms_SendToggleBranchInform() to
--            XdComms_SendBranchToggleEnableInform()
--
--    Revision 1.53  1997/05/07 15:37:44  wman
--    Added libmfc for windows build
--
--    Revision 1.52  1997/04/18 12:10:37  tony
--    Reset User Event list after File|Open
--
--    Revision 1.51  1997/04/11 12:53:04  wman
--    Added support for -bodyName and also filtering on bodyName on select/deselect events.
--
--    Revision 1.50  1997/03/22 17:52:29  wman
--    Bug fixes
--
--    Revision 1.49  1997/03/22 12:12:28  tony
--    Moved the responsability for querying Assembly Attributes when an
--    editor is poped up to each of the editors _Update (popup) routines,
--    thus giving them far more control over what they edit.
--
--    Revision 1.48  1997/03/19 18:21:52  wman
--    bug Fixes
--
--    Revision 1.47  1997/03/18 10:21:55  tony
--    *** empty log message ***
--
--    Revision 1.46  1997/03/16 17:27:32  tony
--    *** empty log message ***
--
--    Revision 1.45  1997/03/12 18:06:07  tony
--    *** empty log message ***
--
--    Revision 1.44  1997/03/11 21:03:56  tony
--    *** empty log message ***
--
--    Revision 1.43  1997/03/10 17:56:30  tony
--    *** empty log message ***
--
--    Revision 1.42  1997/03/05 19:02:02  wman
--    Bug fixes
--    Added time stamp on annotation.
--
--    Revision 1.41  1997/03/05 16:28:52  tony
--    *** empty log message ***
--
--    Revision 1.40  1997/02/22 17:33:54  wman
--    Implemented new exponential scale on navigator distance.
--    Message window pops up automatically on first message.
--    General Bug Fixes
--
--    Revision 1.39  1997/02/13 17:03:26  wman
--    Added colour to frame manager
--
--    Revision 1.38  1997/02/04 20:47:21  tony
--    *** empty log message ***
--
--    Revision 1.37  1997/02/04 19:00:26  wman
--    Bug Fixes to animation dlg
--
--    Revision 1.36  1997/01/24 20:54:09  tony
--    *** empty log message ***
--
--    Revision 1.35  1997/01/10 18:59:44  wman
--    Key Frame fixes
--
--    Revision 1.34  1997/01/09 18:31:25  wman
--    Added two way selection as default on
--    Addded Image Save option to file menu option.
--    Also, Added some to frame manager insert frame
--
--    Revision 1.33  1997/01/08 17:31:35  wman
--    Remove DCIMainLoop... functions from comms.c
--    more tidying up in animation.
--
--    Revision 1.32  1996/12/12 14:23:20  wman
--    Fixed updates to frame manager when moving frames in vis.
--
--    Revision 1.31  1996/12/06 18:09:11  wman
--    Key Frame additions - feedback from dVISE on selection on frames.
--    Bugs in external multiple selection and update fixed.
--
--    Revision 1.30  1996/12/06 17:37:41  tony
--    *** empty log message ***
--
--    Revision 1.29  1996/11/28 17:12:30  wman
--    Added fly to multiple objects selected at once
--
--    Revision 1.28  1996/11/27 20:45:03  tony
--    Added Attributes to the Assembly view
--
--    Revision 1.27  1996/11/27 17:02:35  wman
--    Added File|new and File|open menu functionality
--
--    Revision 1.26  1996/11/27 12:06:07  wman
--    Added new event editor dlg.
--    Fixed behaviour dlg for annotations.
--
--    Revision 1.25  1996/11/21 11:51:15  wman
--    New postit icons
--
--    Revision 1.24  1996/11/14 18:13:44  tony
--    *** empty log message ***
--
--    Revision 1.23  1996/11/08 18:32:38  tony
--    *** empty log message ***
--
--    Revision 1.22  1996/11/07 18:58:53  wman
--    Final Bug fixes in Annotation Stuff
--
--    Revision 1.21  1996/11/07 18:02:12  tony
--    *** empty log message ***
--
--    Revision 1.20  1996/11/06 18:24:00  wman
--    Annotation bugs fixed
--
--    Revision 1.19  1996/11/05 08:37:08  tony
--    *** empty log message ***
--
--    Revision 1.18  1996/11/04 20:07:20  wman
--    Annotation bug Fixes
--
--    Revision 1.17  1996/11/02 15:11:24  wman
--    Default user set upon startup
--
--    Revision 1.16  1996/11/02 11:59:25  tony
--    *** empty log message ***
--
--    Revision 1.15  1996/10/31 19:01:17  wman
--    *** empty log message ***
--
--    Revision 1.14  1996/10/30 18:08:20  tony
--    *** empty log message ***
--
--    Revision 1.13  1996/10/29 17:44:44  tony
--    *** empty log message ***
--
--    Revision 1.12  1996/10/28 18:16:35  tony
--    *** empty log message ***
--
--    Revision 1.11  1996/10/28 18:11:56  wman
--    *** empty log message ***
--
--    Revision 1.10  1996/10/24 17:59:13  tony
--    *** empty log message ***
--
--    Revision 1.9  1996/10/23 18:09:13  wman
--    New Navigator prototype
--
--    Revision 1.8  1996/10/23 18:00:57  tony
--    *** empty log message ***
--
--    Revision 1.7  1996/10/23 16:42:50  wman
--    UserRole Dialog stuff
--
--    Revision 1.6  1996/10/18 17:47:03  wman
--    New annotation stuff!
--
--    Revision 1.5  1996/10/17 17:00:51  tony
--    *** empty log message ***
--
--    Revision 1.4  1996/10/16 15:35:54  wman
--    UserRoleDialog stuff
--
--    Revision 1.3  1996/09/30 17:23:25  tony
--    *** empty log message ***
--
--    Revision 1.2  1996/09/10 15:38:56  tony
--    Changed "Object" to "Assembly"
--
--    Revision 1.1.1.1  1996/08/29 09:25:59  tony
--    first version of xdvise
--
--    Revision 3.3  1996/08/05 15:06:37  tony
--    Check in prior to starting development for IDP
--
--    Revision 3.2  1996/06/18 11:17:02  tony
--    Mid development revision
--
--    Revision 3.1  1996/02/26 16:31:06  tony
--    Release 3.0
--
--    Revision 1.6  1995/10/20 08:35:11  tony
--    TC79 Changed arguments of  XdCommsSendNodeAttributesQuery()
--                       &  XdCommsSendNodeAttributeAssemblyQuery()
--    to avoid using XdTree data structure.
--
--    Revision 1.5  1995/10/05 15:11:06  tony
--    Bug TC11 - Removed "tree" argument from XdCommsSendAssemblyAttributeInform()
--
--
-- ----------------------------------------------------------------------------
*/

#ifndef __XDCOMMS_H__
#define __XDCOMMS_H__

#include <stdio.h>
#include "xdfile.h"  /* For XDFILE_VDILIB, XDFILE_PLUGIN, etc */

#define String VLString
#include <dvs/vc.h>
#include <dvise/ecatools.h>
#include <dvise/dcitools.h>
#undef String

#ifdef __cplusplus
extern "C" {
#endif

#ifndef XDV_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `XDV_EXPORT'
 */
#ifdef  _LIB_XDV
#define XDV_EXPORT __declspec(dllexport) extern
#else
#define XDV_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define XDV_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ifndef XDV_EXPORT */

XDV_EXPORT int  XdCommsInit(int *argcPtr, char **argv);
XDV_EXPORT void XdCommsPipeReader(void);
XDV_EXPORT DCICommsInfo *XdCommsQryDciInfo(void);

XDV_EXPORT void XdComms_SendAssemblyDeleteRequest(char **path);
XDV_EXPORT void XdComms_SendAssemblyLoadOnlyRequest(char **path);
XDV_EXPORT void XdComms_SendAssemblyEnableOnlyRequest(char **path);
XDV_EXPORT void XdComms_SendAssemblyRenameInform(char *oldName, char *newName);
XDV_EXPORT void XdComms_SendAssemblyAttributesQuery(ECAssembly *assy);
XDV_EXPORT void XdComms_SendAttributesQuery(char *path);

XDV_EXPORT void XdComms_SendAssemblyCreateInform(ECAssembly *assy, char *parentName);
XDV_EXPORT void XdComms_SendAssemblyAttributeInform(ECAssembly *assembly, ECItemType attributeType, char *attributeName);
XDV_EXPORT void XdComms_SendAttributeInform(void *entity);
XDV_EXPORT void XdComms_SendRemoveAttributeInform(void *entity);
XDV_EXPORT void XdComms_SendAddAttributeInform(void *entity);

XDV_EXPORT void XdComms_SendAssemblyEvent(ECAssembly *assembly, char *event, EC_DCI_EventData *dciEventData);
XDV_EXPORT void XdCommsSendSave(char *name);
XDV_EXPORT void XdCommsSendSaveAttrs(char *name);
XDV_EXPORT void XdComms_SendSaveLibraries(char *fileName, ECItem *libList);
XDV_EXPORT void XdComms_SendNewLibrary(char *libName);
XDV_EXPORT void XdComms_SendOpenLibrary(char *libName, XdFileTypes type);
XDV_EXPORT void XdComms_SendImportLibrary(ECItem *libList);
XDV_EXPORT void XdComms_SendExportLibrary(ECItem *libList, char *libPath);
XDV_EXPORT void XdComms_SendSaveImage(char *name);
XDV_EXPORT void XdComms_SendLandmarkDataQuery(int count, char *path);
XDV_EXPORT void XdComms_SendLandmarkDeleteInform(char *path);
XDV_EXPORT void XdCommsSendZoneAttribute(ECZone *zone, ECItemType attributeType);

XDV_EXPORT void XdCommsSendLibraryQuery(char *libraryName);
XDV_EXPORT void XdCommsSendMaterialLibraryQuery(void);

XDV_EXPORT void XdComms_SendAssemblyAttributeListInform(void *keyFrame, int index);
XDV_EXPORT void XdComms_SendAssemblyRemoveAttributeListInform(ECFrame *frame);
XDV_EXPORT void XdComms_SendAssemblyAddAttributeListInform(void *keyFrame, int index);
XDV_EXPORT void XdComms_SendAssemblyAddKeyFrameAttributeInform(ECAssembly *assembly, void *keyFrame);

XDV_EXPORT void XdComms_SendAttributeCreateInform(char *parentName, ECItemType attrType);
XDV_EXPORT void XdCommsSendLibraryCreateInform(char *type, char *libName, char *fileName);

XDV_EXPORT void XdComms_SendAssemblyCopy(char **assemblyNames);
XDV_EXPORT void XdComms_SendAttributeCopy(char **attributeNames);
XDV_EXPORT void XdComms_SendAttributePaste(char *parentName);
XDV_EXPORT void XdComms_SendAssemblyPaste(char *parentName);
XDV_EXPORT void XdComms_SendFlyToAllInform(void);

XDV_EXPORT void XdCommsSendExit(void);
XDV_EXPORT void XdCommsSendClose(void);

XDV_EXPORT void XdCommsSendZoneAssemblyQuery(void);
XDV_EXPORT void XdComms_SendLibAssemblyQuery(void);
XDV_EXPORT void XdComms_SendDvisePluginsQuery(void);

XDV_EXPORT void XdComms_RegisterMsgInterest(int msg, DCIClientCallbackFunc fn, 
                                        void *thisPtr, void *clientData);
XDV_EXPORT ECAction *XdComms_RegisterEventInterest(int event, char *focusName, ECItemType focusType, char *expression,
					  DCIClientCallbackFunc fn, void *thisPtr, void *clientData);
XDV_EXPORT void XdComms_DeregisterEventInterest(int event, char *focusName, ECItemType focusType, ECAction *action);
XDV_EXPORT void XdComms_RegisterBodyEventInterest(int event, char *focusName, ECItemType focusType, 
				  DCIClientCallbackFunc fn, void *thisPtr, void *clientData);

XDV_EXPORT void XdCommsSendStartRecordingInform(char *title);
XDV_EXPORT void XdCommsSendPlayRecordingInform(char *title);
XDV_EXPORT void XdCommsSendPauseRecordingInform(char *title);
XDV_EXPORT void XdCommsSendStopRecordingInform(char *title);
XDV_EXPORT void XdCommsSendStopRecordingDeleteInform(char *title);
XDV_EXPORT void XdCommsSendSetViewInform(char *title);
XDV_EXPORT void XdCommsSendSetMarkupInform(char *title, float *body_pos, float *body_ori);
XDV_EXPORT void XdCommsSendAnnotateEventsAdded(char* assembly);

XDV_EXPORT void XdCommsSendAnnotateCreateDataInform(char *parent, ECAssembly *tmp);
XDV_EXPORT char *XdCommsGetCurrentUser(void);

XDV_EXPORT void XdCommsSendAnnotateviewDataQuery(char *name);
XDV_EXPORT void XdCommsSendAnnotateviewReplyOkayQuery(char* name);
XDV_EXPORT void XdCommsSendAnnotateviewVoiceInform(char *name);
XDV_EXPORT void XdCommsSendAnnotateviewViewInform(char *name);
XDV_EXPORT void XdCommsSendAnnotateviewMarkupInform(char *name);
XDV_EXPORT void XdCommsSendAnnotateviewEventInform(char *name);
XDV_EXPORT void XdCommsSendAnnotateviewUserProcessInform(char *name);
XDV_EXPORT void XdCommsSendAnnotateviewGeneralInform(char *name, int useVoice, int useView,
                                          int useEvent, int useProcess, int markup);
XDV_EXPORT void XdCommsSendAnnotateviewUpdateInform(char *name);
XDV_EXPORT void XdCommsSendAnnotateDbUpdateNote(char* assembly);    
XDV_EXPORT void XdCommsSendAnnotateDbUpdate(void);    

XDV_EXPORT void XdCommsSendUsersQuery(void);
XDV_EXPORT void XdCommsSendRolesQuery(void);
XDV_EXPORT void XdCommsSendSetBodyInform(char *tempBodyChar);
XDV_EXPORT void XdCommsSendSetBodyRoleInform(char *tempBodyChar, char *selected);
XDV_EXPORT void XdComms_SendDistanceUnitInform(dmDistanceUnit unit);
XDV_EXPORT void XdComms_SendDistanceUnitQuery(void);

XDV_EXPORT void XdComms_SendBodyNavigatorInform(void);
XDV_EXPORT void XdCommsSendSetBodyTranslateInform(int axes, float distance);
XDV_EXPORT void XdCommsSendSetBodyOrientInform(int axes, float angle);

XDV_EXPORT void XdComms_SendEventForMultipleAssemblyInform(ECItem *ecItem, int event);
XDV_EXPORT void XdComms_SendEventForAssemblyInform(ECAssembly *assy, int event);
XDV_EXPORT void XdComms_SendBinaryAssyEventInform(ECAssembly *assy1, ECAssembly *assy2, int event);

XDV_EXPORT void XdCommsBodyListCB(void *dlg, void *callData, void *clientData);
XDV_EXPORT void XdCommsDefaultUserDummyCB(void *dlg, void *callData, void *clientData);
XDV_EXPORT void XdComms_SendCreateLandmarkInform(char *parent, char *name, char *viewOf_Path, char *cameraName);
XDV_EXPORT void XdComms_SendCreateCameraInform(char *viewOf_Path, char *cameraName);
XDV_EXPORT void XdComms_SendCreateFlightPathInform(char *parentPath, char *flightPathName);

XDV_EXPORT void XdComms_SendKeyFrameEventInform(ECKeyFrames *keyf, int32 keyfEvent);
XDV_EXPORT void XdComms_SendFlightPathEventInform(ECAssembly *assy, int32 fltPathEvent);
XDV_EXPORT void XdComms_SendAssemblyActivateEventInform(ECAssembly *assy, int playOff, int leaveOff);
XDV_EXPORT void XdComms_SendFlightPathRecordEventInform(ECAssembly *assy, int insert);
XDV_EXPORT void XdComms_SendFlightPathSetTimeEventInform(ECAssembly *assy, float time);

XDV_EXPORT void XdComms_SendDisplayControlPointsKeyFrameInform(ECKeyFrames *keyf, int state);
XDV_EXPORT void XdComms_SendRenameKeyFrameInform(ECKeyFrames *keyf, char *newName);
XDV_EXPORT void XdComms_SendControlPointStatusQuery(ECKeyFrames *keyf);
XDV_EXPORT void XdComms_SendFrameSelectInform(ECKeyFrames *keyf, ECFrame *frame, int index, int select);

XDV_EXPORT void XdComms_SendEventForFileInform(char *fileName, int event);
XDV_EXPORT void XdComms_SendSaveInfoQuery(void);
XDV_EXPORT void XdComms_SendSaveInfoInform(uint32 flags);
XDV_EXPORT void XdComms_SendSelectionListQuery(void);
XDV_EXPORT void XdComms_SendInstanceQuery(ECItem *assList, int searchChildren, int displayChildren);

XDV_EXPORT void XdComms_SendUserDCIMessage(DCIMessageType type,
                                           char *DCICommand, char *message);
XDV_EXPORT void XdComms_SendQuotedUserDCIMessage(DCIMessageType type,
                                           char *DCICommand, char *message);
XDV_EXPORT void XdComms_SendLinkInform(ECItem *assList, ECAssembly *linkToAssembly);
XDV_EXPORT void XdComms_SendUnlinkInform(ECItem *assList);

XDV_EXPORT void XdComms_SendQueryAssembliesQuery(Query *query, ECItem *assList, int checkChildren,
                                                 int caseSensitive);
XDV_EXPORT void XdComms_SendQueryListQuery(void);
XDV_EXPORT void XdComms_SendQueryDeleteInform(ECItem *queries);
XDV_EXPORT void XdComms_SendQueryCreateInform(Query *query);
XDV_EXPORT void XdComms_SendQueryUpdateInform(Query *query, char *originalName);

XDV_EXPORT void XdComms_SendBranchToggleEnableInform(ECItem *assList);
XDV_EXPORT void XdComms_SendEventNamesQuery(void);

XDV_EXPORT void XdComms_SendTogglePickingQuery(void);
XDV_EXPORT void XdComms_SendTogglePickingInform(int32 flags);
XDV_EXPORT void XdComms_SendToggleHighlightModeQuery(void);
XDV_EXPORT void XdComms_SendToggleHighlightModeInform(int32 flags);

XDV_EXPORT void XdComms_SendRenderOptsQuery(ECUserData *qryOpts);
XDV_EXPORT void XdComms_SendRenderOptsInform(ECUserData *options);

XDV_EXPORT void XdComms_SendAssemblyMakeNonInstanceInform(char *pathName);

XDV_EXPORT void XdComms_SendAssemblyDestroyInform(char *pathName);

XDV_EXPORT int Xd_PrintTiming(void);
XDV_EXPORT int Xd_GetDynLicense(void);

#ifdef _WIN32
XDV_EXPORT void TempXdCommsAddInput();
#endif

#ifdef __cplusplus
}
#endif

#endif /* __XDCOMMS_H__ */
