/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1996 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: xdgui.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 12 April 1996
--  Author       : Tony Coombes
--
--  Description	 : Motif Graphical User Interface functions
--
--  Modified     : 
--    $Log: xdgui.h,v $
--    Revision 1.1  2005/09/13 15:08:23  pukitepa
--    init
--
--    Revision 1.2.62.1  1998/11/26 16:26:54  wman
--    fixes for bug #6532.
--
--    Revision 1.2  1997/11/18 18:09:49  simon
--    fix year 2000 problem in annotation dates, and made the animation keyframe
--    list single selection.
--
--    Revision 1.1  1997/07/09 12:31:37  simon
--    *** empty log message ***
--
--    Revision 1.10  1997/07/02 13:09:25  dvs-dev
--    Changes for NT build.
--    Modified header files for windows __declspec definitions
--    Added some NON working code for keyboard accelerators.
--
--    Revision 1.9  1997/04/15 16:22:50  tony
--    Changes to allow Key Frames to be instanced
--
--    Revision 1.8  1997/02/28 18:44:15  wman
--    Bug fixes!
--
--    Revision 1.7  1997/02/19 19:13:15  wman
--    Bug Fixes, and Right Mouse Button popup menu implementation
--
--    Revision 1.6  1997/01/03 17:25:56  wman
--    Changed the way in which the property dialogs appear (size)
--
--    Revision 1.5  1997/01/03 14:01:06  wman
--    Added bitmaps to the animation dialog.  Fixed some minor bugs in the animation
--    dialog.
--
--    Revision 1.4  1996/11/19 18:52:11  wman
--    Animation grid widget installed
--
--    Revision 1.3  1996/11/13 18:00:10  tony
--    *** empty log message ***
--
--    Revision 1.2  1996/10/25 16:55:28  tony
--    *** empty log message ***
--
--    Revision 1.1.1.1  1996/08/29 09:26:16  tony
--    first version of xdvise
--
--    Revision 3.1  1996/08/05 15:06:37  tony
--    Check in prior to starting development for IDP
--
--    Revision 1.3  1996/06/25 16:44:21  tony
--    Addition of List Widget
--
--    Revision 1.2  1996/06/18 11:17:02  tony
--    Mid development revision
--
--    Revision 1.1  1996/04/12 15:42:18  tony
--    Initial development of basic components
--    for constructing property editors
--
--
--
-- ----------------------------------------------------------------------------
*/

#ifndef __XDGUI_H__
#define __XDGUI_H__

#include "wkeys.h"   /* For compT */
#include "xdoptfd.h" /* For optnT data type */
#include "xdbtnwd.h" /* For btnWidgT data type */

#ifdef __cplusplus
extern "C" {
#endif

#ifndef XDV_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `XDV_EXPORT'
 */
#ifdef  _LIB_XDV
#define XDV_EXPORT __declspec(dllexport) extern
#else
#define XDV_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define XDV_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ifndef XDV_EXPORT */

XDV_EXPORT compT GUIValueContainerCreate(compT parent);
#ifdef _WIN32
/* A double sized container widget, created for a list control in a generic dialog. */
XDV_EXPORT compT GUIDoubleValueContainerCreate(compT parent);
#endif
XDV_EXPORT compT GUISourceContainerCreate(compT parent);
XDV_EXPORT compT GUIPropFieldBrowseBtnCreate(compT parent, char *label, void *clientData);
XDV_EXPORT compT GUIPropFieldLabelCreate(compT parent, char *label);
XDV_EXPORT compT GUIPropFieldContainerCreate(compT parent, compT *visual, compT *tglBtn);
#ifdef _WIN32
/* A double sized property field container widget, created for a list control in a generic dialog. */
XDV_EXPORT compT GUIDoublePropFieldContainerCreate(compT parent, compT *visual, compT *tglBtn);
#endif
XDV_EXPORT compT GUIOptnWidgetCreate(compT parent, optnT *optns, compT *btns, void *clientData);
XDV_EXPORT compT GUITextWidgetCreate(compT parent, int editable, void *clientData);
XDV_EXPORT compT GUILabelWidgetCreate(compT parent, void *clientData);
XDV_EXPORT compT GUIScrolledTextWidgetCreate(compT parent, void *clientData);
XDV_EXPORT void  GUIOptionMenuSet(compT menuComp, compT btnComp);
XDV_EXPORT compT GUIMenuBarCreate(compT parent, compT mainForm);
XDV_EXPORT void  GUIEditDlgMenuBarCreate(compT parent, compT mainForm, void *clientData);
/*XDV_EXPORT compT GUIPropDlgCreate(compT parent, char *title, compT *maonForm, compT *objList, 
                 compT *fieldList, 
                 void (*closeCB)(btnWidgT *w, void *clientData), 
		 void (*resetCB)(btnWidgT *w, void *clientData), 
		 void (*cancelCB)(btnWidgT *w, void *clientData), void *clientData);
*/
XDV_EXPORT compT GUIPropDlgCreate(compT parent, char *title, compT *menuBar, compT *workArea, 
                 compT *actionArea, int fldCnt, int width, int inputModal, int dialogModal);
XDV_EXPORT compT GUIEditDlgCreate(compT parent, char *title, compT *mainWindow, compT *mainForm, 
                 int fldCnt, compT *fieldList, void (*closeCB)(btnWidgT *w, void *clientData), 
		 void (*resetCB)(btnWidgT *w, void *clientData), 
		 void (*cancelCB)(btnWidgT *w, void *clientData), void *clientData);
XDV_EXPORT compT GUIIntValueWidgetCreate(compT parent, compT *text, int posn, int divns, void *intValWidg);
XDV_EXPORT compT GUIFltValueWidgetCreate(compT parent, compT *text, int posn, int divns, void *fltValWidg);
XDV_EXPORT void  GUITxtValueSet(compT comp, char *str);
XDV_EXPORT void  GUIIntValueSet(compT comp, int value);
XDV_EXPORT void  GUIFltValueSet(compT comp, float value);
XDV_EXPORT void  GUISetLabel(compT comp, char *str);
XDV_EXPORT void  GUISetFgCol(compT comp, char *str);
XDV_EXPORT void  GUIPopupDlg(compT comp);
XDV_EXPORT char *GUITxtValueGet(compT comp);
XDV_EXPORT void  GUISetChkBox(compT comp, int status);
XDV_EXPORT compT GUIListWidgetCreate(compT parent, compT *rtnList, int isMultipleSelect, int leftType, compT leftW, int rightType, 
                    compT rightW, int topType, compT topW, int bottomType, compT bottomW, 
		    void *clientData);
XDV_EXPORT compT GUICascadeMnuBtnCreate(compT parent, char *label, char *mnemonic, compT *cascadeMenu);
XDV_EXPORT compT GUIRowColumnCreate(compT parent, int leftType, compT leftW, int rightType, compT rightW, 
                    int topType, compT topW, int bottomType, compT bottomW, int rowColumn);
XDV_EXPORT void GUIRowColumnWidgetResize(compT scrlLst);
XDV_EXPORT compT GUIScrolledWindowCreate(compT parent, int leftType, compT leftW, int rightType, compT rightW, 
		    int topType, compT topW, int bottomType, compT bottomW);
XDV_EXPORT compT GUIGridWidgetCreate(compT parent, compT *rtnGrid, int leftType, compT leftW, int rightType, 
                    compT rightW, int topType, compT topW, int bottomType, compT bottomW, 
		    int columns, char *title,
		    void *clientData);
XDV_EXPORT void GUIScrolledWindowResize(compT scrlWin);
XDV_EXPORT void GUIGridWidgetAddNewColumn(compT grid, int columns, char *title);

XDV_EXPORT compT GUIPopupMenuWidget_Create(compT parent, char *label);

#ifdef __cplusplus
}
#endif

#endif /* __XDGUI_H__ */
