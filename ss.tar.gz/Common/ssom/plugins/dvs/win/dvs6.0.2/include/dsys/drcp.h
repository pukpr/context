/****************************************************************************
 *
 *  			Copyright 1995 Division Limited.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: drcp.h,v $
 *  Revision      : $Revision: 1.1 $
 *  Date          : $Date: 2005/09/13 15:07:41 $
 *  Author        : $Author: pukitepa $
 *  Last Modified : <250298.1016>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 *  $Log: drcp.h,v $
 *  Revision 1.1  2005/09/13 15:07:41  pukitepa
 *  init
 *
 *  Revision 1.5  1998/02/25 10:18:02  jk
 *  *** empty log message ***
 *
 *  Revision 1.4  1998/02/19 12:40:52  jk
 *  Added extern C wrapper for c++
 *
 *  Revision 1.3  1997/02/24 20:49:30  bill
 *  Added doredge (edge reduction) to bgflod stuff
 *  Fixed SideOfLine problem in the tessellator
 *
 *  Revision 1.2  1996/12/09 11:29:22  bill
 *  Incorperates new dm/dmd chnages to VectorNorm and SqrLength
 *  Now uses dpgUnit support.
 *
 *  Revision 1.1  1996/11/15 14:25:56  bill
 *  New octree routines with recipe editor
 *
 *
 ****************************************************************************
 *
 *  Copyright (c) 1995 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 *  This Document may not, in whole or in part, be copied,
 *  photocopied, reproduced, translated, or reduced to any
 *  electronic medium or machine readable form without prior
 *  written consent from Division Ltd.
 ****************************************************************************/

#ifndef __DRCP_H__
#define __DRCP_H__

#include <dsys/pfile.h>

#ifdef __cplusplus
extern "C" {
#endif

/* The following routines are defined in libdrcp.a and use
 * libdpf.a libdpt.a libdivu.a & libm.a
 */
/* Setup the Recipe stuff by reading the given recipe file.
 * Returns dpgERROR if file was not found, dpgSUCCESS otherwise
 * 
 * drcpSetup - Flags the initialisation state of the Recipe stuff.
 *             If it is set to dpgTRUE it has been successfully been setup
 *                drcpFileName will hold the rcp file name.
 *             Else it hasn't and doRecipeFind will do nothing.
 */
extern int32 drcpSetup ;
extern char  drcpFileName[] ; 
int32
doRecipeRead(char *fileName) ;
/* Find a recipe file.
 * (1) searches for overName
 *     Searching includes
 *     (a) if null then fail
 *     (b) if "-" successed, rcp disabled, returns null
 *     (c) tests for ./overName, ./overName.rcp
 *     (d) tests for recipe/overName, recipe/overName.rcp
 *     (d) tests for $DIVISIONROOT/recipe/overName, 
 *                   $DIVISIONROOT/recipe/overName.rcp
 * (2) searches for fileName
 * (3) searches for $DIVISION_RECIPE
 * (4) searches for dpgProgname
 * 
 * Returns
 *    -1 Failed to initialise (No name was "-" and rcp file not found).
 *     0 A valid recipe file name found and loaded -
 *           filename copied to drcpFileName.
 *     1 First valid name was "-" and rcp stuff disabled.
 */
int32
doRecipeFind(char *overName, char *fileName) ;
/* doRecipeDelete - frees off the du search table, call once 
 * when you nolonger need to call doRecipeFind
 */
void
doRecipeDelete(void) ;
/* Optimises the given pfile using the configuration setup with
 * by a call to doRecipeRead
 */
void
doRecipePFile(dpfFILEPTR pff) ;

void
doPrintLodInfo(void) ;

#ifdef __cplusplus
}
#endif


#endif /* __DRCP_H__ */
