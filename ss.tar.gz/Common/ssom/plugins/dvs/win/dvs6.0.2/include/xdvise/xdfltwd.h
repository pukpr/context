/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1996 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: xdfltwd.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 12 April 1996
--  Author       : Tony Coombes
--
--  Description	 : Float Value Widget
--
--  Modified     : 
--    $Log: xdfltwd.h,v $
--    Revision 1.1  2005/09/13 15:08:23  pukitepa
--    init
--
--    Revision 1.2  1998/03/13 14:29:04  tony
--    Support to allow users to configure the units
--    used to display distance measurements
--
--    Revision 1.1  1997/07/09 12:31:29  simon
--    *** empty log message ***
--
--    Revision 1.1.1.1  1996/08/29 09:26:15  tony
--    first version of xdvise
--
--    Revision 3.1  1996/08/05 15:06:37  tony
--    Check in prior to starting development for IDP
--
--    Revision 1.2  1996/06/18 11:17:02  tony
--    Mid development revision
--
--    Revision 1.1  1996/04/12 15:42:16  tony
--    Initial development of basic components
--    for constructing property editors
--
--
--
-- ----------------------------------------------------------------------------
*/

#ifndef __XDFLTWD_H__
#define __XDFLTWD_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct fltValWidgT fltValWidgT;

extern fltValWidgT *XdFltValueWidgetCreate(compT parent, int posn, int divns, 
                       float min, float max, float smlInc, float lrgInc, 
                       void (*errorCallback)(fltValWidgT *w, void *clientData), 
                       void (*changedCallback)(fltValWidgT *w, void *clientData), 
		       void *clientData);
extern void  XdFltValueWidgetDestroy(fltValWidgT *fltValWidg);
extern int   XdFltValueWidgetSetValue(fltValWidgT *fltValWidg, float value);
extern void  XdFltValueWidgetSetValueWithText(fltValWidgT *fltValWidg, char *str);
extern void  XdFltValueWidgetReset(fltValWidgT *fltValWidg);
extern float XdFltValueWidgetGetValue(fltValWidgT *fltValWidg);
extern float XdFltValueWidgetGetReset(fltValWidgT *fltValWidg);
extern void  XdFltValueWidgetSmlIncValue(fltValWidgT *fltValWidg);
extern void  XdFltValueWidgetLrgIncValue(fltValWidgT *fltValWidg);
extern void  XdFltValueWidgetSmlDecValue(fltValWidgT *fltValWidg);
extern void  XdFltValueWidgetLrgDecValue(fltValWidgT *fltValWidg);
extern int   XdFltValueWidgetHasError(fltValWidgT *fltValWidg);
extern int   XdFltValueWidgetHasChanged(fltValWidgT *fltValWidg);

#ifdef __cplusplus
}
#endif

#endif /* __XDFLTWD_H__ */
