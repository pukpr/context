/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1996 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: xdprpfd.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 12 April 1996
--  Author       : Tony Coombes
--
--  Description	 : Property Editor Field (Base Class)
--
--  Modified     : 
--    $Log: xdprpfd.h,v $
--    Revision 1.1  2005/09/13 15:08:26  pukitepa
--    init
--
--    Revision 1.1.68.1  1998/11/26 16:26:54  wman
--    fixes for bug #6532.
--
--    Revision 1.1  1997/07/09 12:32:22  simon
--    *** empty log message ***
--
--    Revision 1.2  1996/12/19 17:44:44  tony
--    *** empty log message ***
--
--    Revision 1.1.1.1  1996/08/29 09:26:19  tony
--    first version of xdvise
--
--    Revision 3.1  1996/08/05 15:06:37  tony
--    Check in prior to starting development for IDP
--
--    Revision 1.2  1996/06/18 11:17:02  tony
--    Mid development revision
--
--    Revision 1.1  1996/04/12 15:42:27  tony
--    Initial development of basic components
--    for constructing property editors
--
--
--
-- ----------------------------------------------------------------------------
*/

#ifndef __XDPRPFD_H__
#define __XDPRPFD_H__

#ifdef __cplusplus
extern "C" {
#endif


typedef struct propFieldT propFieldT; /* Prototype */

extern propFieldT *XdPropFieldCreate(compT parent, char *label, void(*browserCB)(void *clientData), 
                                     void *clientData, int tglBtn);
extern void  XdPropFieldDestroy(propFieldT *propField);
extern void  XdPropField_SetSensativity(propFieldT *propField, int sensative);
extern void  XdPropFieldSetStatus(propFieldT *propField, int status);
extern void  XdPropFieldSetExplicit(propFieldT *propField, int explicit);
extern void  XdPropFieldBrowserCB(void *clientData);
extern compT XdPropFieldGetValContainer(propFieldT *propField);
extern int   XdPropFieldGetStatus(propFieldT *propField);
#ifdef _WIN32
/* Hack for a double sized property field in NT, as Motif automatically 
   sizes the property field according to it's contents. */
extern propFieldT *XdDoublePropFieldCreate(compT parent, char *label, void(*browserCB)(void *clientData), 
                  void *clientData, int tglBtn);
#endif

#ifdef __cplusplus
}
#endif

#endif /* __XDPRPFD_H__ */
