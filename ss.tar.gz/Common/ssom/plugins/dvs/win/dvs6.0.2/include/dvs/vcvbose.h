/***************************************************************************
 *                                                             <110793.1226>
 *    PROJECT:      dVS
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 ***************************************************************************
 *
 *    File:         $RCSfile: vcvbose.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:08:08 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: vcvbose.h,v 1.1 2005/09/13 15:08:08 pukitepa Exp $
 *    Creator:      Jon Green.
 *
 *    FUNCTION:
 *
 *
 *    $Log: vcvbose.h,v $
 *    Revision 1.1  2005/09/13 15:08:08  pukitepa
 *    init
 *
 *    Revision 1.4  1997/02/20 23:32:02  john
 *    fixed typo
 *
 *    Revision 1.3  1997/02/20 12:58:58  john
 *    changed verbos/debug stuff to use libvc module
 *
 *    Revision 1.2  1996/11/04 18:48:12  john
 *    VC_Verbose etc changed to duVerbose functions.
 *    VC allows verbose for modules
 *    body support for rotateAboutDistance
 *    startup no longer talks to vcrun
 *
 *    Revision 1.1.1.1  1996/04/09 15:52:33  mark
 *    Initial message
 *
 *    Revision 1.3  1995/11/23 10:13:53  john
 *    *** empty log message ***
 *
 *    Revision 1.2  1995/08/11 12:14:07  mark
 *    Changed error, verbose and debug system to use the du reporting.
 *
 * Revision 1.1  1995/06/15  12:48:50  john
 * Initial revision
 *
 * Revision 1.1  95/05/18  10:24:20  10:24:20  john (John Harvey)
 * Initial revision
 * 
 * Revision 1.1  1995/03/10  14:52:46  john
 * Initial revision
 *
 * Revision 0.6  94/10/05  12:51:43  12:51:43  john (John Harvey)
 * Save JH on holiday. - Jon.
 * 
 * Revision 0.5  94/03/30  15:17:49  15:17:49  mark (Mark Greening)
 * New VCActorInit and error routines
 * 
 * Revision 0.4  1993/09/24  11:24:53  jon
 * Release 2.0.4
 *
 * Revision 1.1  93/07/28  14:12:08  jon
 * Initial revision
 * 
 *
 **************************************************************************
 *                                                                        *
 * Copyright (c) 1992 Division Ltd.                                       *
 *                                                                        *
 * All Rights Reserved.                                                   *
 *                                                                        *
 * This Document may not, in whole  or in part, be copied, photocopied,   *
 * reproduced, translated,  or  reduced  to  any  electronic  medium or   *
 * machine readable  form without  prior written  consent from Division   *
 * Ltd.                                                                   *
 *                                                                        *
 *************************************************************************/

/*---	Include Definitions */

#ifndef _VCVBOSE_H
#define _VCVBOSE_H   1

/*---	Include Files */

#include <dsys/du.h>

/*---	Local Macro Definitions */

#define VC_Verbose(x,y)  duVerbose_Module(x,_VCVerboseModule, y)
#define VC_Debug(x,y)  duDebug_Module(x,_VCDebugModule,y)
#define VCVerbose_SetLevel(x)   duVerbose_ModuleSetLevel(_VCVerboseModule,x)
#define VCVerbose_GetLevel()     duVerbose_ModuleGetLevel(_VCVerboseModule)
#define VCDebug_SetLevel(x)      duDebug_ModuleSetLevel(_VCDebugModule,x)
#define VCDebug_GetLevel()       duDebug_ModuleGetLevel(_VCDebugModule)

/*---	Local Type Definitions */

/*---	Local Variable Declarations */

#endif  /* _VCVBOSE_H */
