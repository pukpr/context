/* 
-- ----------------------------------------------------------------------------
--
--  			Copyright 1998 Division Limited.
--			      All Rights Reserved
--
--
--  System       : 
--  Module       : 
--  Object Name  : $RCSfile: dbannplg.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : $Date: 2005/09/13 15:07:49 $
--  Author       : $Author: pukitepa $
--
--  Description	
--
--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __DBANNPLG_H__
#define __DBANNPLG_H__


typedef dbHandle (*dbAnnotationPlugin_Connect)(const dbHandle db, const char* const key);
typedef dbHandle (*dbAnnotationPlugin_Create)(const dbHandle db);
typedef int (*dbAnnotationPlugin_Remove)(dbHandle db, const char* const key);
typedef int (*dbAnnotationPlugin_Close)(dbHandle annotation);

typedef char* (*dbAnnotationPlugin_GetName)(dbHandle db);
typedef void (*dbAnnotationPlugin_SetName)(dbHandle db, const char* const name);

typedef char* (*dbAnnotationPlugin_GetParent)(dbHandle db);
typedef void (*dbAnnotationPlugin_SetParent)(dbHandle db, const char* const parent);

typedef char* (*dbAnnotationPlugin_GetDate)(dbHandle db);
typedef void (*dbAnnotationPlugin_SetDate)(dbHandle db, const char* const date);

typedef char* (*dbAnnotationPlugin_GetTime)(dbHandle db);
typedef void (*dbAnnotationPlugin_SetTime)(dbHandle db, const char* const time);

typedef char* (*dbAnnotationPlugin_GetAudio)(dbHandle db);
typedef void (*dbAnnotationPlugin_SetAudio)(dbHandle db, const char* const audio);

typedef char* (*dbAnnotationPlugin_GetMemo)(dbHandle db);
typedef void (*dbAnnotationPlugin_SetMemo)(dbHandle db, const char* const memo);

typedef char* (*dbAnnotationPlugin_GetEvent)(dbHandle db);
typedef void (*dbAnnotationPlugin_SetEvent)(dbHandle db, const char* const event);

typedef float32* (*dbAnnotationPlugin_GetBodyPos)(dbHandle db);
typedef void (*dbAnnotationPlugin_SetBodyPos)(dbHandle db, const float32* const pos);

typedef float32* (*dbAnnotationPlugin_GetBodyOri)(dbHandle db);
typedef void (*dbAnnotationPlugin_SetBodyOri)(dbHandle db, const float32* const ori);

typedef char* (*dbAnnotationPlugin_GetProcess)(dbHandle db);
typedef void (*dbAnnotationPlugin_SetProcess)(dbHandle db, const char* const process);

typedef char* (*dbAnnotationPlugin_GetAssignee)(dbHandle db);
typedef void (*dbAnnotationPlugin_SetAssignee)(dbHandle db, const char* const assignee);

typedef char* (*dbAnnotationPlugin_GetOwner)(dbHandle db);
typedef void (*dbAnnotationPlugin_SetOwner)(dbHandle db, const char* const owner);

typedef int (*dbAnnotationPlugin_GetPriority)(dbHandle db);
typedef void (*dbAnnotationPlugin_SetPriority)(dbHandle db, const int priority);

typedef char* (*dbAnnotationPlugin_GetStatus)(dbHandle db);
typedef void (*dbAnnotationPlugin_SetStatus)(dbHandle db, const char* const status);

typedef char* (*dbAnnotationPlugin_GetIcon)(dbHandle db);
typedef void (*dbAnnotationPlugin_SetIcon)(dbHandle db, const char* const icon);

typedef char* (*dbAnnotationPlugin_GetMarkupFile)(dbHandle db);
typedef void (*dbAnnotationPlugin_SetMarkupFile)(dbHandle db, const char* const markupFile);

typedef char* (*dbAnnotationPlugin_GetMarkupImage)(dbHandle db);
typedef void (*dbAnnotationPlugin_SetMarkupImage)(dbHandle db, const char* const markupImage);

typedef char* (*dbAnnotationPlugin_GetMarkupTool)(dbHandle db);
typedef void (*dbAnnotationPlugin_SetMarkupTool)(dbHandle db, const char* const markupTool);

typedef dbEventList* (*dbAnnotationPlugin_GetEventList)(dbHandle db);
typedef void (*dbAnnotationPlugin_SetEventList)(dbHandle db, dbEventList* eventList);

typedef void (*dbAnnotationPlugin_SetErrorFunc)(void (*f)(char*));

typedef struct dbAnnotationPlugin
{
    dbAnnotationPlugin_Connect connect;
    dbAnnotationPlugin_Create create;
#if 0
    dbAnnotationPlugin_Remove remove;
#endif
    dbAnnotationPlugin_Close close;

        /* plus some more stuff for the operations */

    dbAnnotationPlugin_GetName getName;
    dbAnnotationPlugin_SetName setName;
    
    dbAnnotationPlugin_GetParent getParent;
    dbAnnotationPlugin_SetParent setParent;
    
    dbAnnotationPlugin_GetDate getDate;
    dbAnnotationPlugin_SetDate setDate;
    
    dbAnnotationPlugin_GetTime getTime;
    dbAnnotationPlugin_SetTime setTime;
    
    dbAnnotationPlugin_GetAudio getAudio;
    dbAnnotationPlugin_SetAudio setAudio;
    
    dbAnnotationPlugin_GetMemo getMemo;
    dbAnnotationPlugin_SetMemo setMemo;
    
    dbAnnotationPlugin_GetEvent getEvent;
    dbAnnotationPlugin_SetEvent setEvent;
    
    dbAnnotationPlugin_GetBodyPos getBodyPos;
    dbAnnotationPlugin_SetBodyPos setBodyPos;
    
    dbAnnotationPlugin_GetBodyOri getBodyOri;
    dbAnnotationPlugin_SetBodyOri setBodyOri;
    
    dbAnnotationPlugin_GetProcess getProcess;
    dbAnnotationPlugin_SetProcess setProcess;
    
    dbAnnotationPlugin_GetAssignee getAssignee;
    dbAnnotationPlugin_SetAssignee setAssignee;
    
    dbAnnotationPlugin_GetOwner getOwner;
    dbAnnotationPlugin_SetOwner setOwner;
    
    dbAnnotationPlugin_GetPriority getPriority;
    dbAnnotationPlugin_SetPriority setPriority;
    
    dbAnnotationPlugin_GetStatus getStatus;
    dbAnnotationPlugin_SetStatus setStatus;
    
    dbAnnotationPlugin_GetIcon getIcon;
    dbAnnotationPlugin_SetIcon setIcon;
    
    dbAnnotationPlugin_GetMarkupFile getMarkupFile;
    dbAnnotationPlugin_SetMarkupFile setMarkupFile;
    
    dbAnnotationPlugin_GetMarkupImage getMarkupImage;
    dbAnnotationPlugin_SetMarkupImage setMarkupImage;
    
    dbAnnotationPlugin_GetMarkupTool getMarkupTool;
    dbAnnotationPlugin_SetMarkupTool setMarkupTool;

    dbAnnotationPlugin_GetEventList getEventList;
    dbAnnotationPlugin_SetEventList setEventList;

    dbAnnotationPlugin_SetErrorFunc setErrorFunc;
} dbAnnotationPlugin;


#endif /* __DBANNPLG_H__ */
