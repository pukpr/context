/****************************************************************************
 *
 *  			Copyright 1995 Division Limited.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: dvstool.h,v $
 *  Revision      : $Revision: 1.1 $
 *  Date          : $Date: 2005/09/13 15:07:43 $
 *  Author        : $Author: pukitepa $
 *  Last Modified : <250298.1015>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 *  $Log: dvstool.h,v $
 *  Revision 1.1  2005/09/13 15:07:43  pukitepa
 *  init
 *
 *  Revision 1.5  1998/02/25 10:20:33  jk
 *  *** empty log message ***
 *
 *  Revision 1.4  1998/02/19 12:41:17  jk
 *  Added extern C wrapper for c++
 *
 *  Revision 1.3  1996/10/16 15:07:04  bill
 *  ptgraphic - Fixed PEX and insight warnings
 *  dvstool - fixed insight warning
 *  pttiny - added new stripping routine
 *
 *  Revision 1.2  1996/09/12 14:47:20  bill
 *  dvstool - Changed the version number and added dgl & dnm the the version list
 *  vdifile - Wasnt freeing the name at Save. Also added the freeing of userData
 *
 *  Revision 1.1.1.1  1996/08/07 15:30:23  bill
 *  first version from dvs3.1.2
 *
 *  Revision 1.2  1996/06/10 11:13:29  bill
 *  RCS -> CVS ci
 *
 *  Revision 1.1  1996/02/20 14:44:44  bill
 *  General 3.2 beta ci
 *
 *
 ****************************************************************************
 *
 *  Copyright (c) 1995 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 *  This Document may not, in whole or in part, be copied,
 *  photocopied, reproduced, translated, or reduced to any
 *  electronic medium or machine readable form without prior
 *  written consent from Division Ltd.
 ****************************************************************************/

#ifndef __DVSTOOL_H__
#define __DVSTOOL_H__

#include <dsys/divtypes.h>

#ifdef __cplusplus
extern "C" {
#endif

void
dvstVersion(char *name, char *version, int32 initYear) ;

#ifdef dvstDEPEND_DVF
#define __dvfVersion(fp) dvfVersion(fp)
#else
#define __dvfVersion(fp)
#endif

#ifdef dvstDEPEND_DMP
#define __dmpVersion(fp) dmpVersion(fp)
#else
#define __dmpVersion(fp)
#endif

#ifdef dvstDEPEND_DPT
#define __dptVersion(fp) dptVersion(fp)
#else
#define __dptVersion(fp)
#endif

#ifdef dvstDEPEND_DPF
#define __dpfVersion(fp) dpfVersion(fp)
#else
#define __dpfVersion(fp)
#endif

#ifdef dvstDEPEND_DPI
#define __dpiVersion(fp) dpiVersion(fp)
#else
#define __dpiVersion(fp)
#endif

#ifdef dvstDEPEND_DGL
#define __dglVersion(fp) dglVersion(fp)
#else
#define __dglVersion(fp)
#endif

#ifdef dvstDEPEND_DNM
#define __dnmVersion(fp) dnmVersion(fp)
#else
#define __dnmVersion(fp)
#endif

#define dvstIdentity(name,version,initYear,compDate)                         \
do {                                                                         \
    extern char *dvstVersionNum ;                                            \
    dvstVersion(name,version,initYear) ;                                     \
    fprintf(stdout,"Division dVS. %s. Version %s%s. %s\n",                   \
            name,dvstVersionNum,version,compDate) ;                          \
    __dvfVersion(NULL) ;                                                     \
    __dmpVersion(NULL) ;                                                     \
    __dpiVersion(NULL) ;                                                     \
    __dptVersion(NULL) ;                                                     \
    __dpfVersion(NULL) ;                                                     \
    __dglVersion(NULL) ;                                                     \
    __dnmVersion(NULL) ;                                                     \
    exit(0) ;                                                                \
          } while(0)
              
#ifdef __cplusplus
}
#endif
              

#endif /* __DVSTOOL_H__ */
