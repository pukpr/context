/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1996 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: xdeulfd.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 24 May 1996
--  Author       : Tony Coombes
--
--  Description	 : Euler Vector Field
--                 based on 3-Vector Field
--
--  Modified     : 
--    $Log: xdeulfd.h,v $
--    Revision 1.1  2005/09/13 15:08:22  pukitepa
--    init
--
--    Revision 1.2  1998/04/28 15:19:17  john
--    keyframe dialogues now display rotation's in eulers instead of an axis/rotation.
--
--    Revision 1.1  1997/07/09 12:31:15  simon
--    *** empty log message ***
--
--    Revision 1.2  1997/02/11 18:57:41  wman
--    Frame reset for animation dialog.
--
--    Revision 1.1.1.1  1996/08/29 09:26:14  tony
--    first version of xdvise
--
--    Revision 3.1  1996/08/05 15:06:37  tony
--    Check in prior to starting development for IDP
--
--    Revision 1.1  1996/06/18 11:17:02  tony
--    Mid development revision
--
--
--
-- ----------------------------------------------------------------------------
*/

#ifndef __XDEULFD_H__
#define __XDEULFD_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct eulVecFieldT eulVecFieldT; /* Prototype */

extern eulVecFieldT*
XdEulVecFieldCreate(compT parent, char *label,  
		      void (*changedCallback)(eulVecFieldT *w, void *clientData), 
		      void *clientData);
extern void XdEulVecFieldDestroy(eulVecFieldT *eulVecField);
extern int  XdEulVecFieldGetValue(eulVecFieldT *eulVecField, dmEuler value);
extern int  XdEulVecField_GetValue(eulVecFieldT *eulVecField, dmEuler value);
extern void XdEulVecFieldSetValue(eulVecFieldT *eulVecField, dmEuler value, int explicit);
extern void XdEulVecField_SetValue(eulVecFieldT *eulVecField, dmEuler value, int explicit);
extern void XdEulVecField_Reset(eulVecFieldT *eulVecField);
extern int  XdEulVecFieldGetResetValue(eulVecFieldT *eulVecField, dmEuler value);
extern int  XdEulVecFieldHasChanged(eulVecFieldT *eulVecField);

#ifdef __cplusplus
}
#endif

#endif /* __XDEULFD_H__ */
