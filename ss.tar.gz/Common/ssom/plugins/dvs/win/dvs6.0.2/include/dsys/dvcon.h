/* -*- C -*- ****************************************************************
 *
 *  			Copyright 1998 Division Ltd.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: dvcon.h,v $
 *  Revision      : $Revision: 1.1 $
 *  Date          : $Date: 2005/09/13 15:07:43 $
 *  Author        : $Author: pukitepa $
 *  Created By    : Steven Phillips
 *  Created       : Tue May 19 13:31:59 1998
 *  Last Modified : <191098.1810>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 *  $Log: dvcon.h,v $
 *  Revision 1.1  2005/09/13 15:07:43  pukitepa
 *  init
 *
 *  Revision 1.1.46.1  1999/01/07 14:30:53  jk
 *  Modifications made for dv/venas
 *
 *  Revision 1.2  1998/10/21 12:14:50  bill
 *  Added a dvconChildPeek
 *
 *  Revision 1.1  1998/07/20 09:58:08  bill
 *  New libdvcon library to handle verbose printing, Time stamps and converter
 *  spawning.
 *
 *
 ****************************************************************************
 *
 *  Copyright (c) 1998 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 * This  document  may  not, in  whole  or in  part, be  copied,  photocopied,
 * reproduced,  translated,  or  reduced to any  electronic  medium or machine
 * readable form without prior written consent from Division Ltd.
 *
 ****************************************************************************/

#ifndef __DVCON_H
#define __DVCON_H

#include <stdarg.h>
#include <dsys/pgeneral.h>
#ifdef _WIN32
#include <windows.h>
#endif

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

/* typedef int32 (*dvconFunction)(char *fileName, 
 *                                char *rcpName, 
 *                                char *outName,
 *                                char *outPath) 
 */
typedef int32 (*dvconFunction)(char *, char *, char *, char *) ; 

/*
 * char *dvconCreateTimeStamp(void) ;
 * char *dvconFileCreateTimeStamp(char *fileName) ;
 * 
 * Format the resultant timestamp is:-
 * 
 *    YYYY:MM:DD:hh:mm:ss:SSS
 * 
 * Where:
 *     YYYY - Year i.e. 1997
 *     MM   - Month of year 1-12
 *     DD   - Day of the month 1-31
 *     hh   - Hours 0-23
 *     mm   - Minutes 0-59
 *     ss   - Seconds 0-59
 */
char *dvconCreateTimeStamp(void) ;
char *dvconFileCreateTimeStamp(char *fileName) ;

/*
 * int32 dvconTimeStampCmp(char *ts1, char *ts2) ;
 * 
 * returns:
 * 
 * -ve: If ts1 is older than ts2
 *   0: If ts1 is thesame as ts2
 * +ve: If ts1 is newer than ts2
 */
#define dvconTimeStampCmp(ts1,ts2) (strcmp(ts1,ts2))

/*
 * void dvconTimeStampFree(char *ts) ;
 * 
 * Frees of a Created TimeStamp
 */
#define dvconTimeStampFree(ts) (dpgFree(ts))

void dvconPrint(char *format, ...) ;
void dvconPrintDynamic(char *format, ...) ;

/* Piped Child support ******************************************************/

/* if dvconPiped is non-zero then dvcon uses piped I/O format */
extern int32 dvconPiped ;

/* Child reading commands ***************************************************/
int32 dvconChildReadLine(char *buff, int buffSize) ;
#define dvconCOMMAND_EXIT    0
#define dvconCOMMAND_CONVERT 1
int32 dvconChildReadCommand(char **fileName, char **rcpName, char **outPath) ;

/* Child writing commands ***************************************************/
int32 dvconChildPeek(void) ;
void  dvconChildPrintInfo(char *format, ...) ;
void  dvconChildStartSection(char *section) ;
void  dvconChildPrintPercent(uint32 Cur, uint32 Tot) ;
void  dvconChildPrintActivity(void) ;
int32 dvconChildRequestQuit(char *name) ;
int32 dvconChildRequestFlip(int32 flip0, int32 flip1) ;
void  dvconChildCompleteSection(void) ;
void  dvconChildCompleteCommand(int32 status) ;

/* Child main loop (for converters) *****************************************/
#define dvcon_EXIT  0
#define dvcon_IDENT 1
#define dvcon_HELP  2
int32 dvconChildMain(int32 argc, char *argv[], dvconFunction convFunc) ;

/* Parent spawning, reading and writing commands ****************************/
typedef struct dvconProgram {
    struct dvconProgram *next ;
    char *progname ;
    int   pid ;
#ifdef _WIN32
    HANDLE  outFd ;
    HANDLE  inFd ;
    HANDLE  hProcess ;
#else
    int     outFd ;
    int     inFd ;
#endif
    uint8 ungetFlag ;
} dvconProgram ;

extern dvconProgram *dvconProgramHead ;

/* dconProgramGet
 * 
 * Gets the dconProgram handle for the given progname, if non exists,
 * then the program is spawned and a new dvconProgram is created and 
 * added to the stack
 */
dvconProgram *dvconProgramGet(char *progname) ;
void dvconProgramFree(dvconProgram *prog) ;
void dvconProgramWriteLine(dvconProgram *prog, char *line) ;
int32 dvconProgramReadLine(dvconProgram *prog, char *buff, int32 buffSize) ;
int32 dvconProgramPeek(dvconProgram *prog) ;

void dvconVersion(FILE *fp)  ;

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif
#endif /* __DVCON_H */
