/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: select.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:07:57 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: select.h,v 1.1 2005/09/13 15:07:57 pukitepa Exp $
 *
 *    FUNCTION:
 *
 *
 *    $Log: select.h,v $
 *    Revision 1.1  2005/09/13 15:07:57  pukitepa
 *    init
 *
 *    Revision 1.10  1998/09/11 14:03:40  clives
 *    New routine ECLimb_SelectEntityNoTouch which, as it says, selects an
 *    assembly without causing a Touch on it.
 *
 *    Revision 1.9  1997/01/29 15:32:20  clives
 *    *** empty log message ***
 *
 *    Revision 1.8  1997/01/23 17:53:37  clives
 *    *** empty log message ***
 *
 *    Revision 1.7  1997/01/15 17:20:19  clives
 *    *** empty log message ***
 *
 *    Revision 1.6  1997/01/10 13:33:18  clives
 *    *** empty log message ***
 *
 *    Revision 1.5  1996/12/20 10:07:40  clives
 *    *** empty log message ***
 *
 *    Revision 1.4  1996/12/17 15:28:03  clives
 *    *** empty log message ***
 *
 *    Revision 1.3  1996/12/12 11:38:09  clives
 *    *** empty log message ***
 *
 *    Revision 1.2  1996/11/28 17:19:12  clives
 *    *** empty log message ***
 *
 *    Revision 1.1  1996/11/26 17:55:18  dvise-dev
 *    *** empty log message ***
 *
 */
/* Version Control */


/* PRIVATE DEFINES =======================================*/

#define EC_MULTI_SELECT    0x01
#define EC_FLYTO_SELECT    0x02

/* PRIVATE TYPES =========================================*/

/* FORWARD DECLARATIONS ==========================*/

/* PUBLIC VARIABLES ======================================*/

/* PRIVATE VARIABLES =====================================*/

/* PUBLIC FUNCTIONS ======================================*/

DV_EXPORT void ECLimb_NewIntersect(ECLimb *, VCBody *, VCAttribute *);
DV_EXPORT void ECLimb_NewIntersectEntity(ECLimb *, VCBody *, VCAttribute *, VCEntity *);
DV_EXPORT void ECLimb_SelectEntity(ECLimb *, VCBody *, VCAttribute *, VCEntity *);
DV_EXPORT void ECLimb_SelectEntityNoTouch(ECLimb *, VCBody *, VCAttribute *, VCEntity *);
DV_EXPORT void ECLimb_DeselectEntity(ECLimb *, VCBody *, VCAttribute *, VCEntity *);
DV_EXPORT void ECLimb_DeselectAll(ECLimb *, VCBody *, VCAttribute *);
DV_EXPORT void ECLimb_SetMultipleSelectMode(ECLimb *);
DV_EXPORT void ECLimb_SetSingleSelectMode(ECLimb *);
DV_EXPORT int ECLimb_InMultiSelectMode(ECLimb *);
DV_EXPORT void ECLimb_FlyToSelectModeOn(ECLimb *);
DV_EXPORT void ECLimb_FlyToSelectModeOff(ECLimb *);
DV_EXPORT int ECLimb_InFlyToSelectMode(ECLimb *);
DV_EXPORT int ECLimb_ClearAssemblyRefs(ECAssembly *delObj);
DV_EXPORT pCLSN *ECLimb_GetSelectListPtr(ECLimb *limb);
DV_EXPORT ECItem *ECLimb_DumpSelectList(ECLimb *limb);
DV_EXPORT void EC_DeselectAll(void);
DV_EXPORT ECLimb *EC_FindSelectionsForBody(VCBody *body);
