/*
 *    PROJECT:      dvs
 *    SUBSYSTEM:    net
 *    MODULE:       dtcp.h
 *
 *    File:         $RCSfile: dtcp.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:07:42 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: dtcp.h,v 1.1 2005/09/13 15:07:42 pukitepa Exp $
 *
 *    FUNCTION:
 *    header file for host independant socket access.
 *
 * Copyright (c) 1994, 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef __DTCP_H
#define __DTCP_H

#include <stdio.h>

#ifndef _WIN32
#include <unistd.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/file.h>
#endif /* !_WIN32 */

#include <string.h>
#include <errno.h>
#ifdef _IRIX5
#include <bstring.h>
#endif

#include <sys/types.h>
#include <signal.h>
#include <fcntl.h>

# ifdef __cplusplus
extern "C" {
# endif

#ifndef DTCP_EXPORT
#if defined(_WIN32) && !defined(__EPP__) && !defined (BUILD_STATIC)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `extern'
 */
#ifdef  _LIB_DIVU
#define DTCP_EXPORT __declspec(dllexport) extern 
#else
#define DTCP_EXPORT __declspec(dllimport) extern 
#endif /* IN_A_DIVISION_LIB */
#else
#define DTCP_EXPORT  extern
#endif /* ! _WIN32 */
/* #define DTCP_EXPORT  extern */
#endif /* ndef DTCP_EXPORT */

#if defined (NOT_SUNOS) || defined(_UNXWR1)
#ifdef _DVS_AGENT
#define TCP_TLI

#else
#define TCP_BSD
#endif
#else
#if defined (_HPUX)  || defined (_IRIX) || defined(_LINUX) || defined(_SUNOS) || defined (_FREEBSD)
#define TCP_BSD
#else
#if defined (_WIN32)
#define TCP_WIN32
#else
#error Undefined system type
#endif
#endif
#endif

#ifdef TCP_TLI
#include <tiuser.h>
#include <stropts.h>

#define  dsock_open			dsock_tli_open
#define  dsock_bind_listen		dsock_tli_bind_listen
#define  dsock_buffer_size		dsock_tli_buffer_size
#define  dsock_select_io		dsock_tli_select_io
#define  dsock_async_io			dsock_tli_async_io
#define  dsock_nb_on			dsock_tli_nb_on
#define	 dsock_nb_off			dsock_tli_nb_off
#define  dsock_disableAsyncRead		dsock_tli_diableAsyncRead
#define  dsock_async_signal		dsock_tli_async_signal
#define  dsock_allow_broadcast  	dsock_tli_allow_broadcast
#define  dsock_set_timeout		dsock_tli_set_timeout
#define  dsock_sendto 			dsock_tli_sendto
#define  dsock_recvfrom 		dsock_tli_recvfrom
#define  dsock_send 			dsock_tli_send
#define  dsock_recv 			dsock_tli_recv
#define  dsock_getFirst_socket 		dsock_tli_getFirst_socket
#define  dsock_getNext_socket 		dsock_tli_getNext_socket
#define  dsock_connect			dsock_tli_connect
#define  dsock_connect_addr		dsock_tli_connect_addr
#define  dsock_listen_accept		dsock_tli_listen_accept
#define  dsock_acceptClose		dsock_tli_acceptClose
#define  dsock_recvConnect		dsock_tli_recvConnect
#define  dsock_enableAsyncWrite		dsock_tli_enableAsyncWrite
#define  dsock_disableAsyncWrite	dsock_tli_diableAsyncWrite
#define  dsock_close			dsock_tli_close
#define  dsock_error			dsock_tli_error
#define  dsock_errno			dsock_tli_errno
#define  dsock_init				dsock_tli_init
#endif

#include <dsys/divtypes.h>

#define DTCP_UDP	0x00000001
#define DTCP_TCP	0x00000002

#define DTCP_INET	0x00000001
#define DTCP_UNIX	0x00000002

#define DTCP_READ	1
#define DTCP_WRITE	2
#define DTCP_EXCEPTION	3
#define DTCP_ERR	4
#define DTCP_HUP	5

#define DTCP_LISTEN	-2
#define DTCP_CONNECT	-3
#define DTCP_DATA	-4
#define DTCP_EXDATA	-5
#define DTCP_DISCONNECT	-6
#define DTCP_ERROR	-7
#define DTCP_UDERR	-8
#define DTCP_ORDREL	-9
#define DTCP_TIMEOUT	-10
#define DTCP_WOULDBLOCK	-11

#ifdef _WIN32
#define DTCP_EINPROGRESS WSAEINPROGRESS
#define DTCP_EWOULDBLOCK WSAEWOULDBLOCK

#else
#define DTCP_EINPROGRESS EINPROGRESS
#define DTCP_EWOULDBLOCK EWOULDBLOCK
#endif


DTCP_EXPORT void dsockVersion(FILE *fp);
DTCP_EXPORT int dsock_open(int family, int type);
DTCP_EXPORT int dsock_bind_listen(int sock, int family, int inet_addr, short *port, int qlength);
DTCP_EXPORT int dsock_buffer_size(int sock, int bufferSize);
DTCP_EXPORT void dsock_select_io(int sock);
DTCP_EXPORT int	dsock_disableAsyncRead(int fd);
DTCP_EXPORT int dsock_async_io(int sock);
DTCP_EXPORT int dsock_nb_on(int sock);
DTCP_EXPORT int dsock_nb_off(int sock);
DTCP_EXPORT int dsock_async_signal(void);
DTCP_EXPORT int dsock_allow_broadcast (int sock);
DTCP_EXPORT void dsock_set_timeout(struct timeval *t);
DTCP_EXPORT int dsock_sendto (int sock, void *msg, int size, struct sockaddr_in *dst);
DTCP_EXPORT int dsock_recvfrom (int sock, void *msg, int size, struct sockaddr_in *from);
DTCP_EXPORT int dsock_send (int sock, void *msg, int size);
DTCP_EXPORT int dsock_recv (int sock, void *msg, int size);
DTCP_EXPORT int dsock_getFirst_socket (int *ioType);
DTCP_EXPORT int dsock_getNext_socket (int *ioType);
DTCP_EXPORT int dsock_connect(int sock, struct sockaddr_in *dst);
DTCP_EXPORT int dsock_connect_addr(int sock, int family, int inet_addr, short *port );
DTCP_EXPORT int dsock_listen_accept(int sock, struct sockaddr_in *addr);
DTCP_EXPORT int dsock_acceptClose(int fd);
DTCP_EXPORT int dsock_recvConnect(int fd);
DTCP_EXPORT int dsock_enableAsyncWrite(int fd);
DTCP_EXPORT int dsock_disableAsyncWrite(int fd);
DTCP_EXPORT int dsock_close(int fd);
DTCP_EXPORT int dsock_init();
DTCP_EXPORT int dsock_shutdown();


DTCP_EXPORT void dsock_error(char *string);
DTCP_EXPORT int32 dsock_flipWord(int32 value);
DTCP_EXPORT int16 dsock_flipShort(int16 value);

DTCP_EXPORT int dsock_errno;


# ifdef __cplusplus
}
# endif
#endif /* DTCP_H */
