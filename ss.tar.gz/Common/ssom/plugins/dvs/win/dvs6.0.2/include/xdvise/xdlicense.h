#include <dvise/eclicense.h>
int	 XDCheckLicense(int *licenseCount, ECLicensedFeaturesEnum ecLicense,
                                    char *licenseName, char *licenseDescription);
void	 XDFreeLicense(int *licenseCount, char *licenseName);
