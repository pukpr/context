/****************************************************************************
 *
 *  			Copyright 1995 Division Limited.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: xdcallbk.h,v $
 *  Revision      : $Revision: 1.1 $
 *  Date          : $Date: 2005/09/13 15:08:21 $
 *  Author        : $Author: pukitepa $
 *  Last Modified : <150798.1201>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 *  $Log: xdcallbk.h,v $
 *  Revision 1.1  2005/09/13 15:08:21  pukitepa
 *  init
 *
 *  Revision 1.4  1998/07/15 16:15:22  simon
 *  made some changes to the progress dlg, and file dlgs so they could be
 *  called from a plugin.  Added a couple of new types for file dlg.
 *
 *  Revision 1.3  1997/11/11 15:50:29  simon
 *  fix to xdcallback which changes definition to get xdvise to compile
 *  on hpux boxes
 *
 *  Revision 1.2  1997/11/07 16:54:40  simon
 *  bug fixes
 *
 *  Revision 1.1  1997/07/09 12:30:58  simon
 *  *** empty log message ***
 *
 *
 ****************************************************************************
 *
 *  Copyright (c) 1995 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 *  This Document may not, in whole or in part, be copied,
 *  photocopied, reproduced, translated, or reduced to any
 *  electronic medium or machine readable form without prior
 *  written consent from Division Ltd.
 ****************************************************************************/

#ifndef __XDCALLBK_H__
#define __XDCALLBK_H__
#ifdef __cplusplus
extern "C" {
#endif
#ifdef _dummyBrace_
}
#endif

/* STRUCTURES ===========================================*/

typedef void XdCallBack(void *contextData, void *callData);

typedef struct _XdCallBackList XdCallBackList;

/* FUNCTIONS ============================================*/

/*
 * set *callBackList = NULL for a new list
 */
void XdCallBackList_AddCallBack(XdCallBackList **callBackList, 
					XdCallBack *callBack, void *callData);
XdCallBackList *XdCallBackList_GetNext(XdCallBackList *thisCallBackList);
void *XdCallBackList_GetCallData(XdCallBackList *thisCallBackList);
XdCallBack *XdCallBackList_GetCallBack(XdCallBackList *thisCallBackList);
XdCallBack *XdCallBackList_FindFromData(XdCallBackList *thisCallBackList, void *callData);
void XdCallBackList_Remove(XdCallBackList **thisList);
void XdCallBackList_RemoveCallBack(XdCallBackList **listPtr, XdCallBack *func);
void XdCallBackList_RemoveMatchingCallBack(XdCallBackList **listPtr, XdCallBack *func, void *callData);
void XdCallBackList_Execute(void *contextData, XdCallBackList *cbList);


#ifdef _dummyBrace_
{
#endif
#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /* __XDCALLBK_H__ */
