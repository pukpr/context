/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1996 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: xdintfd.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 12 April 1996
--  Author       : Tony Coombes
--
--  Description	 : Integer Value Field
--
--  Modified     : 
--    $Log: xdintfd.h,v $
--    Revision 1.1  2005/09/13 15:08:24  pukitepa
--    init
--
--    Revision 1.1  1997/07/09 12:31:46  simon
--    *** empty log message ***
--
--    Revision 1.2  1997/02/11 18:57:45  wman
--    Frame reset for animation dialog.
--
--    Revision 1.1.1.1  1996/08/29 09:26:16  tony
--    first version of xdvise
--
--    Revision 3.1  1996/08/05 15:06:37  tony
--    Check in prior to starting development for IDP
--
--    Revision 1.2  1996/06/18 11:17:02  tony
--    Mid development revision
--
--    Revision 1.1  1996/04/12 15:42:19  tony
--    Initial development of basic components
--    for constructing property editors
--
--
--
-- ----------------------------------------------------------------------------
*/

#ifndef __XDINTFD_H__
#define __XDINTFD_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct intValFieldT intValFieldT; /* Prototype */

extern intValFieldT *XdIntValueFieldCreate(compT parent, char *label, int min, int max, 
                      int smlInc, int lrgInc, 
		      void (*changedCallback)(intValFieldT *w, void *clientData), 
		      void *clientData);
extern void XdIntValueFieldDestroy(intValFieldT *intValField);
extern int  XdIntValueFieldGetValue(intValFieldT *intValField);
extern void XdIntValueFieldSetValue(intValFieldT *intValField, int value, int explicit);
extern int XdIntValueFieldGetResetValue(intValFieldT *intValField);
extern int XdIntValueFieldHasChanged(intValFieldT *intValField);

#ifdef __cplusplus
}
#endif

#endif /* __XDINTFD_H__ */
