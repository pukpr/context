/****************************************************************************
 *
 *  			Copyright 1995 Division Limited.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: mapfile.h,v $
 *  Revision      : $Revision: 1.1 $
 *  Date          : $Date: 2005/09/13 15:07:44 $
 *  Author        : $Author: pukitepa $
 *  Last Modified : <081195.1847>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 ****************************************************************************
 *
 *  Copyright (c) 1995 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 *  This Document may not, in whole or in part, be copied,
 *  photocopied, reproduced, translated, or reduced to any
 *  electronic medium or machine readable form without prior
 *  written consent from Division Ltd.
 ****************************************************************************/

#ifndef __MAPFILE_H__
#define __MAPFILE_H__

#ifdef _PT_LOCAL
#include "ptool.h"
#else
#include <dsys/ptool.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif
    
/* Error Numbers */
#define dmpENO_OPEN  0x50001
#define dmpENO_FORM  0x50002

typedef struct dmpMATFILETYPE
{
    char       *name ;
    dpfFILEPTR  file ;
    struct dmpMATFILETYPE *next ;
} dmpMATFILE, *dmpMATFILEPTR ;

typedef struct dmpBLOCKTYPE
{
    char   *name ;
    int32   ignore ;
    struct dmpBLOCKTYPE *next ;
} dmpBLOCK, *dmpBLOCKPTR ;

typedef struct dmpMAPPINGTYPE
{
    char      *from, *to ;
    int32      gotMat ;
    int32      gotText ;
    dptTEXTURE text ;
    struct dmpMAPPINGTYPE *next ;
} dmpMAPPING, *dmpMAPPINGPTR ;

typedef struct
{
    dmpMATFILEPTR  materials ;
    dmpMAPPINGPTR  mappings ;
    dmpBLOCKPTR    blocks ;
} dmpFILE, *dmpFILEPTR ;

dmpFILEPTR
dmpCreateFile(void) ;
dmpMATFILEPTR
dmpCreateMatFile(void) ;
int32 
dmpAddMatFile(dmpFILEPTR mp, dmpMATFILEPTR mat) ;
dmpBLOCKPTR
dmpCreateBlock(void) ;
int32
dmpAddBlock(dmpFILEPTR mp, dmpBLOCKPTR blk) ;
dmpMAPPINGPTR
dmpCreateMapping(void) ;
int32
dmpAddMapping(dmpFILEPTR mp, dmpMAPPINGPTR map) ;
void
dmpFreeFile(dmpFILEPTR mp) ;
dmpMAPPINGPTR
dmpFindMapping(dmpFILEPTR mp, char *name) ;
dpfMATERIALPTR
dmpFindMaterial(dmpFILEPTR mp, char *name) ;
dpfTEXTUREPTR
dmpFindTexture(dmpFILEPTR mp, char *name) ;
dmpBLOCKPTR
dmpFindBlock(dmpFILEPTR mp, char *name) ;

int32
dmpGetMapFile(dmpFILEPTR mp, char *fileName) ;
int32
dmpSaveFile(char *name, dmpFILEPTR file) ;

void
dmpVersion(FILE *fp) ;

#ifdef __cplusplus
}
#endif

#endif /* __MAPFILE */
