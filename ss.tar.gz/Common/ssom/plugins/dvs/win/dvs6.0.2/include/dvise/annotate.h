/**************************** ANNOTATE.H *****************************/

/* Internal Annotation representation */

typedef struct AnnotateData {
    char *annotate_name;
    char *parent_name;
    char *date;
    char *time;
    char *audiofile;
    char *memo;
    char *trigger_event;
    float32 *body_pos;
    float32 *body_ori;
    char *user_process;
    char *assignee;
    char *owner;
    int	priority;
    char *status;
    char *iconfile;
    char *markup_file;
    char *markup_image;
    char *markup_tool;
} AnnotateData;

#define TESTCASE "ANNOTATE_NAME=fred1|MEMO=There is a problem in the manifold.\nI suggest we start again from scratch & go home.\nOr give up!|EVENT=Trigger|BODYMATRIX=1.0 2.0 3.0 4.0 5.0 6.0|USER_PROCESS=snapshot|ASSIGNEE=stevep|OWNER=stevep|PRIORITY=1|STATUS=Pending|ICONFILE=misc/noteBig"
#define DELIMITER_DCISTRING "|"
#define DELIMITER_TOKEN '='
#define DELIMITER_TOKEN_STR "="
#define DELIMITER_TOKENDATA " "

/* NB: MAXIMUM LENGTH OF TOKEN = 16 CHARS */
#define NUMBER_ANNOTATEDATA_FIELDS 13
#define ANNOTATE_NAME_TOKEN	"ANNOTATE_NAME"
#define ANNOTATE_PARENT_TOKEN	"ANNOTATE_PARENT"
#define DATE_TOKEN	"DATE"
#define TIME_TOKEN "TIME"
#define AUDIOFILE_TOKEN		"AUDIOFILE"
#define MEMO_TOKEN		"MEMO"
#define EVENT_TOKEN		"EVENT"
#define BODYMATRIX_TOKEN	"BODYMATRIX"
#define USER_PROCESS_TOKEN	"USER_PROCESS"
#define ASSIGNEE_TOKEN		"ASSIGNEE"
#define OWNER_TOKEN		"OWNER"
#define PRIORITY_TOKEN		"PRIORITY"
#define STATUS_TOKEN		"STATUS"
#define ICONFILE_TOKEN		"ICONFILE"
#define MARKUPFILE_TOKEN        "MARKUPFILE"
#define MARKUP_IMAGE_TOKEN      "MARKUPIMAGE"
#define MARKUP_TOOL_TOKEN       "MARKUPTOOL"

#define ANNOTATE_NOTES_DIR	"notes"
#define ANNOTATE_AUDIO_DIR	"audio"
#define ANNOTATE_FILE_HEADER	"##################### dVISE Annotator File v0.1 #####################"
#define ANNOTATE_ASSEMBLY_HEADER "Note-"
#define ANNOTATE_COMMENT_HEADER  "ANNOTATE_FILE:"

DV_EXPORT AnnotateData *annotate_create_datastructure (void);
DV_EXPORT void annotate_free_datastructure (AnnotateData *annodata);
DV_EXPORT AnnotateData *convert_string2annotate(char *str);
DV_EXPORT char *convert_annotate2string (AnnotateData *annodata);

DV_EXPORT void annotate_create_file (AnnotateData *annodata);
DV_EXPORT AnnotateData *annotate_read_file (char *filename);
DV_EXPORT ECAssembly* annotate_create_assembly (AnnotateData *annodata);
DV_EXPORT void annotate_setup_assembly (ECAssembly *note);

DV_EXPORT void annotate_get_bodymatrix (AnnotateData *annodata); 
DV_EXPORT ECAssembly *annotate_get_ECAssembly (AnnotateData *annodata);
DV_EXPORT void annotate_play_audio (ECAssembly *assembly, AnnotateData *annodata);
DV_EXPORT void annotate_set_bodymatrix (AnnotateData *annodata, VCBody *body);
DV_EXPORT void annotate_toggle_icon (ECAssembly *assembly, AnnotateData *annodata);
DV_EXPORT void annotate_sendmail (AnnotateData *annodata);
DV_EXPORT void annotate_trigger_userprocess (AnnotateData *annodata);
DV_EXPORT void annotate_trigger_markup (AnnotateData *annodata);
DV_EXPORT void annotate_trigger_event (ECAssembly *assembly, AnnotateData *annodata);

DV_EXPORT void annotation_dci_register_comms(void);
DV_EXPORT void annotate_start_recording(char *audiofile);
DV_EXPORT void annotate_pause_recording(void);
DV_EXPORT void annotate_stop_recording(void);
DV_EXPORT void annotate_destroy_entity(void);
DV_EXPORT void annotate_play_recording(char *audio_filename);
DV_EXPORT void annotate_delete_recording(char *audiofile);

DV_EXPORT void annotate_update_state(AnnotateData *annodata);
AnnotateData *annotate_read_UD(ECAssembly *obj);
void annotate_create_UD(ECAssembly *obj, AnnotateData *adata);

DV_EXPORT void annotation_afuncs_register(void);

DV_EXPORT void annotate_flyto_and_activate(AnnotateData *annodata, VCBody *body, 
                            int useVoice, int useEvent, int useProcess);
DV_EXPORT void annotate_setup_flyto(void);

/* DB functions */

DV_EXPORT void annotation_db_hook(void);

extern int annotation_db_active(void);  
extern int annotation_db_create_annotation(ECAssembly* note);
extern int annotation_db_update_status(ECAssembly* note, const char* const status);
extern int annotation_db_is_db_note(ECAssembly* note);
extern int annotation_db_close(ECAssembly* note);

/* Save functions */

extern int annotation_set_output_file(const char* const filename, const char* const oldname);
extern int annotation_save_annotation(ECAssembly* assembly);
