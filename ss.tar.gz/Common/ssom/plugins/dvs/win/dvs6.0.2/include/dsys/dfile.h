#if ! defined _DFILE_H
#define _DFILE_H

#include <stdio.h>
#include <string.h>

#if ! defined DFILE_EXPORT
#if defined(_WIN32) && !defined(__EPP__) && !defined(BUILD_STATIC)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `extern'
 */
#if defined _LIB_DIVU
#define DFILE_EXPORT __declspec(dllexport) extern 
#else
#define DFILE_EXPORT __declspec(dllimport) extern 
#endif 
#else
#define DFILE_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ndef DFILE_EXPORT */


#if defined __cplusplus
extern "C" {
#endif

/* We'll have path lists separated by ":" in UNIX land, */
/* and ";" in Windows land. */
#if defined _UNIX
#define DFILE_PATH_SEPARATOR ":"
#else
#define DFILE_PATH_SEPARATOR ";"
#endif

/*
 * searching fopen/searching flook functions.
 */

#define SF_READ  1
#define SF_WRITE 2
#define SF_EXEC  4
#define SF_EXIST 8

typedef enum { DFILE_PATH_SYSTEM, DFILE_PATH_USER, DFILE_PATH_OFFSET } dfilePathType;

#ifndef DUSEARCH_MAX_PATH_LEN
#define DUSEARCH_MAX_PATH_LEN 2048
#endif
typedef struct duPathIterator
{
    void *searchList;
    int index, offsetIndex;
    void *offset;
    void *entry;
    char name[DUSEARCH_MAX_PATH_LEN];
} duPathIterator;
typedef struct dfilePathIterator
{
  void * pathNodePtr;
} dfilePathIterator;

DFILE_EXPORT void dfile_flushCache (void);

DFILE_EXPORT int dfile_isDir  (char * path);
DFILE_EXPORT int dfile_isFile (char * path);

DFILE_EXPORT void *dfileConvertPathToTable(char *sysPath,
                                     char *userPath,
                                     char *offset);
DFILE_EXPORT void *dfileAddPathToTable(void *table,
                                 char *path,
                                 dfilePathType type);
DFILE_EXPORT FILE *dfileSearchingFopen(char *fileName,
                                 void *pathList,
                                 char **extensions,
                                 char  *mode,
                                 char  *fullPath,
                                 int maxFullPathSize,
                                 int *extensionIndex,
                                 int absolute);
DFILE_EXPORT int dfileSearchingFlook(char *fileName,
                               void *pathList,
                               char **extensions,
                               char  *fullPath,
                               int maxFullPathSize,
                               int *extensionIndex,
                               int absolute);
DFILE_EXPORT char *dfilePathIterateInit(dfilePathIterator *iter, void *table);
DFILE_EXPORT char *dfilePathIterate(dfilePathIterator *iter);
DFILE_EXPORT void *dfilePathRemoveEntry(void *table, char *entry);
DFILE_EXPORT void dfilePathDelete(void *table);
DFILE_EXPORT void dfileSetDefaultPath(char *path1, char *path2,
                                   char *path3, char *path4);
DFILE_EXPORT void dfileSfSearchPath(char *searchPath);
DFILE_EXPORT void dfileSfSearchVariable(char *searchVariable);
DFILE_EXPORT void dfileSfUserVariable(char *userVariable);
DFILE_EXPORT int dfileGetWorkingDir (char * path, size_t pathSize);
DFILE_EXPORT int dfileSetWorkingDir (char * path);
DFILE_EXPORT int dfile_makePathAbsolute	(char * fullPath, int maxFullPathSize, char * shortPath);

DFILE_EXPORT void dfile_dontConformToAPI  (void);
DFILE_EXPORT void dfile_conformToAPI      (void);

#if defined __cplusplus
}
#endif
#endif /*_DFILE_H */
