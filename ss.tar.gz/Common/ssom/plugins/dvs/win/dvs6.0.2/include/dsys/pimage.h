/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: pimage.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:07:46 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: pimage.h,v 1.1 2005/09/13 15:07:46 pukitepa Exp $
 *
 *    FUNCTION:
 *
 *
 * Copyright (c) 1992-95 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef __PIMAGE_H__
#define __PIMAGE_H__

#include <dsys/divtypes.h>

#ifdef __cplusplus
extern "C" {
#endif


/****************************************************************************
 * pimage error numbers */
#define dpiENO_OPEN  0x7001
#define dpiENO_READ  0x7002
#define dpiENO_WRITE 0x7003
#define dpiENO_CLOSE 0x7004
#define dpiENO_NULL  0x7005
#define dpiENO_FORM  0x7006

/****************************************************************************
 * pimage error numbers */
#define dpiWARN_PROB 2

/****************************************************************************
 * pimage monitor numbers */
#define dpiMON_POS     0x00010000
#define dpiMON_PALLET  0x00020000
#define dpiMON_IMAGE   0x00040000
    
void
dpiVersion(FILE *fp) ;

#define VTX_ALLOW_VTX   1
#define VTX_ALLOW_SVT   2
#define VTX_ALLOW_OTHER 4
#define VTX_ALLOW_DIV   3
#define VTX_ALLOW_ALL   7

#define VTX_WIDTH_EIGHT (uint8)1

#define VTXcmpIRGB(s1,s2)  memcmp(s1,s2,3)
#define VTXcmpIRGBA(s1,s2) memcmp(s1,s2,4)
#define VTXcpyIRGBA(dd,ss) memcpy(dd,ss,sizeof(VTXIRGBA))

typedef enum { VTX_GIF_FILE, VTX_BMP_FILE, VTX_SGI_FILE,
               VTX_SVT_FILE, VTX_TGA_FILE, VTX_TIF_FILE,
               VTX_VTX_FILE, VTX_BSL_FILE, VTX_UNKNOWN_FILE } VTX_IMG_TYPE ;

typedef enum { VTX_PREC_SINGLE=0, VTX_PREC_DOUBLE=1 } VTXPRECISION ;
/* bsl types */
#define dpiBSLNOTYPES 9
typedef enum {dpiBSLTYPE_MONO0=0, dpiBSLTYPE_MONO1=1, dpiBSLTYPE_MONO2=2, 
              dpiBSLTYPE_MONO3=3, dpiBSLTYPE_MONO4=4, dpiBSLTYPE_MONO5=5, 
              dpiBSLTYPE_BILINEAR=6, 
              dpiBSLTYPE_RGB=7, dpiBSLTYPE_RGBA=8 } dpiBSLTYPE ;

typedef enum VTXcoord { /* used for indexing arrays, identifying axies etc */
        VTXERGBA =  4, VTX_R = 0, VTX_G = 1, VTX_B = 2, VTX_A=3
} VTXcoord;

typedef struct
{
    uint8   col[VTXERGBA];
}VTXIRGBA ;

typedef struct
{
    float32 col[VTXERGBA];
}VTXFRGBA ;

typedef float32 VTXBOXFILTER[3][3] ;


struct VTXTEXTURETYPE ;
typedef struct VTXTEXTURETYPE *VTXTEXTUREPTR ;

struct VTXHEADERTYPE ;
typedef struct VTXHEADERTYPE *VTXHEADERPTR ;

struct VTXFILETYPE ;
typedef struct VTXFILETYPE *VTXFILEPTR ;

int32
VTXgetFile(char *name, VTXFILEPTR *file, int32 allowFile) ;
VTXFILEPTR
VTXopenFile(char *name, int32 allowFile) ;
int32
VTXgetFileBody(VTXFILEPTR file) ;
int32
VTXcloseFile(VTXFILEPTR file) ;
int32
VTXfreeFile(VTXFILEPTR file) ;

int32
VTXputFile(char *name, VTXFILEPTR Sfile, VTX_IMG_TYPE fileType) ;
VTXFILEPTR
VTXopenNewFile(char *name, VTX_IMG_TYPE fileType) ;
int32
VTXputFileBody(VTXFILEPTR Dfile, VTXFILEPTR Sfile) ;

VTXFILEPTR
VTXcreateFile(char *name) ;
VTXTEXTUREPTR
VTXcreateTexture(void) ;
int32
VTXaddTexture(VTXFILEPTR file, VTXTEXTUREPTR text) ;
void
VTXcreateData(VTXTEXTUREPTR texture) ;

VTXTEXTUREPTR
VTXgetTexture(VTXFILEPTR file) ;

void
VTXgetTextureSize(VTXTEXTUREPTR vtx, int32 *u, int32 *v) ;
uint8
VTXgetTextureType(VTXTEXTUREPTR vtx) ;
VTXIRGBA *
VTXgetTextureData(VTXTEXTUREPTR vtx) ;
void
VTXgetTextureBgColour(VTXTEXTUREPTR vtx, VTXIRGBA *col) ;

void
VTXsetTextureSize(VTXTEXTUREPTR vtx, int32 u, int32 v) ;
void
VTXsetTextureType(VTXTEXTUREPTR vtx, uint8 type) ;
void
VTXsetTextureData(VTXTEXTUREPTR vtx,VTXIRGBA *data) ;
void
VTXsetTextureBgColour(VTXTEXTUREPTR vtx, VTXIRGBA *col) ;

void
VTXfreeTexture(VTXTEXTUREPTR texture) ;


/* returns non-zero on error, zero otherwise. new_quads points to the same or
** a new array of quads.
*/
int32
VTXinterpolate(VTXTEXTUREPTR vtx, int32 new_width, int32 new_height) ;
int32
VTXboxFilter(VTXTEXTUREPTR file, VTXBOXFILTER BoxF) ;
/* if Opacity is < 0 then the alpha is just initialised, else it is set to 
 * it (range 0 -> 255)
 */
int32
VTXsetTransparency(VTXTEXTUREPTR vtx, int32 glOpacity, int32 bgOpacity) ;


VTXFILEPTR
VTXcreateBSL(char *name, int32 u, int32 v, int32 w) ;
int32
VTXmergeBSL(VTXFILEPTR Dfp, int32 type, VTXFILEPTR Sfp) ;
VTXFILEPTR
VTXextractBSL(int32 imgNo, VTXFILEPTR Sfp) ;

#ifdef __cplusplus
}
#endif

#endif /* __PIMAGE_H__ */

