/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1996 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: xdviewd.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 4 October 1996
--  Author       : Tony Coombes
--
--  Description	 : Tree View Widget
--
--  Modified     : 
--    $Log: xdviewd.h,v $
--    Revision 1.1  2005/09/13 15:08:29  pukitepa
--    init
--
--    Revision 1.8  1998/07/15 10:50:12  wman
--    Addition of Enable Only selected functionality
--
--    Revision 1.7  1998/07/09 15:15:28  clives
--    dvise5.0.2 specific code integrated into Darkstar
--
--    Revision 1.6  1998/07/02 16:10:47  wman
--    Changes for second edit toolbar and functions.
--
--    Revision 1.5  1998/06/12 08:53:31  simon
--    changes for filter tool
--
--    Revision 1.4  1998/03/19 16:20:59  simon
--    added the new distance tool
--
--    Revision 1.3  1997/11/14 17:21:00  tony
--    Convert AssyPostSelectionCB to a more generic EntityPostSelectionCallback
--    so that Attribute editors can be updated properly.
--
--    Revision 1.2  1997/10/28 17:54:41  simon
--    bug fixes - added assembly status change callback to view widget,
--    and made use of it in library viewer.
--
--    Revision 1.1  1997/07/09 12:32:55  simon
--    *** empty log message ***
--
--    Revision 1.44  1997/04/01 16:50:00  tony
--    General fixes to problems highlighted by Insure
--
--    Revision 1.43  1997/03/17 16:52:42  wman
--    Added selection sensitive menus
--
--    Revision 1.42  1997/03/16 17:27:52  tony
--    *** empty log message ***
--
--    Revision 1.41  1997/03/13 17:47:59  tony
--    *** empty log message ***
--
--    Revision 1.40  1997/03/12 18:06:43  tony
--    *** empty log message ***
--
--    Revision 1.39  1997/03/07 20:50:25  tony
--    *** empty log message ***
--
--    Revision 1.38  1997/03/05 16:29:41  tony
--    *** empty log message ***
--
--    Revision 1.37  1997/02/27 21:06:29  tony
--    *** empty log message ***
--
--    Revision 1.36  1997/02/20 19:26:05  wman
--    Bug Fixes
--
--    Revision 1.35  1997/02/19 21:05:27  tony
--    *** empty log message ***
--
--    Revision 1.34  1997/02/16 17:19:59  tony
--    Cjor VS:
--
--    Revision 1.33  1997/02/10 21:02:27  tony
--    *** empty log message ***
--
--    Revision 1.32  1997/02/07 11:02:00  tony
--    *** empty log message ***
--
--    Revision 1.31  1997/01/30 17:49:23  tony
--    *** empty log message ***
--
--    Revision 1.30  1997/01/09 15:57:20  tony
--    *** empty log message ***
--
--    Revision 1.29  1996/12/13 18:02:24  tony
--    *** empty log message ***
--
--    Revision 1.28  1996/12/11 16:47:43  tony
--    *** empty log message ***
--
--    Revision 1.27  1996/12/09 18:32:41  tony
--    *** empty log message ***
--
--    Revision 1.26  1996/12/06 18:09:33  wman
--    Key Frame additions - feedback from dVISE on selection on frames.
--    Bugs in external multiple selection and update fixed.
--
--    Revision 1.25  1996/12/06 17:38:03  tony
--    *** empty log message ***
--
--    Revision 1.24  1996/12/04 18:35:49  tony
--    *** empty log message ***
--
--    Revision 1.23  1996/11/29 21:35:59  tony
--    *** empty log message ***
--
--    Revision 1.22  1996/11/27 20:45:32  tony
--    Added Attributes to the Assembly view
--
--    Revision 1.21  1996/11/15 17:21:12  tony
--    *** empty log message ***
--
--    Revision 1.20  1996/11/14 18:13:57  tony
--    *** empty log message ***
--
--    Revision 1.19  1996/11/08 16:48:56  tony
--    *** empty log message ***
--
--    Revision 1.18  1996/11/07 18:02:19  tony
--    *** empty log message ***
--
-- ----------------------------------------------------------------------------
*/

#ifndef __XDVIEWD_H__
#define __XDVIEWD_H__

typedef struct vieWidgT vieWidgT;
#include <dsys/divtypes.h> /* For uint32 */
#include "wkeys.h" /* For compT */
#include "xdhrchy.h"       /* For hrchyT */

/* This Enum is used to identify the Selection
 * List that the view belongs to. */
typedef enum {
    XDVIEW_SLCT_LST_PRIVATE,  /* Doesn't belong to any Selection List.
                              ** The Selection List of this view is
			      ** independent of all other views. */
    XDVIEW_SLCT_LST_VWORLD,   /* Virtual World selection list */
    XDVIEW_SLCT_LST_LIB       /* Libraries selection list */
} viewSlctnListEnum;

/* This Enum is used to identify the Assembly
 * Hierarchy that the view uses. */
typedef enum {
    XDVIEW_HRCHY_ZONE, /* Zone hierarchy */
    XDVIEW_HRCHY_LIB   /* Library hierarchy */
} viewHrchyEnum;

#ifdef __cplusplus
extern "C" {
#endif


extern vieWidgT *XdViewWidget_Create(compT parent, hrchyT *hrchy, 
                   void (*assySelectedCB)(vieWidgT *w, ECAssembly *assy, int selected, void *clientData), 
                   void (*assyCreatedCB)(vieWidgT *w, ECAssembly *assy, void *clientData), 
                   void (*assyDeletedCB)(vieWidgT *w, ECAssembly *assy, void *clientData), 
                   void (*entityPostSelectionCB)(vieWidgT *w, void *firstSelectedEntity, int selectionCount, void *clientData), 
                   void (*assyUpdatedCB)(vieWidgT *w, ECAssembly *assy, void *clientData), 
		   void (*itemSelectedCB)(vieWidgT *w, ECItem *item, void *cientData), 
		   void (*itemDeselectedCB)(vieWidgT *w, ECItem *item, void *cientData), 
		   void (*entityActivatedCB)(vieWidgT *w, void *entity, void *cientData), 
                   void (*assyStatusChangeCB)(vieWidgT *w, ECAssembly *assy, void *clientData),
                   void (*entityRenamedCB)(vieWidgT *w, ECAssembly *assy, void *clientData),                  
                   void *clientData, int dlg);
extern void      XdViewWidget_Register(vieWidgT *view, viewSlctnListEnum selectionList, 
                      viewHrchyEnum whichSubHrchy, int initialDepth, 
                      int (*assyFilterCB)(ECAssembly *assy, void *userData), 
                      int (*itemFilterCB)(ECItem *item, void *userData), 
		      void *userData);
extern void      XdViewWidget_Deregister(vieWidgT *view);
extern int       XdViewWidget_IsRegistered(vieWidgT *view);
extern void      XdViewWidget_SetViewNumber(vieWidgT *view, int viewNum);
extern int       XdViewWidget_GetViewNumber(vieWidgT *view);
extern int       XdViewWidget_GetDlg(vieWidgT *view);
extern hrchyT   *XdViewWidget_GetHrchy(vieWidgT *view);
extern compT     XdViewWidget_GetTree(vieWidgT *view);
extern void      XdViewWidget_ExpandOneLevel(vieWidgT *view);
extern void      XdViewWidget_ExpandBranch(vieWidgT *view);
extern void      XdViewWidget_CollapseBranch(vieWidgT *view);
extern void      XdViewWidget_CutRequset(vieWidgT *view);
extern void      XdViewWidget_CopyRequset(vieWidgT *view);
extern void      XdViewWidget_PasteRequset(vieWidgT *view);
extern void      XdViewWidget_DeleteRequest(vieWidgT *view);
extern void      XdViewWidget_LoadOnlyRequest(vieWidgT *view);
extern void      XdViewWidget_EnableOnlyRequest(vieWidgT *view);
extern void      XdViewWidget_DeleteLandmarkRequest(vieWidgT *view);
extern void      XdViewWidget_SelectedOperate(vieWidgT *view, 
                             int (*fn)(ECAssembly *assy, void *userData), void *userData);
extern void      XdViewWidget_AllSelectedOperate(vieWidgT *view, 
                             int (*fn)(ECAssembly *assy, void *userData), void *userData);
extern ECAssembly *XdViewWidget_GetSelectedAssembly(vieWidgT *view);
extern void      XdViewWidget_ViewSelected(vieWidgT *view);
extern void      XdViewWidget_Freeze(vieWidgT *view);
extern void      XdViewWidget_Thaw(vieWidgT *view);
extern void      XdViewWidget_UnselectAll(vieWidgT *view);
extern void      XdViewWidget_SelectPath(vieWidgT *view, char *path, int cumulative);
extern void      XdViewWidget_SelectAll(vieWidgT *view);
extern void      XdViewWidget_InvertSelection(vieWidgT *view);
extern void      XdViewWidget_LinkOpInProgress(vieWidgT *view);
extern void      XdViewWidget_ExposeAndViewSelectedNode(vieWidgT *view);


extern void      XdViewWidget_GUIExpandCB(vieWidgT *view, int row, int level);
extern void      XdViewWidget_GUICollapseCB(vieWidgT *view, int row, int level);
extern void      XdViewWidget_GUISelectedStatusChangedCB(vieWidgT *view, int row, int selected, int respond);
extern void      XdViewWidget_GUIActivateCB(vieWidgT *view, int row);
extern void      XdViewWidget_GUISelectionCompleteCB(vieWidgT *view);

extern void      XdViewWidget_AddAttributeCB(vieWidgT *view, int row, int level, ECItem *item);

extern void      XdViewWidget_SetViewSelectedFlag(vieWidgT *view, int newFlagValue);
extern int       XdViewWidget_GetViewSelectedFlag(vieWidgT *view);
extern void      XdViewWidget_QrySelectedAssyAttributes(vieWidgT *view);

extern int       XdViewWidget_GetPasteFlag(vieWidgT *view);
extern void      XdViewWidget_SetPasteFlag(vieWidgT *view, int newValue);

extern void		 XdViewWidget_GUILoadTreeCB(vieWidgT *view, int row, int level, int load);
extern void		 XdViewWidget_GUIEnableTreeCB(vieWidgT *view, int row, int level, int enable);

#ifdef __cplusplus
}
#endif

#endif /* __XDVIEWD_H__ */
