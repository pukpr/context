/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: xdplug.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:08:26 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: xdplug.h,v 1.1 2005/09/13 15:08:26 pukitepa Exp $
 *
 *    FUNCTION:
 *
 * Copyright (c) 1994 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */

#ifndef _XDPLUG_H
#define _XDPLUG_H

/* INCLUDES =================================================*/

#include <dsys/dreg.h>
#include "wkeys.h"
#include "xdcallbk.h"
#include "xddlg.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Version Control */
#ifndef XDV_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `XDV_EXPORT'
 */
#ifdef  _LIB_XDV
#define XDV_EXPORT __declspec(dllexport) extern
#else
#define XDV_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define XDV_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ifndef XDV_EXPORT */

/* DATA STRUCTURES ==========================================*/

typedef struct _XdPluginNode XdPluginNode; 

typedef void XdPluginCallBack(void *callData);

/* FUNCTION PROTOTYPES ======================================*/

XDV_EXPORT int XdPlugins_Create(void);
XDV_EXPORT int XdPlugins_Destructor(void);

XDV_EXPORT int XdPlugins_AddSystem(char *sysName);
XDV_EXPORT int XdPlugins_AddExplicit(char *pluginName);
XDV_EXPORT int XdPlugins_Load(void);

XDV_EXPORT int XdPlugin_RegisterDlg(compT (*instanceAndPopup)(compT parent), 
                     void (*popdown)(dialogInstanceData *inst),
                     int (*popup)(dialogInstanceData *inst), 
                     int (*confirmPopdown)(dialogInstanceData *inst));
XDV_EXPORT int XdPlugin_SetTopLevelDlg(int dlgId, compT dlg);
XDV_EXPORT dialogInstanceData *XdPlugin_Popup(int dlgId);
XDV_EXPORT int XdPlugin_PopupXdviseDlg(int dlgId, dlgContext context);

XDV_EXPORT int 
XdPlugin_UseAssMgrMenu(char *menuName, char *menuSelectLetter, char *buttonName, 
                       char *buttonSelectLetter, 
                       char *selectKeyCode, char *selectKeyCodeText,
                       ECLicensedFeaturesEnum licenseFeature,
                       XdPluginCallBack *selectCallBack, void *selectCallData);
XDV_EXPORT int 
XdPlugin_UseAssViewMenu(char *menuName, char *menuSelectLetter, char *buttonName, 
                        char *buttonSelectLetter, 
                        char *selectKeyCode, char *selectKeyCodeText, 
                        ECLicensedFeaturesEnum licenseFeature,
                        XdPluginCallBack *selectCallBack, void *selectCallData);
XDV_EXPORT int 
XdPlugin_UseAssViewPopupMenu(char *name, char *selectLetter, 
                             char *selectKeyCode, char *selectKeyCodeText, 
                             ECLicensedFeaturesEnum licenseFeature,
                             XdPluginCallBack *selectCallBack, void *selectCallData);
XDV_EXPORT int 
XdPlugin_UseAssViewToolbarButton(char **pixmap, char **armPixmap, 
                                 char **insensitivePixmap, char **licenceLockedPixmap, 
                                 ECLicensedFeaturesEnum licenseFeature,
                                 XdPluginCallBack *selectCallBack, void *selectCallData);
XDV_EXPORT int 
XdPlugin_UseAssMgrToolBarButton(char **pixmap, char **armPixmap, 
                                char **insensitivePixmap, char **licenceLockedPixmap, 
                                ECLicensedFeaturesEnum licenseFeature,
                                XdPluginCallBack *selectCallBack, void *selectCallData);

XDV_EXPORT void XdPlugins_GenerateInfo(char **info);
XDV_EXPORT char *XdPluginNode_GetFile(XdPluginNode *node);
XDV_EXPORT char *XdPluginNode_GetMessage(XdPluginNode *node);
XDV_EXPORT void XdPlugin_InformDvisePluginInfo(char **pluginNames);
XDV_EXPORT void XdPlugins_GenerateDviseInfo(char **info);

#ifdef __cplusplus
}
#endif

#endif /* _XDPLUG_H__ */

