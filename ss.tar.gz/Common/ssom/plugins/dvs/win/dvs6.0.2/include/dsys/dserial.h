/******************************************************************************/
/*									      */
/*	######    ###   #     #   ###    #####    ###   ####### #     #	      */
/*	#     #    #    #     #    #    #     #    #    #     # ##    #	      */
/*	#     #    #    #     #    #    #          #    #     # # #   #	      */
/*	#     #    #    #     #    #     #####     #    #     # #  #  #	      */
/*	#     #    #     #   #     #          #    #    #     # #   # #	      */
/*	#     #    #      # #      #    #     #    #    #     # #    ##	      */
/*	######    ###      #      ###    #####    ###   ####### #     #	      */
/*									      */
/*			   #     #####   #####  #######			      */
/*			  ##    #     # #     # #			      */
/*			 # #    #     # #     # #			      */
/*			   #     ######  ###### ######			      */
/*			   #          #       #       #			      */
/*			   #    #     # #     # #     #			      */
/*			 #####   #####   #####   #####			      */
/*									      */
/* 		Copyright (c) Division Limited. All rights reserved	      */
/*									      */
/* This Document may not, in whole or in part, be copied, photocopied,	      */
/* reproduced, translated, or reduced to any electronic medium or machine     */
/* readable form without prior written consent from Division Ltd.	      */
/*									      */
/******************************************************************************/

#if !defined _DSERIAL_H_
#define _DSERIAL_H_


#if defined __cplusplus
extern "C" {
#endif 

#if defined _WIN32 && !defined (__EPP__) && !defined (BUILD_STATIC)
/*
 * only  Windoze needs this baroque construct.
 * On sensible systems simply use `extern'
 */
#if defined _LIB_DIVU
#define DSERIAL_EXPORT __declspec(dllexport) extern
#else
#define DSERIAL_EXPORT __declspec(dllimport) extern
#endif /* _LIB_DIVU */
#else
#define DSERIAL_EXPORT extern
#endif /* WIN32 */


#if defined _WIN32
#include <windows.h>

#define DSERIAL_READ_BUFFER_SIZE 2048

#endif

/******************************************************************************/
/*									      */
/*	Typedefs and structures etc.					      */
/*									      */
/******************************************************************************/
/* dSerial function pointers are maintained in here */
typedef struct DSERIAL_CONFIG * DSERIAL_CONFIG_PTR;
typedef struct DSERIAL_CONFIG
{
  char * filename;
  int type;
#if defined _WIN32
  HANDLE fd;

  /* Extra grot required for readOrFail etc. */
  char readBuffer [DSERIAL_READ_BUFFER_SIZE];	/* A read buffer */
  unsigned int startData;
  unsigned int endData;
  unsigned int dataAvailable;

#else
  int fd;
  int sgiHack;
#endif
  int mode;
  int status;
  int powerOn;

  /* Some state that we need to maintain */
  int lastTimeout;
  int lastMin;			/* VMIN  */
  int lastTime;			/* VTIME */
  int lastBaudRate;
  int lastBlockMode;
  int lastReadChars;
  int lastStopBits;

  int timeoutLatency;

  void * state;			/* device specific state! */

} DSERIAL_CONFIG;

/* Function pointer typedefs */
typedef int (*DSERIAL_CONTROL)(DSERIAL_CONFIG_PTR config);
typedef int (*DSERIAL_IO)     (DSERIAL_CONFIG_PTR config, void * address, unsigned int nob);
typedef int (*DSERIAL_SETVAL) (DSERIAL_CONFIG_PTR config, int baudrate);

/* dSerial configuration specifics are hidden in here */
typedef struct DSERIAL_FUNCTIONS * DSERIAL_FUNCTIONS_PTR;
typedef struct DSERIAL_FUNCTIONS
{
  DSERIAL_CONTROL open;
  DSERIAL_CONTROL close;
  DSERIAL_IO      readOrReturn;
#if defined OBSOLETE
  DSERIAL_IO      readOrFail;
#endif
  DSERIAL_IO      readNB;
  DSERIAL_IO      write;
  DSERIAL_SETVAL  setBaud;
  DSERIAL_SETVAL  validBaud;
  DSERIAL_SETVAL  setStopBits;
  DSERIAL_CONTROL flushIn;
  DSERIAL_CONTROL flushOut;
  DSERIAL_CONTROL drain;

} DSERIAL_FUNCTIONS;

/* Main dSerial interface */
typedef struct DSERIAL_INTERFACE * DSERIAL_HANDLE;
typedef struct DSERIAL_INTERFACE
{
  DSERIAL_CONFIG    config;
  DSERIAL_FUNCTIONS functions;

} DSERIAL_INTERFACE;




/******************************************************************************/
/*									      */
/*	Defines and constants						      */
/*									      */
/******************************************************************************/
/* Status defines */
#define DSERIAL_STATE_INVALID		0
#define DSERIAL_STATE_CLOSED		1
#define DSERIAL_STATE_OPEN_NOT_OK	2
#define DSERIAL_STATE_OPEN_OK		3

/* RS232 device types */
#define DSERIAL_TYPE_NONE		0
#define DSERIAL_TYPE_TERMIOS		1
#define DSERIAL_TYPE_DRS232		2
#define DSERIAL_TYPE_WIN95		3
#define DSERIAL_TYPE_M3D		4
#define DSERIAL_TYPE_ASO		5

/* Blocking modes */
#define DSERIAL_BLOCK_MODE_NONE    	0
#define DSERIAL_BLOCK_MODE_BLOCK_FAIL  	1
#define DSERIAL_BLOCK_MODE_BLOCK_RETURN 2
#define DSERIAL_BLOCK_MODE_NONBLOCK	3

/* Open modes */
#define DSERIAL_MODE_NONE		0
#define DSERIAL_MODE_READ		1
#define DSERIAL_MODE_WRITE		2
#define DSERIAL_MODE_NDELAY		4

#define DSERIAL_MODE_READ_WRITE	(DSERIAL_MODE_READ | DSERIAL_MODE_WRITE)

/******************************************************************************/
/*									      */
/*	Function prototypes						      */
/*									      */
/******************************************************************************/
DSERIAL_EXPORT DSERIAL_HANDLE dserial_init                (void);
DSERIAL_EXPORT int            dserial_free                (DSERIAL_HANDLE handle);
DSERIAL_EXPORT void           dserial_setupType           (DSERIAL_HANDLE handle, char * filename, int mode);
DSERIAL_EXPORT int            dserial_open                (DSERIAL_HANDLE handle);
DSERIAL_EXPORT int            dserial_close               (DSERIAL_HANDLE handle);
DSERIAL_EXPORT int            dserial_readOrReturn        (DSERIAL_HANDLE handle, void * address, unsigned int nob);
DSERIAL_EXPORT int            dserial_readOrReturnRetry   (DSERIAL_HANDLE handle, void * address, unsigned int nob, unsigned int maxRetry);
#if defined OBSOLETE
DSERIAL_EXPORT int            dserial_readOrFail          (DSERIAL_HANDLE handle, void * address, unsigned int nob);
#endif
DSERIAL_EXPORT int            dserial_readNB              (DSERIAL_HANDLE handle, void * address, unsigned int nob);
DSERIAL_EXPORT int            dserial_write               (DSERIAL_HANDLE handle, void * address, unsigned int nob);
DSERIAL_EXPORT int            dserial_setBaud             (DSERIAL_HANDLE handle, int baudrate);
DSERIAL_EXPORT int	      dserial_validBaud	          (DSERIAL_HANDLE handle, int baudrate);
DSERIAL_EXPORT int            dserial_setStopBits         (DSERIAL_HANDLE handle, int bits);
DSERIAL_EXPORT int            dserial_drain               (DSERIAL_HANDLE handle);
DSERIAL_EXPORT int	      dserial_writeAndDrain       (DSERIAL_HANDLE handle, void * address, unsigned int nob);
DSERIAL_EXPORT int            dserial_flushIn             (DSERIAL_HANDLE handle);
DSERIAL_EXPORT int            dserial_flushOut            (DSERIAL_HANDLE handle);
DSERIAL_EXPORT void           dserial_powerOn             (DSERIAL_HANDLE handle);
DSERIAL_EXPORT void           dserial_powerOff            (DSERIAL_HANDLE handle);
DSERIAL_EXPORT int            dserial_queryType           (DSERIAL_HANDLE handle);
DSERIAL_EXPORT char *         dserial_queryFilename       (DSERIAL_HANDLE handle);
DSERIAL_EXPORT int            dserial_queryBaudrate       (DSERIAL_HANDLE handle);
DSERIAL_EXPORT int            dserial_highestBaudrate     (DSERIAL_HANDLE handle);
DSERIAL_EXPORT int	      dserial_setTimeoutLatency   (DSERIAL_HANDLE handle, int usecs);
DSERIAL_EXPORT int            dserial_validPort		  (char * portName);

#if defined __cplusplus
}
#endif
#endif
