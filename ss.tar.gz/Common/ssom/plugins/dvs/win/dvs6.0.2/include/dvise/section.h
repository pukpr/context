/*
 *    PROJECT:
 *    SUBSYSTEM:
 *    MODULE:
 *
 *    File:         $RCSfile: section.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:07:57 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: section.h,v 1.1 2005/09/13 15:07:57 pukitepa Exp $
 *
 *    FUNCTION:
 *
 * Copyright (c) 1992 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */

/* Version Control */

#ifndef _SECTION_H
#define _SECTION_H
#ifdef __cplusplus
extern "C" {
#endif

#include <dvise/camera.h>
#include <dvise/dcitypes.h>
#include "ecatools.h"

/* PUBLIC TYPES =========================================*/

/* PUBLIC DEFINES =======================================*/

#define EC_SECTION_STATE_OFF 0
#define EC_SECTION_STATE_ON  1

#define EC_SECTION_ALIGNMENT_FREE 0
#define EC_SECTION_ALIGNMENT_X    1
#define EC_SECTION_ALIGNMENT_Y    2
#define EC_SECTION_ALIGNMENT_Z    3

#define EC_SECTION_CLIPPING_OFF 0
#define EC_SECTION_CLIPPING_ON  1

#define EC_SECTION_2DVIEW_OFF 0
#define EC_SECTION_2DVIEW_ON  1

#define EC_SECTION_CAPPING_OFF 0
#define EC_SECTION_CAPPING_ON  1

#define EC_SECTION_INVERT_NORMAL 0
#define EC_SECTION_INVERT_INVERT 1

#define EC_SECTION_VISUALS_SOLID 0
#define EC_SECTION_VISUALS_NONE  1

#define EC_SECTION_2ND_INDEPENDENT_NO  0
#define EC_SECTION_2ND_INDEPENDENT_YES 1
#define EC_SECTION_INTERSECT_ALL  0xffffffff
#define EC_SECTION_INTERSECT_NONE 0x00000000
#define CROSS_SIZE 15


/* PUBLIC VARIABLES ======================================*/

/* PUBLIC FUNCTIONS ======================================*/

DV_EXPORT int ECSection_ToVC(ECAssembly *);
DV_EXPORT int ECSection_VCDelete(ECAssembly *);
DV_EXPORT int ECSection_Enable(ECAssembly *);
DV_EXPORT int ECSection_Disable(ECAssembly *);
DV_EXPORT int ECSection_SynchroniseState(ECAssembly *);
DV_EXPORT int ECSection_2DEnable(ECAssembly *);
DV_EXPORT int ECSection_2DDisable(ECAssembly *);
DV_EXPORT int ECSection_SetRelPos(ECAssembly *section,ECAssembly *parent,dmPoint SAbsPt1,dmPoint SAbsPt2,VCBody *body);
DV_EXPORT int ECSection_SetRelPosfromTri(ECAssembly *section,ECAssembly *parent,dmPoint SAbsPt1,dmPoint SAbsPt2,dmPoint SAbsPt3,VCBody *body);
DV_EXPORT int ECSection_Save(char *);
DV_EXPORT int ECSection_GuiUp(void);
DV_EXPORT int ECSection_GuiDown(void);
DV_EXPORT ECUserData *FindOrCreateUserData(ECAssembly *section, const char * const name);
DV_EXPORT VCSectionData *ECSection_GetVCData(ECAssembly *section);


#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /* _SECTION_H */
