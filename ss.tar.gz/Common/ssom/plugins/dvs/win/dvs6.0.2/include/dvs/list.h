/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1994 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS 2.1
--  Module       : Audio support library
--  Object Name  : $RCSfile: list.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : $Date: 2005/09/13 15:08:03 $
--  Author       : $Author: pukitepa $
--
--  Description	
--	Simple list based table
--
--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __LIST_H__
#define __LIST_H__

/*
 * ------------------------------------------------------------
 * 
 * An abstract data type for lists.
 *
 * ------------------------------------------------------------
 */

struct _ListTable;
  
typedef struct _ListTable *ListTable;
typedef void              *ListKey;
typedef void              *ListData;
typedef void              *ListIter;

/*
 * ------------------------------------------------------------
 *
 * Function pointer typedefs.
 *
 * ListTotalOrder : an ordering relation on keys.
 * ListEquiv      : an equivalence relation on keys.
 * ListCopy       : an assignemnt function on data.  Copies its
 *                  argument into a dynamically allocated object
 *                  and returns a pointer to that object.
 * ListExtractKey : a key extraction function.  Returns a pointer
 *                  to the part of the data used as the primary
 *                  key.
 * ListFree       : a function to free dynamically allocated data
 * ListMapFunc    : a mapping function.  The SLMap function calls
 *                  this for each item in the table.
 * 
 * ------------------------------------------------------------
 */

typedef int      (*ListTotalOrder)(ListKey, ListKey);
typedef int      (*ListEquiv)(ListKey, ListKey);
typedef ListData (*ListCopy)(ListData);
typedef ListKey  (*ListExtractKey)(ListData);
typedef void     (*ListFree)(void *);
typedef void     (*ListMapFunc)(ListData);

/*
 * ------------------------------------------------------------
 *
 * Table functions
 *
 * ListNewTable   : create a new table
 * ListDeleteAll  : delete all data in a table
 * ListAnihilate  : delete all data in table and the table itself
 * ListAdd        : add an item to the table, if the item already
 *                  exists then zero is returned
 * ListUpdate     : update an entry in the table,  if an entry 
 *                  exists with the same key then update the entry
 *                  otherwise a new entry is put into the table
 * ListDelete     : delete an entry from the table.
 * ListFind       : find the data which matches the key value,
 *                  return NULL if no successful match.
 * ListIterate    : create an iterator for a table.
 * ListNext       : returns an element of the table that has not
 *                  been returned in this iteration.  Returns null
 *                  at the end of the iteration.
 * ListEndIterate : terminate the iterator.
 * ListMap        : apply the map function to each element of the 
 *                  table.  Should really be an in-order traversal
 *                  but it ain't right now.
 *
 * ------------------------------------------------------------
 */

ListTable ListNewTable(ListCopy       dataCopy, 
                       ListFree       dataFree, 
                       ListExtractKey extractKey, 
                       ListTotalOrder lt, 
                       ListEquiv      eq);
void     ListDeleteAll(ListTable);
void     ListAnihilate(ListTable);
int      ListAdd(ListTable, ListData);
int      ListUpdate(ListTable, ListData);
int      ListDelete(ListTable, ListKey);
ListData ListFind(ListTable, ListKey);
ListIter ListIterate(ListTable);
ListData ListNext(ListTable, ListIter);
void     ListEndIterate(ListIter);
void     ListMap(ListTable t, ListMapFunc f);

#endif /* __LIST_H__ */

