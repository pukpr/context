/***************************************************************************
 *
 *    PROJECT:      dVS
 *    SUBSYSTEM:    VC Toolkit.
 *    MODULE:       VC Type definitions.
 *
 ***************************************************************************
 *
 *    File:         $RCSfile: vctypes.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:08:08 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: vctypes.h,v 1.1 2005/09/13 15:08:08 pukitepa Exp $
 *
 *    FUNCTION:
 *
 *
 *
 **************************************************************************
 *                                                                        *
 * Copyright (c) 1992 Division Ltd.                                       *
 *                                                                        *
 * All Rights Reserved.                                                   *
 *                                                                        *
 * This Document may not, in whole  or in part, be copied, photocopied,   *
 * reproduced, translated,  or  reduced  to  any  electronic  medium or   *
 * machine readable  form without  prior written  consent from Division   *
 * Ltd.                                                                   *
 *                                                                        *
 *************************************************************************/

#ifndef	_VCTYPES_H	
#define	_VCTYPES_H

typedef struct VCActorResource			VCActorResource;
typedef struct VCBody 		 	 	VCBody;
typedef struct VCEntity			 	VCEntity;
typedef struct VCAttribute 		 	VCAttribute;
typedef struct VCCollision			VCCollision; 
typedef struct VCIntersection			VCIntersection; 
typedef struct VCMaterial			VCMaterial; 
typedef struct VCCollisionSet			VCCollisionSet; 
typedef struct VCCollisionRequestState		VCCollisionRequestState; 
typedef struct VCCollisionRequestReport		VCCollisionRequestReport; 
typedef struct VCCollisionRequest		VCCollisionRequest; 
typedef struct VCSearchPath			VCSearchPath; 
typedef struct VCRadiator			VCRadiator; 
typedef struct VCXWindowId			VCXWindowId; 
typedef struct VCWindow				VCWindow; 
typedef struct VCVisualViewResource		VCVisualViewResource;
typedef struct VCVisualSourceResource		VCVisualSourceResource; 
typedef struct VCPseudoGravity			VCPseudoGravity; 
typedef struct VCVisualBoundingBox		VCVisualBoundingBox;
typedef struct VCSectionBounds		VCSectionBounds;
typedef struct VCTexture			VCTexture; 
typedef struct VCTextureImage			VCTextureImage; 
typedef struct VCVisualScreenDump		VCVisualScreenDump;
typedef struct VCSectionImageSave		VCSectionImageSave;
typedef struct VCAudioRecord			VCAudioRecord; 
typedef struct VCRamp				VCRamp; 
typedef struct VCInput				VCInput; 
typedef struct VCPosition			VCPosition; 
typedef struct VCTracker			VCTracker; 
typedef struct VCSync				VCSync; 
typedef struct VCMonitor			VCCollideMonitor; 
typedef struct VCMonitor			VCTrackerMonitor; 
typedef struct VCMonitor			VCVisualMonitor; 
typedef struct VCDynamicVisual  		VCDynamicVisual;
typedef struct VCLod            		VCLod;
typedef struct VCGeogroup       		VCGeogroup;
typedef struct VCGeometry        		VCGeometry;
typedef struct VCConnectionList  		VCConnectionList;


typedef struct VCCollisionReport_Traverse	VCCollisionReport_Traverse;
typedef struct VCIntersectionReport_Traverse	VCIntersectionReport_Traverse;
typedef struct VCEntity_Traverse  	 	VCEntity_Traverse;
typedef struct VCActorConfig 		 	VCActorConfig;
typedef struct VCEntity_AttributeTraverse	VCEntity_AttributeTraverse;
typedef struct VCAttribute_EntityTraverse	VCAttribute_EntityTraverse;

typedef struct VCBody_Traverse			VCBody_Traverse;
typedef struct VCBody_AttributeTraverse		VCBody_AttributeTraverse;
typedef struct VCVisualView_Traverse		VCVisualView_Traverse;
typedef struct VCUserDataList		 	VCUserDataList;

typedef struct VCCallbackFunctions	 	VCCallbackFunctions;
typedef struct VCActorResource_CallbackData	VCActorResource_CallbackData;
typedef struct VCBodyCreate_CallbackData      	VCBodyCreate_CallbackData;
typedef struct VCBodyDelete_CallbackData      	VCBodyDelete_CallbackData;
typedef struct VCBodyInput_CallbackData      	VCBodyInput_CallbackData;
typedef struct VCBodyScreenIntersection_CallbackData     VCBodyScreenIntersection_CallbackData;
typedef struct VCBodyCollision_CallbackData      VCBodyCollision_CallbackData;
typedef struct VCBodyAttribute_CallbackData	 VCBodyAttribute_CallbackData;
typedef struct VCBodyPartCreate_CallbackData	 VCBodyPartCreate_CallbackData;
typedef struct VCBodyPartDelete_CallbackData 	 VCBodyPartDelete_CallbackData;

typedef struct VLSystemHandleEvent		 VCSystemHandle_CallbackData;
typedef struct VLSignalEvent			 VCSignal_CallbackData;
typedef struct VLStreamEvent			 VCStream_CallbackData;
typedef struct VLFileEvent			 VCFile_CallbackData;
typedef struct VCResourceAllocate_CallbackData	 VCResourceAllocate_CallbackData;
typedef struct VCCollision_CallbackData	 	 VCCollision_CallbackData;
typedef struct VCIntersection_CallbackData	 VCIntersection_CallbackData;
typedef struct VCMaterial_CallbackData		 VCMaterial_CallbackData;
typedef struct VCCollisionSet_CallbackData	 VCCollisionSet_CallbackData;
typedef struct VCCollisionRequestState_CallbackData	 VCCollisionRequestState_CallbackData;
typedef struct VCCollisionRequestReport_CallbackData	 VCCollisionRequestReport_CallbackData;
typedef struct VCCollisionRequest_CallbackData	 VCCollisionRequest_CallbackData;
typedef struct VCSearchPath_CallbackData	 VCSearchPath_CallbackData;
typedef struct VCRadiator_CallbackData		 VCRadiator_CallbackData;
typedef struct VCXWindowId_CallbackData		 VCXWindowId_CallbackData;
typedef struct VCWindow_CallbackData		 VCWindow_CallbackData;
typedef struct VCVisualViewResource_CallbackData VCVisualViewResource_CallbackData;
typedef struct VCVisualSourceResource_CallbackData VCVisualSourceResource_CallbackData;
typedef struct VCPseudoGravity_CallbackData	 VCPseudoGravity_CallbackData;
typedef struct VCPosition_CallbackData		 VCPosition_CallbackData;
typedef struct VCTracker_CallbackData		 VCTracker_CallbackData;
typedef struct VCSync_CallbackData		 VCSync_CallbackData;
typedef struct VCCollideMonitor_CallbackData	 VCCollideMonitor_CallbackData;
typedef struct VCTrackerMonitor_CallbackData	 VCTrackerMonitor_CallbackData;
typedef struct VCVisualMonitor_CallbackData	 VCVisualMonitor_CallbackData;
typedef struct VCTexture_CallbackData		 VCTexture_CallbackData;
typedef struct VCVisualBoundingBox_CallbackData	 VCVisualBoundingBox_CallbackData;
typedef struct VCSectionBounds_CallbackData	 VCSectionBounds_CallbackData;
typedef struct VCTextureImage_CallbackData	 VCTextureImage_CallbackData;
typedef struct VCVisualScreenDump_CallbackData	 VCVisualScreenDump_CallbackData;
typedef struct VCSectionImageSave_CallbackData	 VCSectionImageSave_CallbackData;
typedef struct VCAudioRecord_CallbackData	 VCAudioRecord_CallbackData;
typedef struct VCRamp_CallbackData		 VCRamp_CallbackData;
typedef struct VCInput_CallbackData      	 VCInput_CallbackData;
typedef struct VCInput_UpdateCallbackData   	 VCInput_UpdateCallbackData;
typedef struct VCAttribute_CallbackData	 	 VCAttribute_CallbackData;
typedef struct VCEntityRelocate_CallbackData	 VCEntityRelocate_CallbackData;
typedef struct VCEntityInvalid_CallbackData	 VCEntityInvalid_CallbackData;
typedef struct VCAttributeRelocate_CallbackData	 VCAttributeRelocate_CallbackData;
typedef struct VCEntityAttribute_CallbackData    VCAttributeInvalid_CallbackData;
typedef struct VCEntityAttribute_CallbackData    VCEntityAttribute_CallbackData;
typedef struct VCEntityDrop_CallbackData	 VCEntityDrop_CallbackData;
/* Hoppy, 11/07/98 */
/* XXX Need this */
typedef struct VCEntityDeselect_CallbackData	 VCEntityDeselect_CallbackData;
typedef struct VCEntityIntersection_CallbackData VCEntityIntersection_CallbackData;
typedef struct VCEntityDelete_CallbackData	 VCEntityDelete_CallbackData;
typedef struct VCTimer_CallbackData		 VCTimer_CallbackData;
typedef struct VCExit_CallbackData		 VCExit_CallbackData;
typedef struct VCGroup_CallbackData		 VCGroup_CallbackData;
typedef float32 VCSpecular[4];

/*
 * function types for general callback routines
 */

typedef void (*VC_SystemHandleFunc) (VCSystemHandle_CallbackData *callbackdata, void *data);
typedef void (*VC_SignalFunc) (VCSignal_CallbackData *callbackData, void *data);
typedef void (*VC_ExitFunc) (VCExit_CallbackData *callbackData, void *data);
typedef void (*VC_GroupFunc) (VCGroup_CallbackData *callbackData, void *data);
typedef void (*VC_StreamFunc) (VCStream_CallbackData *streamData, void *data);
typedef void (*VC_FileFunc) (VCFile_CallbackData *fileData, void *data);
typedef void (*VC_CallbackFunc) (VLInstanceEvent *instanceData, void *data);

/*
 * function types for body routines
 */

typedef void (*VC_VersionFunc)			(FILE *fp);
typedef void (*VCActorResource_Func)		(VCActorResource_CallbackData *callbackData, void *data);
typedef void (*VCBody_CreateFunc)	  	(VCBodyCreate_CallbackData *bodyData, void *data);
typedef void (*VCBody_DeleteFunc)	  	(VCBodyDelete_CallbackData *bodyData, void *data);
typedef void (*VCBody_CreateBodyPartFunc)	(VCBodyPartCreate_CallbackData *callbackData, void *data);
typedef void (*VCBody_DeleteBodyPartFunc)	(VCBodyPartDelete_CallbackData *callbackData, void *data);
typedef void (*VCBody_AttributeFunc)		(VCBodyAttribute_CallbackData *callbackData, void *data);
typedef void (*VCBody_InputFunc)   		(VCBodyInput_CallbackData *callbackData, void *data);
typedef void (*VCBody_ScreenIntersectionFunc) 	(VCBodyScreenIntersection_CallbackData *callbackData, 
                                                 void *data);
typedef void (*VCBody_CollisionFunc)   		(VCBodyCollision_CallbackData *callbackData, void *data);
typedef void (*VCEntity_DropFunc)	 	(VCEntityDrop_CallbackData *callbackData, void *data);
/* Hoppy, 11/07/98 */
/* Need this */
typedef void (*VCEntity_DeselectFunc)	 	(VCEntityDeselect_CallbackData *callbackData, void *data);

typedef void (*VCEntity_IntersectionFunc)	(VCEntityIntersection_CallbackData *callbackData, void *data);
typedef void (*VCEntity_DeleteFunc)		(VCEntityDelete_CallbackData *callbackData, void *data);


/* 
 * function types for Resource routines
 */

typedef VCAttribute *(*VCResource_AllocateFunc)	(VCResourceAllocate_CallbackData *callbackData, void *data);

/*
 * function types for vchierarchy routines
 */

typedef	void	(*VCEntity_TraverseFunc) 	(VCEntity * entity, void *data);
typedef	int	(*VCEntity_TraverseTestFunc) 	(VCEntity * entity, void *data);
typedef void	(*VCEntity_Func)		(VCEntity *entity, int32 index, void *data);
typedef void	(*VCAttribute_Func)		(VCAttribute_CallbackData *attributeData, void *data);
typedef void	(*VCAttribute_RelocateFunc) 	(VCAttributeRelocate_CallbackData *entityData, void *data);
typedef void	(*VCEntity_RelocateFunc)    	(VCEntityRelocate_CallbackData *entityData, void *data);
typedef void	(*VCEntity_InvalidFunc)     	(VCEntityInvalid_CallbackData *entityData, void *data);
typedef void	(*VCEntity_AttributeFunc)   	(VCEntityAttribute_CallbackData *attributeData,  void *data);
typedef void	(*VCAttribute_InvalidFunc)  	(VCAttributeInvalid_CallbackData *atttributeData, void *data);
typedef void	(*VCCollision_Func)		(VCCollision_CallbackData *callbackData, void *data);
typedef void	(*VCIntersection_Func)		(VCIntersection_CallbackData *callbackData, void *data);
typedef void	(*VCMaterial_Func)		(VCMaterial_CallbackData *attributeData, void *data);
typedef void	(*VCCollisionSet_Func)		(VCCollisionSet_CallbackData *attributeData, void *data);
typedef void	(*VCCollisionRequestState_Func)	(VCCollisionRequestState_CallbackData *attributeData, void *data);
typedef void	(*VCCollisionRequestReport_Func) (VCCollisionRequestReport_CallbackData *attributeData, void *data);
typedef void	(*VCCollisionRequest_Func)	(VCCollisionRequest_CallbackData *attributeData, void *data);
typedef void	(*VCSearchPath_Func)		(VCSearchPath_CallbackData *attributeData, void *data);
typedef void	(*VCRadiator_Func)		(VCRadiator_CallbackData *attributeData, void *data);
typedef void	(*VCXWindowId_Func)		(VCXWindowId_CallbackData *attributeData, void *data);
typedef void	(*VCWindow_Func)		(VCWindow_CallbackData *attributeData, void *data);
typedef void	(*VCVisualViewResource_Func)	(VCVisualViewResource_CallbackData *attributeData, void *data);
typedef void	(*VCVisualSourceResource_Func)	(VCVisualSourceResource_CallbackData *attributeData, void *data);
typedef void	(*VCPseudoGravity_Func)		(VCPseudoGravity_CallbackData *attributeData, void *data);
typedef void	(*VCPosition_Func)		(VCPosition_CallbackData *attributeData, void *data);
typedef void	(*VCTracker_Func)		(VCTracker_CallbackData *attributeData, void *data);
typedef void	(*VCSync_Func)			(VCSync_CallbackData *attributeData, void *data);
typedef void	(*VCCollideMonitor_Func)	(VCCollideMonitor_CallbackData *attributeData, void *data);
typedef void	(*VCTrackerMonitor_Func)	(VCTrackerMonitor_CallbackData *attributeData, void *data);
typedef void	(*VCVisualMonitor_Func)		(VCVisualMonitor_CallbackData *attributeData, void *data);
typedef void	(*VCInput_Func)			(VCInput_CallbackData *attributeData, void *data);
typedef void	(*VCInput_UpdateFunc)		(VCInput_UpdateCallbackData *attributeData, void *data);
typedef void	(*VCTexture_Func)		(VCTexture_CallbackData *callbackData, void *data);
typedef void	(*VCVisualBoundingBox_Func)	(VCVisualBoundingBox_CallbackData *callbackData, void *data);
typedef void	(*VCSectionBounds_Func)	(VCSectionBounds_CallbackData *callbackData, void *data);
typedef void	(*VCTextureImage_Func)		(VCTextureImage_CallbackData *callbackData, void *data);
typedef void	(*VCVisualScreenDump_Func)	(VCVisualScreenDump_CallbackData *callbackData, void *data);
typedef void	(*VCSectionImageSave_Func)	(VCSectionImageSave_CallbackData *callbackData, void *data);
typedef void	(*VCAudioRecord_Func)		(VCAudioRecord_CallbackData *callbackData, void *data);
typedef void	(*VCRamp_Func)			(VCRamp_CallbackData *callbakData, void *data);
typedef void	(*VCTimer_Func)			(VCTimer_CallbackData *callbackData, void *data);
typedef void	(*VCAttributeDeleteFunc)	(VCAttribute *attribute);

typedef int (*VCCallback_QueryFunc) (void *callbackQueryData, void *systemData, void *callbackData);


#endif	
