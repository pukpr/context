/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: vwtypes.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:08:16 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: vwtypes.h,v 1.1 2005/09/13 15:08:16 pukitepa Exp $
 *
 *    FUNCTION: Generic widget types & enumeration.
 *
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _Types_H
#define _Types_H
#ifdef __cplusplus
extern "C" {
#endif


#include <dvs/vc.h>
#include <float.h>
#include <string.h>
#include <stdarg.h>
#include <memory.h>

#ifndef VW_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `VW_EXPORT'
 */
#ifdef  _LIB_VW
#define VW_EXPORT __declspec(dllexport) extern
#else
#define VW_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define VW_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ifndef VC_EXPORT */

/* PUBLIC DEFINES =======================================*/

#ifndef FALSE
#define FALSE 0
#define TRUE (!FALSE)
#endif

#define VW_OK 1
#define VW_ERROR 0

    
#define VW_RESOURCES_CORE 1000
#define VW_RESOURCES_LABEL 1200
#define VW_RESOURCES_BUTTON 1300
#define VW_RESOURCES_TOGGLE 1400
#define VW_RESOURCES_COMPOSITE 2000
#define VW_RESOURCES_VALUE 2100
#define VW_RESOURCES_SCALAR 2200
#define VW_RESOURCES_DIAL 2300
#define VW_RESOURCES_TUNER 2350
#define VW_RESOURCES_DIGIT 2400
#define VW_RESOURCES_ORIENT 2500
#define VW_RESOURCES_BOUND 2600
#define VW_RESOURCES_VOL 2700
#define VW_RESOURCES_AXLE 2800
#define VW_RESOURCES_CONSTRAINT 5000
#define VW_RESOURCES_FRAME 5100
#define VW_RESOURCES_RADIO 5200
#define VW_RESOURCES_ROWCOL 5300
#define VW_RESOURCES_MSGBOX 5400
#define VW_RESOURCES_SHELL 5500
#define VW_RESOURCES_FORM 5600
#define VW_RESOURCES_SCROLL 5700
#define VW_RESOURCES_SCROLL2 5800
#define VW_RESOURCES_TAPE 5900
#define VW_RESOURCES_TEXT 6000
#define VW_RESOURCES_CIRCLE 6100
    
/* Standard geometry paths for all widget geometry */
#define VW_AUDIO_PATH "widgets/"
#define VW_GEOMETRY_PATH "widgets/"
#define ICON_GEOMETRY_PATH "toolbox/icons/"
#define TEXT_GEOMETRY_PATH "toolbox/text/"
#define TB_GEOMETRY_PATH "toolbox/misc/"

#define VW_AUDIO_GAIN 1.0
#define VW_AUDIO_PRIORITY 50
#define VW_AUDIO_VELOCITY 100

#define VW_MAX_FRAME_ATTRIBUTES 6
#define VW_NULL_MASK 0
#define VW_CLEAR_MASK 0xffffffff
#define VW_VC_INTERSECT_MASK 0xffffffff
#define VW_DYNAMIC_NULL 0
#define VW_MAX_COLLISIONS 10
#ifdef VW_CREATE_MANAGED
#define VW_CREATE_VISIBLE_MASK VC_VISIBLE
#else
#define VW_CREATE_VISIBLE_MASK VW_NULL_MASK
#endif


/* Debugging flags used throughout the widget code */
#define VW_DEBUG_LOW 0x8000
#define VW_DEBUG_MED 0x4000

/* Global scale for the whole widget world */

#define VW_GLOBAL_SCALE 0.0254
/*
 * VW_BIZICON_SCALE is the constant that the
 * icons need to be scaled by to make them fit
 * onto a button nicely.
 */
#define VW_BIZICON_SCALE 0.8

/* The standard scale of each widget */
#define VW_STD_X 0.06
#define VW_STD_Y 0.045
#define VW_STD_Z 0.02

/* The standard width of a BIZICON */
#define VW_BIZICON_X_DIFF 1.0 * VW_GLOBAL_SCALE

/* The standard spacing between widgets */
#define VW_SP_X 0.025
#define VW_SP_Y 0.025

/* The distance an icon is raised above a button */
#define VW_ICON_LIFT 0.005

/* The standard scale of an icon */
#define VW_STD_IRX (VW_BIZICON_SCALE)
#define VW_STD_IRY (VW_BIZICON_SCALE)
#define VW_STD_IRZ (VW_BIZICON_SCALE)


/* The default scale of a scalar widget */
#define VW_STD_SCALAR_WIDTH VW_STD_X
#define VW_STD_SCALAR_LENGTH 5*VW_STD_Y

/* PUBLIC TYPES =========================================*/

typedef struct _VWidget VWidget;
typedef struct _VWBody VWBody;
typedef struct _VWLimits VWLimits;
typedef struct _VWidgetList VWidgetList;
typedef struct _VWEventInfo VWEventInfo;
typedef void VWCallback(VWidget *, VWEventInfo *, void *);
typedef struct _VWCallbackList VWCallbackList;
typedef char * VWtWidgetType;
typedef struct {
        int              type;		/* type of event */
        void             *data;		/* event information */
} VWArg;
typedef struct _VWEvent VWEvent;

typedef enum _VWtIconPositionPolicy {
    VWcIconCentered = 0, 
    VWcIconSurfaced
} VWtIconPositionPolicy;


/* 
 * Widget audio defines
 */
#define VW_AUDIO_DISABLED	0 
#define VW_AUDIO_ENABLED	1

#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /*_Types_H */
