/*
** ----------------------------------------------------------------------------
**
**  			Copyright (c) 1997 Division Limited.
**			      All Rights Reserved
**
**           This Document may not, in whole or in part, be copied,
**           photocopied, reproduced, translated, or reduced to any
**           electronic medium or machine readable form without prior
**           written consent from Division Ltd.
**
**
**  System       : dVISE
**  Module       : EC
**  File         : $RCSfile: eclicense.h,v $
**  Revision     : $Revision: 1.1 $
**  Date         : 14 January 1997
**  Author       : Tony Coombes
**
**  Description	 : License management
**
**  Modified     : 
**    $Log: eclicense.h,v $
**    Revision 1.1  2005/09/13 15:07:53  pukitepa
**    init
**
**    Revision 1.9  1998/09/02 16:34:49  mark
**    Added support for the styling license.
**
**    Revision 1.8  1998/08/03 17:39:15  john
**    new licensing that allows licenses to be aquired for short periods of time
**    and then released
**
**    Revision 1.7  1997/11/13 15:39:18  mark
**    Licenses changes as per bug 4445
**
**    Revision 1.6  1997/09/04 12:41:30  rajini
**    *** empty log message ***
**
**    Revision 1.5  1997/08/28 14:16:36  mark
**    Added the section manager license
**
**    Revision 1.4  1997/05/01 09:01:07  clives
**    *** empty log message ***
**
**    Revision 1.3  1997/01/23 17:57:54  tony
**    *** empty log message ***
**
**    Revision 1.2  1997/01/21 21:18:17  tony
**    *** empty log message ***
**
**    Revision 1.1  1997/01/15 14:20:28  tony
**    Addition of License Manager
**
**
** ----------------------------------------------------------------------------
*/

#ifndef __ECLICENSE_H__
#define __ECLICENSE_H__

#ifdef __cplusplus
extern "C" {
#endif

#ifndef DV_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `DV_EXPORT'
 */
#ifdef  _LIB_DV
#define DV_EXPORT __declspec(dllexport) extern
#else
#define DV_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define DV_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ifndef DV_EXPORT */

typedef enum ECLicensedFeaturesEnum {
    EC_LCNS_NONE, 
    EC_LCNS_OBJECT_LIMIT,              /* dvise limits number of objects */
    EC_LCNS_INTERACTION,               /* dvise allows picking */
    EC_LCNS_SAVE_FILE,                 /* dvise allows file save (VDI, BMF, BGF, image etc.) */

    EC_LCNS_LANDMARK_VIEW,             /* view landmarks */
    EC_LCNS_LANDMARK_EDIT,             /* edit/create landmarks */
    EC_LCNS_ANNOTATION_VIEW,           /* view annotations */
    EC_LCNS_ANNOTATION_EDIT,           /* ... */
    EC_LCNS_ASSEMBLY_VIEW,             /* View assemblies with assembly manager */
    EC_LCNS_ASSEMBLY_EDIT,             /* Allow changes to hierarchy */

    EC_LCNS_ANIMATION_PLAY,            /* play animation property */
    EC_LCNS_ANIMATION_VIEW,            /* view animation property */
    EC_LCNS_ANIMATION_EDIT,
    EC_LCNS_AUDIO_VIEW,                /* view audio property */
    EC_LCNS_AUDIO_EDIT,
    EC_LCNS_BASE_VIEW,                 /* view base property */
    EC_LCNS_BASE_EDIT,
    EC_LCNS_BEHAVIOR_PLAY,             /* play behavior property */
    EC_LCNS_BEHAVIOR_VIEW,             /* view behavior property */
    EC_LCNS_BEHAVIOR_EDIT,
    EC_LCNS_COLLIDE_VIEW,              /* view collision property */
    EC_LCNS_COLLIDE_EDIT,
    EC_LCNS_CONSTRAINT_VIEW,           /* view constraints property */
    EC_LCNS_CONSTRAINT_EDIT,
    EC_LCNS_LIGHT_VIEW,                /* view light property */
    EC_LCNS_LIGHT_EDIT,                /* ... */
    EC_LCNS_VISUAL_VIEW,               /* view visual property */
    EC_LCNS_VISUAL_EDIT,               /* ... */
    EC_LCNS_USERDATA_VIEW,             /* view user data */
    EC_LCNS_USERDATA_EDIT,             /* edit/create user data */
    EC_LCNS_LIBRARY_VIEW,              /* view libraries */
    EC_LCNS_LIBRARY_EDIT,              /* edit libraries */
    
    EC_LCNS_TOOLBOX,                   /* dvise enables toolbox */
    EC_LCNS_MANIKIN,                   /* ??? */
    EC_LCNS_COLLABORATION,             /* agent enabled */
    EC_LCNS_IMMERSION,                 /* ??? */
    EC_LCNS_DPG,                       /* enables tools, free converters etc. built into dpg library. Any idea for a better name? */
    EC_LCNS_SECTION,                   /* section manager enabled */
    EC_LCNS_INTERFERENCE,              /* interference manager enabled */
    EC_LCNS_STYLING,                   /* styling enabled */

    /* Don't change the last entry! */
    EC_LCNS_FEATURES                   /* Number of licensed features */
    } ECLicensedFeaturesEnum;


DV_EXPORT void  ECLicense_Init(void);
DV_EXPORT void *ECLicense_GetState(ECLicensedFeaturesEnum feature);
DV_EXPORT const char *ECLicense_GetMessage(ECLicensedFeaturesEnum feature);
DV_EXPORT const char *ECLicense_GetKey(ECLicensedFeaturesEnum feature);
DV_EXPORT int	ECLicense_GetLicense(char *license);
DV_EXPORT void  ECLicense_FreeLicense(char *license);

#ifdef __cplusplus
}
#endif

#endif /* __ECLICENSE_H__ */
