/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: xdreset.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:08:27 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: xdreset.h,v 1.1 2005/09/13 15:08:27 pukitepa Exp $
 *
 *    FUNCTION:
 *
 * Copyright (c) 1994 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */

#ifndef _XDRESET_H
#define _XDRESET_H

#ifdef __cplusplus
extern "C" {
#endif

/* Version Control */

/* INCLUDES =================================================*/

#include <dsys/dreg.h>
#include "wkeys.h"
#include "xdcallbk.h"

/* DATA STRUCTURES ==========================================*/

/* FUNCTION PROTOTYPES ======================================*/

#ifdef __cplusplus
}
#endif

extern void XdReset_Setup(void);

extern void XdReset_StoreAll(void);
extern void XdReset_StoreBranch(void);
extern void XdReset_StoreAssembly(void);
extern void XdReset_RestorePositionAll(void);
extern void XdReset_RestorePositionBranch(void);
extern void XdReset_RestorePositionAssembly(void);
extern void XdReset_RestoreHierarchyAll(void);
extern void XdReset_RestoreHierarchyBranch(void);
extern void XdReset_RestoreHierarchyAssembly(void);

#endif /* _XDRESET_H__ */

