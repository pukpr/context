/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1996 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : XdVISE
--  Object Name  : $RCSfile: xdgrdwd.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : 12 November 1996
--  Author       : William Man
--
--  Description	 : Grid Widget
--
--  Modified     : 
--    $Log: xdgrdwd.h,v $
--    Revision 1.1  2005/09/13 15:08:23  pukitepa
--    init
--
--    Revision 1.1  1997/07/09 12:31:33  simon
--    *** empty log message ***
--
--    Revision 1.6  1997/04/01 16:49:47  tony
--    General fixes to problems highlighted by Insure
--
--    Revision 1.5  1997/02/21 18:32:04  wman
--    Bug Fixes
--    Also, Added rmb functions to frame manager dlg.
--
--    Revision 1.4  1997/02/13 17:03:52  wman
--    Added colour to frame manager
--
--    Revision 1.3  1996/12/06 18:09:26  wman
--    Key Frame additions - feedback from dVISE on selection on frames.
--    Bugs in external multiple selection and update fixed.
--
--    Revision 1.2  1996/11/22 16:29:20  wman
--    Updates to annimation dlg.
--
--    Revision 1.1  1996/11/19 18:52:08  wman
--    Animation grid widget installed
--
--
--
-- ----------------------------------------------------------------------------
*/

#ifndef __XDGRDWD_H__
#define __XDGRDWD_H__

#ifdef __cplusplus
extern "C" {
#endif


typedef struct gridWidgetT gridWidgetT; /* Prototype */

extern gridWidgetT *XdGridWidgetCreate(compT parent, int leftType, compT leftW, int rightType, 
                   compT rightW, int topType, compT topW, int bottomType, compT bottomW, 
		   int columns, char *title,
                   void(*selectionCB)(gridWidgetT *w, void *clientData, int row, int column), 
                   void(*deselectionCB)(gridWidgetT *w, void *clientData, int row, int column), 
		   void(*dfltActnCB)(gridWidgetT *w, void *clientData, int row, int column), 
                   void(*valueChangedCB)(gridWidgetT *w, void *clientData, int row, int column), 
		   void *clientData);
extern int XdGridWidgetAddColumn(gridWidgetT *grid, char *title, void *clientData);
extern void XdGridWidgetRemoveAllColumns(gridWidgetT *grid, void *clientData);
extern void XdGridWidgetDestroy(gridWidgetT *gridWidget);
extern void XdGridWidgetAddItem(gridWidgetT *gridWidget, int index, char *str);
extern void XdGridWidgetDeleteAllItems(gridWidgetT *gridWidget);
extern void XdGridWidgetSelectRow(gridWidgetT *grid, int row);
extern void XdGridWidgetDeselectRow(gridWidgetT *gridWidget, int row);
extern void XdGridWidgetSelectionCB(gridWidgetT *gridWidget, int row, int column);
extern void XdGridWidgetDeselectionCB(gridWidgetT *gridWidget, int row, int column);
extern void XdGridWidgetDefaultActionCB(gridWidgetT *gridWidget, int row, int column);
extern void XdGridWidgetValueChangedCB(gridWidgetT *gridWidget, int row, int column);
extern void XdGridWidgetSetRowColumnColour(gridWidgetT *gridWidget, int row, int column, char *colour);
extern compT XdGridWidget_GetGrid(gridWidgetT *grid);

#ifdef __cplusplus
}
#endif

#endif /* __XDGRDWD_H__ */
