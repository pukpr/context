/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: ecconst.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:07:52 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: ecconst.h,v 1.1 2005/09/13 15:07:52 pukitepa Exp $
 *
 *    FUNCTION: defines ECconst
 *
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */


/* PUBLIC DEFINES =======================================*/
#ifndef FALSE
#define FALSE 0
#define TRUE (!FALSE)
#endif

#define EC_STAR_NUMBER -9187345.12346f
 /* magic number which replaces the value '*' */

#define EC_NO_MIN FLT_MIN
#define EC_NO_MAX FLT_MAX

#define EC_DEFAULT_MIN 0.f
#define EC_DEFAULT_MAX 0.f

#define EC_NOW_VALUE -1324.57689 
/* key frames attributes applied as response to events whose 
 * start time is EC_NOW_VALUE 
 */

/* The default values of various ECStateTypes.
 *
 * Any attribute whose state value is ECStateUndefined should be interpreted
 * as having the state as defined below.
 */
#define ECDefaultAudioState ECStateOff
#define ECDefaultCollisionState ECStateOff
#define ECDefaultConstraintsState ECStateOn
#define ECDefaultSnapTransState ECStateOn
#define ECDefaultRenderMode ECRenderModePolygonal
#define ECDefaultBillBoardState ECStateOff
#define ECDefaultSnapTransState ECStateOn
#define ECDefaultSnapRotState ECStateOn
#define ECDefaultSnapScaleState ECStateOn

#define ECDefaultKeyFramesState ECStateOn
#define ECDefaultKeyFramesSpeedInterpState ECConstantImplicitInterpolation
#define ECDefaultKeyFramesPathInterpState ECLinearInterpolation
#define ECDefaultFrameSpeedInterpState ECConstantImplicitInterpolation
#define ECDefaultFramePathInterpState ECLinearInterpolation

#define ECDefaultLightState ECStateOn
#define ECDefaultToolsState ECStateOn
#define ECDefaultVisualState ECStateOn
#define ECDefaultLightType VC_LMODE_DIRECTIONAL

/* These events MUST match the list of names in event.c */
#define EC_EVENT_UNDEFINED 	 0
#define EC_EVENT_SYSTEM_BEGIN    1
#define EC_EVENT_SYSTEM_END      2
#define EC_EVENT_RESTART         3
#define EC_EVENT_TICK            4
#define EC_EVENT_USER1		 5
#define EC_EVENT_USER2		 6
#define EC_EVENT_PICK_PRESS      7
#define EC_EVENT_PICK_RELEASE    8
#define EC_EVENT_TOOLBOX_PRESS   9
#define EC_EVENT_TOOLBOX_RELEASE 10
#define EC_EVENT_KEY_PRESS       11
#define EC_EVENT_KEY_RELEASE     12
#define EC_EVENT_BODY_CREATE     13
#define EC_EVENT_BODY_DELETE     14
#define EC_EVENT_BODY_PART_CREATE 15
#define EC_EVENT_BODY_PART_DELETE 16
#define EC_EVENT_COLLIDE	 17
#define EC_EVENT_UNCOLLIDE	 18
#define EC_EVENT_DROP		 19
#define EC_EVENT_PICK		 20
#define EC_EVENT_TOUCH	         21
#define EC_EVENT_UNTOUCH	 22
#define EC_EVENT_MOVE            23
#define EC_EVENT_DRAG            24
#define EC_EVENT_XPICK           25
#define EC_EVENT_SELECT          26
#define EC_EVENT_DESELECT        27
#define EC_EVENT_HIGHLIGHT       28
#define EC_EVENT_UNHIGHLIGHT     29
#define EC_EVENT_CREATE          30
#define EC_EVENT_DELETE          31
#define EC_EVENT_UPDATE          32
#define EC_EVENT_ROLE_ENTER      33
#define EC_EVENT_ROLE_LEAVE      34
#define EC_EVENT_ENTER           35
#define EC_EVENT_LEAVE           36
#define EC_EVENT_LINK            37
#define EC_EVENT_UNLINK          38
#define EC_EVENT_LOAD            39
#define EC_EVENT_UNLOAD          40
#define EC_EVENT_ENABLE          41
#define EC_EVENT_DISABLE         42
#define EC_EVENT_RENAME          43
#define EC_EVENT_DO_FRAME        44
#define EC_EVENT_ACTIVATE        45
#define EC_EVENT_FLYTO           46
#define EC_EVENT_ARRIVED         47
#define EC_EVENT_DELETED         48
#define EC_EVENT_FLIGHTPATH      49
#define EC_EVENT_LOCAL_TICK      50
#define EC_EVENT_LINK_COMPLETE   51
#define EC_EVENT_UNLINK_COMPLETE 52
#define EC_EVENT_BODY_UPDATE     53
#define EC_EVENT_SUB_ENTER       54
#define EC_EVENT_SUB_LEAVE       55
#define EC_INTERNAL_EVENTS       56

#define EC_MAX_EVENT_NAME_LENGTH 50

/* 
#define EC_CONSTRAIN_ENABLE	0x80000000
#define EC_CONSTRAIN_MODE_MASK	0x7fffffff

#define EC_CONSTRAIN_NORMAL     0
#define EC_CONSTRAIN_HINGE_X	1
#define EC_CONSTRAIN_HINGE_Y	2
#define EC_CONSTRAIN_HINGE_Z	3
#define EC_LOCK_X_VAL     	0x00000001
#define EC_LOCK_Y_VAL     	0x00000002
#define EC_LOCK_Z_VAL     	0x00000004
#define EC_LOCK_X         	0x00000010
#define EC_LOCK_Y         	0x00000020
#define EC_LOCK_Z         	0x00000040
#define EC_LOCK_ROLL_VAL  	0x00000100
#define EC_LOCK_PITCH_VAL 	0x00000200
#define EC_LOCK_YAW_VAL   	0x00000400
#define EC_LOCK_ROLL      	0x00001000
#define EC_LOCK_PITCH     	0x00002000
#define EC_LOCK_YAW       	0x00004000
#define EC_LOCK_FIXED           0x00010000
#define EC_UNCONSTRAINED 0
*/

#define EC_NO_IO_ERROR 0
#define EC_SYNTAX_ERROR 1
#define EC_FILE_NOT_FOUND 2
#define EC_PREPROCESS_ERROR 3

#define EC_MPP_MAX_LINE_LENGTH 255
#define EC_MPP_FILENAME_LENGTH 150

/* Vector and colour are the same as we can't tell them apart in the
 * input file 
 */


/* Audio default values */
#define EC_AUDIO_DEFAULT_GAIN 		1.0f
#define EC_AUDIO_DEFAULT_LOOPS 		1
#define EC_AUDIO_DEFAULT_STATE 		ECStateOn
#define EC_AUDIO_DEFAULT_PRIORITY 	0

#define EC_MODE_UNDEFINED			0x80000000


#define EC_PLUGIN_MAJOR_VERSION	5
#define EC_PLUGIN_MINOR_VERSION 0

#define EC_DEFAULT_MATERIAL_LIBRARY_NAME "MaterialsLibrary"

/* PUBLIC TYPES =========================================*/


/* PUBLIC VARIABLES ======================================*/


/* PUBLIC FUNCTIONS ======================================*/


