/*
 *      PROJECT:
 *      SUBSYSTEM:
 *      MODULE:
 *
 *      FILE:           $RCSfile: ds.h,v $
 *      REVISION:       $Revision: 1.1 $
 *      Date:           $Date: 2005/09/13 15:07:42 $
 *      Author:         $Author: pukitepa $
 *      RCS Ident:      $Id: ds.h,v 1.1 2005/09/13 15:07:42 pukitepa Exp $
 *
 *      FUNCTION:
 *
 * Copyright (c) 1994, 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */

#ifndef _DS_H
#define _DS_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef DS_EXPORT
#if defined(_WIN32) && !defined(__EPP__) && !defined(BUILD_STATIC)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `extern'
 */
#ifdef  _LIB_DIVU
#define DS_EXPORT __declspec(dllexport) extern
#else
#define DS_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define DS_EXPORT  extern
#endif /* ! _WIN32 */
/*#define DS_EXPORT  extern*/
#endif /* ndef DS_EXPORT */

typedef struct
{
    char *string;
}DStringTraverseInfo;

DS_EXPORT void dsVersion(FILE *fp);
DS_EXPORT char *dStringFromOptions (char *string, int *size, char *name, ...);
DS_EXPORT char *dStringFirstString (char *string, DStringTraverseInfo *info);
DS_EXPORT char *dStringNextOption  (char *option, DStringTraverseInfo *info);


#define DS_END_OF_OPTIONS '\0'


#ifdef __cplusplus
}
#endif
#endif /*_DS_H */
