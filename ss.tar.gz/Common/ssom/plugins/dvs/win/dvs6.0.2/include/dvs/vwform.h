/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: vwform.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 2005/09/13 15:08:12 $
 *    Author:       $Author: pukitepa $
 *    RCS Ident:    $Id: vwform.h,v 1.1 2005/09/13 15:08:12 pukitepa Exp $
 *
 *    FUNCTION: Frame public function prototypes.
 * 
 * Copyright (c) 1996 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _VWForm_H
#define _VWForm_H
#ifdef __cplusplus
extern "C" {
#endif
#ifdef _dummyBrace_
}
#endif
/* INCLUDES ============================================== */
#include "vwidgets.h"
#include "vwborder.h"
/* PUBLIC FUNCTIONS ====================================== */

enum {
    VWrFormSize = VW_RESOURCES_FORM,
    VWrFormSashSize,
    VWrFormSashVisual,            
    VWrFormSashDisable,
    VWrFormSashHighlightVisual,        
    VWrFormSashMaterial,        
    VWrFormSashHighlightMaterial,
    VWrFormEnableResizeSash,
    VWrFormDontRedrawOnDrag,
    VWrFormRelativeSashSize,
    VWrFormUseRelativeSashSize,
    VWrFormAllowDepthPositioning,
    VWrFormUseBorder
};

VW_EXPORT VWidget *VWForm_CreateManaged(VWidget *Parent, char *name, VWArg args[], int argc);
VW_EXPORT VWidget *VWForm_Create(VWidget *Parent, char *name, VWArg args[], int argc);
VW_EXPORT void VWForm_ManageSash(VWidget *FormWig);
VW_EXPORT void VWForm_UnmanageSash(VWidget *FormWig);
VW_EXPORT void VWForm_DisableRedrawChildren(VWidget *FormWig);
VW_EXPORT void VWForm_EnableRedrawChildren(VWidget *FormWig);

#ifdef _dummyBrace_
{
#endif
#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /*_VWForm_H */
