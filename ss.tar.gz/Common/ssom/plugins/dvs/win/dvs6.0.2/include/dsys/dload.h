/******************************************************************************/
/*									      */
/*	######    ###   #     #   ###    #####    ###   ####### #     #	      */
/*	#     #    #    #     #    #    #     #    #    #     # ##    #	      */
/*	#     #    #    #     #    #    #          #    #     # # #   #	      */
/*	#     #    #    #     #    #     #####     #    #     # #  #  #	      */
/*	#     #    #     #   #     #          #    #    #     # #   # #	      */
/*	#     #    #      # #      #    #     #    #    #     # #    ##	      */
/*	######    ###      #      ###    #####    ###   ####### #     #	      */
/*									      */
/*			   #     #####   #####   #####			      */
/*			  ##    #     # #     # #     #			      */
/*			 # #    #     # #     # #			      */
/*			   #     ######  ###### ######			      */
/*			   #          #       # #     #			      */
/*			   #    #     # #     # #     #			      */
/*			 #####   #####   #####   #####			      */
/*									      */
/* 		Copyright (c) Division Limited. All rights reserved	      */
/*									      */
/* This Document may not, in whole or in part, be copied, photocopied,	      */
/* reproduced, translated, or reduced to any electronic medium or machine     */
/* readable form without prior written consent from Division Ltd.	      */
/*									      */
/******************************************************************************/

#if !defined _DLOAD_H_
#define _DLOAD_H_


#if defined __cplusplus
extern "C" {
#endif 

#if defined _WIN32 && !defined __EPP__ && !defined(BUILD_STATIC)
/*
 * only  Windoze needs this baroque construct.
 * On sensible systems simply use `extern'
 */
#if defined _LIB_DIVU
#define DLOAD_EXPORT __declspec(dllexport) extern
#else
#define DLOAD_EXPORT __declspec(dllimport) extern
#endif /* _LIB_DIVU */
#else
#define DLOAD_EXPORT extern
#endif /* WIN32 */

#if defined _UNIX
#if defined _HPUX

#include <dl.h>

#else /* HPUX */

#include <dlfcn.h>

#endif /* HPUX */
#else /* UNIX */

#include <windows.h>
#include <stdio.h>

#endif /* UNIX */

/******************************************************************************/
/*									      */
/*	Typedefs and structures etc.					      */
/*									      */
/******************************************************************************/
typedef struct DLOAD_INTERFACE * DLOAD_HANDLE;
typedef struct DLOAD_INTERFACE
{
  char         libraryName [256];
  int          openFlags;
  int          openCount;
  DLOAD_HANDLE next;

#if defined _UNIX
#if defined _HPUX

  shl_t        libHandle;

#else /* _HPUX */

  void * libHandle;

#endif /* _HPUX */
#else /* UNIX */

  HMODULE	libHandle;

#endif /* _UNIX */

} DLOAD_INTERFACE;




/******************************************************************************/
/*									      */
/*	Defines								      */
/*									      */
/******************************************************************************/
#define DLOAD_HANDLE_SIZE (sizeof(DLOAD_INTERFACE))
#define DLOAD_VERSION_FUNCTION	"dloadVersionFunction"
#define DLOAD_VINFO_FUNCTION    "dloadVersionStringFunction"
#define DLOAD_TINFO_FUNCTION    "dloadLibraryTypeFunction"

#if defined _UNIX
#if defined _HPUX
  #define DLOAD_DEFAULT_MODE	BIND_DEFERRED

  #define DLOAD_OPEN(x,y,z)	shl_load(x,y,z)
  #define DLOAD_CLOSE(x)	shl_unload(x)

#else /* HPUX */
#ifdef _FREEBSD_2_2_2
  #define DLOAD_DEFAULT_MODE	1
#else
  #define DLOAD_DEFAULT_MODE	RTLD_LAZY
#endif
  #define DLOAD_OPEN(x,y,z)	dlopen(x,y)
  #define DLOAD_CLOSE(x)	dlclose(x)

#endif /* HPUX */
#else /* UNIX */
  #define DLOAD_DEFAULT_MODE	0


  #define DLOAD_OPEN(x,y,z)	LoadLibrary(x)
  #define DLOAD_CLOSE(x)	!FreeLibrary(x)

#endif /* UNIX */

/* Verbose stuff */
#define DLOAD_MODULE_NAME	"dload"
#define DLOAD_VERBOSE_OPEN	0x1
#define DLOAD_VERBOSE_CLOSE	0x2
#define DLOAD_VERBOSE_RESOLVE	0x4
#define DLOAD_VERBOSE_LIBINFO	0x8

/* DLOAD error codes */
#define DLOAD_ERROR_OK		0
#define DLOAD_ERROR_INVAL	1
#define DLOAD_ERROR_VERSION	2
#define DLOAD_ERROR_MEM		3
#define DLOAD_ERROR_OPEN	4
#define DLOAD_ERROR_NOT_FOUND	5
#define DLOAD_ERROR_CLOSE	6
#define DLOAD_ERROR_FUNC	7

/******************************************************************************/
/*									      */
/*	Function prototypes						      */
/*									      */
/******************************************************************************/
DLOAD_EXPORT void		dload_init			(void);
DLOAD_EXPORT DLOAD_HANDLE	dload_open			(char * libraryName, int * versionMajor, int * versionMinor);
DLOAD_EXPORT DLOAD_HANDLE	dload_searchingOpen		(char * libraryName, int * versionMajor, int * versionMinor);
DLOAD_EXPORT int		dload_close			(DLOAD_HANDLE handle);
DLOAD_EXPORT int		dload_functionAddress		(DLOAD_HANDLE handle, const char * symbol, void * address);
DLOAD_EXPORT char * 		dload_getLibraryVersionString	(DLOAD_HANDLE handle);
DLOAD_EXPORT char *		dload_getLibraryTypeString	(DLOAD_HANDLE handle);
DLOAD_EXPORT int		dload_getError			(void);

#if defined __cplusplus
}
#endif /* __cplusplus */
#endif /* DLOAD_H */
