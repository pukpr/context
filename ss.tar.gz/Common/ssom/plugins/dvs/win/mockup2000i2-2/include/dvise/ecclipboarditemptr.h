#include <stdio.h>
#include "ectypes.h"
#include "ecsmartptr.h"
#include "eciteminfo.h"
#ifndef _ECITEMPTR_H
#define _ECITEMPTR_H
class DV_EXPORT _ECClipBoardItem;

/* WMan - Removed
#define ECITEM_UPDATE_DELETE		0x00000001
#define ECITEM_UPDATE_MARKDELETED		0x00000002
#define ECITEM_UPDATE_UNDELETE		0x00000004
#define ECITEM_UPDATE_FUNCTIONALONLY	0x00000008
#define ECITEM_UPDATE_ADDATTRIBUTE		0x00000010
#define ECITEM_UPDATE_REMOVEATTRIBUTE	0x00000020
*/

typedef ECSmartPtr<_ECClipBoardItem> ECClipBoardItemPtr;
class DV_EXPORT _ECClipBoardItem: public _ECBaseItem
{
public:
    _ECClipBoardItem():m_item(NULL) {};
    ~_ECClipBoardItem();
    
    int getId(void) const;
    char *getIdString(void) const;

    static ECCallbackIterator attachGlobalCreateCallback(ecGlobalCallbackFunc func, void *data)
        {
            return _ECBaseItem::attachGlobalCreateCallback(getMyId(), func, data);
        }
    
    static ECCallbackIterator attachGlobalUpdateCallback(ecGlobalCallbackFunc func, void *data)
        {
            return _ECBaseItem::attachGlobalUpdateCallback(getMyId(), func, data);
        }
    
    static ECCallbackIterator attachGlobalDeleteCallback(ecGlobalCallbackFunc func, void *data)
        {
            return _ECBaseItem::attachGlobalDeleteCallback(getMyId(),func, data);
        }
    
    static void detachGlobalCreateCallback(ECCallbackIterator iter)
        {
            _ECBaseItem::detachGlobalCreateCallback(getMyId(), iter);
        }
    
    static void detachGlobalUpdateCallback(ECCallbackIterator iter)
        {
            _ECBaseItem::detachGlobalUpdateCallback(getMyId(), iter);
        }
    
    static void detachGlobalDeleteCallback(ECCallbackIterator iter)
        {
            _ECBaseItem::detachGlobalDeleteCallback(getMyId(),iter);
        }
    
    static int getMyId();
//JOHN    void callCallbacks(void) {
//JOHN        printf("IN ECITEM CAll CALLBACKS function\n");
//JOHN    }; //JOHN todo
    static _ECClipBoardItem *create() 
    {
        _ECClipBoardItem *newItem = new _ECClipBoardItem;
        newItem->_create(0);
        return newItem;
    };
    inline void setItem(ECItem *item) { m_item = item;}
    inline ECItem *getItem() { return m_item;}
private:
    ECItem 	*m_item;
// List of pointers to ECItemIte,
// Added list
//removed list
};



#endif
