/*
 *    PROJECT:      dvise
 *    SUBSYSTEM:    ec
 *    MODULE:
 *
 *    File:         $RCSfile: role.h,v $
 *    Revision:     $Revision: 1.8 $
 *    Date:         $Date: 1999/08/26 12:45:36 $
 *    Author:       $Author: jeff $
 *    RCS Ident:    $Id: role.h,v 1.8 1999/08/26 12:45:36 jeff Exp $
 *
 *    FUNCTION:
 *
 *
 *
 * Copyright (c) 1994 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */

#ifndef _ROLE_H
#define _ROLE_H

#include "dvexport.h"
#include "ectools.h"

#ifdef __cplusplus
extern "C" {
#endif


/* ========================= Role functions ========================= */

DV_EXPORT ECRole *ECRole_Allocate(void);
DV_EXPORT int32 ECRole_SetName(ECRole *, char *name);
DV_EXPORT char *ECRole_GetName(ECRole *);
DV_EXPORT ECItem *ECRole_GetItemList(ECRole *r);
DV_EXPORT ECItem **ECRole_GetItemListPtr(ECRole *r);
DV_EXPORT int32 ECRole_AddEventList(ECRole *role, ECEventList *el);
DV_EXPORT int32 ECRole_Destroy(ECRole *);
DV_EXPORT int32 ECRoleList_Destroy(ECRole *);
DV_EXPORT int32 ECRoleList_AddRole(ECRole *roleList, ECRole *role);
DV_EXPORT ECRole *ECRole_FindNamedInList(ECRole *role, char *name);
DV_EXPORT int32 ECRole_CopyDefined(ECRole *def, ECRole *newRole);
DV_EXPORT ECRole *ECRole_Copy(ECRole *from);
/* Allocate memory for a new ECRole and copy the information 
   from an existing structure into it */
DV_EXPORT int32 ECRole_ExtantCopy(ECRole *to, ECRole *from);
DV_EXPORT int32 ECRole_SetBodyPosition(ECRole *bodyInfo, dmPoint position);
DV_EXPORT int32 ECRole_SetBodyOrientation(ECRole *bodyInfo, dmEuler orientation);
DV_EXPORT int32 ECRole_SetBodyScale(ECRole *bodyInfo, dmScale scale);
DV_EXPORT int32 ECRole_SetBodyBackgroundColour(ECRole *bodyInfo,
					  ECColour *backgroundColour);
DV_EXPORT ECColour *ECRole_GetBodyBackgroundColour(ECRole *bodyInfo);
DV_EXPORT int32 ECRole_SetBodyNearClip(ECRole *bodyInfo, float32 nearClip);
DV_EXPORT float32 *ECRole_GetBodyNearClip(ECRole *bodyInfo);
DV_EXPORT int32 ECRole_SetBodyFarClip(ECRole *bodyInfo, float32 farClip);
DV_EXPORT float32 *ECRole_GetBodyFarClip(ECRole *bodyInfo);
DV_EXPORT int32 ECRole_SetBodyMinFly(ECRole *bodyInfo, float32 minFly);
DV_EXPORT float32 *ECRole_GetBodyMinFly(ECRole *bodyInfo);
DV_EXPORT int32 ECRole_SetBodyMaxFly(ECRole *bodyInfo, float32 maxFly);
DV_EXPORT float32 *ECRole_GetBodyMaxFly(ECRole *bodyInfo);
DV_EXPORT int32 ECArgReference_GetRole(ECArgReference *, ECRole **, ECItem *);
DV_EXPORT ECArgReference *ECArgReference_Copy(ECArgReference *old);
DV_EXPORT int32 ECRole_Enter(ECRole *, VCBody *);
DV_EXPORT int32 ECRole_Leave(ECRole *, VCBody *);


#ifdef __cplusplus
}
#endif

#endif /* _ROLE_H__ */
