/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: vgtools.h,v $
 *    Revision:     $Revision: 1.5 $
 *    Date:         $Date: 2000/05/08 17:41:58 $
 *    Author:       $Author: jeff $
 *    RCS Ident:    $Id: vgtools.h,v 1.5 2000/05/08 17:41:58 jeff Exp $
 *
 *    FUNCTION: Global include file for vwgizmos library
 * 
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _VG_TOOLS_H_
#define _VG_TOOLS_H_
#ifdef __cplusplus
extern "C" {
#endif
/* PUBLIC INCLUDES ========================================== */

#include <dvs/vwidgets.h>
#include "vgtypes.h"
#include <dvs/vc.h>
    
/* PUBLIC FUNCTIONS *************************************************/

/*
 * Version Control
 */

VG_EXPORT void vgVersion(FILE *);
/*
 * Standard VGizmo functions.
 */

VG_EXPORT VGizmo *VG_StartGizmo(VGType gizmoType, char *GizmoName, 
				VWidget *Parent, VGArg args[], int argc);
				
VG_EXPORT void VG_StopGizmo(VGizmo *thisGizmo);

VG_EXPORT void VG_ReStartGizmo(VGizmo *thisGizmo, char *GizmoName, 
				VWidget *Parent, VGArg args[], int argc);

VG_EXPORT void VGSetarg(VGArg *arg_ptr, int32 type, void *data);
VG_EXPORT int VGTokFromString(char *name, char *tokens[], int numtoks);


/*
 * Colour Gizmo Public Functions...
 */

VG_EXPORT void VGColourCreate(VGizmo *thisGizmo, VWidget *Parent, 
					VGArg arguments[], int32 n);
VG_EXPORT void VGColourReuse (VGizmo *thisGizmo, VWidget *Parent, 
					VGArg arguments[], int32 n);
VG_EXPORT void VGColourManage(VGizmo *thisGizmo);
VG_EXPORT void VGColourSetTitleBarIcon(VGizmo *thisGizmo, char *newIcon);
VG_EXPORT void VGColourGetColour(VGizmo *thisGizmo, VCColour colour);
VG_EXPORT float32 VGColourGetSpecular(VGizmo *thisGizmo);
VG_EXPORT void VGColourSetRValue(VGizmo *thisGizmo, float32 newValue);
VG_EXPORT void VGColourSetGValue(VGizmo *thisGizmo, float32 newValue);
VG_EXPORT void VGColourSetBValue(VGizmo *thisGizmo, float32 newValue);
VG_EXPORT void VGColourSetSValue(VGizmo *thisGizmo, float32 newValue);

/*
 * Test Gizmo Public Functions
 */
VG_EXPORT void VGTestCreate(VGizmo *thisGizmo, VWidget *Parent, 
					VGArg arguments[], int32 n);
VG_EXPORT void VGTestReuse (VGizmo *thisGizmo, VWidget *Parent, 
					VGArg arguments[], int32 n);


#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /* _VG_TOOLS_H_ */
