
typedef struct
{
    uint32		 mode;
    char		*geometryName;
    char		*material;
    char		*lod;
    char		*behaviour;
    float32		 mass;
} VCHapticData;

typedef struct
{
    uint32		 mode;
    char		*name;
} VCHapticResourceData;

