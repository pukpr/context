/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: vwradio.h,v $
 *    Revision:     $Revision: 1.3 $
 *    Date:         $Date: 1997/04/22 12:34:05 $
 *    Author:       $Author: simon $
 *    RCS Ident:    $Id: vwradio.h,v 1.3 1997/04/22 12:34:05 simon Exp $
 *
 *    FUNCTION: Radio public function prototypes.
 *
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _Radio_H
#define _Radio_H
#ifdef __cplusplus
extern "C" {
#endif
/* PUBLIC TYPES ==========================================*/

#include "vwrowcol.h"

/* PUBLIC FUNCTIONS ======================================*/
VW_EXPORT VWidget *VWRadio_CreateManaged(VWidget *, char *, VWArg [], int);
VW_EXPORT VWidget *VWRadio_Create(VWidget *, char *, VWArg [], int);
VW_EXPORT VWidget *VWRadio_AddItem(VWidget *RadioWig,  
	    char *IconName, float32 *IconSize, char *IconMat, 
	    VWCallback *Activate_cb, void *Activate_cd);
VW_EXPORT void VWRadio_RemoveAllItems(VWidget *RadioWig);
VW_EXPORT void VWRadio_ActivateItem(VWidget *RadioWig, VWidget *ToggleWig);
VW_EXPORT void VWRadio_HighlightItem(VWidget *RadioWig, VWidget *ButtonWig);

#define VWRadioButtonGetRadio(b) (b)->parent


#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /*_Radio_H */
