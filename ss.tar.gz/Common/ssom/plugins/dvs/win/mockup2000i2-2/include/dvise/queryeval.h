/****************************************************************************
 *
 *  			Copyright 1998 Division Ltd.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: queryeval.h,v $
 *  Revision      : $Revision: 1.1 $
 *  Date          : $Date: 1999/09/30 13:56:11 $
 *  Author        : $Author: simon $
 *  Created       : Mon May 11 16:59:20 1998
 *  Last Modified : <990928.1331>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 *  $Log: queryeval.h,v $
 *  Revision 1.1  1999/09/30 13:56:11  simon
 *  Fixed bugs 7515, 7242, 7551, 7510, 7589, 7149, 7584, 7591, 7610, 7573.
 *  Added libecapp2 directory, and moved queryeval.* code in there.
 *
 *  Revision 1.3  1999/08/26 12:45:42  jeff
 *  moved all #include lines out of extern C blocks. I hope.
 *
 *  Revision 1.2  1999/02/11 18:00:56  john
 *  uses new dvexport declspec stuff
 *  body.c moved to body.cc
 *  body uses new selection list stuff
 *
 *  Revision 1.1  1998/07/30 13:58:52  simon
 *  fixed, and added to queryeval.* from libec
 *
 *  Revision 1.10  1998/07/29 11:00:58  simon
 *  Fixed a few niggly bugs
 *
 *  Revision 1.9  1998/06/18 11:12:32  simon
 *  Upgrades to query engine
 *
 *  Revision 1.8  1998/05/28 17:29:12  simon
 *  *** empty log message ***
 *
 *  Revision 1.7  1998/05/27 17:05:51  simon
 *  *** empty log message ***
 *
 *  Revision 1.6  1998/05/22 16:30:11  simon
 *  *** empty log message ***
 *
 *  Revision 1.5  1998/05/21 17:05:52  simon
 *  *** empty log message ***
 *
 *  Revision 1.4  1998/05/19 17:13:20  simon
 *  *** empty log message ***
 *
 *  Revision 1.3  1998/05/15 15:54:49  simon
 *  *** empty log message ***
 *
 *  Revision 1.2  1998/05/14 16:59:55  simon
 *  *** empty log message ***
 *
 *  Revision 1.1  1998/05/11 17:05:39  simon
 *  *** empty log message ***
 *
 *
 ****************************************************************************
 *
 *  Copyright (c) 1998 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 * This  document  may  not, in  whole  or in  part, be  copied,  photocopied,
 * reproduced,  translated,  or  reduced to any  electronic  medium or machine
 * readable form without prior written consent from Division Ltd.
 *
 ****************************************************************************/

#ifndef __QUERYEVAL_H
#define __QUERYEVAL_H

#include <dvise/queryparser.h>
#include <dvise/ecatools.h>

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

/* these are the different types of test that can occur,
 * the enums are of the format Input_Func_Output
 */
typedef enum {
    Error_ErrorCall_Error,
    Assembly_GetValueFromToken_Value,
    Assembly_GetPropertyFromName_Property,
    Assembly_GetPropertyFromToken_Property,
    Assembly_GetUserDataFromName_UserData,
    Assembly_GetUserDataFieldFromName_UserDataField,
    Assembly_GetUserDataFieldValueFromToken_Value,
    Property_GetPropertyFromToken_Property,
    Property_SequenceGetValueFromToken_Value,
    Property_AudioGetValueFromToken_Value,
    Property_BaseGetValueFromToken_Value,
    Property_BehaviorGetValueFromToken_Value,
    Property_CollisionGetValueFromToken_Value,
    Property_ConstraintGetValueFromToken_Value,
    Property_LightGetValueFromToken_Value,
    Property_VisualGetValueFromToken_Value,
    UserData_GetUserDataFieldFromName_UserDataField,
    UserData_GetUserDataFieldValueFromType_Value,
    UserDataField_GetValueFromToken_Value,
    Value_GetFloat3_Value,
    Value_GetFloat4_Value,
    Value_CompareString_bool,
    Value_CompareAssemblyType_bool,
    Value_CompareState_bool,
    Value_CompareInt_bool,
    Value_CompareFloat_bool,
    Value_CompareFloatInUnits_bool,
    Value_CompareEvent_bool,
    Value_CompareVolumeDefinition_bool,
    Value_CompareConstraintType_bool,
    Value_CompareLightType_bool,
    Value_CompareVisualRenderAs_bool,
    Value_CompareAxis_bool,
    Value_CompareTrackType_bool, 
    Value_CompareTrackValid_bool,
    EvaluatorTestType_LastToken /* this should always be the last token */    
} EEvaluatorTestType;

typedef enum {
    qtError = 0,
    qtAssembly = 200, /* no overlap with q??? enum so more likely to catch bugs */
    qtProperty,
    qtUserData,
    qtUserDataField,
    qtValue,
    qtAny,
    qtSequence,
    qtAudio,
    qtBase,
    qtBehavior,
    qtCollision,
    qtConstraint,
    qtLight,
    qtVisual,
    qtFloat3,
    qtFloat4,
    qtString,
    qtAssemblyType,
    qtState,
    qtInt,
    qtFloat,
    qtEvent,
    qtVolumeDefinition,
    qtConstraintType,
    qtLightType,
    qtRenderAs,
    qtAxis,
    qtBool,
    qtTrack,
    qtLastToken /* this should always be the last token */    
} EEvaluatorTestIOType;

struct QueryEvaluator;
typedef struct QueryEvaluator QueryEvaluator;

struct QueryEvaluatorLine;
typedef struct QueryEvaluatorLine QueryEvaluatorLine;

struct QueryEvaluatorData;
typedef struct QueryEvaluatorData QueryEvaluatorData;

struct QueryEvaluatorDataList;
typedef struct QueryEvaluatorDataList QueryEvaluatorDataList;

struct QueryEvaluatorTest;
typedef struct QueryEvaluatorTest QueryEvaluatorTest;
typedef int (QueryEvaluatorTestFunc)(QueryEvaluatorDataList *input, QueryParseToken token, 
                                     QueryParseToken previousToken, void *data);
typedef int (QueryRevaluatorTestFunc)(QueryEvaluatorDataList *input, QueryParseToken token, 
                                      void *data);

/* The one and only set of query evaluator rules */
DV_EXPORT extern QueryRules *EvaluatorRules;


/* sets up the evaluator rules */
DV_EXPORT void QueryEvaluator_Setup(void);

/* evaluates the given query, against each of the assemblies in assemblyPath array of
 * length numAss.  If checkChildren then evaluates children too.  bodyName is the name of
 * the body for which the current unit (e.g. inches, metres) will be assertained. 
 * Returns an item list of assemblies that match the given query */
DV_EXPORT ECItem *Query_Evaluate(Query *query, char **assemblyPaths, int numAss, int checkChildren,
                                 char *bodyName);
/* sets global value for case sensitivity.  If TRUE then all string comparisions will be
 * case sensitive.  This is FALSE by default - i.e. comparisons are case insensitive */
void Query_SetCaseSensitivity(int caseSensitive);

/* creates an object to be used to evaluate queries */
DV_EXPORT QueryEvaluator *QueryEvaluator_Create(void);
/* deletes an evaluator */
DV_EXPORT int QueryEvaluator_Delete(QueryEvaluator **evaluator);
/* resets an evaluator, removing all its lines */
DV_EXPORT int QueryEvaluator_Reset(QueryEvaluator *evaluator);
/* adds an evaluation line to evaluator */
DV_EXPORT int QueryEvaluator_AddLine(QueryEvaluator *evaluator, QueryEvaluatorLine *evalLine);
/* sets up a query evaluator from a query */
DV_EXPORT int QueryEvaluator_SetupUsingQuery(QueryEvaluator *evaluator, Query *query, 
                                             QueryRules *evaluatorRules);
/* evaluates an assembly, returns TRUE on match */
DV_EXPORT int QueryEvaluator_EvaluateAssembly(QueryEvaluator *evaluator, ECAssembly *assembly);

/* creates an evaluation line - which evaluates a line of a query */
DV_EXPORT QueryEvaluatorLine *QueryEvaluatorLine_Create(void);
DV_EXPORT int QueryEvalatorLine_Delete(QueryEvaluatorLine **evalLine);
/* adds an evalution tests to the ordered list of tests to be done for this line */
DV_EXPORT int QueryEvaluatorLine_AddTestToStart(QueryEvaluatorLine *evalLine, 
                                      QueryEvaluatorTest *test);
/* gets the connector to the next line - e.g. And, Or */
DV_EXPORT QueryParseToken QueryEvaluatorLine_GetConnector(QueryEvaluatorLine *evalLine);
/* sets the connector to the next line - e.g. And, Or */
DV_EXPORT int QueryEvaluatorLine_SetConnector(QueryEvaluatorLine *evalLine, 
                                    QueryParseToken connector);
/* gets the next in list of lines */
DV_EXPORT QueryEvaluatorLine *QueryEvaluatorLine_GetNext(QueryEvaluatorLine *evalLine);
/* sets the next line in list */
DV_EXPORT int QueryEvaluatorLine_SetNext(QueryEvaluatorLine *evalLine, 
                               QueryEvaluatorLine *nextLine);
/* evaluates the lines part of a query for the given assembly returns TRUE on match */
DV_EXPORT int QueryEvaluatorLine_EvaluateAssembly(QueryEvaluatorLine *evalLine, ECAssembly *assembly);

/* creates an object to do tests on parts of lines */
DV_EXPORT QueryEvaluatorTest *QueryEvaluatorTest_Create(void);
DV_EXPORT int QueryEvalatorTest_Delete(QueryEvaluatorTest **test);
/* gets the next test to be done */
DV_EXPORT QueryEvaluatorTest *QueryEvaluatorTest_GetNext(QueryEvaluatorTest *test);
/* gets the test before this one */
DV_EXPORT QueryEvaluatorTest *QueryEvaluatorTest_GetLast(QueryEvaluatorTest *test);
/* sets the test to do after this one - test base output must match nextTest base input */
DV_EXPORT int QueryEvaluatorTest_SetNext(QueryEvaluatorTest *test, QueryEvaluatorTest *nextTest);
/* sets the type of test */
DV_EXPORT int QueryEvaluatorTest_SetType(QueryEvaluatorTest *test, EEvaluatorTestType type);
/* sets the comparison data required to do comparisons with */
DV_EXPORT int QueryEvaluatorTest_SetData(QueryEvaluatorTest *test, QueryParseToken dataType, 
                                         QueryParseToken previousToken, void *data);
/* calls the evaluation function for the given test with the given evalData, returns TRUE
 * on success, evalData is updated to contain the result */
DV_EXPORT int QueryEvaluatorTest_Evaluate(QueryEvaluatorTest *test, QueryEvaluatorDataList *evalDataList);
/* if the next test after this one failed then call this to see if there is any other data that
 * matches this test, evalDataList should contain successful results of evaluation of this test */
DV_EXPORT int QueryEvaluatorTest_Revaluate(QueryEvaluatorTest *test, QueryEvaluatorDataList *evalDataList);

/* creates a data structure to hold a list of query evaluator data's */
DV_EXPORT QueryEvaluatorDataList *QueryEvaluatorDataList_Create(void);
/* deletes the list */
DV_EXPORT int QueryEvaluatorDataList_Delete(QueryEvaluatorDataList **datalist);
/* deletes the head of the list of eval data */
DV_EXPORT int QueryEvalatorDataList_DeleteHead(QueryEvaluatorDataList *datalist);
/* creates, sets and attaches a new eval data to the start of the list */
DV_EXPORT int QueryEvaluatorDataList_SetNewHead(QueryEvaluatorDataList *datalist,
                                  EEvaluatorTestIOType baseType,
                                  EEvaluatorTestIOType exactType, void *data);
/* resets the eval data at the head of the list to contain the data given */
DV_EXPORT int QueryEvaluatorDataList_SetHead(QueryEvaluatorDataList *datalist,
                                  EEvaluatorTestIOType baseType,
                                  EEvaluatorTestIOType exactType, void *data);
/* resets the eval data's second data to contain the data given */
DV_EXPORT int QueryEvaluatorDataList_SetHeadSecond(QueryEvaluatorDataList *datalist,
                                  EEvaluatorTestIOType baseType,
                                  EEvaluatorTestIOType exactType, void *data);
/* resets the eval data's third data to contain the data given */
DV_EXPORT int QueryEvaluatorDataList_SetHeadThird(QueryEvaluatorDataList *datalist,
                                  EEvaluatorTestIOType baseType,
                                  EEvaluatorTestIOType exactType, void *data);
/* get the first eval data in the list */
DV_EXPORT QueryEvaluatorData *QueryEvaluatorDataList_GetHead(QueryEvaluatorDataList *datalist);
/* get the second eval data in the list */
DV_EXPORT QueryEvaluatorData *QueryEvaluatorDataList_GetTail(QueryEvaluatorDataList *datalist);
/* get the data in the eval data at the head of the list */
DV_EXPORT void *QueryEvaluatorDataList_GetHeadData(QueryEvaluatorDataList *datalist);
/* get the second data in the eval data at the head of the list */
DV_EXPORT void *QueryEvaluatorDataList_GetHeadSecondData(QueryEvaluatorDataList *datalist);
/* get the third data in the eval data at the head of the list */
DV_EXPORT void *QueryEvaluatorDataList_GetHeadThirdData(QueryEvaluatorDataList *datalist);
/* get the base type in the eval data at the head of the list */
DV_EXPORT EEvaluatorTestIOType QueryEvaluatorDataList_GetHeadBaseType(QueryEvaluatorDataList *datalist);
/* get the exact type in the eval data at the head of the list */
DV_EXPORT EEvaluatorTestIOType QueryEvaluatorDataList_GetHeadExactType(QueryEvaluatorDataList *datalist);
/* adds the given evalator data as a new head of list */
DV_EXPORT int QueryEvaluatorDataList_AddNewHead(QueryEvaluatorDataList *datalist, QueryEvaluatorData *newHead);
/* deletes the existing head, and inserts the new head */
DV_EXPORT int QueryEvaluatorDataList_OverwriteHead(QueryEvaluatorDataList *datalist, QueryEvaluatorData *newHead);


/* creates a data structure to hold some qt*** data */
DV_EXPORT QueryEvaluatorData *QueryEvaluatorData_Create(void);
/* deletes an evaluator data */
DV_EXPORT int QueryEvaluatorData_Delete(QueryEvaluatorData **evalData);
/* gets the next eval data in the list */
DV_EXPORT QueryEvaluatorData *QueryEvaluatorData_GetNext(QueryEvaluatorData *evalData);
/* gets as a (void *) the copy of actual data stored in the evalData.  You can store three
 different lumps of data, each of the functions retrieve a seperate one */ 
DV_EXPORT void *QueryEvaluatorData_GetData(QueryEvaluatorData *evalData); /* get first */
DV_EXPORT void *QueryEvaluatorData_GetSecondData(QueryEvaluatorData *evalData); /* get second */
DV_EXPORT void *QueryEvaluatorData_GetThirdData(QueryEvaluatorData *evalData); /* get third */
/* gets the base type of first, second or third data */
DV_EXPORT EEvaluatorTestIOType QueryEvaluatorData_GetBaseType(QueryEvaluatorData *evalData);
DV_EXPORT EEvaluatorTestIOType QueryEvaluatorData_GetSecondBaseType(QueryEvaluatorData *evalData);
DV_EXPORT EEvaluatorTestIOType QueryEvaluatorData_GetThirdBaseType(QueryEvaluatorData *evalData);
/* gets the exact type of first, second or third data */
DV_EXPORT EEvaluatorTestIOType QueryEvaluatorData_GetExactType(QueryEvaluatorData *evalData);
DV_EXPORT EEvaluatorTestIOType QueryEvaluatorData_GetSecondExactType(QueryEvaluatorData *evalData);
DV_EXPORT EEvaluatorTestIOType QueryEvaluatorData_GetThirdExactType(QueryEvaluatorData *evalData);
/* sets the next eval data in the list */
DV_EXPORT int QueryEvaluatorData_SetNext(QueryEvaluatorData *evalData, QueryEvaluatorData *next);
/* sets eval data to hold a specific type of data specified by baseType, and exactType,
 * pass a ptr to the actual data as (void *) in data, this will only be copied for simple types,
   i.e. if you pass in a string, that will be copied, where as an assembly will not.
   Three separate lumps of data can be stored - appropriate function sets each of them */
DV_EXPORT int QueryEvaluatorData_Set(QueryEvaluatorData *evalData, EEvaluatorTestIOType baseType,
                           EEvaluatorTestIOType exactType, void *data);
DV_EXPORT int QueryEvaluatorData_SetSecond(QueryEvaluatorData *evalData, EEvaluatorTestIOType baseType,
                           EEvaluatorTestIOType exactType, void *data);
DV_EXPORT int QueryEvaluatorData_SetThird(QueryEvaluatorData *evalData, EEvaluatorTestIOType baseType,
                           EEvaluatorTestIOType exactType, void *data);

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif
#endif /* __QUERYEVAL_H */
