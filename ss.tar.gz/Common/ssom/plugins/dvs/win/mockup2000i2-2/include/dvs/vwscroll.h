/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: vwscroll.h,v $
 *    Revision:     $Revision: 1.10 $
 *    Date:         $Date: 1997/05/22 16:20:06 $
 *    Author:       $Author: simon $
 *    RCS Ident:    $Id: vwscroll.h,v 1.10 1997/05/22 16:20:06 simon Exp $
 *
 *    FUNCTION: Frame public function prototypes.
 * 
 * Copyright (c) 1996 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _VWScroll_H
#define _VWScroll_H
#ifdef __cplusplus
extern "C" {
#endif
#ifdef _dummyBrace_
}
#endif
/* INCLUDES ============================================== */
#include "vwidgets.h"
#include "vwborder.h"
/* PUBLIC FUNCTIONS ====================================== */

enum {
    VWrScrollNumButtons = VW_RESOURCES_SCROLL,
    VWrScrollNumColumns,
    VWrScrollUseScalar,
    VWrScrollDontUseBorder,
    VWrScrollType,
    VWrScrollUseRectangularIcons,
    VWrScrollUseFlatButtons,
    VWrScrollAdjustScalarButtonHeight,
    VWrScrollAdjustScalarWidth,
    VWrScrollBackgroundFlatWhite,
    VWrScrollButtonPressCallBack,
    VWrScrollButtonPressCallBackData,
    VWrScrollButtonReleaseCallBack,
    VWrScrollButtonReleaseCallBackData
};

typedef enum VWScroll_Type {
    VWScroll_Label, 
    VWScroll_Button, 
    VWScroll_Toggle
} VWScroll_Type;

VW_EXPORT VWidget *VWScroll_CreateManaged(VWidget *Parent, char *name, VWArg args[], int argc);
VW_EXPORT VWidget *VWScroll_Create(VWidget *Parent, char *name, VWArg args[], int argc);
VW_EXPORT void VWScroll_AddIcon(VWidget *ScrollWig, char *texture, int newIconNo);
VW_EXPORT void VWScroll_AddIconMap(VWidget *ScrollWig, VCTexture *texture, int newIconNo);
VW_EXPORT void VWScroll_AddIconImage(VWidget *ScrollWig, VCTextureImage *image, int newIconNo);
VW_EXPORT void VWScroll_AddIcons(VWidget *ScrollWig, char *argt[], int argc, 
				 int newFirst, int *retLast);
VW_EXPORT void VWScroll_ResetIcons(VWidget *ScrollWig);
VW_EXPORT int VWScroll_GetDepressedIconNo(VWidget *thisWig);
VW_EXPORT char *VWScroll_GetDepressedIconLocation(VWidget *thisWig);
VW_EXPORT VCTexture *VWScroll_GetIconTexture(VWidget *thisWig, int iconNo);
VW_EXPORT void VWScroll_SelectIcon(VWidget *thisWig, int selIconNo);
VW_EXPORT void VWScroll_ReleaseIcon(VWidget *thisWig);
VW_EXPORT int VWScroll_GetNumIcons(VWidget *thisWig);

VW_EXPORT void VWScroll_StopUpdates(VWidget *thisWig);
VW_EXPORT void VWScroll_StartUpdates(VWidget *thisWig);

VW_EXPORT void VWScroll_AddButtonPressCb(VWidget *thisWig, VWCallback *cb, void *cd);
VW_EXPORT void VWScroll_AddButtonReleaseCb(VWidget *thisWig, VWCallback *cb, void *cd);

#ifdef _dummyBrace_
{
#endif
#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /*_VWForm_H */
