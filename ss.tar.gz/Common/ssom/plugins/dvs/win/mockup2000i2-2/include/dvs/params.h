/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1994 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS 2.1
--  Module       : Audio support library
--  Object Name  : $RCSfile: params.h,v $
--  Revision     : $Revision: 1.1.1.1 $
--  Date         : $Date: 1996/04/10 16:08:41 $
--  Author       : $Author: mark $
--
--  Description	
--	Device parameter management.
--
--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __PARAMS_H__
#define __PARAMS_H__

/*
 * ============================================================
 *
 * PARAMETER TYPES
 *
 * ============================================================
 */

    /* -- the types of parameters supported */

typedef enum 
{
    PARAM_STRING,
    PARAM_FLOAT,
    PARAM_INT
} ParamType;

    /*  -- representation of a parameter */

typedef struct Parameter
{
    char *name;
    ParamType type;
    union
    {
        char *string;
        float32 real;
        int32 integer;
    } value;
} Parameter;

    /* -- structure defining a parameter's name and type */

typedef struct ParameterDef
{
    char *name;
    ParamType type;
    char *string;
    float32 real;
    int32 integer;
} ParameterDef;


 /* -- structure representing a set of parameters */

typedef struct Parameters Parameters;

/*
 * ============================================================
 *
 * INTERFACE FUNCTIONS
 *
 * ============================================================
 */

    /* -- create a set of parameters */

extern Parameters *ParamsCreate(void);

    /* -- destroy a set of parameters */

extern void ParamsDestroy(Parameters *params);

    /* -- define the parameter names for a parameter set */

extern void ParamsDefine(Parameters *params, ParameterDef *definitions);

    /* -- set the value of a parameter */

extern int ParamsSet(Parameters *params, Parameter *param);

    /* -- retrieve a parameter */

extern Parameter *ParamsGet(Parameters *params, char *parameter);

    /* -- determine if a parameter exists and its type */

extern int ParamsExists(Parameters *params, char *parameter, ParamType *type);


#endif /* __PARAMS_H__ */
