/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1995 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : MultiSound support for vcaudio
--  Object Name  : $RCSfile: wavfile.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : $Date: 1997/04/18 11:03:00 $
--  Author       : $Author: mark $
--
--  Description	
--	Constants for accessing data in Microsoft RIFF/WAV files
--
--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __WAVFILE_H__
#define __WAVFILE_H__

/*
 * ============================================================
 *
 * Types
 *
 * ============================================================
 */

typedef struct WavHeader
{
    uint8 riff[4];              /* "RIFF" */
    uint32 len;                 /* length of the rest */
    uint8 wave[4];              /* "WAVE" */
    uint8 fmt[4];               /* "fmt " */
    uint32 fmtLen;              /* length of format data == 16 */
    uint16 fmtCode;             /* format code == 1 */
    uint16 fmtChans;            /* number of channels */
    uint32 fmtRate;             /* sample rate */
    uint32 fmtBytesPerSec;      /* bytes per second */
    uint16 fmtFormLen;          /* length of format spec data == 2*/
    uint16 fmtBitsPerSample;    /* number of bits in sample == 16 */
    uint8  data[4];             /* "data" */
    uint32 sampleBytes;         /* number of sample bytes */
} WavHeader;

/*
 * ------------------------------------------------------------
 *
 * WAV file constants
 *
 * ------------------------------------------------------------
 */

#define WAV_HEADER_SIZE 44
#define WAV_FORMAT_OFFSET 8
#define WAV_STEREO_OFFSET 22
#define WAV_SAMPLE_RATE_OFFSET 24
#define WAV_SAMPLE_WIDTH_OFFSET 34

extern int WAVHeaderValid(char *header, int32 *stereo, int32 *sampleRate, int32 *sampleWidth);
extern int WriteWavHeader(int fp, int32 bytesWritten, int32 mono, int32 sampleRate);


#endif /* __WAVFILE_H__ */


