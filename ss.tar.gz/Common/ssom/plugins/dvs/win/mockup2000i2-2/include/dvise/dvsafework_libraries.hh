#ifndef _DVSAFEWORKLIBRARIES_HH
#define _DVSAFEWORKLIBRARIES_HH

#ifndef _ECTOOLS_H
#include <dvise/ectools.h>
#endif

#ifndef _ECATOOLS_H
#include <dvise/ecatools.h>
#endif

#ifndef _EVENT_H
#include <dvise/event.h>
#endif

#ifndef _swapi_h
#define ofltMAN_POST   00001000
#define ofltMAN_RPOST  00002000
#define ofltMAN_LPOST  00004000
#define ofltMAN_LIM    00010000
#define ofltMAN_ANT    00020000
#define ofltMAN_PREF   00040000 // added here for prefangles
#define ofltMAN_VISION 00200000
#define ofltMAN_LIMDB  00400000 
#endif

#ifndef _DVSW_HH
#include "dvsw.hh"
#endif

#ifndef _DVSAFEWORKDEBUG_HH
#include "debug.hh"
#endif

/*
  This module manages the Safework libraries action function interface.  
 */
typedef enum {
    dvSwLibItemUnknown		= 0,
    dvSwLibItemPost		= ofltMAN_POST,
    dvSwLibItemPostAndRef	= ofltMAN_RPOST,
    dvSwLibItemLocalPost	= ofltMAN_LPOST,
    dvSwLibItemJointLimits	= ofltMAN_LIM,
    dvSwLibItemAnthropometry	= ofltMAN_ANT,
    dvSwLibItemPrefAngles	= ofltMAN_PREF,
    dvSwLibItemVis		= ofltMAN_VISION,
    dvSwLibItemJointLimitsDB	= ofltMAN_LIMDB
}libItemType;
   
// Callback FLAG DEFINITION:
#define dvSwLIBRARY_CREATE_FROM_FILE
#define dvSwLIBRARY_CREATE_FROM_SCRATCH
#define dvSwLIBRARY_UPDATE_ADD_ITEM
#define dvSwLIBRARY_UPDATE_REMOVE_ITEM
#define dvSwLIBRARY_UPDATE_CLOSE_FILE
#define dvSwLIBRARY_UPDATE_SAVE_FILE

class DV_EXPORT  _ECSwLibrary: public _ECBaseItem
{

    void initValues();

public:
    //_ECSwLibrary();
    //~_ECSwLibrary();
    
    static _ECSwLibrary * findAndOpenLib(char * libName = NULL);
    static _ECSwLibrary * findOrCreateLib(char * libName = NULL);
    static _ECSwLibrary * findLib(char * libName);
    static bool findFile(char **libName, char ** fileName);

    virtual dvSwRetType createLib()=0;
    virtual dvSwRetType openLib()=0;

    virtual dvSwRetType closeLib()=0;

    virtual dvSwRetType saveLib(char * filename = NULL)=0;

    virtual dvSwRetType openPanel()=0;

    virtual dvSwRetType removeLib()=0;


    virtual int getItemNb() {return 0;};

    virtual dvSwRetType getFirstItem(char ** itemName, 
				     libItemType *itemType)=0;
    virtual dvSwRetType getNextItem(char * thisName, 
				    char ** nextName, 
				    libItemType *nextType) = 0;


    virtual dvSwRetType findItem(char * searchName,
				 char ** foundName, 
				 libItemType *foundType) = 0;

    virtual dvSwRetType getItemFromManikin(char * manikinHandle, 
				       libItemType itemType,
				       char ** itemName)
    {return dvSwFailure;};
    
    virtual dvSwRetType putItemToManikin(char * manikinHandle, 
					 char * itemName)
    {return dvSwFailure;};
    
    virtual dvSwRetType deleteItem(char * itemName)
    {return dvSwFailure;};
     
    virtual dvSwRetType renameItem(char * itemName, char ** newName)
    {return dvSwFailure;};

     // Generic query and set methods
    int getId(void) const;
    static int getMyId(void);
    char *getIdString(void) const; // %WAR: Abstract virtual from _ECBaseItem
    char *GetName() const {return _attributeName;};
    ECError SetName(char *newName);
    ECError SetNameNoCopy(char *newName);

private: 

    char * _attributeName; // Name of this attribute

};

typedef ECSmartPtr<_ECSwLibrary> ECSwLibraryPtr;

dvSwRetType
dvsafework_libraries_setup();

int
dvSwLibOpenFileFunc(ECEvent *, ECEventData *, ECAction *);
int
dvSwLibCloseFileFunc(ECEvent *, ECEventData *, ECAction *);
int
dvSwLibSaveFileFunc(ECEvent *, ECEventData *, ECAction *);
int
dvSwLibOpenPanelFunc(ECEvent *, ECEventData *, ECAction *);
int
dvSwLibItemPutToManikinFunc(ECEvent *, ECEventData *, ECAction *);

int
dvSwLibItemGetGlobalPostureFromManikinFunc(ECEvent *, ECEventData *, ECAction *);
int
dvSwLibItemGetGlobalPostureAndRefFromManikinFunc(ECEvent *, ECEventData *, ECAction *);
int
dvSwLibItemGetLocalPostFromManikinFunc(ECEvent *, ECEventData *, ECAction *);
int
dvSwLibItemGetJointLimitsFromManikinFunc(ECEvent *, ECEventData *, ECAction *);
int
dvSwLibItemGetJointLimitsDBFromManikinFunc(ECEvent *, ECEventData *, ECAction *);
int
dvSwLibItemGetAnthropometryFromManikinFunc(ECEvent *, ECEventData *, ECAction *);
int
dvSwLibItemGetPreferredAnglesFromManikinFunc(ECEvent *, ECEventData *, ECAction *);
int
dvSwLibItemGetVisionFromManikinFunc(ECEvent *, ECEventData *, ECAction *);
int
dvSwLibItemDeleteFunc(ECEvent *, ECEventData *, ECAction *);


#endif
