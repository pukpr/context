/******************************************************************************/
/*									      */
/*	######    ###   #     #   ###    #####    ###   ####### #     #	      */
/*	#     #    #    #     #    #    #     #    #    #     # ##    #	      */
/*	#     #    #    #     #    #    #          #    #     # # #   #	      */
/*	#     #    #    #     #    #     #####     #    #     # #  #  #	      */
/*	#     #    #     #   #     #          #    #    #     # #   # #	      */
/*	#     #    #      # #      #    #     #    #    #     # #    ##	      */
/*	######    ###      #      ###    #####    ###   ####### #     #	      */
/*									      */
/*									      */
/*			#####    ###     ###     ###			      */
/*			     #  #   #   #   #   #   #			      */
/*			     # #     # #     # #     #			      */
/*			#####  #     # #     # #     #			      */
/*			#      #     # #     # #     #			      */
/*			#       #   #   #   #   #   #			      */
/*			######   ###     ###     ###			      */
/*									      */
/* 		Copyright (c) Division Limited. All rights reserved	      */
/*									      */
/* This Document may not, in whole or in part, be copied, photocopied,	      */
/* reproduced, translated, or reduced to any electronic medium or machine     */
/* readable form without prior written consent from Division Ltd.	      */
/*									      */
/******************************************************************************/

#if !defined _SS_H_
#define _SS_H_

#include <dsys/dp.h>
#include <dsys/ssc.h>

typedef struct SS_INTERFACE * SS_HANDLE;

extern SS_HANDLE ss_openServer           (void);
extern SS_HANDLE ss_openClient           (char * plugin);
extern SS_HANDLE ss_servAccept           (SS_HANDLE ss);
extern void      ss_close                (SS_HANDLE ss);

#if defined HOPPY
extern void    ss_setAttachID            (SS_HANDLE ss, int    attachID);
extern void    ss_setAttachHandle        (SS_HANDLE ss, void * attachHandle);
#endif
extern void    ss_setDebugFile           (SS_HANDLE ss, char * debugFile);
extern int     ss_setBlockedReadHandler  (SS_HANDLE ss, SSC_HANDLER_FUNC func, void * udp);
extern int     ss_setBlockedWriteHandler (SS_HANDLE ss, SSC_HANDLER_FUNC func, void * udp);
extern int     ss_getSocket              (SS_HANDLE ss);
#if defined HOPPY
extern int     ss_getAttachID            (SS_HANDLE ss);
extern void *  ss_getAttachHandle        (SS_HANDLE ss);
#endif
extern char *  ss_getDebugFile           (SS_HANDLE ss);

extern int ss_write          (SS_HANDLE ss);
extern int ss_read           (SS_HANDLE ss);
#if defined HOPPY
extern int ss_startGroup     (SS_HANDLE ss);
extern int ss_endGroup       (SS_HANDLE ss);
#endif
extern int ss_addInt         (SS_HANDLE ss, uint32 data);
extern int ss_addCommand     (SS_HANDLE ss, uint16 command);
extern int ss_addData        (SS_HANDLE ss, char * data, size_t sizeData);
extern int ss_addString      (SS_HANDLE ss, char * string);
extern int ss_getInt         (SS_HANDLE ss, uint32 * data);
extern int ss_getCommand     (SS_HANDLE ss, uint16 * command);
extern int ss_getData        (SS_HANDLE ss, char ** data, size_t * sizeData);
extern int ss_getString      (SS_HANDLE ss, char ** string);
extern int ss_eraseTxBuffer  (SS_HANDLE ss);
extern int ss_startRxBuffer  (SS_HANDLE ss);
#if defined HOPPY
extern int ss_cmdsInRxBuffer (SS_HANDLE ss);
#endif
extern int ss_moreRxData     (SS_HANDLE ss);

#if defined HOPPY
extern int ss_servPlugin       (SS_HANDLE ss);
#endif
extern int ss_handleCommand    (SS_HANDLE ss, int * shutdown);

#if defined _WIN32 && ! defined(_WINDU_SOURCE) && ! defined __EPP__ && ! defined(BUILD_STATIC)
#define SS_PLUGIN_FUNC __declspec(dllexport) extern
#else
#define SS_PLUGIN_FUNC extern 
#endif /* WIN32 */

extern "C"
{
  SS_PLUGIN_FUNC int ss_pluginOpen  (SS_HANDLE ss);
  SS_PLUGIN_FUNC int ss_pluginClose (SS_HANDLE ss);
  SS_PLUGIN_FUNC int ss_pluginRead  (SS_HANDLE ss, uint16 command);
}

#endif /* _SS_H */
