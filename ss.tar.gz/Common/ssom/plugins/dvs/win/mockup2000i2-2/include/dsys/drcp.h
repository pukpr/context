/* -*- C -*- ****************************************************************
 *
 *  			Copyright 1998 Division Ltd.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: drcp.h,v $
 *  Revision      : $Revision: 1.10 $
 *  Date          : $Date: 1999/04/15 10:11:32 $
 *  Author        : $Author: bill $
 *  Created By    : Steven Phillips
 *  Created       : Wed Mar 4 15:44:00 1998
 *  Last Modified : <150499.0740>
 *
 *  Description	
 *
 *  Notes
 *
 ****************************************************************************
 *
 *  Copyright (c) 1998 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 * This  document  may  not, in  whole  or in  part, be  copied,  photocopied,
 * reproduced,  translated,  or  reduced to any  electronic  medium or machine
 * readable form without prior written consent from Division Ltd.
 *
 ****************************************************************************/

#ifndef __DRCP_H
#define __DRCP_H

#include <dsys/doctree.h> 
#include <dsys/pfile.h>
#include <dsys/dreg.h>

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

#define drcpCONVFLAG_NOVDI     0x01     /* Converter does not output a vdifile    */
#define drcpCONVFLAG_NOWRITING 0x02     /* Disable the "Writing" section printout */
#define drcpCONVFLAG_NONUMBONE 0x04     /* Name first geom file "foo" not "foo_1" */

typedef struct {
    float32 doLodDist ;
    int32   doLodType ;
    float32 doLodPerc ;
    int32   doLodBnde ;
    int32   doLodDece ;
    float32 doLodDect ;
    int32   doLodEdge ;
    float32 doLodEdgt ;
    int32   doLodNo ;
    int32   triCount[2] ;
} drcpLodConfig ;

typedef struct {
    Registry *registry ;
    Registry *general ;
    Registry *converter ;
    char     *fileName ;
    char     *convName ;
    int32     convFlag ;
    int32     changed ;
    
    /* following are internal geometry processing variables */
    int32   doLodVerbose ;
    int32   doToolVerbose ;
    
    int32   doPrep ;
    int32   doRdup ;
    int32   doRsmt ;
    int32   doWeld ;
    int32   doFlip ;
    int32   doNorm ;
    int32   doNormForce ;
    int32   doNwld ;

    int32   doLod ;
    dpfTRANSITION doLodTrans ;
    int32   doLodLodNo ;
    int32   doLodMaxLPF ;
    int32   doLodBbox ;
    float32 doLodBboxScrn ;
    float32 doLodBboxMaxSz ;
    float32 doLodBboxMinDt ;
    float32 doLodBboxMinRd ;
    int32   doLodNoth ;
    float32 doLodNothScrn ;
    float32 doLodNothMaxSz ;
    float32 doLodNothMinDt ;
    int32   doLodFileCount ;
    
    drcpLodConfig *doLodCfg ;
} drcpFile ;

/* drcpFileOpen
 * 
 * Open up the given recipe returning a pointer to the new file. searches for
 * the recipe file in ., $DIVISIONROOT, /home/division and in ./recipe for all
 * the above locations. The .rcp extension is also appended and tried.
 * fileName cannot be NULL as no default name is assumed.
 * 
 * Returns NULL is failed to find file with an error message.
 */
drcpFile *drcpFileOpen(char *fileName) ;
/* drcpFileClose
 * 
 * Closes down and frees the given recipe file handle. If the recipe file has
 * changed (file->changed != 0), then the changes are saved back to the file.
 * 
 * If the file needed writing and this failed then the returns dpgERROR before
 * then file is freed so the fileName could be changed and this function
 * called again. Otherwise dpgSUCCESS is returned.
 */
int32 drcpFileClose(drcpFile *file) ;
/* drcpFileSetConverter
 * 
 * Sets the given rcp file to use the given converters values. This effects
 * the values returned by function drcpFileGetConverterValue. If the given
 * converter section cannot be found then dpgERROR is returned, else
 * dpgSUCCESS is returned.
 */
int32 drcpFileSetConverter(drcpFile *file, char *convName) ;
#define drcpFileGetConverterName(file) ((file)->convName)

void drcpFileInitGeometry(drcpFile *file) ;
/* drcpFileFindSrcFile
 * 
 * Find a source file given the file name and parent file name (if any, can pass
 * NULL. If the source file name is not an absolute path then the file is looked
 * for relative to 1) the current directory, 2) the parents path, 3) the recipe
 * files source path
 */
char *drcpFileFindSrcFile(drcpFile *file, char *srcName, char *parName) ;

int32 drcpFileSetupOutputLocation(drcpFile *rcpFile, char *fileName, char *filePart, 
                                  char *outPath, char *outName, int32 crtPaths,
                                  char **outBasePath, int32 *outMidPath,
                                  char **outExtPath,  char **outBaseName) ;

/* drcpFileIdSourceFile
 * 
 * Uses the recipe files ID table to identify the given source file. The
 * source file must be able to be opened and read, if not dpgERROR is
 * returned. If the file is successfully identified then drcpFileIdSourceFile
 * calls drcpFileSetConverter with the appropriate converter name
 */
int32 drcpFileIdSourceFile(drcpFile *file, char *srcFileName) ;

/* drcpFileGetGeneralValue
 * drcpFileGetConverterValue
 * 
 * Looks up the given "var" in the recipe file.
 * 
 * drcpFileGetGeneralValue   - looks in the general section for "var"
 * drcpFileGetConverterValue - looks in the converter section for "var"
 *                             (see drcpFileSetConverter)
 * 
 * If found, returns a pointer to the actual value (i.e. don't free)
 * Else returns NULL
 */
char    *drcpGetValue(Registry *rr, char *var, char *def) ;
int32    drcpGetInt32Value(Registry *rr, char *name, int32 def) ;
float64  drcpGetFloat64Value(Registry *rr, char *name, float64 def) ;
#define  drcpGetFloat32Value(rr,name,def) \
              (float32) drcpGetFloat64Value(rr,name,(float64) def)
#define  drcpFileGetGeneralValue(file,var,def) \
              drcpGetValue(file->general,var,def)
#define  drcpFileGetGeneralInt32Value(file,var,def) \
              drcpGetInt32Value(file->general,var,def)
#define  drcpFileGetGeneralFloat32Value(file,var,def) \
              drcpGetFloat32Value(file->general,var,def)
#define  drcpFileGetGeneralFloat64Value(file,var,def) \
              drcpGetFloat64Value(file->general,var,def)
#define  drcpFileGetConverterValue(file,var,def) \
              drcpGetValue(file->converter,var,def)
#define  drcpFileGetConverterInt32Value(file,var,def) \
              drcpGetInt32Value(file->converter,var,def)
#define  drcpFileGetConverterFloat32Value(file,var,def) \
              drcpGetFloat32Value(file->converter,var,def)
#define  drcpFileGetConverterFloat64Value(file,var,def) \
              drcpGetFloat64Value(file->converter,var,def)
/*
 * drcpFileGetConverterUnit
 * 
 * Returns a conversion factor to convert a distance in the file units
 * to meters.
 * 
 * If the recipe unit setting is "Default" this is probably the internal
 * file unit and is file/converter specific, a value of -1.0 is returned.
 */
float64 drcpFileGetConverterUnit(drcpFile *file) ;

/* drcpFileOpimiseGeometry
 * 
 * Optimises the given geometry, both the pfile and the octree, according to
 * the settings of the given recipe file. The given octree can be NULL, all
 * geometry is first transfered to the octree for optimisation and then the
 * octree is unloaded to the pfile and free. Any geoemtry in hte octree must
 * be linked to a valid geogroup present in the pfile.
 * 
 * This function assumes that the given recipe file has already been
 * initialised for Goemetry optimisation by a previous call to
 * drcpFileSetConverter
 * 
 * matFile should be a material file in which to put any material map generated
 * materials.
 */
void drcpFileOpimiseGeometry(drcpFile *file, dpfFILEPTR pfile,
                             doOCTREEPTR octree) ;

/* drcpFilePrintLodInfo
 * 
 * Prints Lod generation stats for all files that the recipe file has been
 * used to optimise
 */
void drcpFilePrintLodInfo(drcpFile *file) ;

/* drcpFileTextureOctree
 * 
 * Textures the given octree as specified in the recipe file
 */
void drcpFileTextureOctree(Registry *reg, doOCTREEPTR octree);

#define   drcpFileGetFileName(file)        ((file)->fileName)

void drcpVersion(FILE *fp) ;

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif
#endif /* __DRCP_H */
