#ifndef _ECITEMINFO_H
#define _ECITEMINFO_H

#ifndef VDI_PARSE_H
#include "vdi_parse.h"
#endif

#ifndef _ECSMARTPTR_H
#include "ecsmartptr.h"
#endif


char * ECParseNameParameters(dParseFilePtr);


// lists of smart-pointers to base items.

DV_TEMPLATE_EXPORT template class DV_EXPORT STLPORT::list<ECBaseItemPtr>;

typedef  list<ECBaseItemPtr> _ECBaseItemPtrList;


class DV_EXPORT _ECItemInfo: public _ECBaseItem
{
    
public:
    _ECItemInfo(char *keyword);
    ~_ECItemInfo();
    static _ECItemInfo  *findParser(int id);
    static _ECBaseItem       *parse(dParseFilePtr IS, hierarchy *pH, int *parsedOk);
    static _ECBaseItem       *parse(ECUserData *ud);
    virtual int     parseFileStream(dParseFilePtr IS, _ECBaseItem *thisAttribute, hierarchy *pH) = 0;
    virtual int     parseFromUserData(_ECBaseItem *thisAttribute, ECUserData *userData) { return -1; }
    virtual _ECBaseItem *createItem(void) = 0;
    virtual bool	parseParameters(void) { return true; };
    virtual int         getId(void) const { return m_id;};
    virtual char *getIdString(void) const { return m_keyword;};
    void        callCallbacks(void);
    void    addCreateCallback(ECBaseItemPtr &itemToCall);
    void    addUpdateCallback(ECBaseItemPtr &itemToCall);
    void    addDeleteCallback(ECBaseItemPtr &itemToCall);
    void removeCreateCallback(ECBaseItemPtr &itemToCall);
    void removeUpdateCallback(ECBaseItemPtr &itemToCall);
    void removeDeleteCallback(ECBaseItemPtr &itemToCall);

private:
    static int addParser(_ECItemInfo *);
    static int removeParser(_ECItemInfo *);
    void callGlobalCallbacks(_ECBaseItemPtrList *itemList,
                             _ECBaseItemPtrList *addedList,
                             ecCallbackList *callList,
                             int callbackFlag);

    _ECBaseItemPtrList	m_cList;
    _ECBaseItemPtrList	m_addedCList;
    _ECBaseItemPtrList	m_uList;
    _ECBaseItemPtrList	m_addedUList;
    _ECBaseItemPtrList	m_dList;
    _ECBaseItemPtrList	m_addedDList;

    static list<_ECItemInfo *> 	m_attributeList;
    char 			       *m_keyword;
    int					m_id;
    static int				m_nextId;
    int					m_status;
};

typedef ECSmartPtr<_ECItemInfo> ECItemInfoPtr;
#endif
