/*
 * This class holds the materials for one manikin
 * 
 */

#ifndef _MANAPPEARANCE_HH
#define _MANAPPEARANCE_HH

/*****************************************************************************/
class DV_EXPORT _ECSwManAppearance;
// Update flags
#define manAPPEARANCE_UPDATE_SKIN 0x001
#define manAPPEARANCE_UPDATE_TROU 0x002
#define manAPPEARANCE_UPDATE_SHIR 0x004
#define manAPPEARANCE_UPDATE_SHOE 0x008
#define manAPPEARANCE_UPDATE_HEAD 0x010

// Parser tokens

#define DEF_TOKEN(a, b, c) a,
typedef enum{
    tSwManAprStartToken = 256,
#include "man_appearance_def.hh"
    tSwManAprEndToken
}SwManAppearanceToken;
#undef DEF_TOKEN 
class DV_EXPORT _ECSwManAppearance;
typedef ECSmartPtr<_ECSwManAppearance> ECSwManAppearancePtr;

class DV_EXPORT _ECSwManAppearanceInfo: public _ECItemInfo
{

public:
    _ECSwManAppearanceInfo(char *keyword);
    _ECBaseItem * createItem(void) ;
    int parseFileStream(dParseFilePtr, _ECBaseItem *, hierarchy *);

    void setDefaults( _ECSwManAppearance * ref);

    // %WAR:  Only the first default value is used for now!!!
     _ECSwManAppearance * getDefaults();
     static dvSwRetType init();

private:

    ECSwManAppearancePtr _default;

    friend void
    _ECSwManAppearanceInfoExitCallback(VCExit_CallbackData *callbackData, void *data);

};

extern _ECSwManAppearanceInfo ManAppearanceParser;

typedef ECSmartPtr<_ECSwManAppearanceInfo> ECSwManAppearanceInfoPtr;

class DV_EXPORT _ECSwManAppearance : public _ECBaseItem
{ 
    friend class  _ECSwManAppearanceInfo;
    void initValues();
    // implemented in man_appearance.cc

public:
    _ECSwManAppearance();
    _ECSwManAppearance(char *RootName);
    ~_ECSwManAppearance();

    void operator = (_ECSwManAppearance & app);

     // Generic query and set methods
    int getId(void) const;
    static int getMyId(void);
    char *getIdString(void) const; // %WAR: Abstract virtual from _ECBaseItem
    char *GetName() const {return _attributeName;};
    ECError SetName(char *newName);
    ECError SetNameNoCopy(char *newName);

    // Specific query and set methods
    static _ECSwManAppearance *getFromAssembly(ECAssembly *ass); 
    char *getManikinHandle() const {return _objectHandle;};
    char *getObjectHandle() const {return _objectHandle;};
    _ECAssembly *getThisAssembly() {return getManikinRootAssembly();};
    _ECAssembly *getManikinRootAssembly() ;

    const char * getSkinMaterial() {
	return _skinMaterial;};

    const char * getTrousersMaterial() {
	return (((_trousersMaterial != NULL) && 
		 (_trousersMaterial[0] != '\0')) ? 
		_trousersMaterial : _skinMaterial);
    };
    const char * getShirtMaterial() {
	return (((_shirtMaterial != NULL) && 
		 (_shirtMaterial[0] != '\0')) ?
		_shirtMaterial : _skinMaterial);
    };
    const char * getHeadMaterial() {
	return (((_headMaterial != NULL) && 
		 (_headMaterial[0] != '\0')) ? 
		_headMaterial : _skinMaterial);
    };
    const char * getShoeMaterial() {
	return (((_shoeMaterial != NULL) && 
		 (_shoeMaterial[0] != '\0')) ?
		_shoeMaterial : _skinMaterial);
    };

    const char * getSegmentMaterial(const int segId);
    const char * getSegmentMaterial(const char * segName);

    dvSwRetType setSkinMaterial(const char * matName );
    dvSwRetType setTrousersMaterial(const char * matName);
    dvSwRetType setShirtMaterial(const char * matName);
    dvSwRetType setHeadMaterial(const char * matName);
    dvSwRetType setShoeMaterial(const char * matName);

    // %HACK ahoy!!!
    // Load material libraries needed by the _ECSwManAppearance
    dvSwRetType loadMaterialLibraries();

    // I/O methods
    int writeVdiFile(); // %NOTE: The write method is member...
    // .. But the read method is a friend 
    // member of the class  _ECSwManAppearanceInfodefined above)

    //  Gets the defaults from the _ECSwManAppearanceInfo
    dvSwRetType getDefaults();

    // This one gets the bare-bone defaults, not those 
    // stored in the _ECSwManAppearanceInfo
    dvSwRetType getSystemDefaults();

    void setDefaults(_ECSwManAppearance * ref);

    void *getParseMethod(const char * segName);

private: 
    //dvSwRetType updateMaterials

    char * _objectHandle; // Safework name of THIS instance
    char * _attributeName; // Name of this attribute

    char * _skinMaterial;
    char * _trousersMaterial;
    char * _shirtMaterial;
    char * _headMaterial;
    char * _shoeMaterial;

    // Update callback for this (does the actual job instead of the class)
    _ECBaseItem::ECCallbackIterator _updateCallback;  
    friend void _ECSwManAppearanceCreateAssociationsCallback(ECCallbackInfo *info, void *data);

};

#endif
