/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: vwmacros.h,v $
 *    Revision:     $Revision: 1.6 $
 *    Date:         $Date: 2000/05/09 12:40:38 $
 *    Author:       $Author: jeff $
 *    RCS Ident:    $Id: vwmacros.h,v 1.6 2000/05/09 12:40:38 jeff Exp $
 *
 *    FUNCTION: Some widget macro functions to VC 
 * 
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _VWMACROS_H
#define _VWMACROS_H
#ifdef __cplusplus
extern "C" {
#endif

/*
 * Some VCEntity Utilities..
 */



#define VW_SubEntityMatrix(e) (e)->object->dmPos.pos


#define VW_EntityGetLocalPoint(e,p) dmPointFromMat(p, VW_SubEntityMatrix(e))
#define VW_EntityGetLocalScale(e,s) dmScaleFromMat(s, VW_SubEntityMatrix(e))
#define VW_EntityGetLocalEuler(e,o) dmEulerFromMat(o, VW_SubEntityMatrix(e))
#define VW_EntityGetLocalMat(e, m) dmMatCopy((m),VW_SubEntityMatrix(e))

#define VW_EntitySetLocalPos(e,p) VCEntity_SetPosition(e, p)
#define VW_EntitySetLocalMat(e,m) VCEntity_SetPositionMatrix((e), (m))
#define VW_EntitySetLocalScale(e,s) VCEntity_SetPositionScale(e, s)
#define VW_EntitySetLocalPoint(e,p) VCEntity_SetPositionPoint(e, p)
#define VW_EntitySetLocalEuler(e,o) VCEntity_SetPositionEuler(e, o)

#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /* _VW_MACROS_ */
