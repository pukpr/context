/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: vgtypes.h,v $
 *    Revision:     $Revision: 1.5 $
 *    Date:         $Date: 1999/03/22 16:26:21 $
 *    Author:       $Author: jeff $
 *    RCS Ident:    $Id: vgtypes.h,v 1.5 1999/03/22 16:26:21 jeff Exp $
 *
 *    FUNCTION: Generic VGizmos types and enumerations.
 * 
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _VGTypes_H
#define _VGTypes_H
#ifdef __cplusplus
extern "C" {
#endif

#ifndef VG_EXPORT
#if defined (_WIN32)  && !defined(_WINDU_SOURCE) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `VG_EXPORT'
 */
#ifdef  _LIB_VG
#define VG_EXPORT __declspec(dllexport) extern 
#else
#define VG_EXPORT __declspec(dllimport) extern 
#endif /* IN_A_DIVISION_LIB */
#else
#define VG_EXPORT  extern 
#endif /* ! _WIN32 */
#endif /* ifndef VC_EXPORT */



/* PUBLIC DEFINES =======================================*/

#define VG_DEBUG 0x2000
#define STDGZ_VIR_Z 0.05

typedef struct _VGizmo VGizmo;


typedef enum VGType {
    VG_ColourEditor = 1
}VGType;

typedef struct _VGArg {
        int		type;		/* type of event */
        void		*data;		/* event information */
} VGArg;

typedef void VGCallBack(VGizmo *, VWEventInfo *info, void *data);

struct _VGizmo {
    char	*name;
    VGType	gizmoType;
    VWidget	*toplevel;
    dmEuler	orient;
    dmPoint	origin;
    dmScale     size;
    uint32	active;
    void	*typedata;
}; /* VGizmo was prototyped earlier */

typedef struct _VGGizmoList {
    VGizmo		*gizmo;
    struct _VGGizmoList	*next;
} VGGizmoList;

enum  {
    VG_Origin = 0, 
    VG_Orientation,
    VG_Size
};

enum {
    VGCol_RedScalarValue = 100, 
    VGCol_GreenScalarValue, 
    VGCol_BlueScalarValue, 
    VGCol_SpecularScalarValue, 
    VGCol_UpdateCallBack, 
    VGCol_UpdateCallData, 
    VGCol_CancelCallBack, 
    VGCol_CancelCallData, 
    VGCol_AcceptCallBack, 
    VGCol_AcceptCallData, 
    VGCol_QuitCallBack, 
    VGCol_QuitCallData, 
    VGCol_TitleBarIcon, 
    VGCol_TitleBarIconSizeRatio,  
    VGCol_ColourMode
}; 


#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /* _VGTypes_H */
