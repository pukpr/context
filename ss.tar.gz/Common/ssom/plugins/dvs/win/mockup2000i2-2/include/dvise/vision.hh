#ifndef _VISION_HH
#define _VISION_HH

#ifndef _swapi_h

typedef float  Real,   *PtrReal;   /*  Real number  */
typedef int    Int,    *PtrInt;    /*  Integer (16 or 32 bits).  */    

typedef struct API_ManVis_t{
	Int ViewPointType;       /* Left : 1, Right 2, binocular 3,
				    ambinocular 4, stereo 5 */
	Int VisionWindowState;   /* 0:OFF, 1:ON */
	Int PeriphericContour;   /* 0:OFF, 1:ON */
	Int CentralSpot;         /* 0:OFF, 1:ON */
	Int BlindSpot;           /* 0:OFF, 1:ON */
	Int LineOfSight;         /* 0:OFF, 1:ON */
	Int PeriphericCone;      /* 0:OFF, 1:ON */
	Int CentralCone;         /* 0:OFF, 1:ON */
	Int BlindCone;           /* 0:OFF, 1:ON */
	Int VisionGridMesh;      /* 0:OFF, 1:ON */
	Int VisionGridNumbers;   /* 0:OFF, 1:ON */
	Real HorizontalMonocular;
	Real HorizontalAmbinocular;
	Real VerticalTop;
	Real VerticalBottom;
	Real Central;
	Real BlindHorizontalFOV;
	Real BlindVerticalFOV;
	Real BlindHorizontalPosition;
	Real BlindVerticalPosition;
	Real FocusDistance;
	Real PonctumProximum;
	Real PonctumRemotum;
	Real GridHorizontalLeft;
	Real GridHorizontalRight;
	Real GridVerticalTop;
	Real GridVerticalBottom;
	Real GridHorizontalIncrement;
	Real GridVerticalIncrement;
}API_ManVis, *PtrAPI_ManVis;

#endif
/*****************************************************************************/

class DV_EXPORT _ECSwManRegister;
typedef ECSmartPtr<_ECSwManRegister> ECSwManRegisterPtr;

/* This class will be instanced only once in the application (as a static
   global).  It will be an anchor for all instances of ECSwReachAndVision
   attributes.  The vdi parser can use this to know these attributes before one
   is created (through the keyword) and it also provides a short-cut to making
   ECSwReachAndVision attributes. */

class DV_EXPORT _ECSwReachAndVisionInfo: public _ECItemInfo
{
public:

					// Constructor.

    _ECSwReachAndVisionInfo(char *keyword) : _ECItemInfo(keyword){};


					// Create a ECSwReachAndVision
					// attribute (a short cut to new...).

    _ECBaseItem *createItem(void);


					// A vdi file reader that is called
					// when an attribute of type
					// ECSwReachAndVision is discovered.

    int parseFileStream(dParseFilePtr, _ECBaseItem *, hierarchy *);
};

typedef ECSmartPtr<_ECSwReachAndVisionInfo> ECSwReachAndVisionInfoPtr;

extern _ECSwReachAndVisionInfo SwReachAndVisionParser;


/******************************************************************************
  This class is the implementation of the dVISE Reach and vision attribute.
******************************************************************************/

					// Vision parameters' values.
typedef enum
{
    VisionConesOn,
    VisionConesOff

} SwVisionShow;


typedef enum
{
    VisionModelBinocular,
    VisionModelAmbinocular,
    VisionModelMonocularLeft,
    VisionModelMonocularRight

} SwVisionModel;


typedef enum
{
    VisionLineOfSightOn,
    VisionLineOfSightOff

} SwVisionLineOfSight;


typedef enum
{
    VisionCentralOn,
    VisionCentralOff

} SwVisionCentral;


typedef enum
{
    VisionPeripheralOn,
    VisionPeripheralOff

} SwVisionPeripheral;


typedef enum
{
    VisionBlindOn,
    VisionBlindOff

} SwVisionBlind;


					// Reach parameters' values.
typedef enum
{
    ReachEnvelopesOn,
    ReachEnvelopesOff

} SwReachShow;


typedef enum
{
    ReachLeftOn,
    ReachLeftOff

} SwReachLeft;

typedef enum
{
    ReachRightOn,
    ReachRightOff

} SwReachRight;


typedef enum
{
    SwVisionUpdate_None                               = 0x00000,
    SwVisionUpdate_Show				= 0x00001,
    SwVisionUpdate_Model			= 0x00002,
    SwVisionUpdate_LineOfSight			= 0x00004,
    SwVisionUpdate_Central			= 0x00008,
    SwVisionUpdate_Peripheral			= 0x00010,
    SwVisionUpdate_Blind			= 0x00020,
    SwVisionUpdate_VerticalTop			= 0x00040,
    SwVisionUpdate_VerticalBottom		= 0x00080,
    SwVisionUpdate_CentralAngle			= 0x00100,
    SwVisionUpdate_HorizontalMonocular		= 0x00200,
    SwVisionUpdate_HorizontalAmbinocular	= 0x00400,
    SwVisionUpdate_PonctumProximum		= 0x00800,
    SwVisionUpdate_FocalDistance		= 0x01000,
    SwVisionUpdate_PonctumRemotum		= 0x02000,

    SwReachUpdate_ReachShow			= 0x04000,
    SwReachUpdate_ReachLeft			= 0x08000,
    SwReachUpdate_ReachRight			= 0x10000,

    SwVisionUpdateFromPosture			= 0x20000

} _ECSwReachAndVisionUpdateFlags;



class DV_EXPORT _ECSwReachAndVision : public _ECBaseItem
{
public:

    /* Methods that overwrite virtual methods in the base class. */

					// Overloaded constructor for making
					// this attriubute when reading a
					// vdifile.
    _ECSwReachAndVision();

    ~_ECSwReachAndVision(void);		// Destructor.

    int		getId(void) const;
    static int	getMyId(void);
    char	*getIdString(void) const;


    // This function will be called by the delete operation and it allows all
    // the delete callbacks to be called cleanly before the attribute is freed.
    // We can just rely on the default one.

//    virtual void destroy();


    // These called to send the create and update callbacks for this class.  We
    // must call them whenever any of our data changes to inform dVISE.
    // Overwriting these functions here can be done to implement more specific
    // versions, but the default functions should just suit us.

//     virtual int _create(uint32 flags);
//     virtual int _update(uint32 flags);


    // Internal functions for manipulating this class when it is on a callback
    // list eg. it is updated, and then restored to its former state, so there
    // is no net change, this can be flagged as being of no interest to the
    // user by calling dontCallCallbacks().

//     virtual void callCallbacks(void);


    // We supply a function for writing this attribute to the vdi file.

    int		writeVdiFile();


    // This allows us to set the name of this attribute.  Nb. the 'no copy'
    // function won't strdup() the string passed in for efficiency, it will
    // just refer to it.

    ECError	SetName(char *);

    ECError	SetNameNoCopy(char *);

    char *getName() const
    {
	return (attribute_name);
    };


    // Get the update flags...???

//     virtual uint32 GetUpdateFlags(void) { return m_updateFlags; };


    /* Methods for the implementation of the reach and vision attribute. */


					// Overloaded constructor for making
					// the attribute based upon a SAFEWORK
					// manikin.

    _ECSwReachAndVision(char *manikin_handle);


    // Functions to access the data held by this attribute.

					// Vision show.

    dvSwRetType		set_vision_show(SwVisionShow);
    SwVisionShow	get_vision_show(void)
    {
	return (vision_show);
    };


					// Vision model.

    dvSwRetType		set_vision_model(SwVisionModel);
    SwVisionModel	get_vision_model(void)
    {
	return (vision_model);
    };


					// Line of sight.

    dvSwRetType		set_line_of_sight(SwVisionLineOfSight);
    SwVisionLineOfSight	get_line_of_sight(void)
    {
	return (line_of_sight);
    };


					// Central cone.

    dvSwRetType		set_central_cone(SwVisionCentral);
    SwVisionCentral	get_central_cone(void)
    {
	return (central_cone);
    };


					// Peripheral cone.

    dvSwRetType		set_peripheral_cone(SwVisionPeripheral);
    SwVisionPeripheral	get_peripheral_cone(void)
    {
	return (peripheral_cone);
    };


					// Blind cone.

    dvSwRetType		set_blind_cone(SwVisionBlind);
    SwVisionBlind	get_blind_cone(void)
    {
	return (blind_cone);
    };
                                       // Vertcal top.
 
     dvSwRetType               set_vertical_top(float32);
     float32           get_vertical_top(void)
     {
       return (vertical_top);
     };
 
 
                                       // Vertcal bottom.
 
     dvSwRetType               set_vertical_bottom(float32);
     float32           get_vertical_bottom(void)
     {
       return (vertical_bottom);
     };
 
 
                                       // Central angle.
 
     dvSwRetType               set_central_angle(float32);
     float32           get_central_angle(void)
     {
       return (central_angle);
     };
 
 
                                       // Horizontal monocular.
 
     dvSwRetType               set_horizontal_monocular(float32);
     float32           get_horizontal_monocular(void)
     {
       return (horizontal_monocular);
     };
 
 
                                       // Horizontal ambinocular.
 
     dvSwRetType               set_horizontal_ambinocular(float32);
     float32           get_horizontal_ambinocular(void)
     {
       return (horizontal_ambinocular);
     };
 
 
                                       // Ponctum proximum.
 
     dvSwRetType               set_ponctum_proximum(float32);
     float32           get_ponctum_proximum(void)
     {
       return (ponctum_proximum);
     };
 
 
                                       // Focal distance.
 
     dvSwRetType               set_focal_distance(float32);
     float32           get_focal_distance(void)
     {
       return (focal_distance);
     };
 
 
                                       // Ponctum remotum.
 
     dvSwRetType               set_ponctum_remotum(float32);
     float32           get_ponctum_remotum(void)
     {
       return (ponctum_remotum);
     };

					// Reach show.

    dvSwRetType		set_reach_show(SwReachShow);
    SwReachShow		get_reach_show(void)
    {
	return (reach_show);
    };

					// Reach left.

    dvSwRetType		set_reach_left(SwReachLeft);
    SwReachLeft		get_reach_left(void)
    {
	return (reach_left);
    };

					// Reach right.

    dvSwRetType		set_reach_right(SwReachRight);
    SwReachRight	get_reach_right(void)
    {
	return (reach_right);
    };


    // Functionality of this attribute.

					// Fly to a position to give a
					// representative view of what the
					// manikin can see.

    dvSwRetType		fly_to_manikins_view(VCBody *);



    // Functionality of this attribute to keep it in line with the manikin
    // definition.

    dvSwRetType		update_vision_segment_for_posture_change(void);
    dvSwRetType		update_reach_envelope_for_anthropometry_change(void);

    // methods to retrieve the assemblies
    _ECAssembly *get_visual_segment();
    int32 get_visual_segment_index(){ return _vision_segment_index;};
    _ECAssembly *get_reach_left_segment();
    int32 get_reach_left_segment_index(){ return _reach_left_segment_index;};
    _ECAssembly *get_reach_right_segment();
    int32 get_reach_right_segment_index(){ return _reach_right_segment_index;};

    /* Friends of this class. */

    // Make the parse method of _ECSwReachAndVisionInfo a friend of this
    // attribute class so that it can write into the private slots when
    // parsing.

    friend int	_ECSwReachAndVisionInfo::parseFileStream(dParseFilePtr,
							 _ECBaseItem *,
							 hierarchy *);

    // This one to setup the values from Safework and callbacks;
    friend void 
    _ECSwReachAndVisionCreateAssociationsCallback(ECCallbackInfo *info, 
						  void *data);
    friend void 
    _ECSwReachAndVisionUpdateCallback(ECCallbackInfo *info, void *data);

    char *getManikinHandle() {return _manikinHandle;};
    _ECAssembly *getManikinRootAssembly() ;
    static _ECSwReachAndVision *getFromAssembly(ECAssembly *ass);

protected:

private:

    void initProperties();

    /* These memebers of the class deal with making the geometry. */


					// A method for updating a vision
					// cone or reach envelope's visibility.

    dvSwRetType create_or_update_visual_attribute_visibility(_ECAssembly *,
				const char * const, ECVisual **, ECStateType);


					// A method to create or update the
					// line of sight's geometry.

    dvSwRetType create_or_update_line_of_sight_geometry(ECVisual *);


					// A method to create or update the
					// central cone's geometry.

    dvSwRetType create_or_update_central_cone_geometry(ECVisual *);


					// A method to create or update the
					// peripheral cone's geometry.

    dvSwRetType create_or_update_peripheral_cone_geometry(ECVisual *);


					// A method to create or update the
					// blind cone's geometry.

    dvSwRetType create_or_update_blind_cone_geometry(ECVisual *);



					// A method for updating the reach
					// envelope geometry.

    dvSwRetType create_or_update_reach_envelope_geometry(_ECAssembly *, ECVisual *);


                                        // A method for updating any vision
					// cone's geometry.

    dvSwRetType create_or_update_vision_cone_geometry(ECVisual *, dmVector,
				float32, float32, float32, float32,
				int, char *, char *);


					// A method for making the vertices
					// of a cone.

    dvSwRetType create_vision_cone_vertices(VCVertexXYZ **, dmVector,
					    float32, float32, float32, float32,
					    int);




    /* These members of this class are used in communicating changes in the
       vision parameters to and from SAFEWORK using SWAPI.  The safework_vision
       struct is kept here so that it doesn't require a call to SWAPI to set it
       up when only passing one parameter.  */


					// Struct to pass/get the parameters
					// to/from SAFEWORK.
    API_ManVis		safework_vision;


					// A method get the indices of the
					// segments that will be used to attach
					// the visual attributes to for the
					// reach envelopes and vision cones.
    dvSwRetType
    get_segment_indices_from_man_register(void);


					// A method to help with initialisation
					// that will set the vision parameters
					// in SAFEWORK to those that are in the
					// vision attribute.
    dvSwRetType
    sync_safework_vision(void);

					// Methods to help with passing
					// values to and from the
					// safework_vision SWAPI structure for
					// communicating with SAFEWORK.

    void vision_model_to_safework_vision(void);
    void vision_model_from_safework_vision(void);

    void line_of_sight_to_safework_vision(void);
    void line_of_sight_from_safework_vision(void);

    void central_cone_to_safework_vision(void);
    void central_cone_from_safework_vision(void);

    void peripheral_cone_to_safework_vision(void);
    void peripheral_cone_from_safework_vision(void);

    void blind_cone_to_safework_vision(void);
    void blind_cone_from_safework_vision(void);


					// Group geometry updates to avoid code
					// duplication.

    dvSwRetType	update_geometry_for_distance_change(void);


					// A simple range enforcing function.

    void	restrict_to_range(float32 &, float32, float32);


					// Methds to help in transmitting the
					// values between the safework_vision
					// structure and SAFEWORK.

    dvSwRetType		safework_vision_to_safework(void);
    dvSwRetType		safework_vision_from_safework(void);




					// The dVISE attribute name of this
					// attribute.

    char 		*attribute_name;


    char * _manikinHandle; // name of the manikin's root under Safework

    // pointer to the register entry
    //ECSwManRegisterPtr  thisRegister;


    int32 _vision_segment_index;
    int32 _reach_left_segment_index;
    int32 _reach_right_segment_index;

    /* Attribute parameters.  All the slots below this point are the main body
       of data stored and manipulated by the reach and vision attribute, these
       are the values manipulated by the GUI and saved in the vdifile. */


    // Vision parameters.

					// Vision toggles and options.
    SwVisionShow	vision_show;


    SwVisionModel	vision_model;


    SwVisionLineOfSight	line_of_sight;

    SwVisionCentral	central_cone;

    SwVisionPeripheral	peripheral_cone;

    SwVisionBlind	blind_cone;


					// Vision settings in degrees.
    float32		vertical_top;

    float32		vertical_bottom;

    float32		central_angle;

    float32		horizontal_monocular;

    float32		horizontal_ambinocular;


					// Vision settings in meters.
    float32		ponctum_proximum;

    float32		focal_distance;

    float32		ponctum_remotum;



    // Reach parameters.

					// Reach toggles and options.
    SwReachShow		reach_show;

    SwReachLeft		reach_left;

    SwReachRight	reach_right;
};


typedef ECSmartPtr<_ECSwReachAndVision> ECSwReachAndVisionPtr;

/*****************************************************************************/

#endif
