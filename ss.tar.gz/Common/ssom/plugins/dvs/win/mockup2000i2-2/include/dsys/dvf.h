/****************************************************************************
 *
 *  			Copyright 1995 Division Limited.
 *			      All Rights Reserved
 *
 *
 *  System        :
 *  Module        :
 *  Assembly Name   : $RCSfile: dvf.h,v $
 *  Revision      : $Revision: 1.34 $
 *  Date          : $Date: 2001/10/16 10:18:07 $
 *  Author        : $Author: anng $
 *  Last Modified : <011010.1008>
 *
 *  Description
 *
 *  Notes
 *
 *  History
 *
 ****************************************************************************
 *
 *  Copyright (c) 1995 Division Ltd.
 *
 *  All Rights Reserved.
 *
 *  This Document may not, in whole or in part, be copied,
 *  photocopied, reproduced, translated, or reduced to any
 *  electronic medium or machine readable form without prior
 *  written consent from Division Ltd.
 ****************************************************************************/

#ifndef __DVF_H__

#define __DVF_H__

#include <assert.h>
#include <dsys/dmd.h>
#include <dsys/dmap.h>
#include <dsys/dgl.h>
#include <dsys/drcp.h>
#include <dsys/pfile.h>

#ifdef __cplusplus
extern "C" {
#endif

/* vdifile error numbers */

void
dvfVersion(FILE *fp) ;

#define dvf_ASSEMBLY_TYPE        0x01     /* if flag bit set then ass in zone     */
#define dvf_PARENT_TYPE          0x02     /* if flag bit set then ass is parent   */
#define dvf_ASSEMBLY_LIB         0x04     /* if flag bit set ass is a library     */
#define dvf_ASSEMBLY_LOAD        0x08     /* if flag bit set ass is "Load=On"     */
#define dvf_ASSEMBLY_CAMERA      0x10     /* if flag bit set then add camera type */
#define dvf_ASSEMBLY_ANNOTATION  0x20     /* if flag bit set then add annotation type */

/* internal assembly flags */
#define dvf_ASSEMBLY_WRITE1      0x0100
#define dvf_ASSEMBLY_WRITE2      0x0200
#define dvf_ASSEMBLY_NOBGF       0x0400
#define dvf_ASSEMBLY_NOOL        0x0800

#define dvfFile_DISLIGHT         0x0001   /* if set then disable default lights   */
#define dvfFile_COLLIDE          0x0002   /* if set then make assembly collidable */
#define dvfFile_CONSTRAIN        0x0004   /* if set make assembly constrained     */
#define dvfFile_VDIVER6          0x0008   /* if set write v6 vdi files            */
#define dvfFile_SINGLESDD        0x0010   /* if set output single sided bgf geom  */
#define dvfFile_DOUBLESDD        0x0020   /* if set output double sided geom      */

#define dvfGEOGROUP_SOLID_FLAG   0x10000000
#define dvfGEOGROUP_QUILT_FLAG   0x20000000
#define dvfGEOGROUP_DATUM_FLAG   0x40000000
#define dvfGEOGROUP_WRITEN_FLAG  0x80000000
#define dvfGEOGROUP_TYPE_MASK    0x70000000

#define dvf_TABSIZE 2

#define dvfGEOMETRY_BOUNDARY_EDGE   1

typedef enum {
    dvfLIGHT_AMBIENT,
    dvfLIGHT_DIRECT,
    dvfLIGHT_POINT,
    dvfLIGHT_SPOT
} dvfLightTYPE ;
typedef enum {
    dvfSTATE_ON=0,
    dvfSTATE_OFF
} dvfSTATE ;
typedef enum {
    dvfKEYMODE_ABSOLUTE=0,
    dvfKEYMODE_RELATIVE
} dvfKEYMODE ;
typedef enum {
    dvfPATHLINEAR=0,
    dvfPATHCATMULLROM
} dvfPATHINTERPOLATION ;
typedef enum {
    dvfRENDERMODE_POLYGONAL=0,
    dvfRENDERMODE_WIREFRAME
} dvfRENDERMODE ;

typedef struct
{
    float32      halfangle ;
    float32      exponent ;
}  dvfLightCone ;

typedef struct
{
    /* lighting stuff */
    dvfLightTYPE lightType ;
    dvfSTATE     lightState ;
    dvfLightCone lightCone ; /* applies only to spotlights */
    dpfRGBA      lightColor ;
} dvfLight ;

typedef struct dvfEvent
{
    int32  flags ;
    char  *name ;
    char  *command ;
    struct dvfEvent *next ;
} dvfEvent ;

/* These attributes are needed for conversion of ComputerVision
 * product structure (_ps) files */
typedef enum {
    dvfATTRIBUTE_ASSY ,
    dvfATTRIBUTE_PROPERTY
} dvfATTRIBUTETYPE ;

typedef struct dvfAttribute
{
    dvfATTRIBUTETYPE type ;
    char * attribute ;
    char * attribute_name ;
    char * attribute_file ;
    struct dvfAttribute * next ;
} dvfAttribute ;

/* Structures needed for dVISE UserData */

/* enum for dVISE UserData types.  This not a complete list -- just what's
 * needed to support ProE user data. */
typedef enum {
    dvfUSERBOOL=0,
    dvfUSERINTEGER,
    dvfUSERFLOAT,
    dvfUSERTEXT,
    dvfUSERVECTOR
} dvfUserFieldTYPE ;


typedef struct
{
    char             * name ;
    dvfUserFieldTYPE   type ;
    union {
        float32 f ;
        char  * s ;
        int     i ;
        int     b ;
        float32 v[3];
    } value ;

} dvfUserField ;

typedef struct dvfUserData
{
    char               *name ;
    int32               nFields, nSet ;
    dvfUserField       *fields ;
    struct dvfUserData *next ;

} dvfUserData ;

#define dvfFrame_POSIT 0x01
#define dvfFrame_ORIEN 0x02
#define dvfFrame_SCALE 0x04

typedef struct dvfFrame
{
    float32  time ;
    int32    flags ;
    dmVector posit ;
    dmQuaternion orien ;
    dmVector scale ;
    struct dvfFrame *next ;
} dvfFrame ;

typedef struct
{
    float32     totalTime ;
    int32       loop ;
    dvfKEYMODE  mode ;
    dvfSTATE    state ;           /* if ON then start running */
    dvfPATHINTERPOLATION interpolation ;
    dvfFrame *frame_hd, *frame_tl ;
} dvfKeyFrame ;

#define dvfGeometry_Surface 0x01
#define dvfGeometry_Curve   0x02
#define dvfGeometry_GDT     0x03
#define dvfGeometry_Point   0x04
#define dvfGeometry_Text    0x05

typedef struct
{
    dmdPoint   point ;
    char      *text ;
    int32      noLines ;
    int32     *noPoints ;
    dmdPoint **points ;
} dvfGDT ;

typedef struct dvfGeometry
{
    struct dvfGeometry *next ;
    dpfGEOMETRYPTR      geometry ;
    union {
        dglSurface     *surface ;
        dglCurve       *curve ;
        dvfGDT         *gdt ;
    } u ;
    int32               type ;
    int32               layerDef ;
} dvfGeometry ;

typedef struct dvfGeogroup
{
    struct dvfGeogroup *next ;
    dvfGeometry        *geometry ;
    char               *name ;
    char               *matName ;
    uint32              solidNo ;
    uint8               vflag ;
} dvfGeogroup ;

typedef struct dvfLod
{
    struct dvfLod      *next ;
    dvfGeogroup        *geogroup ;
    float64             inDist ;
    float64             outDist ;
    dmdVector           reference ;
    dpfTRANSITION       transition ;
    uint8               referenceFlag ;
} dvfLod ;

typedef struct dvfAssembly
{
    /* Assembly name, library file name, template name and comment */
    char          *name ;
    char          *libName ;
    char          *comment ;
    char          *id ;
    char          *cadPath ;

    /* New field for file defining assembly */
    char          *fileName ;

    /* position in the world relative to parent */
    dmdMatrix      matrix ;

    /* visual info */
    char          *geomName ;
    dvfLod        *geomLod ;
    dvfSTATE       geomState ;         /* if ON then visible else invisble */
    dvfRENDERMODE  renderMode ;
    char          *geomFMat ;
    char          *geomBMat ;

    /* assembly is a key frame */
    dvfKeyFrame   *keyFrame ;

    /* Light setting of the assembly */
    dvfLight      *light ;

    /* Events for the assembly */
    dvfEvent      *events ;

    /* Attributes for the assembly */
    dvfAttribute  *attributes ;

    /* Pointer to dVISE User data for the assembly. Note that two assemblys
     * may point to the same piece of UserData. */
    dvfUserData   *dviseUserData ;

    /* Pointer to ed file properties for the assembly */
    dvfUserData   *edProps ;

    /* List of layer definitions used in ol files */
    int32          noLayerDef ;
    char         **layerName ;

    /* User data - do what you want with these.
     * Guaranteed to be initialised to 0s and NULLs
     */
    int32          userFlags ;
    void          *userData ;
    int32          userFlags2 ;
    void          *userData2 ;

    /* internal flags */
    int32               flags ;
    struct dvfAssembly *tempAss ;
    struct dvfAssembly *child_hd, *child_tl ;
    struct dvfAssembly *next, *assParent ;
    struct dvfFile     *fileParent ;
} dvfAssembly ;


typedef struct dvfFile
{
    drcpFile *rcpFile ;
    dmapFile *mapFile ;
    char     *srcName ;
    char     *srcPart ;
    char     *outPath ;
    char     *basePath ;
    int32     useMid ;
    char     *extPath ;
    char     *baseName ;
    char     *outFileName ;
    int32     dependCount ;
    char     *dependType ;
    char    **dependFile ;
    char    **dependRcp ;
    int32     useLibs ;
    int32     fullSubNames ;
    int32     filtMask ;
    int32     spltMask ;
    int32     mmapMask ;
    int32     type ;
    int32     skipFlag ;
    int32     noSkips ;
    int32    *skipTable ;

    int32     geomFileNo ;
    int32     drawFileNo ;
    int32     textFileNo ;
    int32     edLineNo ;
    uint32    solidNo ;
    uint32    quiltNo ;
    uint32    datumNo ;
    FILE     *fp ;
    dpfRGBA   bgColor ;
    int32     flags ;
    int32     tab ;
    char     *comment ;

    /* dVISE user data attached to vdifile. This is because assemblies within
     * the vdifile can share userdata nodes. */
    dvfUserData *dviseUserData_hd ;

    int32  userFlags ;
    void  *userData ;

    /* transformation information */
    int32     doOrien ;
    int32     doTrans ;
    dmdVector trans ;
    int32     doScale ;
    float64   origScale ;
    float64   unitScale ;
    float64   addmScale ;
    float64   scale ;

    /* vdi file inserts */
    char     *vdiMainIns ;
    char     *vdiLibIns ;
    char     *vdiAssIns ;
    char     *vdiTassIns ;

    /* url variables */
    int32     urlUse ;

    /* repository variables */
    char     *repositoryPath ;
    char     *repositoryFile ;

    /* resolution values */
    float64   chdRes ;
    float64   lenRes ;
    float64   curveThick ;

    dvfAssembly *rootLib ;
    dvfAssembly *rootAss ;
    dvfAssembly *defs_hd, *defs_tl ;
    dvfAssembly *zone_hd, *zone_tl ;
    dpfFILEPTR   matFile ;
} dvfFile ;


/* dvfNameCorrect
 *
 * Copies sname into dname, correcting any bad characters to '_'
 *        dname can been sname!
 */
void    dvfNameCorrect(char *dname, char *sname) ;


/* File setup and saving ****************************************************/
dvfFile *dvfFileCreate(void) ;
int32   dvfFileWriteFreeGeometry(dvfFile *file) ;
int32   dvfFileWrite(dvfFile *file) ;
void    dvfFileFree(dvfFile *file) ;
typedef void (*dvfFREECLIENTDATAFUNC)(void *) ;
extern  dvfFREECLIENTDATAFUNC dvfAssemblyFreeClientDataFunc ;
extern  dvfFREECLIENTDATAFUNC dvfAssemblyFreeClientData2Func ;

void    dvfFileSetBaseName(dvfFile *file, char *name) ;
#define dvfFileSetType(f,t)               ((f)->type = (t))
#define dvfFileSetBackGroundColor(f,c)    (dpfRGBACpy((f)->bgColor,c))
#define dvfFileDisableDefaultLighting(f)  ((f)->flags |= dvfFile_DISLIGHT)
#define dvfFileEnableAssemblyCollide(f)   ((f)->flags |= dvfFile_COLLIDE)
#define dvfFileEnableAssemblyConstrain(f) ((f)->flags |= dvfFile_CONSTRAIN)
#define dvfFileSetVdiVersion6(f)          ((f)->flags |= dvfFile_VDIVER6)
#define dvfFileSetOutputSingleSided(f)    ((f)->flags |= dvfFile_SINGLESDD)
#define dvfFileSetOutputDoubleSided(f)    ((f)->flags |= dvfFile_DOUBLESDD)

#define dvfFileGetRecipeFile(f)           ((f)->rcpFile)
#define dvfFileGetSourceFileName(f)       ((f)->srcName)
#define dvfFileGetSourceFilePart(f)       ((f)->srcPart)
#define dvfFileGetOutputBaseName(f)       ((f)->baseName)
#define dvfFileGetOutputFileName(f)       ((f)->outFileName)
#define dvfFileGetMaterialFile(f)         ((f)->matFile)
#define dvfFileGetRootAssembly(f)         ((f)->rootAss)
#define dvfFileGetRootLibrary(f)          ((f)->rootLib)
#define dvfFileGetChordResolution(f)      ((f)->chdRes)
float64 dvfFileGetScaledChordResolution(dvfFile *file) ;
#define dvfFileGetMaxLenResolution(f)     ((f)->lenRes)
float64 dvfFileGetScaledMaxLenResolution(dvfFile *file) ;
#define dvfFileTestUseLibraries(f)        ((f)->useLibs)
#define dvfFileGetSolidNo(f)              ((f)->solidNo)
#define dvfFileGetQuiltNo(f)              ((f)->quiltNo)
#define dvfFileGetDatumNo(f)              ((f)->datumNo)
#define dvfFileIncSolidNo(f)              ((f)->solidNo)++
#define dvfFileIncQuiltNo(f)              ((f)->quiltNo)++
#define dvfFileIncDatumNo(f)              ((f)->datumNo)++

int32 __dvfFileSkipEntity(dvfFile *file, int32 idno) ;
#define dvfFileSkipEntity(file,idno)                                            \
(((file)->noSkips > 0) ? __dvfFileSkipEntity(file,idno):0)
#define dvfFileIsFiltered(file,filterName)                                      \
(((file->mapFile == NULL) || (filterName == NULL) || (*filterName == '\0')) ?   \
 0:dmapFileIsFiltered(file->mapFile,filterName))
#define dvfFileGetSplitString(file,splitName)                                   \
(((file->mapFile == NULL) || (splitName == NULL) || (*splitName == '\0')) ?     \
 splitName:dmapFileGetSplitString(file->mapFile,splitName))

int32   dvfFileGetFilterMask(dvfFile *file) ;
int32   dvfFileGetSplitMask(dvfFile *file) ;
int32   dvfFileGetMapMask(dvfFile *file) ;
char   *dvfFileGetNextGeometryFileName(dvfFile *file) ;
char   *dvfFileGetNextDrawingFileName(dvfFile *file) ;
char   *dvfFileGetNextTextureFileName(dvfFile *file) ;
void    dvfFileSetComment(dvfFile *file, char *comment) ;

/* dvf URL support function, arguments are pointers to string pointer which must be set
 * to point to a string value. args are:
 *     source file conv - recipe converter name, e.g. proe etc.
 *     source file type - recipe URL value, typically urlAsm, urlPart or urlDraw
 *     source file path - substitute string %p
 *     source file name - substitute string %f
 *     instance - substitute string %i
 *     revision - substitute string %r
 */
typedef int32 (*dvfURLGETDEPENDENCYINFO)(char **,char **,char **,char **,char **,char **) ;
extern dvfURLGETDEPENDENCYINFO dvfUrlGetDependencyInfo ;
char   *dvfFileCreateSrcFileName(dvfFile *file, char *srcName, char *srcPart) ;
void    dvfFileAddDependency(dvfFile *file, char type, char *fileName,
                             char *partName, char *rcpName, dvfAssembly **vdiFile) ;
#define dvfFileAddInternalDependency(file,fileName,partName) \
            dvfFileAddDependency(file,'I',fileName,partName,NULL,NULL)
#define dvfFileAddExternalDependency(file,fileName,partName) \
            dvfFileAddDependency(file,'E',fileName,partName,NULL,NULL)
#define dvfFileAddTextureDependency(file,fileName) \
            dvfFileAddDependency(file,'T',fileName,NULL,NULL,NULL)

/* ASSEMBLY Functions ******************************************************/


dvfAssembly *dvfAssemblyCreate(void) ;
void    dvfAssemblyUnlink(dvfAssembly *assembly) ;

/* adding assembly to the hierarchy */
void    dvfFileAddLibrary(dvfFile *file, dvfAssembly *assembly) ;
void    dvfFileAddAssembly(dvfFile *file, dvfAssembly *assembly) ;
void    dvfAssemblyAddAssembly(dvfAssembly *parent, dvfAssembly *assembly) ;
/* dvfAssemblyFind
 *
 * Finds or creates an assembly withthe appropriate name branched off the
 * given parent which must not be NULL.
 *
 * This function copes with '/'s in names turning them into a hierarchy e.g.
 * dvfFindAssembly(root,"Level_1/Level_2/Leaf") ; will find or create
 * assemblies "Level_1", "Level_2" & "Leaf".
 */
dvfAssembly *
dvfAssemblyFind(dvfFile *file, dvfAssembly *parent, char *name) ;

dvfLod *
dvfAssemblyFindLod(dvfAssembly *ass, float64 inDist, float64 outDist,
                   dmdVector reference, dpfTRANSITION transition) ;

dvfGeogroup *
dvfAssemblyFindGeogroup(dvfAssembly *ass, dvfLod *lod, uint32 solidNo,
                        char *name, char *matName, uint8 vflag) ;
void
dvfAssemblyMergeAssemblyGeometry(dvfFile *file, dvfAssembly *ass1, dvfAssembly *ass2) ;

dvfGeometry *
dvfGeogroupCreateSurfaceGeometry(dvfFile *file, dvfGeogroup *geogroup, int32 layerDef,
                                 dglSurface *surface, dpfGEOMETRYPTR geometry) ;
dvfGeometry *
dvfGeogroupCreateCurveGeometry(dvfFile *file, dvfGeogroup *geogroup, int32 layerDef,
                               dglCurve *curve, dpfGEOMETRYPTR geometry) ;
dvfGeometry *
dvfGeogroupCreateTextGeometry(dvfFile *file, dvfGeogroup *geogroup, int32 layerDef,
                              dpfGEOMETRYPTR geometry) ;
dvfGeometry *
dvfGeogroupCreatePointGeometry(dvfFile *file, dvfGeogroup *geogroup, int32 layerDef,
                               dpfGEOMETRYPTR geometry) ;
dvfGeometry *
dvfGeogroupCreateGDTGeometry(dvfFile *file, dvfGeogroup *geogroup, int32 layerDef,
                             dmdPoint point, char *text) ;
void
dvfGDTGeometryAddLeaderLine(dvfGeometry *gdtGeometry, int32 noPoints, dmdPoint *points) ;

void
dvfGeometrySetResolution(dvfGeometry *geometry, float64 chordRes, float64 maxLenRes) ;
/* if file != NULL, this will scale the translation part of the matrix by the global scale factor */
void
dvfGeometryXformMat(dvfFile * file, dvfGeometry *geom, dmdMatrix mat, int32 norm);
dpfGEOMETRYPTR
dvfGeometryGetDpfGeometry(dvfFile *file, dvfGeometry *geom) ;
void
dvfGeometrySetDpfGeometry(dvfGeometry *geometry, dpfGEOMETRYPTR dpfGeom) ;

/* setting assembly information */
void    dvfAssemblySetName(dvfAssembly *assembly, char *name) ;
void    dvfAssemblySetId(dvfAssembly *assembly, char *id) ;
void    dvfAssemblySetCadPath(dvfAssembly *assembly, char *cadPath) ;
void    dvfAssemblySetComment(dvfAssembly *assembly, char *comment) ;
void    dvfAssemblySetGeometryName(dvfAssembly *assembly, char *name) ;
#define dvfAssemblySetGeometryState(a,s)  ((a)->geomState = s)
#define dvfAssemblySetRenderMode(a,m)     ((a)->renderMode = m)
void    dvfAssemblySetGeometryMaterial(dvfAssembly *assembly, char *fMatName,
                                       char *bMatName) ;
void    dvfAssemblySetLight(dvfAssembly *assembly, dvfLight *light) ;
void    dvfAssemblySetKeyFrame(dvfAssembly *assembly, dvfKeyFrame *keyFrame) ;
void    dvfAssemblySetMatrix(dvfFile *file, dvfAssembly *assembly, dmdMatrix mat) ;
void    dvfAssemblySetMatrix32(dvfFile *file, dvfAssembly *assembly, dmMatrix mat) ;
#define dvfAssemblySetLoad(a)             ((a)->flags |= dvf_ASSEMBLY_LOAD)
#define dvfAssemblySetCamera(a)           ((a)->flags |= dvf_ASSEMBLY_CAMERA)
#define dvfAssemblySetAnnotation(a)       ((a)->flags |= dvf_ASSEMBLY_ANNOTATION)
int32   dvfAssemblyAddLayerDef(dvfAssembly *assembly, char *layerName) ;
void    dvfAssemblyAddEdProperty(dvfFile *file, dvfAssembly *assembly,
                                 char * name, char * value) ;
void    dvfAssemblyXformMatGeometry(dvfFile * file, dvfAssembly *assembly, dmdMatrix mat);

/* Getting information back again */
#define dvfAssemblyGetName(a)             ((a)->name)
#define dvfAssemblyGetAssemblyParent(a)   ((a)->assParent)
#define dvfAssemblyGetFirstChild(a)       ((a)->child_hd)
#define dvfAssemblyGetLastChild(a)        ((a)->child_tl)
#define dvfAssemblyGetNext(a)             ((a)->next)
#define dvfAssemblyGetFileParent(a)       ((a)->fileParent)
#define dvfAssemblyGetGeometryName(a)     ((a)->geomName)
#define dvfAssemblyGetFirstLod(a)         ((a)->geomLod)
#define dvfAssemblyGetLight(a)            ((a)->light)
#define dvfAssemblyGetMatrix(a,m)         dmdMatCopy(m,(a)->matrix)
#define dvfAssemblyGetGeometryState(a)    ((a)->geomState)
#define dvfAssemblyGetRenderMode(a)       ((a)->renderMode)
#define dvfAssemblyHasGeometry(a)         ((a)->geomLod != NULL)
/* These functions return 1 if a color, point, orientation, scale
 * respectively are set to default values, zero otherwise. */
int32   dvfColorTestDefault(dpfRGBA col) ;
int32   dvfPositionTestDefault(dmdPoint point) ;
int32   dvfOrientationTestDefault(dmdEuler orien) ;
int32   dvfScaleTestDefault(dmdScale scale) ;

void    dvfAssemblySetAssemblyInstance(dvfAssembly *ass, dvfAssembly *instAss) ;
void    dvfAssemblyAddFileInstance(dvfFile *file, dvfAssembly *assembly,
                                   char *fileName, char *filePart, char *rcpFile) ;
#define dvfAssemblySetFileInstance(file,assembly,fileName,filePart) \
dvfAssemblyAddFileInstance(file,assembly,fileName,filePart,NULL)

int32   dvfAssemblyWriteFreeGeometry(dvfFile *file, dvfAssembly *assembly) ;
void    dvfAssemblyFreeGeometry(dvfAssembly *assembly) ;
void    dvfAssemblyFree(dvfAssembly *assembly) ;
/* Dont use the following as it doesnt up-date pointers */
void    dvfAssemblyFreeList(dvfAssembly *assembly) ;

/* Geometry Functions *******************************************************/

#define dvfLodGetNext(l)               ((l)->next)
#define dvfLodGetFirstGeogroup(l)      ((l)->geogroup)
#define dvfGeogroupGetNext(g)          ((g)->next)
#define dvfGeogroupGetFirstGeometry(g) ((g)->geometry)
#define dvfGeometryGetNext(g)          ((g)->next)

/* KeyFrame Functions *******************************************************/
dvfKeyFrame *dvfKeyFrameCreate(void) ;
#define dvfKeyFrameGetState(k)         ((k)->state)
#define dvfKeyFrameSetState(k,s)       ((k)->state = s)

#define dvfKeyFrameGetMode(k)          ((k)->mode)
#define dvfKeyFrameSetMode(k,m)        ((k)->mode = m)

#define dvfKeyFrameGetInterpolation(k)   ((k)->interpolation)
#define dvfKeyFrameSetInterpolation(k,m) ((k)->interpolation = m)

#define dvfKeyFrameGetLoop(k)          ((k)->loop)
#define dvfKeyFrameSetLoop(k,l)        ((k)->loop = l)

#define dvfKeyFrameGetTotalTime(k)     ((k)->totalTime)
#define dvfKeyFrameSetTotalTime(k,t)   ((k)->totalTime = t)

dvfFrame *dvfFrameCreate(void) ;
#define dvfFrameSetTime(f,t)         ((f)->time = t)
void    dvfFrameSetPosition(dvfFrame *f, dmVector p) ;
void    dvfFrameSetOrientation(dvfFrame *f, dmQuaternion q) ;
void    dvfFrameSetScale(dvfFrame *f, dmVector s) ;
void    dvfKeyFrameAddFrame(dvfKeyFrame *keyFrame, dvfFrame *frame) ;

/* Light Functions **********************************************************/
dvfLight *dvfLightCreate(void) ;

#define dvfLightGetType(l)        ((l)->lightType)
#define dvfLightGetState(l)       ((l)->lightState)
#define dvfLightGetColor(l,c)     (dpfRGBCpy(c,(l)->lightColor))

#define dvfLightSetType(l,t)      ((l)->lightType = t)
#define dvfLightSetState(l,s)     ((l)->lightState = s)
#define dvfLightSetColor(l,c)     (dpfRGBACpy((l)->lightColor,c))
#define dvfLightSetCone(l,a,e)    ((l)->lightCone.halfangle=(a),(l)->lightCone.exponent=(e))

/* Event Functions **********************************************************/
dvfEvent *dvfEventCreate(void) ;
void    dvfAssemblyAddEvent(dvfAssembly *assembly, dvfEvent *event) ;
void    dvfEventSetName(dvfEvent *event, char *name) ;
void    dvfEventSetCommand(dvfEvent *event, char *com) ;

/* Attribute Functions ******************************************************/
dvfAttribute *dvfAttributeCreate(dvfATTRIBUTETYPE type,
                                 char * attribute ,
                                 char * attribute_name ,
                                 char * attribute_file ) ;

void    dvfAssemblyAddAttribute(dvfAssembly *assembly, dvfAttribute *attr) ;

void    dvfAttributeFreeList(dvfAttribute *attr) ;

/* dVISE User data functions ************************************************/

dvfUserData *dvfUserDataCreate(dvfFile *vdifile, int32 nfields) ;

void    dvfAssemblySetUserData(dvfAssembly *assembly, dvfUserData *udata) ;

void    dvfUserDataSetName(dvfUserData *ud, char * name) ;
void    dvfUserDataSetInteger(dvfUserField *uf, char * fieldName, int32 value) ;
void    dvfUserDataSetFloat(dvfUserField *uf, char * fieldName, float32 value) ;
void    dvfUserDataSetText(dvfUserField *uf, char * fieldName, char * value) ;
void    dvfUserDataSetBool(dvfUserField *uf, char * fieldName, int32 value) ;
void    dvfUserDataSetVector(dvfUserField *uf, char * fieldName, float32 value[3]) ;


/* Find assembly utilities **************************************************/
dvfAssembly *dvfFileFindUseLibrary(dvfFile *vdiFile, char *libname) ;

dvfFile *dvfFileInit(char *rcpName, char *convName, char *fileName,  char *filePart,
                     char *outName, char *outPath) ;

/* dvfFileSetSourceFileUnitConversion
 *
 * Set the current source file unit to meter conversion factor. this is used
 * by the dvfFileSetModify when modifying vertex points.
 */
void    dvfFileSetSourceFileUnitConversion(dvfFile *file, float64 scale) ;
/* dvfFileSetSourceFileScale
 *
 * Adds an additional scaling factor to be used by the dvfFileSetModify when
 * modifying vertex points.
 */
void    dvfFileSetSourceFileScale(dvfFile *file, float64 scale) ;
#define dvfFileGetSourceFileScale(f)    ((f)->scale)

int32 dvfColorTestDefault(dpfRGBA col) ;
int32 dvfPositionTestDefault(dmdPoint point) ;
int32 dvfOrientationTestDefault(dmdEuler orien) ;
int32 dvfScaleTestDefault(dmdScale scale) ;
int32 dvfMatrixTestDefault(dmdMatrix mat) ;

#ifdef __cplusplus
}
#endif

#endif /* __DVF_H__ */
