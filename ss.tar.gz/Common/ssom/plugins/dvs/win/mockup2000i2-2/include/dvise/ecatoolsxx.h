#include <dvise/eclist.h>
#include <dvise/ecassembly.h>
#include <dvise/ecclipboarditemptr.h>
DV_EXPORT ECItemListPtr ECBody_GetSelectionList(ECBody *body);
DV_EXPORT ECItemListPtr *ECLimb_GetSelectListPtr(ECLimb *limb);

