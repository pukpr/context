/****************************************************************************
 *
 *  			Copyright 1995 Division Limited.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Assembly Name   : $RCSfile: vwmbox.h,v $
 *  Revision      : $Revision: 1.4 $
 *  Date          : $Date: 1997/04/22 12:34:01 $
 *  Author        : $Author: simon $
 *  Last Modified : <220497.1125>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 *  $Log: vwmbox.h,v $
 *  Revision 1.4  1997/04/22 12:34:01  simon
 *  *** empty log message ***
 *
 *  Revision 1.3  1996/10/08 14:01:27  alex
 *  Tidies up the widget header file interface.
 *  Added some (incomplete) support for toolbox positioning.
 *  Added support for 'Context Sensitive' Area and callbacks around a widget.
 *  Fixed bug with re-sizeing a form widget via the draggable sash widget.
 *
 *  Revision 1.2  1996/09/10 16:06:04  simon
 *  *** empty log message ***
 *
 *  Revision 1.1.1.1  1996/07/25 16:05:48  alex
 *  Initial import of VWidgets
 *
 *  Revision 1.1.1.1  1996/07/24 15:01:44  alex
 *  Initial version we hope.
 *
 *
 ****************************************************************************
 *
 *  Copyright (c) 1995 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 *  This Document may not, in whole or in part, be copied,
 *  photocopied, reproduced, translated, or reduced to any
 *  electronic medium or machine readable form without prior
 *  written consent from Division Ltd.
 ****************************************************************************/

#ifndef _VWMBOX_H_
#define _VWMBOX_H_
#ifdef __cplusplus
extern "C" {
#endif

#include "vwidgets.h"
/* PUBLIC FUNCTIONS ======================================*/
/* PUBLIC TYPES ===========================================*/

enum {
    VWrAcceptIconVisual = VW_RESOURCES_MSGBOX, 
    VWrAcceptIconMaterial,
    VWrCancelIconVisual, 
    VWrCancelIconMaterial,
    VWrDialogTitleIconVisual,
    VWrDialogTitleIconMaterial,
    VWrMessageIconVisual,
    VWrMessageIconMaterial
};


VW_EXPORT VWidget *VWMessageBox_CreateManaged(VWidget *Parent, char *name, VWArg args[], int argc);
VW_EXPORT VWidget *VWMessageBox_Create(VWidget *Parent, char *name, VWArg args[], int argc);
VW_EXPORT void VWMessageBox_AddAcceptCallback(VWidget *MBoxWig, VWCallback *callback, void *calldata);
VW_EXPORT void VWMessageBox_RemoveAcceptCallback(VWidget *MBoxWig, VWCallback *cb, void *cd);
VW_EXPORT void VWMessageBox_RemoveAllAcceptCallbacks(VWidget *MBoxWig);
VW_EXPORT void VWMessageBox_AddCancelCallback(VWidget *MBoxWig, VWCallback *callback, void *calldata);
VW_EXPORT void VWMessageBox_RemoveCancelCallback(VWidget *MBoxWig, VWCallback *cb, void *cd);
VW_EXPORT void VWMessageBox_RemoveAllCancelCallbacks(VWidget *MBoxWig);
VW_EXPORT void VWMessageBox_AddQuitCallback(VWidget *MBoxWig, VWCallback *callback, void *calldata);
VW_EXPORT void VWMessageBox_RemoveQuitCallback(VWidget *MBoxWig, VWCallback *cb, void *cd);
VW_EXPORT void VWMessageBox_RemoveAllQuitCallbacks(VWidget *MBoxWig);
VW_EXPORT void VWMessageBox_SetMessageIconVisual(VWidget *MBoxWig, char *geomName);

#ifdef __cplusplus
}
#endif /* _cplusplus */

#endif /* _VWMBOX_H_ */
