//-*-C++-*-
#ifndef _ECASSSEMBLY_H
#define _ECASSSEMBLY_H

#ifndef _DM_H
#include <dsys/dm.h>
#endif

#ifndef _ECSMARTPTR_H
#include "ecsmartptr.h"
#endif

class DV_EXPORT _ECAssembly;

typedef struct ECAssembly ECAssembly;

					// This is included to define the flags
					// for the _ECAssembly update
					// callbacks.
#ifndef _ECASSEMBLY_UPDATE_FLAGS_H
#include "ecassembly_update_flags.h"
#endif

// flags from 0x01000000 onwards reserved for specific assembly type callbacks
// Note: if mutually exclusive then duplication is allowed
// ECASSEMBLY_GROUP special updates
#define ECASSEMBLY_UPDATE_GROUP_TYPE            0x01000000

// EC_ASSEMBLY_DVSW_MANIKIN_CONSTRAINT special updates
#define ECASSEMBLY_UPDATE_IKCONSTRAINT_MOVEMENT 0x01000000

// EC_ASSEMBLY_SECTION special updates
#define ECASSEMBLY_UPDATE_SECTION_STATE         0x01000000
#define ECASSEMBLY_UPDATE_SECTION_2DVIEW        0x02000000

class DV_EXPORT _ECAssembly: public _ECBaseItem
{
    friend class ECSmartPtr<_ECAssembly>;

protected:
     _ECAssembly();
     _ECAssembly(const _ECAssembly &);
    ~_ECAssembly();

public:
    static int getMyId();

    static ECCallbackIterator attachGlobalCreateCallback(ecGlobalCallbackFunc func, void *data);
    static ECCallbackIterator attachGlobalUpdateCallback(ecGlobalCallbackFunc func, void *data);
    static ECCallbackIterator attachGlobalDeleteCallback(ecGlobalCallbackFunc func, void *data);
    static void detachGlobalCreateCallback(ECCallbackIterator iter);
    static void detachGlobalUpdateCallback(ECCallbackIterator iter);
    static void detachGlobalDeleteCallback(ECCallbackIterator iter);

    static _ECAssembly        *create();

    virtual void          setAssembly(ECAssembly *assembly) = 0;
    virtual ECAssembly   *getAssembly(void) const = 0;

        //This is the one that gets saved in ECFiles...
    virtual void      SetECPosOrScale(const dmPoint p,
                                      const dmEuler e,
                                      const dmScale s) = 0;

        //This sets the VC level stuff, but adds callbacks to get called
        //on this items. nasty hack, I',m afraid.
    virtual void SetTransientPosition(dmMatrix) = 0;
};



DV_TEMPLATE_EXPORT template class DV_EXPORT ECSmartPtr<_ECAssembly>;
class DV_EXPORT ECAssemblyPtr: public  ECSmartPtr<_ECAssembly>
{
public:
    ECAssemblyPtr()                      :ECSmartPtr<_ECAssembly>(){};
    ECAssemblyPtr(_ECBaseItem* s)        :ECSmartPtr<_ECAssembly>(s){};
    ECAssemblyPtr(const ECBaseItemPtr& s):ECSmartPtr<_ECAssembly>(s){};
    ECAssemblyPtr(const ECAssemblyPtr& s):ECSmartPtr<_ECAssembly>(s){};
};


DV_TEMPLATE_EXPORT template class DV_EXPORT ECAutoNullingPtr<ECAssemblyPtr>;
typedef ECAutoNullingPtr<ECAssemblyPtr> ECAssemblyNullingPtr;



DV_EXPORT ECAssemblyPtr ECAssembly_GetAssemblyPtr(ECAssembly *assembly);

DV_EXPORT ECAssemblyPtr ECAssembly_GetOrigAssemblyPtr(ECAssembly *assembly);
DV_EXPORT int ECAssembly_SetOrigAssemblyPtr(ECAssembly *assembly, ECAssemblyPtr assemblyPtr);
DV_EXPORT void ECAssemblyTree_RemoveOrigAssembly(ECAssembly *assembly);

#endif
