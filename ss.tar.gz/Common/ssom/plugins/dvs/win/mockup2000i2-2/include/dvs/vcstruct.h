
struct VCActorConfig
{
    char *actorName;
    char *domainName;
    char *domainExtName;
    char *logName;
    int32 actorId;
    int32	 startProcessor;
    int32	 endProcessor;
    int32	 verboseLevel;
    FILE *fpLog;
};

struct VCBodyCreate_CallbackData
{
    VCBody		*body;
};

struct VCBodyDelete_CallbackData
{
    VCBody		*body;
};

struct VCBodyAttribute_CallbackData
{
    VCBody		*body;
    VCAttribute		*bodyPart;
    VCAttribute		*attribute;
};

struct VCBodyPartCreate_CallbackData
{
    VCBody		*body;
    VCAttribute		*bodyPart;
};

struct VCBodyPartDelete_CallbackData
{
    VCBody		*body;
    VCAttribute		*bodyPart;
};

struct VCTimer_CallbackData
{
    uint32		 dummy;
};


struct VCExit_CallbackData
{
    uint32		 dummy;
};

struct VCGroup_CallbackData
{
    uint32		 operation;
};



struct VCBodyInput_CallbackData
{
    VCBody 	*body;
    VCAttribute	*bodyPart;
    uint32	 keyCode;
};

struct VCBodyCollision_CallbackData
{
    VCBody 	*body;
    VCAttribute	*bodyPart;
    VCCollision	*collision;
};
struct VCBodyScreenIntersection_CallbackData
{
    VCBody 		*body;
    VCAttribute		*bodyPart;
    VCIntersection	*intersection;
};

struct VCInput_UpdateCallbackData
{
    VCInput	*input;
/*
    VCAttribute	*inputResource;
*/
    uint32	 keyCode;
};

struct VCInput_CallbackData
{
    VCInput	*input;
/*

    VCAttribute	*inputResource;
    uint32	 keyCode;
*/
};


struct VCEntityRelocate_CallbackData
{
    VCEntity		*entity;
    VCPositionData	*pos;
    uint32		 flags;
};

struct VCEntityInvalid_CallbackData
{
    VCEntity		*entity;
};

struct VCAttributeRelocate_CallbackData
{
    VCEntity		*entity;
    int32		 index;
    VCAttribute 	*attribute;
    VCPositionData 	*pos;
    uint32		 flags;
};

struct VCEntityAttribute_CallbackData
{
    VCEntity	 	*entity;
    int32		 index;
    VCAttribute 	*attribute;
};

struct VCAttribute_CallbackData
{
    VCAttribute 	*attribute;
};

struct VCCollision_CallbackData
{
    VCCollision		*collision;
};

struct VCIntersection_CallbackData
{
    VCIntersection	*intersection;
};

struct VCMaterial_CallbackData
{
    VCMaterial		*material;
};

struct VCCollisionSet_CallbackData
{
    VCCollisionSet	*collisionSet;
};

struct VCCollisionRequestState_CallbackData
{
    VCCollisionRequestState	*collisionRequestState;
};

struct VCCollisionRequestReport_CallbackData
{
    VCCollisionRequestReport	*collisionRequestReport;
};

struct VCCollisionRequest_CallbackData
{
    VCCollisionRequest	*collisionRequest;
};

struct VCSearchPath_CallbackData
{
    VCSearchPath	*searchPath;
};

struct VCRadiator_CallbackData
{
    VCRadiator		*radiator;
};

struct VCXWindowId_CallbackData
{
    VCXWindowId		*xwindowId;
};

struct VCWindow_CallbackData
{
    VCWindow		*window;
};

struct VCVisualViewResource_CallbackData
{
    VCVisualViewResource	*view;
};

struct VCVisualBoundingBox_CallbackData
{
    VCVisualBoundingBox		*boundingBox;
};

struct VCVisualSourceResource_CallbackData
{
    VCVisualSourceResource	*src;
};

struct VCSectionBounds_CallbackData
{
    VCSectionBounds *bounds;
};

struct VCPseudoGravity_CallbackData
{
    VCPseudoGravity	*pseudoGravity;
};

struct VCResourceAllocate_CallbackData 
{
    char 		*name;
};


struct VCPosition_CallbackData
{
    VCPosition		*position;
};

struct VCTracker_CallbackData
{
    VCTracker		*tracker;
};

struct VCSync_CallbackData
{
    VCSync		*sync;
};

struct VCCollideMonitor_CallbackData
{
    VCCollideMonitor	*collideMonitor;
};

struct VCTrackerMonitor_CallbackData
{
    VCTrackerMonitor	*trackerMonitor;
};

struct VCVisualMonitor_CallbackData
{
    VCVisualMonitor	*visualMonitor;
};

struct VCTexture_CallbackData
{
    VCTexture		*texture;
};

struct VCTextureImage_CallbackData
{
    VCTextureImage	*textureImage;
};

struct VCVisualScreenDump_CallbackData
{
    VCVisualScreenDump	*visualScreenDump;
};

struct VCSectionImageSave_CallbackData
{
    VCSectionImageSave	*sectionImageSave;
};

struct VCAudioRecord_CallbackData
{
    VCAudioRecord	*audioRecord;
};

struct VCRamp_CallbackData
{
    VCRamp		*ramp;
};

typedef struct 
{
    uint32   debug;
    char *nameExt;
    int	  logging;
    char *logExt;
    char *domainName;
    uint32   verboseLevel;
    int		startProc;
    int		endProc;
}VCCommandLineOptions ;


struct VCEntityDrop_CallbackData
{
    VCBody 		*body;
    VCAttribute		*bodyPart;
    VCEntity		*droppedEntity;
    VCEntity		*movedEntity;
    int			 mode;
};

/* Hoppy, 11/07/98 */
/* XXXX Need this??  */
struct VCEntityDeselect_CallbackData
{
    VCBody 		*body;
    VCAttribute		*bodyPart;
    VCEntity		*deselectedEntity;
    VCEntity		*movedEntity;
    int			 mode;
};

struct VCEntityIntersection_CallbackData
{
    VCEntity		*intersectingEntity;
    VCEntity		*intersectedEntity;
    VCIntersection	*intersection;
    int			 mode;
};

struct VCEntityDelete_CallbackData
{
    VCEntity		*entity;

};


struct VCActorResource_CallbackData
{
    VCActorResource		*actorResource;
};



typedef enum VCMaterialFileType
{
    VC_MATERIAL_FILE_TYPE_MATERIAL,
    VC_MATERIAL_FILE_TYPE_TEXTURE,
    VC_MATERIAL_FILE_TYPE_RAMP,
    VC_MATERIAL_FILE_TYPE_ANY
} VCMaterialFileType;

typedef struct VCMaterialFileData VCMaterialFileData;

struct VCMaterialFileData
{
    VCMaterialFileType type;
    char *name;
    void *data;
    VCMaterialFileData *next;
};

typedef struct VCMaterialFile
{
    VCMaterialFileData *data;
} VCMaterialFile;


typedef struct VCMaterialFile_Traverse
{
    VCMaterialFileType type;
    char *name;
    VCMaterialFileData *current;
} VCMaterialFile_Traverse;




