/****************************************************************************
 *
 *  			Copyright 1995 Division Limited.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: __pfile.h,v $
 *  Revision      : $Revision: 1.5 $
 *  Date          : $Date: 1999/05/12 11:36:25 $
 *  Author        : $Author: bill $
 *  Last Modified : <100599.0822>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 ****************************************************************************
 *
 *  Copyright (c) 1995 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 *  This Document may not, in whole or in part, be copied,
 *  photocopied, reproduced, translated, or reduced to any
 *  electronic medium or machine readable form without prior
 *  written consent from Division Ltd.
 ****************************************************************************/

#ifndef ____PFILE_H__
#define ____PFILE_H__

#ifndef DPF_EXPORT
#if defined (_WIN32) && !defined(BUILD_STATIC)
#ifdef _PF_LOCAL
#define DPF_EXPORT __declspec(dllexport) extern
#else
#define DPF_EXPORT __declspec(dllimport) extern
#endif
#else
#define DPF_EXPORT extern
#endif
#endif

#include <dsys/du.h>
#include <dsys/filelib.h>
#include <dsys/pfparser.h>

#include "pfile.h"

#ifdef __cplusplus
extern "C" {
#endif


/* Constant ID strings */
#define dpfBIZIDstrLen 31
#define dpfBIZIDstr    "biz v1.0 (c) DIVISION Ltd 1992"
#define dpfVIZIDstr    "/* viz v1.0 (c) DIVISION Ltd 1992 */\n"

#define dpfB2ZIDstrLen  8
#define dpfB2ZIDstr     "DIV-BIZ2"
#define dpfV2ZIDstrLen  8
#define dpfV2ZIDstr     "DIV-VIZ2"
#define dpfBMFIDstrLen  8
#define dpfBMFIDstr     "DIV-BMF2"
#define dpfVMFIDstrLen  8
#define dpfVMFIDstr     "DIV-VMF2"

/* ver   change 
 * 2.00  Initial pfile version 
 * 2.01  Replairs to pmesh tag and section length tests 
 * 2.02  pmesh extended to have polygons of upto 255 faces 
 * 2.03  boundary information added 
 * 2.04  Line definition change, can now be textured cooked & normalized 
 * 2.05  Introduction of material libraries 
 * 2.06  pgeneral way of doing things 
 * 2.07  STRIP_LISTs and POINTLISTs added to format 
 * 2.08  ENVIRONMENT added back to materials 
 * 2.8.1 New Reduce utility and Xbgftool suppot 
 * 2.8.2 dgp -> dpg, rm progname, use divvers 
 * 2.8.3 Patch -> Geogroup
 * 3.8.4 3.1 release upgraded on 14/3/96
 */
#define dpf_LIBRARY_MAJOR_VER 2 
#define dpf_LIBRARY_MINOR_VER 8
#define dpf_LIBRARY_VER_STR   "2.8.4"

#define dpfSTDINName   "Std In"
#define dpfSTDOUTName  "Std Out"

/* new biz v2 max depth constant */
#define dpf_MAX_DEPTH 10

/* load in basic types, struct names and procedure heading which
** can be externally called.
*/

#define dpfVBLKSIZE 1024

DPF_EXPORT uint8 dpfVERTFLAG ;
DPF_EXPORT uint8 dpfVERTSIZE ;
DPF_EXPORT uint8 dpfVERTNORM ;
DPF_EXPORT uint8 dpfVERTRGBA ;
DPF_EXPORT uint8 dpfVERTTEXT ;
DPF_EXPORT uint8 dpfVERTOVER ;

/* Now define all the internal structures */
typedef int32 dpfTOKEN ;

/* The following is for the new wizzy v1.0 -> v2.0 texture converter */ 
typedef struct dpfVISTEXTURETYPE
{
    char *visName ;
    char *F_textName, *F_textMap ;
    char *B_textName, *B_textMap ;
    
    struct dpfVISTEXTURETYPE *next ;
} dpfVISTEXTURE ;


typedef struct dpfSTRINGTYPE
{
    int32 length ;
    uint8 *string ;
} dpfSTRING ;

typedef struct dpfTEXTURETYPE 
{
    char        *textName ;
    char        *fileName ;
    
    dpfMINIFY    minify ;
    dpfMAGNIFY   magnify ;
    dpfALPHA     alpha ;
    dpfWRAP      wrap_U, wrap_V ;
    dpfDETAIL    detail ;
    char        *detailName;
    uint8        bitslice ;
    dpfSTRINGPTR special ;
    int32        dataLength ;
    struct dpfFILE_TYPE   *file;
    struct dpfTEXTURETYPE *next ;
    
} dpfTEXTURE ;


typedef struct dpfRAMPTYPE 
{
    char         *name ;
    dpfRGBA       data[2] ;

    dpfSTRINGPTR  special ;
    int32         dataLength ;
    
    struct dpfFILE_TYPE *file;
    struct dpfRAMPTYPE  *next ;
} dpfRAMP ;

typedef struct dpfMATERIALTYPE
{
    char         *name ;
    
    dpfMATTXTTYPE   textureType ;
    char           *textureName ;
    char           *rampName ;
    dpfENVIRONMENT  envType ;
    char           *envName ;
    dpfRGBA         ambient, 
                    diffuse, 
                    specular,
                    emissive,
                    opacity ;
    dpfSTRINGPTR    special ;
    int32           dataLength ;
    struct dpfFILE_TYPE    *file;
    struct dpfMATERIALTYPE *next ;
    
} dpfMATERIAL ;


typedef struct dpfSURFACETYPE
{
    char        *name ;
    dpfMATTYPE   F_Material ;
    dpfMATTYPE   B_Material ;
    char        *F_MatName ;
    char        *B_MatName ;
    
    dpfPLANE     plane ;
    dpfFACET     facet ;
    int32        decal ;
    dpfDRAWMODE  drawMode ;
    uint8        width ;
    uint8        vertex ;
    dpfLOCK      lock ;
    dpfSTRINGPTR special ;

} dpfSURFACE ;

typedef struct dpfVERTEXTYPE {
    struct dpfVERTEXTYPE   *next ;
    union {
        struct dpfGEOMETRYTYPE *geom ;
        struct dptTRILISTTYPE  *triList ;
    } ptr ;
    uint8            vertex ;
    uint8            flag ;
    unsigned short   count ;
    float32          data[3] ;
} dpfVERTEX ;

typedef struct dpfVERTBLK {
    struct dpfVERTBLK *next ;
    dpfVERTEX vert[dpfVBLKSIZE] ;
} dpfVERTBLK, *dpfVERTBLKPTR ;

    
/*************************************************************
*   The Following are type defs for the ptmesh utility       *
*************************************************************/

typedef struct dptTRILISTTYPE
{
    struct dptTRIANGLETYPE *triangle ;
    struct dptTRILISTTYPE  *next ;
} dptTRILIST, *dptTRILISTPTR ;

typedef struct dptCONNECTTYPE
{
    struct dptTRIANGLETYPE *connection ;
    int32                   p1 ;
    struct dptCONNECTTYPE  *next ;
} dptCONNECT, *dptCONNECTPTR ;

typedef struct dptTRIANGLETYPE
{
    dpfGEOGROUPPTR          geogroup ;
    dpfVERTEXPTR            points[3] ;
    dptCONNECTPTR           connections ;
    dmVector                normal ;
    /* Beware of using the octPos flag. it is used in the flipper, octize, 
    ** spatial divide and the unloading of meshes
    */
    int32                   octPos ;
    struct dptTRIANGLETYPE *next, *prev ;
} dptTRIANGLE ;

typedef struct
{
    dpfGEOGROUPPTR  geogroup ;
    dptTRIANGLEPTR  LTrian,  RTrian ;
    int32           LVertNo, RVertNo ;
    int32           ROrient, LOrient ;
    int32           noVerts ;
    int32           octPos ;
} dptSAVEBLOCK, *dptSAVEBLOCKPTR ;

typedef struct dptMESHTYPE {
    dpfVERTEXPTR   *hash_tbl ;
    dptTRIANGLEPTR  trian_hd, trian_tl ;
    dpfGEOMETRYPTR  geom_hd,  geom_tl ;
    duBlkCtrl       conBC, trilBC, trisBC ;
    int32           hash_size, normals ;
    int32           No_trian, No_verts ;
    int32           noGroups ;
    int32           DropTri ;
} dptMESH ;


/************************************************************/


typedef struct dpfCLISTTYPE
{
    int32                   pcount ;
    int32                   fcount ;
    int32                   DataLength ;
    struct dpfGEOMETRYTYPE *geom;
    struct dpfCLISTTYPE    *next ;
    int32                  *faces ;
} dpfCLIST ;

typedef struct dpfSLISTTYPE
{
    int32                   pcount ;
    int32                   vcount ;
    int32                   DataLength ;
    struct dpfGEOMETRYTYPE *geom;
    struct dpfSLISTTYPE    *next ;
    int32                  *faces ;
} dpfSLIST ;

/* 4th float of point (point[dpf_U]) is used as radius */
typedef struct dpfSPHERENODETYPE
{
    dmVector                  point ;
    float32                   radius ;
    struct dpfGEOMETRYTYPE   *geom;
    struct dpfSPHERENODETYPE *next ;
    int32                    *block ;
} dpfSPHERENODE ;

typedef struct dpfTEXTNODETYPE
{
    dmVector                point ;
    char                   *string ;
    struct dpfGEOMETRYTYPE *geom;
    struct dpfTEXTNODETYPE *next ;
    int32                  *block ;
} dpfTEXTNODE ;

typedef struct dpfSTRIPTYPE {
    dpfVERTEXPTR        point_hd, point_tl ;
    union
    {
        uint8           thickness ;
        float32         size ;
    } data ;
    int32               noVertex, pDataLength ;
} dpfSTRIP, *dpfSTRIPPTR ;

typedef struct dpfPMESHTYPE {
    dpfVERTEXPTR        point_hd, point_tl ;
    dpfCLISTPTR         cList_hd, cList_tl ;
    dpfSLISTPTR         sList_hd, sList_tl ;
    int32               noVertex, pDataLength ;
    int32               noCList,  clDataLength ;
    int32               noSList,  slDataLength ;
} dpfPMESH, *dpfPMESHPTR ;

typedef struct dpfSPHERETYPE {
    uint16              dice_u, dice_v ;
    dpfSPHERENODEPTR    sphere_hd, sphere_tl ;
    int32               noSphereNode, sDataLength ;
} dpfSPHERE, *dpfSPHEREPTR ;

typedef struct dpfLETTEXTTYPE {
    dpfFONT             font ;
    dmVector            scale, orientation ;
    dpfTEXTNODEPTR      text_hd, text_tl ;
    int32               noTextNode, tDataLength ;
} dpfLETTEXT, *dpfLETTEXTPTR ;

typedef struct dpfGEOMETRYTYPE 
{
    int32               geomType ;
    union
    {
        dpfSTRIPPTR     strip ;
        dpfPMESHPTR     pmesh ;
        dpfSPHEREPTR    sphere ;
        dpfLETTEXTPTR   text ;
    } u_data ;
    int32               dataLength ;
    struct dpfGEOGROUPTYPE *geogroup;
    struct dpfGEOMETRYTYPE *next ;
} dpfGEOMETRY ;


typedef struct dpfGEOGROUPTYPE {
    dpfSURFACE              surface;
    dpfGEOMETRYPTR          geom_hd;
    dpfGEOMETRYPTR          geom_tl;
    int32                   dataLength ;
    struct dpfLODTYPE      *LOD ;
    struct dpfGEOGROUPTYPE *next;
} dpfGEOGROUP ;

typedef struct dpfLODTYPE 
{
    char          *name ;
    float32        inDist, outDist ;
    dpfTRANSITION  transition ;
    int32          referenceFlag ;
    dmVector       reference ;
    dpfGEOGROUPPTR geogroup_hd;
    dpfGEOGROUPPTR geogroup_tl;
    dpfSTRINGPTR   special ;
    int32          dataLength ;
    struct dpfOBJECTTYPE *object;
    struct dpfLODTYPE    *next ;
} dpfLOD ;

typedef struct dpfOBJECTTYPE {
    dpfSURFACE            surface;
    dpfLODPTR             LOD_hd;
    dpfLODPTR             LOD_tl;
    int32                 dataLength ;
    struct dpfOBJECTTYPE *next;
    struct dpfFILE_TYPE  *file;
} dpfOBJECT ;

typedef struct dpfHEADERTYPE 
{
    uint8          verMajor, verMinor;
    uint8          day, month, year ;
    uint8          hours, minutes ;
    uint8          headerLoaded ;
    float32        scale ;
    dpfPRECISION   precision ;
    dpfSTRINGPTR   comment ;
    dpfUNIT        unit ;
    dpfSTRINGPTR   special ;
    int32          dataLength ;
    dpfFILEFORMAT  type;
} dpfHEADER ;


typedef struct dpfBOUNDTYPE
{
    char          *objectName ;
    char          *LODName ;
    dpfAUTO        Auto ;
    
    uint8          gotBSphere ;
    dmVector       sphPoint ;
    float32        sphRadius ;

    uint8          gotBBox ;
    dmVector       boxMax, boxMin ;
    dmVector       boxOrien ;

    dpfGEOMETRYPTR pmesh ;
    
    dpfSTRINGPTR   special ;
    int32          dataLength ;

    dpfBOUNDPTR    child_hd ;
    dpfBOUNDPTR    child_tl ;
    
    dpfBOUNDPTR    next ;
    dpfBOUNDPTR    parent ;
    dpfFILEPTR     file ;
} dpfBOUND ;


/* dpfFILETYPE => dpfFILE_TYPE to stop conflict */
typedef struct dpfFILE_TYPE
{
    dpfHEADER       header ;
    
    dpfFILETYPE     type;
    dpfFILEMODE     mode;
    char           *fileName ;
    dflFILEPTR      fl ;
    
    /* viz 1 & 2 reading variables */
    dppFILEPTR      fptr ;
    
    /* biz 1 reading variables */
    int32           curtag;

    /* biz 2 reading variables */
    int32           dataLength, blockDepth, blockEnd[dpf_MAX_DEPTH] ;
    
    /* File contents structure */
    dpfTEXTUREPTR   texture_hd ;
    dpfTEXTUREPTR   texture_tl ;
    dpfMATERIALPTR  material_hd ;
    dpfMATERIALPTR  material_tl ;
    dpfRAMPPTR      ramp_hd ;
    dpfRAMPPTR      ramp_tl ;
    
    dpfBOUNDPTR     bound ;

    dpfOBJECTPTR    object_hd;
    dpfOBJECTPTR    object_tl;
    
    /* File contents count */
    int32           noMaterials, noTextures, noRamps ;
    int32           noObjects, noLODs, noGeogroups ;
    int32           noGeometries, noPmeshes ;
    int32           noCLists, noCFaces, cFtimesP ;
    int32           noSLists, noSFaces, sFtimesP ;
    int32           noPolystrips, noTristrips ;
    int32           noPolygons, noPolyVerts ;
    int32           noVertices, noVertLists, noTriangles ;
    int32           noSphereLists, noSpheres ;
    int32           noPointLists, noPoints ;
    int32           noLineLists, noLines ;
    int32           noTextLists, noTexts ;
    
    /* viz & biz 1 conversion material stuff */
    dpfVISTEXTUREPTR visList ;
    int32            mazSearched ;
    char            *FtextName, *BtextName ;
    uint8            forceVer ;
} dpfFILE ;

/*****************************************************************************/
/* Global variables and macros */
/*****************************************************************************/

/* Internal functions */

DPF_EXPORT int32 (*dpfReadFloatP)(dpfFILEPTR file,float32 *dest);
DPF_EXPORT int32 (*dpfReadnFloatP)(dpfFILEPTR file, int32 n, float32 *dest);

/* Reading data */
DPF_EXPORT int32
dpfReadFloatPSS(dpfFILEPTR file,float32 *dest) ;
DPF_EXPORT int32
dpfReadFloatPSD(dpfFILEPTR file,float32 *dest) ;
DPF_EXPORT int32
dpfReadFloatPDS(dpfFILEPTR file,float64 *dest) ;
DPF_EXPORT int32
dpfReadFloatPDD(dpfFILEPTR file,float64 *dest) ;

DPF_EXPORT int32
dpfReadnFloatPSS(dpfFILEPTR file,int32 n, float32 *dest) ;
DPF_EXPORT int32
dpfReadnFloatPSD(dpfFILEPTR file,int32 n, float32 *dest) ;
DPF_EXPORT int32
dpfReadnFloatPDS(dpfFILEPTR file,int32 n, float64 *dest) ;
DPF_EXPORT int32
dpfReadnFloatPDD(dpfFILEPTR file,int32 n, float64 *dest) ;

#define dpfRead1byte(file,dest)      dflRead1byte(file->fl,(void *)(dest))
#define dpfReadn1byte(file,n,dest)   dflReadn1byte(file->fl,n,(void *)(dest))
#define dpfRead2byte(file,dest)      dflRead2byte(file->fl,(void *)(dest))
#define dpfReadn2byte(file,n,dest)   dflReadn2byte(file->fl,n,(void *)(dest))
#define dpfRead4byte(file,dest)      dflRead4byte(file->fl,(void *)(dest))
#define dpfReadn4byte(file,n,dest)   dflReadn4byte(file->fl,n,(void *)(dest))
#define dpfRead8byte(file,dest)      dflRead8byte(file->fl,(void *)(dest))
#define dpfReadn8byte(file,n,dest)   dflReadn8byte(file->fl,n,(void *)(dest))

/* Writing data */
#define dpfFwriteint8(file,i)      dflWriteint8(file->fl,i)
#define dpfFwriteuint8(file,i)     dflWriteuint8(file->fl,i)
#define dpfFwriteint16(file,i)     dflWriteint16(file->fl,i)
#define dpfFwriteuint16(file,i)    dflWriteuint16(file->fl,i)
#define dpfFwriteint32(file,i)     dflWriteint32(file->fl,i)
#define dpfFwritefloat32(file,f)   dflWritefloat32(file->fl,f)
#define dpfFwritefloat64(file,f)   dflWritefloat64(file->fl,f)
DPF_EXPORT void
dpfFwriteFloatP(dpfFILEPTR file, float32 f) ;

/* pfcheck checks input values */
DPF_EXPORT int32
dpfRgbNotUnit(dpfRGBA r) ;
DPF_EXPORT int32
dpfRgbNotZero(dpfRGBA r) ;
DPF_EXPORT float32
dpfCheckRGBValue(dpfFILEPTR file, float32) ;
DPF_EXPORT float32
dpfCheckAlphaValue(dpfFILEPTR file, float32) ;
DPF_EXPORT float32
dpfCheckV1PowerValue(dpfFILEPTR file, float32) ;
DPF_EXPORT float32
dpfCheckV2PowerValue(dpfFILEPTR file, float32) ;
DPF_EXPORT float32
dpfCheckOpacityValue(dpfFILEPTR file, float32) ;
#define dpfV12v2PowerConvert(p)    p
#define dpfV22v1PowerConvert(p)    \
    ((p > dpfV1POWER_MAX) ? dpfV1POWER_MAX:p)

/* Dirty data structure stuff */
/* Does not unlink from structure so be careful */
DPF_EXPORT int32
dpfFreeVertexList(dpfVERTEXPTR vert) ;
DPF_EXPORT int32
dpfFreeCListList(dpfCLISTPTR cList) ;
DPF_EXPORT int32
dpfFreeGeometryList(dpfGEOMETRYPTR geometry) ;
DPF_EXPORT int32
dpfFreeSurfaceNames(dpfSURFACEPTR surface) ;
DPF_EXPORT int32
dpfFreeGeogroupList(dpfGEOGROUPPTR geogroup) ;
DPF_EXPORT int32
dpfFreeLODList(dpfLODPTR lod) ;
DPF_EXPORT int32
dpfFreeObjectList(dpfOBJECTPTR object) ;

DPF_EXPORT int32
dpfFreeBoundList(dpfBOUNDPTR bound) ;
DPF_EXPORT int32
dpfFreeTextureList(dpfTEXTUREPTR txt) ;
DPF_EXPORT int32
dpfFreeMaterialList(dpfMATERIALPTR mat) ;
DPF_EXPORT int32
dpfFreeRampList(dpfRAMPPTR ramp) ;


/* Use setSurface, not copySurface, does not free name memory if 
** dest suface has already got names
*/
DPF_EXPORT void
dpfCopySurface(dpfSURFACEPTR dest, dpfSURFACEPTR source);
 
DPF_EXPORT dpfFILETYPE
dpfIdentifyFile(dflFILEPTR fp) ;


DPF_EXPORT int32
dpfGetB1FileBody(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetV1FileBody(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetB2FileBody(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfGetV2FileBody(dpfFILEPTR file) ;
DPF_EXPORT int32
dpfPutB1FileBody(dpfFILEPTR Dfile, dpfFILEPTR Sfile, dpfFILEPTR matFile) ;
DPF_EXPORT int32
dpfPutV1FileBody(dpfFILEPTR Dfile, dpfFILEPTR Sfile, dpfFILEPTR matFile) ;
DPF_EXPORT int32
dpfPutB2FileBody(dpfFILEPTR dest, dpfFILEPTR infile) ;
DPF_EXPORT int32
dpfPutV2FileBody(dpfFILEPTR dest, dpfFILEPTR infile) ;

DPF_EXPORT void
dpfConvertV1Texture(dpfFILEPTR Sfp, dpfMATERIALPTR Fmat, dpfMATERIALPTR Bmat) ;

DPF_EXPORT void
VIZsetLexdfl(dflFILEPTR fl);

#ifdef __cplusplus
}
#endif

#endif /* ____PFILE_H__ */
