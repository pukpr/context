#ifndef _DVSOCKTYPES_H_
#define _DVSOCKTYPES_H_

typedef struct agentMessage
{
    uint16	size;
    uint16	messageType;
} AgentMessage;

typedef struct
{
    uint32	endian;
    uint16	size;
    uint16	messageType;
    uint16	version;
} AgentBroadCastMessage;

typedef struct agentAliveMessage
{
    uint16	connectPort;
    char 	domainName[1];
}AgentAliveMessage;

typedef struct agentConnectMessage
{
    uint16	port;
    uint8	master;
    uint8	dataBaseId;
    uint32	endian;
    uint32	masterAddr;
    uint16	masterPort;
}AgentConnectMessage;

typedef struct
{
    uint8	endian;
    uint16	port;
    uint32	addr;
    uint32	dataBaseId;
} AgentConnectionInfo;

struct connections
{
    int32	 addr;
    uint16	 portNum;
    AgentMessage rxHeader;
    AgentMessage *tmpRxHeader;
    char	*txBuffer;
    int32	 txBufferSize;
    char	*rxBuffer;
    int32	 rxBufferSize;
    int		 fd;
    int		 state;
    int 	 socketState;
    int		 connectionInfo;
    uint8	 rxHeaderPos;
    uint16	 txBufferPos;
    uint16	 rxBufferPos;
    uint32	 txSize;
    int32	 flipData;
    int32 	 dataBaseId;
    void       (*messageFunc)(int connection, char *message, int messageLen, void *appData); /* Used by dvise plugins to process messages from a specific connection */
    void        *appInfo; /* Used by agent to store extra info for each connection */
};

typedef struct dvsockInfo {
    int32 server;
    char *domainName;
    int32 startPort;
    int32 numPorts;
    int32 masterAddr;
}dvsockInfo;

typedef struct dvsockFunctionTable {
    void       (*select)(int sock, int type, void *userData);
    void       (*unselect)(int sock, int type, void *userData);
    void       (*message)(int connection, char *message, int messageLen, void *userData);
    void       (*remove)(int sock, void *userData);
    void       (*connect)(int connection, struct sockaddr_in *addr, int thisEndian);
    void       (*add)(int connection);
}dvsockFunctionTable;

#endif
