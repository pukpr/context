/*
-- ----------------------------------------------------------------------------
--
--  		     Copyright 1994, 1997 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS 2.1
--  Module       : Audio support library
--  Object Name  : $RCSfile: autils.h,v $
--  Revision     : $Revision: 1.3 $
--  Date         : $Date: 1999/02/11 15:18:25 $
--  Author       : $Author: mark $
--
--  Description	
--
--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __AUTILS_H__

#define __AUTILS_H__

#ifdef _BUILDING_AUDIOSUP
#include "auverb.h"
#else
#include <dvs/auverb.h>
#endif

typedef void (*AUExitHandler)(void *userData);

extern void AUAddExitHandler(AUExitHandler, void *userData);
extern void AURunExitHandlers(void);

extern char *AUFileBase(const char *fileName);
extern char *AUCopyString(const char * const str);

extern void AUSwapBytes(unsigned char* buf, const int numBytes);
extern void AUSwab(unsigned char* buf, const int numBytes);

#endif /* __AUTILS_H__ */
