/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: vwcircle.h,v $
 *    Revision:     $Revision: 1.2 $
 *    Date:         $Date: 2000/05/09 12:40:36 $
 *    Author:       $Author: jeff $
 *    RCS Ident:    $Id: vwcircle.h,v 1.2 2000/05/09 12:40:36 jeff Exp $
 *
 *    FUNCTION: Frame public function prototypes.
 * 
 * Copyright (c) 1996 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _VWCIRCLE_H
#define _VWCIRCLE_H

#ifndef _VWIDGETS_H
#include "vwidgets.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif
#ifdef _dummyBrace_
}
#endif
/* PUBLIC FUNCTIONS ====================================== */

enum {
    VWrCircleMarkerMaterial = VW_RESOURCES_CIRCLE,
    VWrCircleCoreMaterial,
    VWrCircleMarkerVisual,
    VWrCircleCoreVisual,
    VWrCircleDisableCollide,
    VWrCircleUpdateCallback,
    VWrCircleUpdateCalldata
};

typedef enum VWCirclePoint { VWCirclePoint1 = 0, VWCirclePoint2 = 1, 
              VWCirclePoint3 = 2 } VWCirclePoint;

/* NOTE: This widget should have NO parent to operate correctly */
VW_EXPORT VWidget *VWCircle_CreateManaged(VWidget *Parent, char *name, VWArg args[], int argc);
VW_EXPORT VWidget *VWCircle_Create(VWidget *Parent, char *name, VWArg args[], int argc);
VW_EXPORT void VWCircle_SetPoint(VWidget *CircleWig, VWCirclePoint pnt, dmPoint absPnt, dmPoint relPnt, VCEntity *entity,
                                  int setEntity);
VW_EXPORT void VWCircle_AddUpdateCallback(VWidget *thisWig, VWCallback *cb, void *cd);
VW_EXPORT VWidget *VWCircle_GetMarkerWidget(VWidget *thisWig, VWCirclePoint pnt);
VW_EXPORT VWidget *VWCircle_GetCoreWidget(VWidget *thisWig);
VW_EXPORT VCEntity *VWCircle_GetMarkerEntity(VWidget *thisWig, VWCirclePoint pnt);
VW_EXPORT void VWCircle_GetMarkerWidgetAbsOrigin(VWidget *thisWig, VWCirclePoint pnt, 
                                       dmPoint absPos);
VW_EXPORT float32 VWCircle_GetRadius(VWidget *thisWig);
VW_EXPORT void VWCircle_GetCentre(VWidget *thisWig, dmPoint centre);
VW_EXPORT char *VWCircle_GetMarkerVisual(VWidget *thisWig, VWCirclePoint pnt);
VW_EXPORT float32 VWCircle_GetMarkerScale(VWidget *thisWig, VWCirclePoint pnt);
VW_EXPORT void VWCircle_SetMarkerVisual(VWidget *thisWig, char *visual);
VW_EXPORT void VWCircle_SetMarkerScale(VWidget *thisWig, VWCirclePoint pnt, float32 scale);
VW_EXPORT void VWCircle_SetPoint(VWidget *CircleWig, VWCirclePoint pnt, dmPoint absPnt, dmPoint relPnt, VCEntity *entity,
                                  int setEntity);

#ifdef _dummyBrace_
{
#endif
#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /*_VWCIRCLE_H */
