// -*-C++-*-
#ifndef _ECSMARTPTR_H
#define _ECSMARTPTR_H

#ifndef _DIVTYPES_H
#include <dsys/divtypes.h>
#endif

#ifndef DV_EXPORT
#include "dvexport.h"
#endif

#ifndef _ECUDATA_H
#include "ecudata.h"
#endif

#ifndef _CALLBACK_H
#include "eccallback.h"
#endif

#ifndef _ECASSERT_H
#include "ecassert.h"
#endif

typedef enum { EC_ERR=-1, EC_OK=0} ECError;


#define ECITEM_CREATED_FROM_FILE 0x80000000

#define ITEM_NOT_CREATED 	0x00000000
#define ITEM_CREATED 		0x00000001
#define ITEM_DELETED 		0x00000002
#define ITEM_STATUS_MASK	0x00000003

#define ITEM_CREATING 		0x00000004
#define ITEM_UPDATEING 		0x00000008
#define ITEM_DELETING 		0x00000010

#define ITEM_CALLBACK_STATUS_MASK    (ITEM_CREATING | ITEM_UPDATEING | ITEM_DELETING)

#define ITEM_GLOBAL_CREATING	0x00000020
#define ITEM_GLOBAL_UPDATEING	0x00000040
#define ITEM_GLOBAL_DELETING	0x00000080

#define ITEM_GLOBAL_CALLBACK_STATUS_MASK    (ITEM_GLOBAL_CREATING | ITEM_GLOBAL_UPDATEING | ITEM_GLOBAL_DELETING)

//Forward ref
typedef struct ECCppItem ECCppItem;


/*
 * Base item: all top level ecitems will be derrived from one of these.
 */
class DV_EXPORT _ECBaseItem: public ECUdataMap
{
public:
    typedef ecCallbackList::iterator ECCallbackIterator;
// typedef enum {NOT_CREATED, CREATING, CREATED, UPDATEING, DELETING, DELETED } ECBaseItemStatus;
	// Construction:
                                             _ECBaseItem();
    virtual                                 ~_ECBaseItem();

        // JOHN Should also clean out callback lists
    void                                    AddReference(void)             { m_Counter++; }
    int                                  RemoveReference(void)             { return --m_Counter; }
    int                                GetReferenceCount(void) const       { return m_Counter; }
    void                               dontCallCallbacks(void);
    void                               clearCallbackFlag(int callbackFlag);
    bool                                  IsBeingDeleted(void) const       { 
                                                                               int stat = (m_smartP_status & ITEM_STATUS_MASK);
                                                                               return (  (stat == ITEM_DELETING)
                                                                                       ||(stat == ITEM_DELETED));
                                                                           }
    bool                                  IsBeingUpdated(void) const       { return (m_smartP_status & ITEM_UPDATEING);}

    virtual int                                    getId(void) const;
    virtual char                            *getIdString(void) const =0;
    virtual int                                  destroy(void);
    virtual _ECBaseItem                           *clone(void) const;
    virtual int                                  _create(uint32 flags);
    virtual int                                  _update(uint32 flags);
    virtual void                           callCallbacks(void);
    virtual int                             writeVdiFile(void);
    virtual int                                flushToVC(void);
    virtual int                             removeFromVC(void);
    virtual void                  FixupLowLevelCallbacks(void);
    virtual ECError                              SetName(char *newName);
    virtual ECError                        SetNameNoCopy(char *newName);
    virtual char                                *GetName(void) const;
    virtual uint32                        GetUpdateFlags(void);
    virtual void	                        SetOwner(ECCppItem *item);
    virtual void                                SetOwner(ECCppItem *item, void *owner) { SetOwner(item); }
    virtual ECCppItem                          *GetOwner(void) const;
    virtual bool                             operator < (const _ECBaseItem &) const;
    
    
        //Callback stuff
    bool                                      IsObserved(void) const;
    static ECCallbackIterator attachGlobalCreateCallback(int id,ecGlobalCallbackFunc, void *);
    static ECCallbackIterator attachGlobalUpdateCallback(int id,ecGlobalCallbackFunc, void *);
    static ECCallbackIterator attachGlobalDeleteCallback(int id,ecGlobalCallbackFunc, void *);
    static void               detachGlobalCreateCallback(int id,ECCallbackIterator iter);
    static void               detachGlobalUpdateCallback(int id,ECCallbackIterator iter);
    static void               detachGlobalDeleteCallback(int id,ECCallbackIterator iter);

    ECCallbackIterator	            attachCreateCallback(ecCallbackFunc, void *);
    ECCallbackIterator	            attachUpdateCallback(ecCallbackFunc, void *);
    ECCallbackIterator	            attachDeleteCallback(ecCallbackFunc, void *);
    ECCallbackIterator	            attachCreateCallback(const ecCallback &);
    ECCallbackIterator	            attachUpdateCallback(const ecCallback &);
    ECCallbackIterator	            attachDeleteCallback(const ecCallback &);
    void                            detachCreateCallback(ECCallbackIterator);
    void                            detachUpdateCallback(ECCallbackIterator);
    void                            detachDeleteCallback(ECCallbackIterator);

protected:
    virtual void                           	  _clone(const _ECBaseItem *)             {};
    ecCallbackList	cList;
    ecCallbackList	uList;
    ecCallbackList	dList;
    
    uint32 		m_smartP_status;
    bool		m_doingCallback;
    ECCppItem	       *m_owner;
private:
    uint32		m_updateFlags;
    short		m_Counter;
};


/*
 * Smart ptrs  point at things derrived from base items and do clevver
 * reference counting things.
 */
class DV_EXPORT ECBaseItemPtr 
{
public:
    typedef _ECBaseItem  *ptr_type;

protected:
    _ECBaseItem *m_ptr;

// Implementation
    void                  Construct(_ECBaseItem* ptr)             {if (m_ptr = ptr) m_ptr->AddReference();}
    void                     Delete()                             {
                                                                      if(m_ptr && (m_ptr->RemoveReference() == 0)) {
                                                                          m_ptr->destroy();
                                                                          if(m_ptr->GetReferenceCount() == 0) {
                                                                              delete m_ptr;		
                                                                              m_ptr = NULL;
                                                                          }
                                                                      }
                                                                  }
public:

                      ECBaseItemPtr(const ECBaseItemPtr& T)       {Construct(T.m_ptr);}
                      ECBaseItemPtr()                             :m_ptr(0){}
                      ECBaseItemPtr(_ECBaseItem* ptr)             {Construct (ptr);}
                     ~ECBaseItemPtr()                             {Delete();}
    
    const _ECBaseItem  *operator-> () const	                  {return  m_ptr;}
    const _ECBaseItem  &operator*  () const	                  {return *m_ptr;}
    _ECBaseItem*        operator-> ()		                  {return  m_ptr;}
    _ECBaseItem& 	operator*  () 		                  {return *m_ptr;}
    // simon 29/9/99 a more obvous way of getting a dumb ptr to base item
    const _ECBaseItem*  GetContents(void) const                   {return  m_ptr;}
    _ECBaseItem*        GetContents(void)                         {return  m_ptr;}
    
    ECBaseItemPtr&      operator=  (const ECBaseItemPtr& T)       {return operator=(T.m_ptr);}
    ECBaseItemPtr&      operator=  (_ECBaseItem* ptr)             {
                                                                      if (m_ptr != ptr) { Delete(); Construct (ptr);}
                                                                      return *this;
                                                                  }

    bool                operator== (const ECBaseItemPtr& t) const {return (m_ptr == t.m_ptr); }
    bool                operator!= (const ECBaseItemPtr& t) const {return (m_ptr != t.m_ptr); }
    bool                operator== (const _ECBaseItem *t)   const {return (m_ptr == t); }
    bool                operator!= (const _ECBaseItem *t)   const {return (m_ptr != t); }
    bool                operator<  (const ECBaseItemPtr& t) const {return ((*m_ptr) < (*(t.m_ptr))); }
    
    bool                  IsLastOne(void) const                   {return (m_ptr&&(m_ptr->GetReferenceCount()==1));}
    bool                   IsShared(void) const                   {return (m_ptr&&(m_ptr->GetReferenceCount()> 1));}
    size_t                     Hash(void) const                   {return ( ((size_t)m_ptr)>>2); }
};

template<class TYPE>
class DV_EXPORT ECSmartPtr :public ECBaseItemPtr
{
public:
    typedef TYPE *ptr_type;

                        ECSmartPtr()                          :ECBaseItemPtr(){}
                        ECSmartPtr(_ECBaseItem* ptr)          {Construct(dynamic_cast<TYPE *>(ptr));}
                        ECSmartPtr(const ECBaseItemPtr& T)    {
                                                                  _ECBaseItem *b = const_cast<_ECBaseItem *>(T.operator->());
                                                                      //const TYPE        *s= dynamic_cast<const TYPE *> (b);
                                                                  Construct(dynamic_cast<TYPE *> (b));
                                                              }
                        ECSmartPtr(const ECSmartPtr& T)       {Construct(T.m_ptr);}
    
    static ECSmartPtr<TYPE> create(void)                      {
                                                                  TYPE *newPtr = TYPE::create(); 
                                                                  ECSmartPtr<TYPE> tmpPtr(newPtr);
                                                                  return tmpPtr;
                                                              }
    const TYPE*        operator-> () const	              { return   (const TYPE*)(m_ptr); }
    const TYPE&        operator*  () const	              { return *((const TYPE*)(m_ptr));}
    TYPE*              operator-> ()		              { return   (TYPE*)(m_ptr); }
    TYPE& 	       operator*  () 		              { return *((TYPE*)(m_ptr));}
    ECSmartPtr&        operator=  (const ECBaseItemPtr& T)    {
                                                                  _ECBaseItem *b = const_cast<_ECBaseItem *>(T.operator->());
                                                                  return  operator= (dynamic_cast<TYPE *> (b));
                                                              }
    ECSmartPtr&        operator=  (_ECBaseItem* ptr)          {
                                                                  if(ptr != m_ptr) {Delete();Construct(dynamic_cast<TYPE *>(ptr));}
                                                                  return *this;
                                                              }
    
    ECSmartPtr&        operator=  (const ECSmartPtr& T)       {return operator=(T.m_ptr);}
};


template <class SMART_PTR>
class DV_EXPORT ECAutoNullingPtr: public SMART_PTR
{
    _ECBaseItem::ECCallbackIterator m_iter;
    bool                            m_iterValid;

    static void         autoNull(ECCallbackInfo *, void *d)      {ECAutoNullingPtr *x=(ECAutoNullingPtr*)d;x->Delete();x->rmAutoNull();}
    void                 cloneCb(const ECAutoNullingPtr& p)      {
                                                                      if(p.haveCb()){
                                                                          m_iter=m_ptr->attachDeleteCallback(*(p.m_iter));
                                                                          m_iterValid = true;
                                                                      }
                                                                      else 
                                                                          m_iterValid=false;
                                                                 }
    bool                  haveCb(void) const                     {return (m_ptr)&&(m_iterValid);}
    void              rmAutoNull(void)                           {
                                                                      if(haveCb()){
                                                                          m_ptr->detachDeleteCallback(m_iter);
                                                                          m_iterValid = false;
                                                                      }
                                                                 }
     
    void             addAutoNull(ecCallbackFunc func,
                                 void *data)                     {
                                                                      if (m_ptr){
                                                                          m_iter=m_ptr->attachDeleteCallback(func, data);
                                                                          m_iterValid=true;
                                                                      }
                                                                 }

public:
                ECAutoNullingPtr(const ECAutoNullingPtr& p)      :SMART_PTR(p),m_iterValid(false) {cloneCb(p);}
                ECAutoNullingPtr(const SMART_PTR& p)             :SMART_PTR(p),m_iterValid(false) {}
                ECAutoNullingPtr(typename SMART_PTR::ptr_type p) :SMART_PTR(p),m_iterValid(false) {}
                ECAutoNullingPtr()                               :m_iterValid(false) {}
               ~ECAutoNullingPtr()                               {rmAutoNull();}

    ECAutoNullingPtr& operator= (const ECAutoNullingPtr &p)      {rmAutoNull();SMART_PTR::operator=(p);cloneCb(p);return *this;}
    ECAutoNullingPtr& operator= (const SMART_PTR &p)             {rmAutoNull();SMART_PTR::operator=(p);return *this;}
    ECAutoNullingPtr& operator= (typename SMART_PTR::ptr_type p) {rmAutoNull();SMART_PTR::operator=(p);return *this;}

    void          attachCallback(ecCallbackFunc func,
                                 void *data) const               {ECAutoNullingPtr *x = const_cast<ECAutoNullingPtr *>(this);
                                                                  x->rmAutoNull();x->addAutoNull(func, data);}
    void          attachCallback(void) const                     {attachCallback(autoNull,(void *)this);}
    void          detachCallback(void) const                     {ECAutoNullingPtr *x = const_cast<ECAutoNullingPtr *>(this);
                                                                  x->rmAutoNull();}
};

DV_TEMPLATE_EXPORT template class DV_EXPORT ECAutoNullingPtr<ECBaseItemPtr>;
typedef ECAutoNullingPtr<ECBaseItemPtr> ECBaseItemNullingPtr;


// Use this functor as the hash argument when building STL hash tables indexed by
// any of our Ptr classes.

template <class TYPE>
struct ECPtrHash {
    size_t operator()(const TYPE &x) const { return x.Hash(); }
};


template <class TYPE>
struct ECPtrOrder: public binary_function<const TYPE &,const TYPE &,bool>
{
    bool operator() (const TYPE &a, const TYPE &b) const
        {return (a.Hash() < b.Hash());}
};



DV_EXPORT ECBaseItemPtr ECCppItem_GetItem(ECCppItem *cppItem);
DV_EXPORT ECBaseItemPtr *newBaseItem(_ECBaseItem *);


struct  ECGlobalCallbackInfo
{
    list<ECBaseItemPtr> *itemList;
};
typedef STLPORT::list<ECBaseItemPtr>::iterator ECGlobalCallbackInfo_Iterator;

#endif // __ECSMARTPTR_H

















