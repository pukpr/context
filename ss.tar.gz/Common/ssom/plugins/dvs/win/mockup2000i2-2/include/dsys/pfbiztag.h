/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: pfbiztag.h,v $
 *    Revision:     $Revision: 1.1.1.1 $
 *    Date:         $Date: 1996/08/07 13:15:56 $
 *    Author:       $Author: bill $
 *    RCS Ident:    $Id: pfbiztag.h,v 1.1.1.1 1996/08/07 13:15:56 bill Exp $
 *
 *    FUNCTION:
 *
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef __PFBIZTAG_H__
#define __PFBIZTAG_H__

#ifdef __cplusplus
extern "C" {
#endif
    
/* PUBLIC DEFINES =======================================*/
/* Biz v1.0 tag defines */
#define dpf_BIZ_PATCH       34
#define dpf_BIZ_STRIP       35
#define dpf_BIZ_TRISTRIP    0
#define dpf_BIZ_POLYSTRIP   1
#define dpf_BIZ_DONE        37

/* Biz v2.x tag defines */
#define dpfB_0_COMMENT_TAG	         0x0000
#define dpfB_HEADER_TAG	                 0x0003
#define dpfB_PROPAGATED_COMMENT_TAG      0x0004
#define dpfB_BIZ_DONE                    0x0005
#define dpfB_TEXTURE_TAG                 0x0010
#define dpfB_TEXTURE_MAP_TAG             0x0011
#define dpfB_TEXTURE_MINIFY_TAG 	 0x0012
#define dpfB_TEXTURE_MAGNIFY_TAG 	 0x0013
#define dpfB_TEXTURE_ALPHA_TAG 		 0x0014
#define dpfB_TEXTURE_WRAP_U_TAG          0x0015
#define dpfB_TEXTURE_WRAP_V_TAG 	 0x0016
#define dpfB_TEXTURE_DETAIL_TAG 	 0x0017
#define dpfB_TEXTURE_BITSLICE_TAG 	 0x0018
#define dpfB_MATERIAL_TAG                0x0020
#define dpfB_MATERIAL_TEXTURE_TAG        0x0021
#define dpfB_MATERIAL_ENVIRONMENT_TAG    0x0022
#define dpfB_MATERIAL_AMBIENT_TAG 	 0x0023
#define dpfB_MATERIAL_DIFFUSE_TAG 	 0x0024
#define dpfB_MATERIAL_SPECULAR_TAG	 0x0025
#define dpfB_MATERIAL_EMISSIVE_TAG 	 0x0026
#define dpfB_MATERIAL_OPACITY_TAG 	 0x0027
#define dpfB_MATERIAL_RAMP_TAG 		 0x0028
#define dpfB_RAMP_TAG 			 0x0030
#define dpfB_RAMP_DATA_TAG               0x0031
#define dpfB_OBJECT_TAG                  0x0040
#define dpfB_LOD_TAG                     0x0041
#define dpfB_GEOGROUP_TAG                0x0042
#define dpfB_POLYGON_TAG                 0x0043
#define dpfB_TRISTRIP_TAG                0x0044
#define dpfB_POLYSTRIP_TAG 		 0x0045
#define dpfB_PMESH_TAG                   0x0046
#define dpfB_CONNECTION_LIST_TAG         0x0047
#define dpfB_SPHERE_LIST_TAG             0x0048
#define dpfB_SPHERE_TAG                  0x0049
#define dpfB_LINE_TAG                    0x004a
#define dpfB_TEXT_TAG                    0x004b
#define dpfB_TEXT_STRING_TAG             0x004c
#define dpfB_PCONN_LIST_TAG              0x004d
#define dpfB_PSTRIP_LIST_TAG             0x004e
#define dpfB_POINT_LIST_TAG              0x0050

#define dpfB_BOUND_TAG                   0x0070
#define dpfB_BBOX_TAG                    0x0071
#define dpfB_BSPHERE_TAG                 0x0072

#define dpfB_LINE_NODE_TAG               0x0080
#define dpfB_VERTEX_XYZ_TAG              0x0080
#define dpfB_VERTEX_XYZ_N_TAG		 0x0081
#define dpfB_VERTEX_XYZ_RGBA_TAG	 0x0082
#define dpfB_VERTEX_XYZ_UV_TAG		 0x0088
#define dpfB_VERTEX_XYZ_N_UV_TAG	 0x0089
#define dpfB_VERTEX_XYZ_RGBA_UV_TAG	 0x008A

#define dpfB_2_COMMENT_TAG               0x2000
#define dpfB_VERSION_TAG                 0x2002
#define dpfB_DATE_TAG 			 0x2003
#define dpfB_TIME_TAG 			 0x2004
#define dpfB_SCALE_TAG 			 0x2005
#define dpfB_PRECISION_TAG 		 0x2006
#define dpfB_FILETYPE_TAG 		 0x2007
#define dpfB_SV_NAME_TAG                 0x2008
#define dpfB_MATERIAL_NAME_TAG           0x2008
#define dpfB_RAMP_NAME_TAG 		 0x2008
#define dpfB_TEXTURE_NAME_TAG		 0x2008
#define dpfB_UNIT_TAG                    0x2009
#define dpfB_SCOPE_TAG                   0x200a
#define dpfB_SV_F_MATERIAL_TAG 		 0x2030
#define dpfB_SV_B_MATERIAL_TAG 		 0x2031
#define dpfB_SV_PLANE_TAG 		 0x2032
#define dpfB_SV_DRAW_MODE_TAG            0x2033
#define dpfB_SV_DECAL_TAG                0x2034
#define dpfB_SV_FACETED_TAG              0x2035
#define dpfB_SV_VERTEX_TAG               0x2036
#define dpfB_SV_SPECIAL_TAG              0x2037
#define dpfB_SV_LOCK_TAG                 0x2039
#define dpfB_SPHERE_DICE_V_TAG           0x2040
#define dpfB_SPHERE_DICE_U_TAG           0x2041
#define dpfB_LINE_THICKNESS_TAG          0x2042
#define dpfB_TEXT_FONT_TAG               0x2043
#define dpfB_TEXT_SCALE_TAG              0x2044
#define dpfB_TEXT_ORIENTATION_TAG        0x2045

#define dpfB_LOD_DISTANCE_TAG		 0x2046
#define dpfB_LOD_REFERENCE_TAG 		 0x2047
#define dpfB_LOD_TRANSITION_TAG          0x2048

#define dpfB_POINT_SIZE_TAG              0x2049

#define dpfB_BAUTO_TAG                   0x2070
#define dpfB_BLODNAME_TAG                0x2071
#define dpfB_BOBJNAME_TAG                0x2072

#define dpfB_NO_DEF_TAGS 256
#define dpfB_NO_CON_TAGS 256

#define dpfValidTag(tag)                                      \
    ((((tag) & 0x1fff) > 0x00ff) ? 0 :                        \
     ((tag) & 0x2000) ? dpfB_CON_TAG_INFO[(tag) & 0x00ff] :   \
                        dpfB_DEF_TAG_INFO[(tag) & 0x00ff] )

/* PUBLIC TYPES =========================================*/


/* PUBLIC VARIABLES ======================================*/


extern uint8 dpfB_DEF_TAG_INFO[dpfB_NO_DEF_TAGS] ;
extern uint8 dpfB_CON_TAG_INFO[dpfB_NO_DEF_TAGS] ;
    

#ifdef _dpf_INCLUDE_BIZ_TABLE

uint8 dpfB_DEF_TAG_INFO[dpfB_NO_DEF_TAGS] = {
        1, 1, 1, 3, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        3, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0,
        3, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0,
        3, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 3, 3, 1, 3, 3, 0,
        3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        3, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0,
        1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
} ;
uint8 dpfB_CON_TAG_INFO[dpfB_NO_DEF_TAGS] = {
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
} ;

#endif

/* PUBLIC FUNCTIONS ======================================*/


#ifdef __cplusplus
}
#endif

#endif /*__PFBIZTAG_H__ */
