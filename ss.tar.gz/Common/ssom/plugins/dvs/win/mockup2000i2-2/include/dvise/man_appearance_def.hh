DEF_TOKEN( tSwManAprRootHandle, "manroothandle", PARSER_MATCH_CASE )
DEF_TOKEN( tSwManAprSkinMaterial, "swmanaprskinmaterial", PARSER_MATCH_CASE )
DEF_TOKEN( tSwManAprTrousersMaterial, "swmanaprtrousersmaterial", PARSER_MATCH_CASE )
DEF_TOKEN( tSwManAprShirtMaterial, "swmanaprshirtmaterial", PARSER_MATCH_CASE )
DEF_TOKEN( tSwManAprShoeMaterial, "swmanaprshoematerial", PARSER_MATCH_CASE )
DEF_TOKEN( tSwManAprHeadMaterial, "swmanaprheadmaterial", PARSER_MATCH_CASE )



