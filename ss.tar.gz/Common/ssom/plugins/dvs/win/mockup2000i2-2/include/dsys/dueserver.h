/* 
-- ----------------------------------------------------------------------------
--
--  			Copyright 1999 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVISE
--  Module       : du error server support
--  Object Name  : $RCSfile: dueserver.h,v $
--  Revision     : $Revision: 1.4 $
--  Date         : $Date: 1999/08/18 15:59:53 $
--  Author       : $Author: rajini $
--
--  Description	
--
--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/


#ifndef __DUESERVER_H__
#define __DUESERVER_H__



#ifndef DU_EXPORT
#if defined(_WIN32) && !defined(_WINDU_SOURCE) && !defined(__EPP__) && !defined(BUILD_STATIC)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `extern'
 */
#ifdef  _LIB_DIVU
#define DU_EXPORT __declspec(dllexport) extern 
#else
#define DU_EXPORT __declspec(dllimport) extern 
#endif 
#else
#define DU_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ndef DU_EXPORT */

#ifdef __cplusplus
extern "C" {
#endif

#include <sys/types.h>
    
/*
 * Error Server Protocol Description
 *
 * The error server protocol allows messages sent vi the du messaging
 * system: verbose, debug, warn, error and fatal to be sent to the
 * error server.  The protocol used by these messages is described
 * here.  The messages all have the following form:
 *
 *    +-----------+-----------+-------+----------+----------------------+
 *    | Timestamp | Sequence  | Tag   |  Length  |    Message Data      |
 *    +-----------+-----------+-------+----------+----------------------+
 *
 *    Field            Size            Description
 *    -----            ----            -----------
 *
 *    Timestamp        4 bytes         Date and time message sent
 * 
 *    Sequence         4 bytes         Sequence number of messages sent
 *                                     with the same time stamp.

 *    Tag              4 bytes         A value indicating the type of the
 *                                     data contained in the message
 * 
 *    Length           4 bytes         An unsigned integer indicating the
 *                                     number of bytes 
 *
 *    Message Data     Length bytes    Message data, content is dependent on
 *                                     the tag value supplied.
 *
 *
 * The message types are described below:
 *
 * DU_ESERVER_TAG_NAME       -- name of the actor
 *
 *     Message data is a string containing the actor name
 *
 * DU_ESERVER_TAG_MODULE     -- defines a new verbose/debug modules
 *
 *     Message data has the following format:
 *
 *     +--------+---------+-----------------------------------+
 *     |  Type  |   Id    |                 Name              |
 *     +--------+---------+-----------------------------------+
 *
 *     Field       Size         Description
 *     -----       ----         -----------
 *
 *     Type        1 byte       Defines the modules as being a debug
 *                              or verbosity module.  Values are one of:
 *
 *                              DU_ESERVER_MODULE_TYPE_VERBOSE
 *                              DU_ESERVER_MODULE_TYPE_DEBUG
 *
 *     Id          4 bytes      Integer representing the module id
 *
 *     Name        remainder    Name of the module.
 *
 * DU_ESERVER_TAG_VERBOSE    -- a verbose message
 * DU_ESERVER_TAG_DEBUG      -- a debug message
 *
 *     The message data is the same format for both these messages
 *
 *     +--------+---------+------+----------+-----------------+
 *     | Module |  Level  | Line | File len | file + message  |
 *     +--------+---------+------+----------+-----------------+
 *
 *     Field       Size         Description
 *     -----       ----         -----------
 *
 *     Module      4 bytes      The module id, corresponding to one
 *                              defined by an earlier module message
 *
 *     Level       4 bytes      Integer representing the debug/verbose
 *                              level specified in the function call
 *     
 *     Line        4 bytes      The line number for debug, 0 for verbose
 *
 *     File len    4 bytes      The length of the file name.  This will
 *                              always be 0 for verbose messages
 *
 *     Message     remainder    The (file len) bytes of the filename
 *                              followed by the text of the message.
 *
 * DU_ESERVER_TAG_WARN       -- a warning message
 * DU_ESERVER_TAG_ERROR      -- an error message
 * DU_ESERVER_TAG_FATAL      -- a fatal error message
 *
 *     Message data is the text of the warning/error/fatal message.
 * */

typedef struct duEServerHeader
{
    time_t stamp;               /* time stamp for the message */
    int seq;                    /* time stamp sequence number */
    unsigned int tag;           /* one of the message tags */
    unsigned int len;           /* length of the message */
} duEServerHeader;
    
    /* Message tags */

#define DU_ESERVER_TAG_NAME    1 /* name of this actor */
#define DU_ESERVER_TAG_MODULE  2 /* module name to id mapping */
#define DU_ESERVER_TAG_VERBOSE 3 /* verbose message */
#define DU_ESERVER_TAG_DEBUG   4 /* debug message  */
#define DU_ESERVER_TAG_WARN    5 /* warning message */
#define DU_ESERVER_TAG_ERROR   6 /* error message */
#define DU_ESERVER_TAG_FATAL   7 /* fatal message */

    /* DU_ESERVER_TAG_MODULE field tags and offsets */

#define DU_ESERVER_MODULE_TYPE_VERBOSE  0 /* module id is for verbosity */
#define DU_ESERVER_MODULE_TYPE_DEBUG    1 /* module id is for debugging data */

#define DU_ESERVER_MODULE_OFFSET_TYPE 0
#define DU_ESERVER_MODULE_OFFSET_ID   4
#define DU_ESERVER_MODULE_OFFSET_NAME 8

    /* DU_ESERVER_TAG_VERBOSE offsets */

#define DU_ESERVER_VERBOSE_OFFSET_MODULE 0
#define DU_ESERVER_VERBOSE_OFFSET_LEVEL  4
#define DU_ESERVER_VERBOSE_OFFSET_LINE   8
#define DU_ESERVER_VERBOSE_OFFSET_FILE  12
#define DU_ESERVER_VERBOSE_OFFSET_MSG   16 

    /* DU_ESERVER_TAG_DEBUG offsets */

#define DU_ESERVER_DEBUG_OFFSET_MODULE 0
#define DU_ESERVER_DEBUG_OFFSET_LEVEL  4
#define DU_ESERVER_DEBUG_OFFSET_LINE   8
#define DU_ESERVER_DEBUG_OFFSET_FILE  12
#define DU_ESERVER_DEBUG_OFFSET_MSG   16


    /* Number of bytes contained in a message header */

#define DU_ESERVER_HEADER_LEN 5

    /* Functions to send the various message types
     *
     * Return values: 0 => failure; 1 => success
     */

DU_EXPORT void duEServer_SetSocket(const int socket);    
DU_EXPORT int duEServer_SendName(const char* const name);
DU_EXPORT int duEServer_SendModule(const int type, const int id, const char* const name);
DU_EXPORT int duEServer_SendVerbose(const int module, const int level, const char* const msg);
DU_EXPORT int duEServer_SendDebug(const int module, const int level,
                                  const char* file, const int line,
                                  const char* const msg);
DU_EXPORT int duEServer_SendWarn(const char* const msg);
DU_EXPORT int duEServer_SendError(const char* const msg);
DU_EXPORT int duEServer_SendFatal(const char* const msg);
DU_EXPORT int duEServer_FlushMessages(void);

    /* Functions to decode the various message types
     *
     * Note: strings returned out of these function via char**
     * parameters will have been dynamically allocated via malloc
     * It is the callers responsibility to free these string when
     * they are no longer required
     * 
     * Return values: 0 => failure; 1 => success
     */

DU_EXPORT int duEServer_DecodeHeader(const char* const header, int* tag, int* len);
DU_EXPORT int duEServer_DecodeName(const char* const data, const int len, char** name);
DU_EXPORT int duEServer_DecodeModule(const char* const data, const int len,
                                     int* type, int* id, char** name);
DU_EXPORT int duEServer_DecodeVerbose(const char* const data, const int len, int* module,
                                      int* level, char** msg);
DU_EXPORT int duEServer_DecodeDebug(const char* const data, const int len, int* module,
                                    int* level, char** file, int* line, char** msg);
DU_EXPORT int duEServer_DecodeWarn(const char* const data, const int len, char** warn);
DU_EXPORT int duEServer_DecodeError(const char* const data, const int len, char** error);
DU_EXPORT int duEServer_DecodeFatal(const char* const data, const int len, char** fatal);



#ifdef __cplusplus
}
#endif
#endif /* __DUESERVER_H__ */
