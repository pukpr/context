/* -*- C -*- ****************************************************************
 *
 *  			Copyright 1998 Division Ltd.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: dvcon.h,v $
 *  Revision      : $Revision: 1.11 $
 *  Date          : $Date: 2000/10/17 09:19:19 $
 *  Author        : $Author: bill $
 *  Created By    : Steven Phillips
 *  Created       : Tue May 19 13:31:59 1998
 *  Last Modified : <001011.0933>
 *
 *  Description	
 *
 *  Notes
 *
 ****************************************************************************
 *
 *  Copyright (c) 1998 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 * This  document  may  not, in  whole  or in  part, be  copied,  photocopied,
 * reproduced,  translated,  or  reduced to any  electronic  medium or machine
 * readable form without prior written consent from Division Ltd.
 *
 ****************************************************************************/

#ifndef __DVCON_H
#define __DVCON_H

#ifndef DVCON_EXPORT
#if defined(_WIN32) && !defined(_WINDU_SOURCE) && !defined(__EPP__) && !defined(BUILD_STATIC)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `extern'
 */
#if defined _LIB_DIVU
#define DVCON_EXPORT __declspec(dllexport) extern 
#else
#define DVCON_EXPORT __declspec(dllimport) extern 
#endif 
#else
#define DVCON_EXPORT extern
#endif
#endif

#include <string.h>
#include <stdarg.h>
#include <dsys/pgeneral.h>
#ifdef _WIN32
#include <windows.h>
#endif

#ifdef _WIN32
/* the following is defined in winsock.h, dvconSocket should be defind to SOCKET
 * and dvconSOCKET_ERROR to SOCKET_ERROR but to avoid the inclusion they are defined
 * here
 */
#define	dvconSOCKET_ERROR ((unsigned int) -1)
typedef	unsigned int dvconSocket;
#else
#define	dvconSOCKET_ERROR -1
typedef	int dvconSocket;
#endif


#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

/* typedef int32 (*dvconFunction)(char  *rcpName, 
 *                                char  *fileName, 
 *                                char  *filePart, 
 *                                char  *outName,
 *                                char  *outPath) 
 */
typedef int32 (*dvconFunction)(char *, char *, char *, char *, char *) ; 

/*
 * char *dvconCreateTimeStamp(void) ;
 * char *dvconFileCreateTimeStamp(char *fileName) ;
 * 
 * Format the resultant timestamp is:-
 * 
 *    YYYY:MM:DD:hh:mm:ss:SSS
 * 
 * Where:
 *     YYYY - Year i.e. 1997
 *     MM   - Month of year 1-12
 *     DD   - Day of the month 1-31
 *     hh   - Hours 0-23
 *     mm   - Minutes 0-59
 *     ss   - Seconds 0-59
 */
DVCON_EXPORT char *
dvconCreateTimeStamp(void) ;
DVCON_EXPORT char *
dvconFileCreateTimeStamp(char *fileName) ;

/*
 * int32 dvconTimeStampCmp(char *ts1, char *ts2) ;
 * 
 * returns:
 * 
 * -ve: If ts1 is older than ts2
 *   0: If ts1 is thesame as ts2
 * +ve: If ts1 is newer than ts2
 */
#define dvconTimeStampCmp(ts1,ts2) (strcmp(ts1,ts2))

/*
 * void dvconTimeStampFree(char *ts) ;
 * 
 * Frees of a Created TimeStamp
 */
#define dvconTimeStampFree(ts) (dpgFree(ts))

/* dvconRegexpStrCmp - regular expression comparer
 * 
 * reg is the regular expersion which is matched against str
 * reg's special chars are * ? [
 * in a [, a ^ can follow meaning not, and ranges are allowed
 * the exact flag indicates a case sensitive comparision
 */
DVCON_EXPORT int
dvconRegexpStrCmp(char *str, char *reg, int exact) ;

/* File name and part name munging support ***********************************/
/*
 * char *dvconFileNameCreate(char *fileName, char *filePart)
 * char *dvconFileNameGetPart(char *fileName)
 *
 */
#define dvconFILENAME_PARTLEN 6
#define dvconFILENAME_PARTSTR ":Part:"
DVCON_EXPORT char *
dvconFileNameCreate(char *fileName, char *filePart) ;
#define dvconFileNameGetPart(fileName) (strstr(fileName,dvconFILENAME_PARTSTR))

#define dvconFILENAME_RPEXTLEN 7
#define dvconFILENAME_RPEXTSTR ":RpExt:"
#define dvconFileNameGetExtensionReplace(fileName) (strstr(fileName,dvconFILENAME_RPEXTSTR))

/*
 * dvconOutput - what output is required.
 * 
 * Current default is to output everything, ol files as non-gzipped ascii
 */
#define dvconOUTPUT_VDI        0x00001
#define dvconOUTPUT_BGF        0x00002
#define dvconOUTPUT_ED         0x00004
#define dvconOUTPUT_OL         0x00008
#define dvconOUTPUT_OLGZIP     0x00010
#define dvconOUTPUT_OLASCII    0x00020
#define dvconOUTPUT_SOLID      0x00040
#define dvconOUTPUT_QUILT      0x00080
#define dvconOUTPUT_DATUM      0x00100
#define dvconOUTPUT_OLSURFACES 0x00200
#define dvconOUTPUT_OLCURVES   0x00400
#define dvconOUTPUT_OLNURBS    0x00800
#define dvconOUTPUT_OLTESSEL   0x01000
#define dvconOUTPUT_OLGDTS     0x02000
#define dvconOUTPUT_DRAWING    0x04000
#define dvconOUTPUT_BGFCURVES  0x08000
#define dvconOUTPUT_BGFPOINTS  0x10000
#define dvconOUTPUT_BGFTEXTS   0x20000
#define dvconOUTPUT_BGFGDTS    0x40000
#define dvconOUTPUT_COUNT      19

#define dvconOUTPUT_DEFAULT    0x03ed3

DVCON_EXPORT char dvconOutputLetter[] ;
DVCON_EXPORT int32 dvconOutput ;
#define dvconOutputVDI()            (dvconOutput & dvconOUTPUT_VDI)
#define dvconOutputBGF()            (dvconOutput & dvconOUTPUT_BGF)
#define dvconOutputED()             (dvconOutput & dvconOUTPUT_ED)
#define dvconOutputOL()             (dvconOutput & dvconOUTPUT_OL)
#define dvconOutputOLGzip()         (dvconOutput & dvconOUTPUT_OLGZIP)
#define dvconOutputOLAscii()        (dvconOutput & dvconOUTPUT_OLASCII)
#define dvconOutputOLBinary()       (!(dvconOutput & dvconOUTPUT_OLASCII))
#define dvconOutputSolid()          (dvconOutput & dvconOUTPUT_SOLID)
#define dvconOutputQuilt()          (dvconOutput & dvconOUTPUT_QUILT)
#define dvconOutputDatum()          (dvconOutput & dvconOUTPUT_DATUM)
#define dvconOutputOLSurfaces()     (dvconOutput & dvconOUTPUT_OLSURFACES)
#define dvconOutputOLCurves()       (dvconOutput & dvconOUTPUT_OLCURVES)
#define dvconOutputOLNurbs()        (dvconOutput & dvconOUTPUT_OLNURBS)
#define dvconOutputOLTessellation() (dvconOutput & dvconOUTPUT_OLTESSEL)
#define dvconOutputOLGDTs()         (dvconOutput & dvconOUTPUT_OLGDTS)
#define dvconOutputDrawing()        (dvconOutput & dvconOUTPUT_DRAWING)
#define dvconOutputBGFCurves()      (dvconOutput & dvconOUTPUT_BGFCURVES)
#define dvconOutputBGFPoints()      (dvconOutput & dvconOUTPUT_BGFPOINTS)
#define dvconOutputBGFTexts()       (dvconOutput & dvconOUTPUT_BGFTEXTS)
#define dvconOutputBGFGDTs()        (dvconOutput & dvconOUTPUT_BGFGDTS)
#define dvconOutputCurves()         \
(((dvconOutput & (dvconOUTPUT_OL|dvconOUTPUT_OLCURVES)) == (dvconOUTPUT_OL|dvconOUTPUT_OLCURVES)) || \
 ((dvconOutput & (dvconOUTPUT_BGF|dvconOUTPUT_BGFCURVES)) == (dvconOUTPUT_BGF|dvconOUTPUT_BGFCURVES)))
#define dvconOutputGDTs()           \
(((dvconOutput & (dvconOUTPUT_OL|dvconOUTPUT_OLGDTS)) == (dvconOUTPUT_OL|dvconOUTPUT_OLGDTS)) || \
 ((dvconOutput & (dvconOUTPUT_BGF|dvconOUTPUT_BGFGDTS)) == (dvconOUTPUT_BGF|dvconOUTPUT_BGFGDTS)))
#define dvconOutputPoints()         \
((dvconOutput & (dvconOUTPUT_BGF|dvconOUTPUT_BGFPOINTS)) == (dvconOUTPUT_BGF|dvconOUTPUT_BGFPOINTS))
#define dvconOutputTexts()          \
((dvconOutput & (dvconOUTPUT_BGF|dvconOUTPUT_BGFTEXTS)) == (dvconOUTPUT_BGF|dvconOUTPUT_BGFTEXTS))

/* Piped Child support ******************************************************/

#define dvconMODE_COMMLINE  0
#define dvconMODE_PUBLISH   1
#define dvconMODE_DVCONVERT 2
#define dvconMODE_WORKER    3
DVCON_EXPORT int32
dvconModeSet(int32 mode) ;
DVCON_EXPORT int32
dvconModeGet(void) ;

#define dvconCOMM_STDIO   0
#define dvconCOMM_PIPED   1
#define dvconCOMM_SOCKET  2
DVCON_EXPORT int32
dvconCommSetStdio(void) ;
DVCON_EXPORT int32
dvconCommSetPiped(void) ;
DVCON_EXPORT int32
dvconCommSetSocket(char *host, int32 port) ;
DVCON_EXPORT int32
dvconCommGet(void) ;

DVCON_EXPORT int32
dvconConversionDepthGet(void) ;

/* Child reading commands ***************************************************/
DVCON_EXPORT int32
dvconChildReadLine(char *buff, int buffSize) ;
#define dvconCOMMAND_EXIT    0
#define dvconCOMMAND_CONVERT 1
DVCON_EXPORT int32
dvconChildReadCommand(char **rcpName, char **fileName, char **filePart,
                      char **outName, char **outPath) ;

/* Child writing commands ***************************************************/
DVCON_EXPORT int32
dvconChildPeek(void) ;
DVCON_EXPORT void
dvconChildPrintInfo(char *format, ...) ;
DVCON_EXPORT void
dvconChildSetOutputFile(char *outFile) ;
DVCON_EXPORT void
dvconChildStartSection(char *section) ;
DVCON_EXPORT void
dvconChildPrintPercent(uint32 Cur, uint32 Tot) ;
DVCON_EXPORT void
dvconChildPrintActivity(void) ;
DVCON_EXPORT int32
dvconChildRequestQuit(char *name) ;
DVCON_EXPORT int32
dvconChildRequestFlip(int32 flip0, int32 flip1) ;
DVCON_EXPORT void
dvconChildCompleteSection(void) ;
DVCON_EXPORT void
dvconChildCompleteCommand(int32 status) ;

/* Child main loop (for converters) *****************************************/
#define dvcon_IDENT -2
#define dvcon_HELP  -3
DVCON_EXPORT void
dvconHelpPrintOptions(void) ;
DVCON_EXPORT int32
dvconChildInit(int32 argc, char *argv[], char ***files) ;
DVCON_EXPORT void
dvconFileCacheAddFile(char *rcpName, char *fileName, char *outName, char *outPath, int32 fileId) ;
DVCON_EXPORT int32
dvconChildMain(int32 argc, char *argv[], char *convName, dvconFunction convFunc) ;
DVCON_EXPORT int32
dvconChildLicenseFailure(void) ;

DVCON_EXPORT char *
dvconChildGetRcpFileName(void) ;
DVCON_EXPORT char *
dvconChildGetOutPath(void) ;
DVCON_EXPORT char *
dvconChildGetOutName(void) ;

/* Parent spawning, reading and writing commands ****************************/
typedef struct dvconProgram {
    struct dvconProgram *next ;
    char *progname ;
    int   pid ;
#ifdef _WIN32
    HANDLE  outFd ;
    HANDLE  inFd ;
    HANDLE  hProcess ;
    DWORD   dwProcessId ;
#else
    int     outFd ;
    int     inFd ;
#endif
    int32   read ;
    int32   offset ;
    char    buffer[2048] ;
} dvconProgram ;

DVCON_EXPORT dvconProgram *dvconProgramHead ;

/* dconProgramGet
 * 
 * Gets the dconProgram handle for the given progname, if non exists,
 * then the program is spawned and a new dvconProgram is created and 
 * added to the stack
 * 
 * dvconProgramLocate uses the env var $PATH to search for the given program
 *                  (using extensions .bat, .exe & .com on windows), returns
 *                  non-zero if the program was found.
 * 
 * dvconProgramFind looks for the given program and returns it if found,
 *                  otherwise it returns null.
 * 
 * dvconProgramGet  looks for the given program and if not found it
 *                  creates it.
 */
DVCON_EXPORT int32
dvconProgramGetSocket(dvconSocket *sock) ;
DVCON_EXPORT dvconProgram *
dvconProgramFind(char *progname) ;
DVCON_EXPORT int32
dvconProgramLocate(char *progname) ;
DVCON_EXPORT dvconProgram *
dvconProgramGet(char *progname, char **argv, char *rhost, dvconSocket sock) ;
DVCON_EXPORT void
dvconProgramFree(dvconProgram *prog) ;
DVCON_EXPORT void
dvconProgramWriteLine(dvconProgram *prog, char *line) ;
DVCON_EXPORT void
dvconProgramWriteCommand(dvconProgram *prog, char command, char *line) ;
#define dvcon_TIMEOUT -2
DVCON_EXPORT int32
dvconProgramReadLine(dvconProgram *prog, char *buff, int32 buffSize, int32 timeOut) ;
DVCON_EXPORT int32
dvconProgramPeek(dvconProgram *prog) ;

/* dvcon standard options */
#define dvcon_OR_IDENT     1
#define dvcon_OR_HELP      2
#define dvcon_OR_ONAME     3
#define dvcon_OR_OPATH     4
#define dvcon_OR_RCPNAME   5
#define dvcon_OR_DVCONVERT 6
#define dvcon_OR_WORKER    7
#define dvcon_OR_PUBLISH   8
#define dvcon_OR_PIPED     9
#define dvcon_OR_SOCKET   10
#define dvcon_OR_OUTPUT   11
#define dvcon_OR_VCON     12
#define dvcon_OR_VCON1    13
#define dvcon_OR_VCON2    14
#define dvcon_OR_VLOG     15
#define dvcon_OR_VERROR   16
#define dvcon_OR_VWARN    17
#define dvcon_OR_VPRCSS   18
#define dvcon_OR_VMNTR    19
#define dvcon_OR_DEPTH    20
DVCON_EXPORT dpgTABLE dvconOptionsTable[] ;

/* dvcon conversion stats support *****************************************/
DVCON_EXPORT int32 dvconStatsReadDisabled ;
DVCON_EXPORT int32 dvconStatsReadUnknown ;
DVCON_EXPORT int32 dvconStatsReadIgnored ;
DVCON_EXPORT int32 dvconStatsReadFailure ;
DVCON_EXPORT int32 dvconStatsReadSurfaceFailure ;
DVCON_EXPORT int32 dvconStatsReadCurveFailure ;
DVCON_EXPORT int32 dvconStatsReadGDTFailure ;
DVCON_EXPORT int32 dvconStatsReadPointFailure ;
DVCON_EXPORT int32 dvconStatsReadTextFailure ;
DVCON_EXPORT int32 dvconStatsSurface ;
DVCON_EXPORT int32 dvconStatsCurve ;
DVCON_EXPORT int32 dvconStatsGDT ;
DVCON_EXPORT int32 dvconStatsText ;
DVCON_EXPORT int32 dvconStatsPoint ;
DVCON_EXPORT int32 dvconStatsSurfaceOLDisabled ;
DVCON_EXPORT int32 dvconStatsCurveOLDisabled ;
DVCON_EXPORT int32 dvconStatsGDTOLDisabled ;
DVCON_EXPORT int32 dvconStatsSurfaceOLFailed ;
DVCON_EXPORT int32 dvconStatsCurveOLFailed ;
DVCON_EXPORT int32 dvconStatsGDTOLFailed ;
DVCON_EXPORT int32 dvconStatsSurfaceBGFDisabled ;
DVCON_EXPORT int32 dvconStatsCurveBGFDisabled ;
DVCON_EXPORT int32 dvconStatsPointBGFDisabled ;
DVCON_EXPORT int32 dvconStatsTextBGFDisabled ;
DVCON_EXPORT int32 dvconStatsSurfaceBGFFailed ;
DVCON_EXPORT int32 dvconStatsCurveBGFFailed ;
DVCON_EXPORT int32 dvconStatsGDTBGFFailed ;
DVCON_EXPORT int32 dvconStatsPointBGFFailed ;
DVCON_EXPORT int32 dvconStatsTextBGFFailed ;

#define dvconStatsIncReadDisabled()       (dvconStatsReadDisabled++)
#define dvconStatsIncReadUnknown()        (dvconStatsReadUnknown++)
#define dvconStatsIncReadIgnored()        (dvconStatsReadIgnored++)
#define dvconStatsIncReadFailure()        (dvconStatsReadFailure++)
#define dvconStatsIncReadSurfaceFailure() (dvconStatsReadSurfaceFailure++)
#define dvconStatsIncReadCurveFailure()   (dvconStatsReadCurveFailure++)
#define dvconStatsIncReadGDTFailure()     (dvconStatsReadGDTFailure++)
#define dvconStatsIncReadPointFailure()   (dvconStatsReadPointFailure++)
#define dvconStatsIncReadTextFailure()    (dvconStatsReadTextFailure++)
#define dvconStatsIncSurface()            (dvconStatsSurface++)
#define dvconStatsIncCurve()              (dvconStatsCurve++)
#define dvconStatsIncGDT()                (dvconStatsGDT++)
#define dvconStatsIncPoint()              (dvconStatsPoint++)
#define dvconStatsIncText()               (dvconStatsText++)
#define dvconStatsIncSurfaceOLDisabled()  (dvconStatsSurfaceOLDisabled++)
#define dvconStatsIncCurveOLDisabled()    (dvconStatsCurveOLDisabled++)
#define dvconStatsIncGDTOLDisabled()      (dvconStatsGDTOLDisabled++)
#define dvconStatsIncSurfaceOLFailed()    (dvconStatsSurfaceOLFailed++)
#define dvconStatsIncCurveOLFailed()      (dvconStatsCurveOLFailed++)
#define dvconStatsIncGDTOLFailed()        (dvconStatsGDTOLFailed++)
#define dvconStatsIncSurfaceBGFDisabled() (dvconStatsSurfaceBGFDisabled++)
#define dvconStatsIncCurveBGFDisabled()   (dvconStatsCurveBGFDisabled++)
#define dvconStatsIncPointBGFDisabled()   (dvconStatsPointBGFDisabled++)
#define dvconStatsIncTextBGFDisabled()    (dvconStatsTextBGFDisabled++)
#define dvconStatsIncSurfaceBGFFailed()   (dvconStatsSurfaceBGFFailed++)
#define dvconStatsIncCurveBGFFailed()     (dvconStatsCurveBGFFailed++)
#define dvconStatsIncGDTBGFFailed()       (dvconStatsGDTBGFFailed++)
#define dvconStatsIncPointBGFFailed()     (dvconStatsPointBGFFailed++)
#define dvconStatsIncTextBGFFailed()      (dvconStatsTextBGFFailed++)

DVCON_EXPORT void
dvconStatsReset(void) ;
DVCON_EXPORT void
dvconStatsPrint(void) ;

/* dvcon performance timing routines***************************************/
DVCON_EXPORT float64
dvconTimeGetCurrent(void) ;
#define dvconTimeGetDiff(t1,t2) (t2-t1)

/* dvcon version **********************************************************/
DVCON_EXPORT void
dvconVersion(FILE *fp)  ;

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif
#endif /* __DVCON_H */
