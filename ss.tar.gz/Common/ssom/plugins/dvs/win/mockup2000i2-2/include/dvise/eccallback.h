/*
 *    PROJECT:      DVS
 *    SUBSYSTEM:    libec
 *    MODULE:       callback.h
 *
 *    File:         $RCSfile: eccallback.h,v $
 *    Revision:     $Revision: 1.15 $
 *    Date:         $Date: 2000/05/22 11:03:30 $
 *    Author:       $Author: simon $
 *    RCS Ident:    $Id: eccallback.h,v 1.15 2000/05/22 11:03:30 simon Exp $
 *
 *    FUNCTION:
 * provide classes to manage C++ callback functionality
 *
 *
 * Copyright (c) 1998 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _CALLBACK_H
#define _CALLBACK_H

#include <list.h>

#ifndef _ECASSERT_H
#include "ecassert.h"
#endif

struct ECGlobalCallbackInfo;

class  _ECBaseItem;

struct ECCallbackInfo
{
    _ECBaseItem *callbackItem;
};

extern "C"
{
 typedef void       (*ecCallbackFunc)(ECCallbackInfo *, void *data);
 typedef void (*ecGlobalCallbackFunc)(ECGlobalCallbackInfo *, void *data);
}

class DV_EXPORT ecCallback
{
public:
    
private:
    bool            active;
    bool            delayedRm;
    ecCallbackFunc  pmf; //func to call back
    void          *data;
public:
// This needs to be here to keep windows happy
    inline    ecCallback(ecCallbackFunc xmf, void *d) :active(false),delayedRm(false),pmf(xmf),data(d){};
    inline    ecCallback()                            :active(false),delayedRm(false),pmf(0),data(0){};

              ecCallback(const ecCallback &);
    bool    needsRemoval(void) const;
    void  markForRemoval(void);
    void            call(ECCallbackInfo *);
    void   replaceCbFunc(ecCallbackFunc xmf)          {pmf = xmf;} 
    void   replaceCbData(void *d)                     {data = d;} 
    void replaceCallback(ecCallbackFunc xmf, void *d) {pmf = xmf;data = d;} 
};
  
    
//
// the basic callback list. 
// Is really just a basic STL list of callback items, 
// with some safety features to cope with adding to and
// deleting from a list that is being traversed.
// recursive calls to the same callback node are also trapped.

class DV_EXPORT ecCallbackList
{
public:
    /*
     * member types
     */

    typedef list<ecCallback> cbList;
    typedef cbList::iterator         iterator;
     
private:
    bool   inUse;
    bool   delayedRm;
    cbList delayedAdd;
    cbList callbacks;

    void          checkIterIsOnList(iterator &x);    
    void      doDelayedHousekeeping(void);
public:
        //TODO: do we need specific copy constructor???
                     ecCallbackList();
    void                      flush(void);
    inline iterator     addCallback(const ecCallback &cb);
    inline iterator     addCallback(ecCallbackFunc pmf, void *data) {return addCallback(ecCallback(pmf,data));}
    void             removeCallback(iterator &);

        // Also checks for any delayed adds & Rms that are needed.
    void              callCallbacks(ECCallbackInfo *);
    void        callGlobalCallbacks(ECGlobalCallbackInfo *);
    bool                      empty(void) const;

    inline size_t              size(void) const;
};


/*
 * From here on its just defs of member functions.
 */
 
inline
ecCallback::ecCallback(const ecCallback &x) :active(false),delayedRm(false),data(x.data),pmf(x.pmf){}

 
inline bool
ecCallback::needsRemoval(void) const
{
    return delayedRm;
}

 
inline void
ecCallback::markForRemoval(void)
{
    delayedRm = true;
}

 
inline void
ecCallback::call(ECCallbackInfo *info)
{
    if(active){
//TODO - implement the throw properly
        abort();// throw some error
    }
    if (!needsRemoval()) {
        active = true;
        pmf(info, data);
        active = false;
    }
}

//member funcs for ecCallbackList

inline void
ecCallbackList::checkIterIsOnList(iterator &x)
{
#ifndef NDEBUG
        // Check if x is really on our list!(check delayed add list too)
     iterator y    = callbacks.begin();
     iterator last = callbacks.end();
     while ( y != last) {
         if (x == y)
             break;
         ++y;
     }
     if ( y == last) {
         y    = delayedAdd.begin();
         last = delayedAdd.end();
         while ( y != last) {
             if (x == y)
                 break;
             ++y;
         }
         ECAssert(y != last);
     }
#endif
}

inline void 
ecCallbackList::doDelayedHousekeeping(void)
{
        // do delayed adds
    callbacks.splice(callbacks.end(), delayedAdd);
        //ECAssert (delayedAdd.empty());
    
        // do delayed removes.
    if(delayedRm) {
            //would like to use 'remove_if()'
            //- but get 'internal compiler error' messages
        iterator first = callbacks.begin();
        iterator last  = callbacks.end();
        while (first != last) {
            iterator next = first;
            ++next;
            if ((*first).needsRemoval())
                callbacks.erase(first);
            first = next;
        }
        delayedRm = false;   
    }
}

inline
ecCallbackList::ecCallbackList()
        :inUse(false),
         delayedRm(false)
{}

 
inline void
ecCallbackList::flush(void)
{
    if(inUse) {
        iterator y    = callbacks.begin();
        iterator last = callbacks.end();
        while( y != last) {
            (*y).markForRemoval();
            y++;
        }
    }
    else
        callbacks.erase(callbacks.begin(),callbacks.end());
    
    delayedAdd.erase(delayedAdd.begin(),delayedAdd.end());
}

inline ecCallbackList::iterator
ecCallbackList::addCallback(const ecCallback &cb)
{
    if(inUse) {
        delayedAdd.push_back(cb);
        return (--delayedAdd.end());
    }
    else {
        callbacks.push_back(cb);
        return (--callbacks.end());
    }
}
 
inline void
ecCallbackList::removeCallback(iterator &x)
{
    checkIterIsOnList(x);
    
    if (inUse){
        delayedRm = true;
        (*x).markForRemoval();
    }
    else
        callbacks.erase(x);
}
 
inline void
ecCallbackList::callGlobalCallbacks(ECGlobalCallbackInfo *info)
{
    inUse = true;

    iterator y    = callbacks.begin();
    iterator last = callbacks.end();
    while( y != last) {
        (*y).call((ECCallbackInfo *)info);
        y++;
    }
    inUse = false;
    doDelayedHousekeeping();
}

inline void
ecCallbackList::callCallbacks(ECCallbackInfo *info)
{
    inUse = true;

    iterator y    = callbacks.begin();
    iterator last = callbacks.end();
    while( y != last) {
        (*y).call(info);
        y++;
    }
    inUse = false;
    doDelayedHousekeeping();
}

 
inline bool 
ecCallbackList::empty(void) const
{
    return callbacks.empty();
}


inline size_t
ecCallbackList::size(void) const
{
    return callbacks.size();
}

#endif /*_CALLBACK_H */
