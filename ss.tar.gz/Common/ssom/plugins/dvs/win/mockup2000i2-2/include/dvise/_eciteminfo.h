
#include "eccppitem.h"

#ifdef __cplusplus
extern "C" {
#endif
ECCppItem *ECParseItem(dParseFilePtr IS, hierarchy *pH, int *parsedOk);
ECCppItem *ECParseItemFromUserData(ECUserData *ud);
int ECWriteItem(ECCppItem *item);
ECCppItem *ECWriteItem_GetCppItem(void);
    
int ECCppItemToVC(ECCppItem *item);
int ECCppItemRemoveFromVC(ECCppItem *item);
#ifdef __cplusplus
}
#endif
