/*
 *    PROJECT:      DVS
 *    SUBSYSTEM:    vl
 *    MODULE:       vlmanager.h
 *
 *    File:         $RCSfile: vlmanager.h,v $
 *    Revision:     $Revision: 1.16 $
 *    Date:         $Date: 2000/05/11 14:21:42 $
 *    Author:       $Author: john $
 *    RCS Ident:    $Id: vlmanager.h,v 1.16 2000/05/11 14:21:42 john Exp $
 *
 *    FUNCTION:
 *    external defs of the functions in
 *    server.c
 *
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _VLMANAGER_H
#define _VLMANAGER_H

#define DVS_VERBOSE_ACTOR         0x000000001
#define DVS_VERBOSE_DVS           0x000000002
#define DVS_VERBOSE_LICENCE       0x000000004
#define DVS_VERBOSE_SHUTDOWN      0x000000008

typedef enum {VL_SPAWNED, 
              VL_CONNECTED,
              VL_DISCONNECTED,
              VL_WAITING_DOMAIN,
              VL_INCONSISTENT
} VLActorState;
typedef void (*VLManagerTimeoutFunc) (void *data);

extern int dvsVerboseHandle;
extern void     VLShutdownDomain(void);
#ifdef OLD_SERVER
extern VLStatus VLCreateDomain(char8   *domain,
                               uint32   master,
                               int32    key,
                               int32    memSize,
                               void    *memAddr,
                               int32    semCount,
                               int32    instBuckets,
                               int32    elemBuckets,
                               int32    streamBuckets,
                               int32     memcheck,
                               char8	*systemName);
#else
extern VLStatus VLCreateDomain(char8   *domain,
                               uint32   master,
                               int32    key,
                               int32    memSize,
                               void    *memAddr,
                               int32    numProcesses,
                               int32    instBuckets,
                               int32    elemBuckets,
                               int32    memcheck,
                               int32    dbcheck,
                               char8   *systemName,
                               char8   *networkName,
                               int      permissions,
                               int      forceStart);
#endif
VLStatus VLServeDomain(VLManagerTimeoutFunc func, void *data);
int	 VLGetManagerPipeFd(void);
void	 VLProcessServerCommand(int fd, char *buf);
ActorId  VLGetLockHolder(void);
void	 VLSetLockHolder(ActorId id);
int	 VLCleanupActor(ActorId id);
void	 VLManagerUnlock(void);
void	 VLCloseDomain(void);
int	 VLManagerSendMessages(void);
int      VLManagerCloseActor(ActorId id);
void     VLSendDomainId(int32 fd);
void     VLSendActorTerminate(void);
void     VLSendActorNoLicense(void);
void     VLManagerCleanup(int numActors);
char    *VLManagerGetErrorFileName(void);

void     managerSetActorId(int fd, long actorId);
int      managerSetActorPid(int fd, int32 pid);
ActorId  managerGetActorId(int fd);
VLActorState managerGetActorState(int fd);
void     managerSetActorState(int fd, VLActorState state);
int      managerSetActorCleanupFlag(int fd, int cleanup);
void     doDelayedCleanups(void);
void     sendDelayedDomainIds(void);
void     VLAddActorSocketToInfoFile( int aid );
void     VLAddPidToInfoFile( dpPid pid );
void     VLRemovePidFromInfoFile( dpPid pid );
void     VLAddIpcToInfoFile( dpIpcCtl *ipcCtrl );
void     VLRemoveActorSocket(int actorId);
int VLCleanupPreviousSession( char *domain );
int validatePidFromInfoFile( dpPid pid );
#endif /*_VLMANAGER_H */
