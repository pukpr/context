/*
       PROJET:
       SUBSYSTEM:
       MODULE:

       FILE:           $RCSfile: vceltype.h,v $
       REVISION:       $Revision: 1.45 $
       Date:           $Date: 2000/05/02 09:10:29 $
       Author:         $Author: scgriffiths $
       RCS Ident:      $Id: vceltype.h,v 1.45 2000/05/02 09:10:29 scgriffiths Exp $

       FUNCTION:




  Copyright (c) 1992 Division Ltd.

  All Rights Reserved.

  This Document may not, in whole or in part, be copied,
  photocopied, reproduced, translated, or reduced to and
  electronic medium or machine readable form without prior
  written consent from Division Ltd.
*/
#ifndef VCELTYPE_H
#define VCELTYPE_H
#ifdef _LIB_VC
#include <vcdefs.h>

#else
#include <dvs/vcdefs.h>
#endif


#define InstanceNo uint32	/* Define InstanceNo as a basic type !! */

#ifndef VCColor
typedef float32		VCColour[3];
#endif
typedef struct
{
    uint32 	secs;
    uint32	uSecs;
} VCTime;


/* NOTE: All attributes which can be attached to entities
 *       SHOULD have parentEntity as the first field.
 */
typedef struct
{
    InstanceNo parentEntity;
}_VCAttrTemplate;

typedef struct
{
    InstanceNo parentEntity;
    uint32          	mode;
    int32	    	loopCnt;
    float32         	gain;
    uint16		play;
    uint8		velocity;
    int8		priority;
    InstanceNo		audioResourceIno;
    char8		voice[1];
} _VCAudio;

typedef struct
{
    uint16     		 mode;
    uint16		 recordStart;
    uint16		 recordEnd;
    InstanceNo		audioResourceIno;
    char8     		 name[1];
} _VCAudioRecord;

typedef struct
{
    char8	name[VC_RADIATOR_NAME_LENGTH];
    int32       numPoints;
    float32	points[VC_RADIATOR_MAX_POINTS];
} _VCRadiator;


typedef struct
{
    InstanceNo parentEntity;
    uint32     mode;
    uint32     flags;
    float32    point[6];
    float32    rotation[6];
} _VCConstraints;

typedef struct
{
    InstanceNo visualIno;
    uint32     mode;
    float32    points[6];
} _VCVisualBoundingBox;

typedef struct
{
    InstanceNo parentEntity;
    uint32     mode;
    uint32     intersectMask;
    InstanceNo dynamicIno;
    InstanceNo bboxIno;
    char8      geometry[1];
} _VCVisual;

typedef struct
{
    InstanceNo sectionIno;
    uint32     mode;
    float32    corners[12];
} _VCSectionBounds;

typedef struct
{
    InstanceNo parentEntity;
    uint32     mode;
    uint32     intersectMask;
    uint32     visualMode;
    InstanceNo boundsIno;
    char8      name[1];
} _VCSection;

typedef struct
{
    uint32	mode;
    float32     ambient[3];
    float32     diffuse[3];
    float32     specular[4];
    float32     emissive[3];
    float32     opacity[3];
    char8       name[1];
} _VCMaterial;

typedef struct
{
    uint32	mode;
    InstanceNo  textureImageIno;
    uint8	minify;
    uint8       magnify;
    uint8       alpha;
    uint8       wrapU;
    uint8       wrapV;
    uint8       detailType;
    char8       name[1];
} _VCTexture;

typedef struct
{
    uint32 mode;
    uint16 width;
    uint16 height;
    uint8  numComponents;
    uint8  image[1];
} _VCTextureImage;

typedef struct
{
    uint16     mode;
    uint16     status;
    InstanceNo textureImageIno;
    int16      width;
    int16      height;
    char8      name[1];
} _VCVisualScreenDump;

typedef struct
{
    uint16     mode;
    InstanceNo firstIno;
    InstanceNo secondIno;
    char8      name[1];
} _VCSectionImageSave;

typedef struct
{
    InstanceNo parentEntity;
    uint32     mode;
    uint16     numberLights;
    float32    radius;
    float32    length;
    float32    lightWidth;
    float32    power;
    float32    startAngle;
    float32    endAngle;
    VCColour   lightColour;
    VCColour   background;
} _VCLightTube;

typedef struct
{
        InstanceNo      boundaryIno;
        uint16          flags;
        dmPoint        	point;
        dmVector       	direction;
        VCTime          time;
} _VCCollisionReport;

typedef struct
{
    InstanceNo		myBoundaryIno;
    uint32		numberCollisions;
    _VCCollisionReport	collisions[1];
} _VCCollisionState;

typedef struct
{
        InstanceNo parentEntity;
        float32         bound[VC_BOUND_SIZE];
        uint32          mode;
        int32		numberCollisions;
        InstanceNo	collisionStateIno;
        InstanceNo	dynamicVisual;
        char8           geometry[1];
} _VCBoundary;

/*
typedef struct VCLightData _VCLight;
*/

typedef struct
{
    InstanceNo parentEntity;
    uint32           mode;
    VCColour         colour;
    float32	     exponent;
    float32	     theta;
} _VCLight;

typedef struct
{
    dmPosition		dmPos;
    uint32		mode;
}_VCPosition;

typedef struct
{
    dmPosition		dmPos;
    uint32		mode;
#ifdef USE_PS_INVC
    uint32		psParent;
#endif
    uint32		parent;
}_VCObject;

typedef struct
{
        InstanceNo parentEntity;
        uint32	actorId;
        char8	name[1];
} _VCBodyPart;

typedef struct
{
    float32     headUpdateRate;     /* No updates / second */
    float32     geometryUpdates;    /* No updates / second */
    float32     frameRate;          /* No frames drawn/second */
    float32     drawRate;           /* Tri's per second */
    char8       name[1];               /* Name of the actor. */
} _VCVisualMonitor;

typedef struct
{
    float32     sensorRate[VC_MAX_SENSORS];      /* Sensor updates per second */
    uint32	sensorBaseNumber;
    char8       name[1];               /* Name of the actor. */
} _VCTrackerMonitor;

typedef struct {
    uint32 	updateRate;
    uint32 	transmissionDelay;
    dmPoint 	sourcePosition;
    dmEuler 	sourceEuler;
    uint32 	baudRate;
    char8 	name[1];
} _VCTracker;

typedef struct {
    InstanceNo parentEntity;
    uint32		mode;
    InstanceNo		trackerIno;
    uint32 		sensorId;
    float32 		scaleTranslate[3];
    float32 		scaleRotate[3];
    float32 		rotationCurveOrder[3];
    float32 		translationCurveOrder[3];
    dmPoint 		prePosition;
    dmPoint 		postPosition;
    dmEuler 		preEuler;
    dmEuler 		postEuler;
    float32 		relativeSphere[6];
    InstanceNo 		positionIno;
    _VCConstraints 	constraints;
    char8       	name[1];               /* Name of the actor. */
} _VCSensorResource;

typedef struct
{
    InstanceNo parentEntity;
    uint32    		 mode;
    InstanceNo     	 inputIno;
    char8       	 name[1];               /* Name of the actor. */
} _VCInputResource;

typedef struct
{
    float32     objectInRate;       /* Object updates per second */
    float32     objectInActive;     /* Objects that are collidable per second */
    float32     objectTests;        /* Number of collision tests per second */
    char8       name[1];               /* Name of the actor. */
} _VCCollideMonitor;

typedef struct
{
    char8       name[1];               /* Name of the actor. */
} _VCBodyMonitor;

typedef struct
{
    InstanceNo parentEntity;
    uint32     mode;
    float32    frameRate;
    float32    iod;
    float32    convergence;
    float32    background[3];
    float32    nearClip;
    float32    farClip;
    float32    fogColour[3];
    float32    nearFog;
    float32    farFog;
    float32    lodScale;
    uint32     frameSyncTime;
    uint32     capability;
    uint32     actorId;
    uint16     flatten;
    uint16     accumSamples;
    uint8      statisticsLevel;
    uint8      maxStatisticsLevel;
    char8      name[1];
} _VCVisualResource;

typedef struct
{
    InstanceNo parentEntity;
    InstanceNo	visualResourceIno;
    uint32     	mode;
    dmPoint    	offset;
    dmEuler    	orientation;
    float32    	size[2];
    char8      	name[1];
} _VCVisualViewResource;

typedef struct
{
    InstanceNo parentEntity;
    char8 name[1];
} _VCVisualSourceResource;

typedef struct
{
    float32	slow_speed;
    float32	fast_speed;
    float32	acceleration;
    float32	max_speed;
    uint32	slow_key;
    InstanceNo	slow_keyLimb;
        uint32	fast_key;
    InstanceNo	fast_keyLimb;
    uint32	accelerate_key;
    InstanceNo	accelerate_keyLimb;
} _VCBodyFlyInfo;

typedef struct
{
    uint32		actorId;
    InstanceNo  	bodyRoot;
    InstanceNo  	bodyPosObject;
    _VCBodyFlyInfo	fly_forward;
    _VCBodyFlyInfo	fly_backward;
    _VCBodyFlyInfo	fly_up;
    _VCBodyFlyInfo	fly_down;
    _VCBodyFlyInfo	fly_left;
    _VCBodyFlyInfo	fly_right;
    _VCBodyFlyInfo	rot_left;
    _VCBodyFlyInfo	rot_right;
    _VCBodyFlyInfo	rot_up;
    _VCBodyFlyInfo	rot_down;
    dmPoint		orbitPoint;
    uint32		verticalFly_key;
    InstanceNo		verticalFly_keyLimb;
    uint32		altFly_key;
    InstanceNo		altFly_keyLimb;
    InstanceNo		flyDirectionLimb;
    InstanceNo		altFlyDirectionLimb;
    InstanceNo		altFlyLimb;
    uint32		flyMode;
    uint32		extraMode;
    uint32		distanceUnit;
    int32		interruptRate;
    uint32		displayNavigator;
    uint32              parentWindow;
    int32               x, y;
    char8       	name[1];
} _VCBody;

typedef struct
{
    InstanceNo ino;
    char8	name[1];
} _VCConfigRequest;

typedef struct
{
    InstanceNo user;
    int32      verboseLevel;
    int32      enable;
    char8       log[4];
    char8       config[1];
} _VCConfigReply;

typedef struct
{
    char8  name[1];
} _VCUser;

typedef struct
{
        InstanceNo	resourceIno;
        uint8  		allocated;
        char8		name[1];
} _VCResource;

typedef struct
{
        InstanceNo	resource;
        int32		updated;
        InstanceNo	serverResource;
        uint32		resourceType;
} _VCResourceRequest;

typedef struct
{
    InstanceNo          parentEntity;
    uint32		mode;
    float32		iad;
    float32		volume;
    float32		spreadingRollOff;
    float32	 	atmosphericAbsorption;
    float32		worldScale;
    char8		name[1];
} _VCAudioResource;

typedef struct
{
    uint32		numWraps;
    int32		head;
    uint32		input[1];
} _VCInput;

typedef struct
{
    InstanceNo parentEntity;
    InstanceNo		pickInstance;
    uint32		mode;
    uint32		pickActorId;
} _VCPickObject;


/* Hoppy, 11/07/98 */
typedef struct
{
    InstanceNo		parentEntity;
    InstanceNo		selectInstance;
    uint32		mode;
    uint32		selectActorId;
} _VCSelectObject;

typedef struct {
    uint32  windowId;               /* Identity of the window */
    char8   name [1];               /* Name of the resource. */
} _VCXWindowId;

typedef struct {

    uint32	 actorId;
    uint32	 mode;
    InstanceNo	 subject;
} _VCQuery;

typedef struct {
    uint32	 status;
    InstanceNo	 result;
} _VCResponse;

typedef struct {
    _VCQuery	 query;
    _VCResponse	 response;
} _VCVisualQuery;

typedef struct
{
    InstanceNo intersectIno;
    uint32     numIntersections;
    uint32     numIntersectionsReported;
    InstanceNo object;
    InstanceNo visual;
    InstanceNo patch;
    dmPoint    point;
    dmVector   normal;
    dmPoint    nearestVertex;
    char8      info[1];
} _VCIntersectionState;

typedef struct
{
    InstanceNo parentEntity;
    uint32	mode;
    float32	length;
    uint32	intersectMask;
    int32	numberIntersections;
    InstanceNo	intersectStateIno;
} _VCVectorIntersect;

typedef struct
{
    InstanceNo parentEntity;
    uint32	mode;
    float32	x;
    float32	y;
    uint32	intersectMask;
    int32	numberIntersections;
    InstanceNo	intersectStateIno;
    char8	pipeName[1];
} _VC2dIntersect;

typedef struct
{
    InstanceNo parentEntity;
    uint32     mode;
    uint32     type;
    dmPoint    offset;
    float32    data[72];
    char8      texture[1];
} _VCVisualEffect;

typedef struct
{
    InstanceNo parentEntity;
    uint32	mode;
    float32	iMass;
    float32	gMass;
    dmPoint	centre;
    float32	iTensor[6];
    float32	spring;
    float32	damper;
    float32	staticFriction;
    float32	dynamicFriction;
} _VCDynamics;

typedef struct
{
    InstanceNo parentEntity;
    uint32	mode;
    dmVector	force;
    dmPoint	point;
} _VCForce;

typedef struct
{
    uint32	mode;
    dmVector	direction;
    float32	gravity;
} _VCPseudoGravity;

typedef struct
{
    InstanceNo parentEntity;
    uint32	mode;
    uint32	actorMask;
} _VCZone;

typedef struct
{
    uint32     mode;
    InstanceNo lod;
    char8      name[1];
} _VCDynamicVisual;

typedef struct
{
    uint32     mode;
    float32    in;
    float32    out;
    dmPoint    reference;
    InstanceNo next;
    char8      name[1];
} _VCLod;

typedef struct
{
    uint32     mode;
    uint8      faceted;
    uint8      vertexFormat;
    uint8      lock;
    uint8      drawMode;
    uint8      drawWidth;
    int32      decal;
    InstanceNo lod;
    char8      name[1];
} _VCGeogroup;

typedef struct
{
    uint32     mode;
    uint32     numVertices;
    InstanceNo geogroup;
} _VCGeometryHeader;

typedef struct
{
    float32          vertices[1];
} _VCVertices;

typedef struct
{
    _VCGeometryHeader header;
    _VCVertices		vertices;
} _VCGeometry;

typedef struct
{
    uint8   font;
    dmPoint position;
    dmEuler orientation;
    dmScale scale;
    char8   text[1];
} _VCTextData;

typedef struct
{
    _VCGeometryHeader header;
    _VCTextData       text;
} _VCText;

typedef struct
{
    uint32    			 numConnections;
    uint32			 mode;
    InstanceNo			 geometry;
} _VCConnectionListHeader;

typedef struct
{
    uint32                	 connections[1];
} _VCConnections;


typedef struct
{
    _VCConnectionListHeader	 header;
    _VCConnections		 connections;
} _VCConnectionList;

typedef struct
{
    float32 pointSize;
    float32 vertices[1];
} _VCPointListData;

/* container. */
typedef struct
{
    _VCGeometryHeader header;
    _VCPointListData  pointList;
} _VCPointList;

typedef struct
{
    VCTime	time;
    char8	name[1];
} _VCSync;

typedef struct
{
    uint32	mode;
    VCColour	minRgb;
    VCColour	maxRgb;
    char8	name[1];
} _VCRamp;




typedef struct
{
    InstanceNo parentEntity;
    uint32		 mode;
    uint32		 state;
    int32		 loopCount;
    float32		 rate;
    char8		 name[1];
} _VCReplayResource;

typedef struct
{
    uint32		 status;
    uint32		 mode;
    char8		 name[1];
} _VCActorResource;

typedef struct
{
    char8		 searchPath[1];
} _VCSearchPath;

typedef struct
{
    uint32		 collisionMode;
    InstanceNo		 objectIno[1];
} _VCCollisionSet;

typedef struct
{
    uint32		 cmd;
    float32		 tolerance;
    uint32		 relation;
    InstanceNo		 exclusionSetIno;
    InstanceNo		 resultsIno;
    InstanceNo		 clearenceSetsIno[1];
} _VCCollisionRequest;

typedef struct
{
    InstanceNo		 boundary1Ino;
    InstanceNo		 boundary2Ino;
    dmMatrix             position1;
    dmMatrix             position2;
    float32              distance;
    int32 		 type;
    float32              polylines[1];
}  _VCCollisionRequestReport;

typedef struct
{
    uint32		 	mode;
    float32		        tolerance;
    InstanceNo	                collisions[1];
}  _VCCollisionRequestState;

typedef struct
{
    uint16		paint;
    uint16		size;
    uint16		queryNewPallete;
    uint16		palleteChanged;
    uint16		mapped;
    uint32		windowHandle;
    uint32              state;
} _VCWindow;


#undef	InstanceNo		/* Remove local Instance Number definition */
#define el_VCReplayResource	el__VCReplayResource
#define el_VCActorResource	el__VCActorResource
#define el_VCPosition el__VCPosition
#define el_VCObjectPosition el__VCObjectPosition
#define el_VCObject el__VCObject
#define el_VCConstraints el__VCConstraints
#define el_VCZone el__VCZone

#define el_VCVisualMonitor el__VCVisualMonitor
#define el_VCConfigRequest el__VCConfigRequest
#define el_VCConfigReply el__VCConfigReply
#define el_VCUser el__VCUser
#define el_VCResource el__VCResource
#define el_VCResourceRequest  el__VCResourceRequest

#define el_VCAudio el__VCAudio
#define el_VCAudioRecord el__VCAudioRecord
#define el_VCRadiator el__VCRadiator
#define el_VCAudioResource el__VCAudioResource

#define el_VCVisualBoundingBox el__VCVisualBoundingBox
#define el_VCVisual el__VCVisual
#define el_VCMaterial el__VCMaterial
#define el_VCTexture el__VCTexture
#define el_VCTextureImage el__VCTextureImage
#define el_VCVisualScreenDump el__VCVisualScreenDump
#define el_VCLight el__VCLight
#define el_VCSectionBounds el__VCSectionBounds
#define el_VCSection el__VCSection
#define el_VCSectionImageSave el__VCSectionImageSave
#define el_VCVisualResource el__VCVisualResource
#define el_VCVisualViewResource el__VCVisualViewResource
#define el_VCVisualSourceResource el__VCVisualSourceResource

#define el_VCLightTube el__VCLightTube

#define el_VCIntersect el__VCIntersect
#define el_VCVectorIntersect el__VCVectorIntersect
#define el_VC2dIntersect el__VC2dIntersect

#define el_VCIntersectionState	el__VCIntersectionState

#define el_VCVisualEffect el__VCVisualEffect

#define el_VCCollisionReport el__VCCollisionReport
#define el_VCCollisionState el__VCCollisionState
#define el_VCBoundary el__VCBoundary

#define el_VCBodyPart  el__VCBodyPart
#define el_VCBodyMonitor el__VCBodyMonitor
#define el_VCBodyFlyInfo el__VCBodyFlyInfo
#define el_VCBody el__VCBody
#define el_VCPickObject el__VCPickObject
/* Hoppy, 11/07/98 */
#define el_VCSelectObject el__VCSelectObject

#define el_VCTrackerMonitor el__VCTrackerMonitor
#define el_VCCollideMonitor el__VCCollideMonitor


#define el_VCSensorResource el__VCSensorResource
#define el_VCTracker el__VCTracker

#define el_VCInputResource el__VCInputResource
#define el_VCInput el__VCInput

#define el_VCXWindowId el__VCXWindowId

#define el_VCQuery el__VCQuery
#define el_VCResponse el__VCResponse
#define el__VCResponse el__VCResponse
#define el_VCVisualQuery el__VCVisualQuery

#define el_VCDynamics el__VCDynamics
#define el_VCForce el__VCForce
#define el_VCPseudoGravity el__VCPseudoGravity

#define el_VCDynamicVisual el__VCDynamicVisual
#define el_VCLod el__VCLod
#define el_VCGeogroup el__VCGeogroup
#define el_VCGeometryHeader el__VCGeometryHeader
#define el_VCGeometry el__VCGeometry
#define el_VCVertices el__VCVertices
#define el_VCTextData el__VCTextData
#define el_VCText el__VCText
#define el_VCConnectionListHeader el__VCConnectionListHeader
#define el_VCConnectionList el__VCConnectionList
#define el_VCConnections el__VCConnections
#define el_VCSync el__VCSync
#define el_VCRamp el__VCRamp
#define el_VCPointListData el__VCPointListData
#define el_VCPointList 			el__VCPointList
#define el_VCSearchPath 		el__VCSearchPath
#define el_VCCollisionRequest 		el__VCCollisionRequest
#define el_VCCollisionSet 		el__VCCollisionSet
#define el_VCCollisionRequestReport 	el__VCCollisionRequestReport
#define el_VCCollisionRequestState 	el__VCCollisionRequestState

#define el_VCWindow			el__VCWindow

#endif /* VCELTYPE_H */
