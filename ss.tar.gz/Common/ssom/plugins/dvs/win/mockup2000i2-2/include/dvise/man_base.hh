#ifndef _MANBASE_HH
#define _MANBASE_HH

#ifndef _swapi_h
#define SWAPI_SEXM 0 /* mannequin sex */
#define SWAPI_SEXF 1

#define SWAPI_PERC05 5 /* mannequin percentile */ 
#define SWAPI_PERC50 50
#define SWAPI_PERC95 95
#endif

DV_EXPORT dvSwRetType 
dvsw_manikin_create(int sex, int percentile, VCBody *body);

#endif
