/*
 *    PROJECT:      DVS
 *    SUBSYSTEM:    dp
 *    MODULE:       divvers.c
 *
 *    File:         $RCSfile: divvers.h,v $
 *    Revision:     $Revision: 1.3 $
 *    Date:         $Date: 1998/07/27 18:01:25 $
 *    Author:       $Author: john $
 *    RCS Ident:    $Id: divvers.h,v 1.3 1998/07/27 18:01:25 john Exp $
 *
 *    FUNCTION:
 *    macro to aid the printing of version no's for components.
 *
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _DIVVERS_H
#define _DIVVERS_H

#ifdef __cplusplus
extern "C" {
#endif
        
#include <stdio.h>
#include <dsys/buildno.h>

#define divVersion(filep,module,description,version) \
do { 										\
    static int done = 0; 							\
    static char *vstring = "@(#)Division dVS. " module " - " description 	\
                           ". Build \'" BUILD_VERSION_NO "\'. " __DATE__ ; 		\
    if (done == 0) { 								\
        fprintf (stdout, "%s\n", &vstring [4]); 				\
        if (filep && filep != stdout )							\
            fprintf (filep, "%s\n", &vstring [4]); 				\
    } 										\
    done = 1; 									\
} while (/*CONSTCOND*/0)

#define div3rdPartyVersion(filep,party,description,version,date) \
do { 										\
    static int done = 0;							\
    static char *vstring = party ". " description 				\
                           ". Version " version ". " date ; 			\
    if (done == 0) {							 	\
        fprintf (stdout, "%s\n", vstring); 					\
        if (filep && filep != stdout) 								\
            fprintf (filep, "%s\n", vstring ); 					\
    } 									        \
    done = 1; 									\
} while (/*CONSTCOND*/0)

#ifdef __cplusplus
}
#endif

#endif
