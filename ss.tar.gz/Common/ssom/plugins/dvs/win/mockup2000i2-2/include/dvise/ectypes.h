/*7 $9 14:52:01 $
 *    Author:       $Author: steve $
 *    RCS Ident:    $Id: ectypes.h,v 1.67 2000/03/07 15:19:44 jeff
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: ectypes.h,v $
 *    Revision:     $Revision: 1.68
 *    Date:         $Date: 2001/06/12 12:47:21 $
 *
 *    FUNCTION: defines data structures used in the EC file read/writer
 * 
 *
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */



#ifndef _ECTYPES_H
#define _ECTYPES_H

#ifndef NO_VC
    /*
     * vc libraries are currently used by:
     * role.c
     * audio.c
     * ecio.c
     */
#include <dvs/vc.h>
#include <dsys/dload.h>

#endif 

#ifdef __cplusplus
extern "C" {
#endif

    /* PUBLIC DEFINES =======================================*/

#define EC_DEBUG  0x200
#define VDI_DEBUG 0x100
#define EC2_DEBUG 0x400

    /* PUBLIC DEFINES =======================================*/

    /* PUBLIC TYPES =========================================*/

    typedef char ECString;
    typedef float32 ECFloat;
    typedef void ECReference;


    typedef struct ECColour { 
        float32 r, g, b;
    } ECColour;

    typedef struct ECVec3 {
        float32 x, y, z;
    } ECVec3;  

    typedef struct ECQuat {
        float32 x, y, z;
        float32 theta;
    }ECQuat;

    /* typedef float32 ECVec3; */

    typedef ECVec3 ECVector;

    typedef enum {
        ECStateUndefined,
        ECStateOff,
        ECStateOn,
        ECStateToggle,
        ECStatePaused, /* for animations */
        ECStateDelete,
        ECStateReset /* looped, terminated animations */
    } ECStateType;

    typedef enum {
        ECPositionAbsolute = 0,
        ECPositionRelative, 
        ECPositionError
    } ECPositionMode;

    typedef enum {
        ECDataTypeNull=0,
        ECDataTypeInt,
        ECDataTypeFloat,
        ECDataTypeVector,
        ECDataTypeColour,
        ECDataTypeString,
        ECDataTypeSentence,
        ECDataTypeAssembly,
        ECDataTypeZone,
        ECDataTypeRole,
        ECDataTypeVoid,
        ECDataTypeState,
        ECDataTypeEvent,
        ECDataTypeFileName,
        ECDataTypeAngle, 
        ECDataTypeAxis,
        ECDataTypeAnimationState,
        ECDataTypeIntVar,
        ECDataTypeFloatVar,
        ECDataTypeVectorVar,
        ECDataTypeColourVar,
        ECDataTypeStringVar,
        ECDataTypeSentenceVar,
        ECDataTypeAssemblyVar,
        ECDataTypeZoneVar,
        ECDataTypeRoleVar,
        ECDataTypeVoidVar,
        ECDataTypeStateVar,
        ECDataTypeEventVar,
        ECDataTypeFileNameVar,
        ECDataTypeAngleVar, 
        ECDataTypeAxisVar,
        ECDataTypeAnimationStateVar
    } ECParameterType;

    typedef enum {
        ECListItemTypeNull=0,
        ECListItemTypeList, ECListItemTypeAssembly, 
        ECListItemTypeRole, ECListItemTypeZone
    } ECListItemType;

    typedef enum {
        ECItemTypeNull=0,
        ECItemTypeAudio, 
        ECItemTypeComment,
        ECItemTypeConstraints, 
        ECItemTypeCollision,
        ECItemTypeEventList, 
        ECItemTypeFile,
        ECItemTypeIcon, 
        ECItemTypeLibrary,
        ECItemTypeLight, 
        ECItemTypeList, 
        ECItemTypeListItem,
        ECItemTypeMaterial,
        ECItemTypeAssembly, 
        ECItemTypePath,
        ECItemTypePosition, 
        ECItemTypeRamp,
        ECItemTypeRole,
        ECItemTypeZone,
        ECItemTypeSystem,
        ECItemTypeText,
        ECItemTypeTexture,
        ECItemTypeTools, 
        ECItemTypeUserData, 
        ECItemTypeVisual,
        ECItemTypePivot,
        ECItemTypeCppItem,

/* 
 * This must be at the end of the list JH
 */
        ECItemTypeLastType
    } ECItemType;

    typedef enum {
        ECFieldTypeNull = 0,
        ECFieldTypeInt,
        ECFieldTypeFloat,
        ECFieldTypeString,
        ECFieldTypeColour,
        ECFieldTypeColor,
        ECFieldTypeVector,
        ECFieldTypeRotation,
        ECFieldTypeState,
        ECFieldTypeAxis,
        ECFieldTypeBinaryData,
        ECFieldTypeAssembly,
        ECFieldTypeZone,
        ECFieldTypeAngle,
        ECFieldTypeAction,
        ECFieldTypeSection,
        ECFieldTypeScale,
        ECFieldTypePosition,
        ECFieldTypeFileName,
        ECFieldTypeURL,
        ECFieldTypeEuler
    } ECFieldType;

    typedef enum {
        ECInstanceNot=0,
        ECInstanceTop,
        ECInstanceChild
    } ECInstanceType;

    typedef enum {
        ECGroupOfAssemblies=0,
        ECGroupOfPairs=1,
        ECGroupSelfIntersect=2,
        ECGroupIllegal
    }ECGroupType;

    struct ECItem;
    struct ECAssembly;
    struct ECAudio;
    struct ECComment;
    struct ECConstraints;
    struct ECCollision;
    struct ECEventList;
    struct ECEvent;
    struct ECExtraEventData;
    struct ECEventData;
    struct EC_DCI_EventData;
    struct ECFile;
    struct ECIcon;
    struct ECLibrary;
    struct ECLight;
    struct ECList;
    struct ECMaterial;
    struct ECAssembly;
    struct ECPosition;
    struct ECRamp;
    struct ECRole;
    struct ECTexture;
    struct ECTools;
    struct ECUserData;
    struct ECVisual;
    struct ECPivot;

    typedef struct ECItem        ECItem;
    typedef struct ECAssembly    ECAssembly;

    typedef struct ECEvent       ECEvent;
    typedef struct ECEventData   ECEventData;
    typedef struct EC_DCI_EventData EC_DCI_EventData;
    typedef struct ECExtraEventData ECExtraEventData;

    typedef struct ECMaterial    ECMaterial;

    typedef struct ECRamp 	     ECRamp;
    typedef struct ECTexture     ECTexture;
    typedef struct ECPivot       ECPivot;


    typedef int (*fileSPfunc)(struct ECFile *);
    typedef int (*ecappPlugFunc)(struct ECAssembly *);

#define ECZone ECAssembly
#define ECLibrary ECAssembly
#define ECGroup ECAssembly

    typedef struct ECGroup_Traverse {
        int index;
    }ECGroup_Traverse;

    struct DCICommsInfo;

    /* DCIString structures store messages.  The structure can store strings
     * containing NULLS as the length is recorded and operations on these
     * strings reallocate the string storage memory as needed.
     */
    typedef struct dciString {
        char *s;                   /* a NULL terminated string */
        size_t l;                  /* length of string (not including the NULL) */
        size_t n;                  /* space allocated for string */
        struct DCICommsInfo *info; /* destination of this message, or all clients if null */
    } DCIString;

    typedef struct ECStringset {
        char *string;
        struct ECStringset *next;
    } ECStringset;
    /* A set of strings.  This is used to store the message for the
     * sendMessage action.
     */

    typedef struct ECWriteData {
        char *filename;
        char *fileDir;
        char *filenameOpen;
        int dynamicNames;
        int writeVisuals;
    } ECWriteData;

    typedef struct ECLight {
        ECItemType      type;
        struct ECAssembly *owner;
        char	   *name;
        char	   *pathName;
        void           *clientData;
        struct ECLight *definition;
        ECItem      *instanceList;
        VCColour	    colour;
        uint32	    mode;
        float32	    exponent;
        float32	    theta;
        int		    instances;
        char	    *libraryName;
        VCAttribute     *vcAttr;
    }  ECLight;

    typedef struct ECVisual {
        ECItemType       type;
        struct ECAssembly *owner;
        char 	    *name;
        char	    *pathName;
        void            *clientData;
        struct ECVisual *definition;
        ECItem      *instanceList;
        uint32 	     mode;
        char	    *frontMaterial;
        char	    *backMaterial;
        char 	    *geometryFilename;
        char 	    *libraryName;
        char	    *lod;
        int 	     instances;
        VCAttribute	    *vcAttr;
        uint32	     intersectMask;
        ECStateType      visStatic;
        char        *frontOverideMaterial;
        char        *backOverideMaterial;
    } ECVisual;

    typedef struct ECListItem {
        ECListItemType type;
        char *name;
    } ECListItem;

    typedef struct ECConstraints {
        ECItemType      type;
        struct ECAssembly *owner;
        char *name; 
        char	    *pathName;
        void            *clientData;
        struct ECConstraints *definition;
        ECItem      *instanceList;
    
        /* lock controls */
        uint32	flags;
        uint32 	mode;
    
        float32		*point; /* six values */	
        float32		*rotation; /* six values */	
    
        /* arbitrary snap plane */
        ECVec3 *lockPlane;
        float32 *lockPlaneDist;
    
        /* Grid values */
        ECVec3 *snapTrans;
        ECVec3 *snapRot;
        ECVec3 *snapScale;
        ECStateType snapTransState;
        ECStateType snapRotState;
        ECStateType snapScaleState;
    
        uint32 instances;
        char *libraryName;
        VCAttribute	*vcAttr;
    } ECConstraints;

    typedef struct ECPlugin {
        uint32	flags;
        char	*file;
        char 	*path;
        DLOAD_HANDLE handle;
        struct ECPlugin	*next;
    } ECPlugin;

    typedef struct ECAudio {
        ECItemType      type;
        struct ECAssembly *owner;
        char	   *name;
        char	   *pathName;
        void           *clientData;
        struct ECAudio *definition;
        ECItem     *instanceList;
        char 	   *voice;
        float32	    gain;
        uint32 	    mode;
        int32	    loopCnt;
        int8	    priority;
        uint8	    velocity;
        uint32	    instances;
        char	   *libraryName;
        char	   *radiatorName;
        char	   *radiatorFileName;
        VCAttribute	   *vcAttr;
    } ECAudio;
    /* Sound information for a EC object */

    typedef struct ECParameter {
        ECParameterType type;
        void *param;
        struct ECParameter *next;
    } ECParameter;

    typedef struct ECActionFunc {
        int              (*func)();
        char            *name;
        void             (*dFunc)();
        ECParameterType *paramTypes;
        char           **paramNames;
        int              numParams;
        char            *comment;
        char		*pluginLib;
        struct ECActionFunc *next;
    } ECActionFunc;

#define EC_ACTION_ANIMATING 0x1
#define EC_ACTION_DELETED   0x2
#define EC_ACTION_TRIGGERED 0x4  /* This action has been invoked (at least once) */

    /* A list of actions which is attached to an event in the
     * ECEvent structure...   
     */
    typedef struct ECAction {
        struct ECActionFunc *actionFunc;
        void                **parameters;
        unsigned short int   flags;
        char                *description;
        struct ECAction     *next;
        struct ECAction     *link;
        char                *exp; /* only used when the action is on an internal event */
        void	            *reserved;
    } ECAction;

    /* The structure associating the event name (as appears in the input file
     * with an id number.
     */
    typedef struct ECEventDef {
        char *name;
	char *helpString;
        unsigned int id;
        struct ECEventDef *next;
    } ECEventDef;

    /* A linked list of events, each with a separate list of actions.
     * This is usually attached either to a ECAssembly or a ECZone.
     * The object name is used for specific collision events and the
     * frames value is used in animation
     */
    typedef struct ECEventList {
        ECItemType          type;
        struct ECAssembly *owner;
        char *name;
        char	       *pathName;
        void               *clientData;
        struct ECEventList *definition;
        ECItem             *instanceList;
        struct ECEvent     *events;
        struct ECEvent     *old_events;
        int                 instances;
        char               *libraryName;
    } ECEventList;

    typedef struct ECTextureImage {
	int width, height;
	uint8 *pixels;

        VCTextureImage     *image;
        VCTexture          *texture;
        VCVisualScreenDump *dump;
        char               *textureName;
	char 		   *pathname;
    } ECTextureImage;

    typedef struct ECIcon {
        ECItemType          type;
        struct ECAssembly  *owner;
        char               *name;
        void               *clientData;
        struct ECIcon      *definition;
        ECItem             *instanceList;
        struct ECItem      *attributes;
        int                 instances;
        char               *libraryName;
        ECStateType         state;       /* for delete */
        ECTextureImage     *image;
    } ECIcon;

    struct ECAssemblyChain;


    /* ECZoneChain is a more simple structure; simply a linked list of
     * pointers to zones.
     */

    typedef struct ECRoleChain {
        struct ECRole *role;
        struct ECRoleChain *next;
    } ECRoleChain;

    typedef struct ECTools {
        ECItemType      type;
        struct ECAssembly *owner;
        char           *name;
        char	   *pathName;
        char           *file;
        struct ECTools *definition;
        ECItem         *instanceList;
        ECStateType     state;
        int             instances;
        char           *libraryName;
        void           *reference;
    } ECTools;

    typedef struct ECLimbInfo {
        int limbNum;
        char *visualFilename;
        struct ECLimbInfo *next;
    } ECLimbInfo;


    typedef struct ECBodyInfo {
        ECColour *backgroundColour;
        dmPoint	*pos;
        dmEuler	*rot;
        dmScale	*scale;
        float32 *nearClip, *farClip;
        float32 *minFly, *maxFly;
        ECLimbInfo *limbs;
    } ECBodyInfo;

    typedef struct ECRole {
        ECItemType         type;
        struct ECFile     *owner;
        char              *name;
        char	      *pathName;
        void              *clientData;
        struct ECRole     *definition;
        ECItem            *instanceList;
        struct ECRole     *next;
        struct ECItem     *attributes;
        int instances;
        char              *libraryName;
        struct ECBodyInfo  bodyInfo;
    } ECRole;


    typedef struct ECPosition {
        ECItemType   type;
        struct ECAssembly *owner;
        char        *name;
        char	*pathName;
        void        *clientData;
        ECPositionMode mode;
        ECPositionMode origMode;
        ECVec3      *position;
        ECVec3      *orientation;
        ECVec3      *scale;
        ECVec3      *zoom;
    } ECPosition;

    typedef struct ECQuatPos {
        ECVec3 *point;
        ECVec3 *scale;
        ECQuat *quat;
    }ECQuatPos;

    typedef struct ECVecString {
        ECVec3 *point;
        char *string;
        struct ECVecString *next;
    } ECVecString;


    /* =========================================================================== */

    typedef struct ECField {
        int type;
        char *keyWord;
        void *data;
        struct ECField *next;
    } ECField;

    typedef struct ECUserData {
        ECItemType     type;
        void          *owner;
        char          *name;
        char          *pathName;
        void          *clientData;
        struct ECUserData *defn;
        char          *keyWord;
        ECField       *fields;
        ECField       *lastField;
        ECItemType     ownerType;
    } ECUserData;

    typedef struct ECBinaryData {
        char *name;
        char *keyWord;
        int32 length;
        void *data;
    } ECBinaryData;

    typedef struct ECComment {
        ECItemType         type;
        struct ECAssembly *owner;
        char *name;
        char *pathName;
        void *clientData;
        char *string;
        int length;
    } ECComment;

    typedef struct ECCollision {
        ECItemType   type;
        struct ECAssembly *owner;
        char        *name;
        char        *pathName;
        void        *clientData;
        struct ECCollision *definition;
        ECItem          *instanceList;
        char        *libraryName;
        uint32	 mode;
        char	*geometry;
	char    *implicitGeometry;
        char	*lod;
        float32	 bound[VC_BOUND_SIZE]; 
        int instances;
        VCAttribute	*vcAttr;
        void        *vcHandler;
    } ECCollision;

    typedef int (*ECActionFunction)(ECEvent *event, ECEventData *data, ECAction *action);
    typedef void (*ECActionDestructor)(ECAction *action);
    /*
     * Here is the linked object structure:
     *
     *  object              ->       next     ->   ...
     *    |                            |
     *    V                            V
     *  child -> next                child
     */

    typedef enum { 
        ECAssemblyStatusUnlocked=0,
        ECAssemblyStatusLocked, 
        ECAssemblyStatusFileFixed, 
        ECAssemblyStatusUndefined
    } ECAssemblyStatus;

    /* Assembly flags */
#define EC_OBJECT_COLLIDE_HANDLER_ADDED 	0x1
#define EC_OBJECT_CREATE_ABSOLUTE 		0x2
#define EC_OBJECT_FREEZE 			0x4
#define EC_OBJECT_FLATTEN 			0x8
#define EC_OBJECT_NO_SAVE			0x10
    /* ALEX
     * EC_OBJECT_SELECTED is a bit mask for the two possible types
     * of object selection.
     */
#define EC_OBJECT_SELECTED			0x60
#define EC_OBJECT_2D_SELECTED			0x20
#define EC_OBJECT_3D_SELECTED			0x40
    /*
     * The following flags are set if the object has been
     * touched or highlighted
     */
#define EC_OBJECT_HIGHLIGHTED			0x80
#define EC_OBJECT_TOUCHED			0x300
#define EC_OBJECT_TOUCHED_2D			0x100
#define EC_OBJECT_TOUCHED_3D			0x200
    /* ALEX
     * These are not used...yet....but might be useful
     * to prevent selecting a picked object.
     */
#define EC_OBJECT_PICKED			0xC00
#define EC_OBJECT_2D_PICKED			0x400
#define EC_OBJECT_3D_PICKED			0x800
    /*
     * This flag is set in an ECAssembly->flags field whilst the object
     * is begin deleted. 
     */
#define EC_OBJECT_BEING_DELETED                 0x1000

    struct list_entity {
        uint8 flags;
        struct list_entity *next;
        struct list_entity *prev;
        void *data;
    };

    typedef struct list_entity CLSN, *pCLSN;

#define CLSN_BLOCK_SIZE		20
#define CLSN_INUSE		0x01
#define CLSN_DO_UNCOLLIDE	0x02
#define CLSN_DO_COLLIDE		0x04

    typedef struct _ECCallbackData
    {
        void    *data;
    } ECCallbackData;

    typedef void (*ECAssemblyCallbackPtr) (struct ECAssembly *object, 
                                           ECCallbackData *callbackData, 
                                           void *userData);

    typedef struct _ECAssemblyCallbackList {
        ECAssemblyCallbackPtr           callbackPtr;
        void                          *userdata;
        struct _ECAssemblyCallbackList  *next;
    } ECAssemblyCallbackList;

    /* attributes can contain 
       struct ECAudio *
       struct ECEventList *
       struct ECCollision *
       struct ECConstraints *
       struct ECIcon *
       struct ECLight *
       struct ECPhysicl *
       struct ECPosition *
       struct ECReference *
       struct ECUserData *
       struct ECVisual *
       */

    /* the following structures (ECXxxReference) are used as the data values
     * of parameters of action functions which specify an object, zone, role,
     * etc. by name which is to be referenced at run time.
     */
    typedef struct ECAssemblyReference {
        char *name;
        ECAssembly *object;
    } ECAssemblyReference;

    typedef struct ECRoleReference {
        char *name;
        ECRole *role;
    } ECRoleReference;

    typedef struct ECArgReference {
        char *exp;
        ECParameterType type;
        char *name;
        void *data;
    } ECArgReference;

    /* A ECAssemblyChain can be used to link ec objects
     * together without affecting their original hierarchies.
     * The chain structure is the head of the list, having a
     * name, a pointer to "next" (so chains can be stored
     * in linked lists) and a pointer to the chains links.
     * Each link is a ECAssemblyLink structure.
     */
    typedef struct ECAssemblyLink {
        struct ECAssembly *object;
        struct ECAssemblyLink *next;
    } ECAssemblyLink;

    typedef struct ECAssemblyChain {
        char *name;
        struct ECAssemblyLink *links;
        struct ECAssemblyChain *next;
        void *userData;
    } ECAssemblyChain;

    typedef struct ECList {  
        char *name;
        ECItem *items;
        struct ECList *definition;
        ECItem *instanceList;
        int instances;
        char *libraryName;
    } ECList;

    struct ECFile;

    typedef enum { 
        VDIUnitMeter=0,
        VDIUnitInch,
        VDIUnitMM 
    }  VDIUnit;

    typedef enum { 
        VDIFileTypeMain, VDIFileTypeSrc, VDIFileTypeLib, VDIFileTypeNull
    }  VDIFileType; 

    typedef enum {
        VDIFileReadWrite=0, VDIFileReadOnly
    } VDIFileMode;

    typedef struct ECHeader {
        VDIUnit unit;
        VDIFileType fileType;
        VDIFileMode fileMode;
        struct { int major, minor; } version;
        struct { int day, month, year; } date;
        struct { int hours, minutes; } time;
        float32 *scale;
        ECItem *attributes;
    } ECHeader;

    typedef struct ECUserEvent {
        char *name;
        struct ECUserEvent *next;
    } ECUserEvent;

    typedef struct ECFileNameList {
        char *fileName;
        struct ECFileNameList *next;
    } ECFileNameList;

    typedef struct ECSystem {
        ECItemType       type;
        struct ECFile   *owner;
        char            *name;
        char	    *pathName;
        void            *clientData;
        struct ECFileNameList *actionFunctionSyntaxFileNames;
        struct ECFileNameList *userDataSyntaxFileNames;
        struct ECItem *attributes; /* event lists */
        float32 tickRate;
        struct ECUserEvent *userEvents; /* for user defined event types */
        ECAssemblyChain *delAssemblys; /* a list of all deleted objects */
    } ECSystem;


    typedef struct ECFile {
        ECItemType       type;
        struct ECFile   *parent;
        struct ECFile   *child;
        struct ECFile   *sibling;
        char            *id;
        char            *name;     /* name of this file */
        char	        *pathName; /* expanded path name */
        void            *clientData;
        struct ECHeader *header;
        struct ECItem   *attributes;
        struct ECSystem *system;
        ECItemType       useLibraryParentType;
        union {
            struct ECFile *file;
            struct ECLibrary *library;
        } useLibraryParentUnion; /* for internal use by the file reader */
        uint32           flags;
        VCSearchPath    *vcPath;
        DLOAD_HANDLE	 handle;
        duHashTab *hashTable; /* hash table of uniqueIds in this file */
        void            *treeData; /* used when this file is in a tree */
    } ECFile;

    typedef enum {
	ECFCB_NO_VDIFILE,
        ECFCB_NO_REFFILE,
	ECFCB_NO_MATERIALFILE,
	ECFCB_NO_PLUGINFILE,
        ECFCB_NO_IMAGEFILE,
        ECFCB_PARSE_ERROR,
        ECFCB_VERSION_CHANGE,
        ECFCB_WRITE_ERROR,
        ECFCB_NO_SPACE,
        ECFCB_READONLY,
        ECFCB_PROGRESS
    } ECFileCallbackType;

    typedef struct {
	ECFileCallbackType type;
	char *messageString;
	char *returnString;
    } ECFileCallbackData;

    /* PUBLIC VARIABLES ======================================*/


    /* PUBLIC FUNCTIONS ======================================*/


#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /* _ECTYPES_H */
