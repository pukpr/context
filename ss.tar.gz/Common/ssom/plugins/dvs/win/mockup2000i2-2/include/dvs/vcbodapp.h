
typedef struct
{
    int 		 state;
    void		*collideEntity;
    void		*intersectEntity;
    void		*pickEntity;
    void		*pickRelocateHandle;
    void		*relocateData;
}VCBodyPartAppInfo;

typedef struct
{
    VCEntity		*entity;
    VCAttribute		*bodyPart;
    VCBody		*body;
}VCBodyAppCallbackData;

typedef struct
{
    VCAttribute 	*bodyPart;
    VCBody		*body;
}VCBodyAppRelocateData;


#define VC_BODYAPP_COLLIDED		0x00000001
#define VC_BODYAPP_PICK_PRESSED		0x00000002
#define VC_BODYAPP_INTERSECTED		0x00000004

typedef void (*VCBodyTouchFunc)(VCBodyAppCallbackData *callbackData, void *data);
typedef void (*VCBodyUnTouchFunc)(VCBodyAppCallbackData *callbackData, void *data);
typedef void (*VCBodyPickFunc)(VCBodyAppCallbackData *callbackData, void *data);
typedef void (*VCBodyDropFunc)(VCBodyAppCallbackData *callbackData, void *data);
typedef void (*VCBodyMoveFunc)(VCBodyAppCallbackData *callbackData, void *data);

typedef struct
{
    void	*touchFunc;
    void	*unTouchFunc;
    void	*pickFunc;
    void	*dropFunc;
    void	*moveFunc;
} VCBodyFuncInfo;

VC_EXPORT void 	*VCBody_AttachInteractionCallbacks(VCBody *body, VCBodyTouchFunc touchFunc,
                                                   VCBodyUnTouchFunc unTouchFunc, VCBodyPickFunc pickFunc,
                                                   VCBodyDropFunc dropFunc, VCBodyMoveFunc moveFunc, void *data);
    
VC_EXPORT void	 VCBody_DetachInteractionCallbacks(VCBody *body, void *callbackHandle);
