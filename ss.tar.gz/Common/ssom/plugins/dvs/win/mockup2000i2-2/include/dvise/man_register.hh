#ifndef _MANREGISTER_HH
#define _MANREGISTER_HH

#include <set.h>
#include <map.h>

#ifndef _swapi_h
typedef struct API_ManPost_t{
	int nbEl;
	void *postEl;
}API_ManPost;
#endif

// these are in STL containers so we need the 
// complete class definitions
#include "man_handle.hh"
#include "man_cns.hh" 
#include "man_invkin.hh" 
#include "man_appearance.hh" 
#include "vision.hh" 

#include "dvsw_postural_score.hh"

// Type definition of the man_register smart pointer
class DV_EXPORT _ECSwManRegister;
class DV_EXPORT _ECSwManIKSpecs;
class DV_EXPORT _ECSwManCns;
class DV_EXPORT _ECSwReachAndVision;
class DV_EXPORT _ECSwManAppearance;

typedef ECSmartPtr<_ECSwManRegister> ECSwManRegisterPtr;
typedef ECSmartPtr<_ECSwManCns> ECSwManCnsPtr;
typedef ECSmartPtr<_ECSwManIKSpecs> ECSwManIKSpecsPtr;
typedef ECSmartPtr<_ECSwReachAndVision> ECSwReachAndVisionPtr;
typedef ECSmartPtr<_ECSwManAppearance> ECSwManAppearancePtr;

// Comparison operators required for map indexing

struct ltstr
{
  bool operator()(const char* s1, const char* s2) const
  {
    return strcmp(s1, s2) < 0;
  }
};
struct lti
{
  bool operator()(const int i1, const int i2) const
  {
    return (i1 < i2);
  }
};

// The segment list is a map sorted by segment index
typedef map<int, ECSwManHandlePtr , lti> segmentMap;
typedef STLPORT::map<int, ECSwManHandlePtr, lti>::iterator segmentMap_iterator;

// The constraint list is a map sorted by constraint's name
typedef map<char *, ECSwManHandlePtr, ltstr> constraintMap;
typedef STLPORT::map<char *, ECSwManHandlePtr, ltstr>::iterator constraintMap_iterator;

// The constraint attribute list is a map sorted by constraint's name
typedef map<char *, ECSwManCnsPtr, ltstr> constraintAttrMap;
typedef STLPORT::map<char *, ECSwManCnsPtr, ltstr>::iterator constraintAttrMap_iterator;


// Callback FLAG DEFINITION:
#define manREGISTER_CREATE_REGISTER_COMPLETE 0x0100000

#define UPD_LOCAL_POST			0x001
#define UPD_GLOBAL_POST			0x002
#define UPD_ANTHROPOMETRY		0x004
#define UPD_POSTURE_MASK		0x007
#define UPD_ROOT			0x008
#define UPD_POSTURALSCORE		0x010
#define UPD_LINEOFSIGHT			0x020
#define UPD_REINIT_CNS			0x040
#define UPD_REINIT_AND_STORE_CNS	0x080
#define UPD_SOLVE_IK			0x100
#define UPD_REACHENVELOPE		0x200

#define manREGISTER_UPDATE_FROM_SEG	0x08
#define manREGISTER_UPDATE_FROM_CONS    0x10
#define manREGISTER_UPDATE_FROM_ROOT    0x20
#define manREGISTER_UPDATE_FROM_COMM    0x40
#define manREGISTER_UPDATE_FROM_SYNC    0x80

class DV_EXPORT _ECSwManRegister : public _ECBaseItem
{
public:
    // So we can define the "addRegister" stuff with the 
    // private members of the class
    friend class _ECSwManHandle;
    
    // Constructors, destructors and associates
    _ECSwManRegister();
    _ECSwManRegister(char  *manName);
    ~_ECSwManRegister();
    static _ECSwManRegister * addToRegister(_ECBaseItem *item);
    static _ECSwManRegister * findRegister(char *SWhandle);
    friend void removeItemFromRegisterCallback(ECCallbackInfo *info, void *data);

    // Generic query and set methods
    int getId(void) const;
    static int getMyId(void);
    char *getIdString(void) const; // %WAR: Abstract virtual from _ECBaseItem
    char *GetName() const {return _attributeName;};
    ECError SetName(char *newName);
    ECError SetNameNoCopy(char *newName);

    // Specific query and set methods
    char *getManikinHandle(){ return _manikinName; };
    char *getManikinSegmentHandle(int segId);
    segmentMap_iterator getManikinSegmentEntry(int segId) {
	return (segMap.find(segId));
    };

    static int getManikinNb();

    int getSegTotal() { return (totalSegs); }
    int getCnsNb() { return (totalCons); }

    segmentMap_iterator getSegmentMapBegin() {return (segMap.begin());};
    segmentMap_iterator getSegmentMapEnd() {return (segMap.end());};
    constraintMap_iterator getConstraintMapBegin() {return (consMap.begin());};
    constraintMap_iterator getConstraintMapEnd() {return (consMap.end());};
    constraintAttrMap_iterator getConstraintAttrMapBegin() {return (consAttrMap.begin());};
    constraintAttrMap_iterator getConstraintAttrMapEnd() {return
							      (consAttrMap.end());};

    segmentMap_iterator  findOneSegmentRegex(const char *regex, 
					     segmentMap_iterator srcBegin,
					     segmentMap_iterator srcEnd,
					     bool caseSensitive=TRUE);
    dvSwRetType copySegmentRegex(const char *regex, 
				 segmentMap &dest,
				 segmentMap_iterator srcBegin,
				 segmentMap_iterator srcEnd,
				 bool caseSensitive=TRUE);

    constraintMap_iterator  findOneConstraintRegex(const char *regex, 
					     constraintMap_iterator srcBegin,
					     constraintMap_iterator srcEnd,
					     bool caseSensitive=TRUE);
    dvSwRetType copyConstraintRegex(const char *regex, 
				 constraintMap &dest,
				 constraintMap_iterator srcBegin,
				 constraintMap_iterator srcEnd,
				 bool caseSensitive=TRUE);

    constraintAttrMap_iterator  findOneConstraintAttrRegex(const char *regex, 
				constraintAttrMap_iterator srcBegin,
			        constraintAttrMap_iterator srcEnd,
				bool caseSensitive=TRUE);
    dvSwRetType copyConstraintAttrRegex(const char *regex, 
				 constraintAttrMap &dest,
				 constraintAttrMap_iterator srcBegin,
				 constraintAttrMap_iterator srcEnd,
				 bool caseSensitive=TRUE);

    bool segsComplete(){return((segMap.size() == totalSegs) && 
			       (totalSegs>0));};
    bool rootComplete(){return(manikinRoot != NULL); };
    bool consComplete(){return((consMap.size() == totalCons) && 
			       (totalCons >0));};
    bool assembliesComplete(){ return(segsComplete() && 
				      rootComplete() && 
				      consComplete());};
    bool consAttrComplete(){return((consAttrMap.size() == totalCons) && 
			       (totalCons > 0));};
    bool attributesComplete();

    bool allSegsLoaded() { return(loadedSegs == totalSegs);};
    bool allRootLoaded() { return(loadedRoot == 1);};
    bool allConsLoaded() { return(loadedCons == totalCons);};
    bool assembliesLoaded() { return(allSegsLoaded() 
			      && allRootLoaded() && 
			      allConsLoaded());};    
    
    bool getParsing() { return _parsing; };
    void setParsing() { 
	_parsing = TRUE; 
	// dontCallCallbacks();
    };
    void clearParsing() { 
	_parsing = FALSE; 
	// callCallbacks();
    };
    int getManikinUpdateFlag() { return _manikinUpdateFlag; };

    _ECAssembly *getManikinRootAssembly()
    {
	if (manikinRoot == (_ECSwManHandle *)NULL)
	{
	    return ((_ECAssembly *)NULL);
	}

	return (manikinRoot->getThisAssembly());
    };

    _ECAssembly *getManikinSegmentAssembly(int segId);
    _ECAssembly *getManikinConstraintAssembly(char *swHandle);
   
    _ECSwManIKSpecs *getIKSpecs() {
	return ((_ECSwManIKSpecs *)ikSpecs.operator->());};
    _ECSwReachAndVision *getReachAndVision() {
	return ((_ECSwReachAndVision *)reachAndVision.operator->());};
    _ECSwManAppearance *getManAppearance() {
	return ((_ECSwManAppearance *)apr.operator->());};

    dvSwPosturalScoreStruct & getPosturalScoreStruct() 
    {
	return _posturalScore;
    };

    // Regex utilities
    static bool isLeft(const char *segName) {
	return((segName) ? ((segName[0] == 'L') ? TRUE : FALSE) : FALSE);
    };
    static bool isRight(const char *segName) {
	return((!isLeft(segName)) && (isLimb(segName)));
    };
    static bool isFoot(const char *segName) {
	return(regexCmp(segName,getFootRegex()));
    };
    static bool isTorso(const char *segName) {
	return(regexCmp(segName,getTorsoRegex()));};
    static bool isPelvis(const char *segName){
	return( (segName) ? 
		(strcmp(segName, getPelvisName()) ? FALSE : TRUE) :
		FALSE);};
    static bool isHead(const char *segName) {
	return((segName && (strlen(segName) > 2)) ? 
	       (((segName[0]=='S') && (segName[1]=='H') && (segName[2]=='e')) ?
	       TRUE : FALSE) : FALSE);};
    static bool isTheHead(const char *segName) {
	return((segName) ? 
	       (strcmp(segName, getHeadName()) ? FALSE : TRUE) :
		FALSE);};
    static bool isArm(const char *segName) {return(regexCmp(segName,getArmRegex()));};
    static bool isHand(const char *segName) {return(regexCmp(segName,getHandRegex()));};
    static bool isLeg(const char *segName) {return(regexCmp(segName,getLegRegex()));};

    static bool isLimb(const char *segName) {
	return(isArm(segName)||isHand(segName)||isLeg(segName)||isFoot(segName));
    };    

    static const char * getFootRegex() {return _footRegex;};
    static const char * getTorsoRegex() {return _torsoRegex;};
    static const char * getPelvisName() {return _pelvisName;};
    static const char * getArmRegex() {return _armRegex;};
    static const char * getLegRegex() {return _legRegex;};
    static const char * getHeadRegex() {return _headRegex;};
    static const char * getHeadName() {return _headName;};
    static const char * getHandRegex() {return _handRegex;};
    static const char * getLumbarRegex() {return _lumbarRegex;}; 
    static const char * getThoracicRegex() {return _thoracicRegex;};
    static const char * getLeftRegex() {return _leftRegex;}; 
 
    // Interface methods
    static bool canUseSafework() {return(useSafework);};
    friend void dvsafework_control_server_error(VCSignal_CallbackData *sigData, 
					   void *data);
    friend dvSwRetType dvsafework_control_exit();
    friend dvSwRetType dvsafework_control_init();
 

    dvSwRetType requestLocalPostureUpdateCommand(int nb, int *segTable);
    dvSwRetType requestGlobalPostureUpdateCommand();
    dvSwRetType requestAnthropometryUpdateCommand();
    dvSwRetType requestRootMovementCommand();
    dvSwRetType requestIKResolutionCommand();
    dvSwRetType requestLineOfSightUpdateCommand();
    dvSwRetType requestReachEnvelopeUpdateCommand();
    dvSwRetType loadAssembly(_ECSwManHandle *handle);
    dvSwRetType unloadAssembly(_ECSwManHandle *handle);
    dvSwRetType resetPosture();
    dvSwRetType exportGeometry();
    // Update callback
    friend void 
    _ECSwManRegisterUpdateCallback(ECCallbackInfo *info, void *data);

    // I/O methods
    int writeVdiFile() {return 0;}; // %NOTE: The write method is member...
    // .. But the read method is a friend (member of the class defined above)
//     friend int _ECSwManRegisterInfo::parseFileStream(dParseFilePtr IS, 
// 						 _ECBaseItem *thisAttribute,
// 						 hierarchy *pH);

private:    

    static bool useSafework; // This indicates whether Safewrok can be used
                             //or not

    // References to the manikin assemblies 
    // ECAssemblyPtr
    ECSwManHandlePtr manikinRoot; // The root of this manikin instance
    segmentMap segMap; // Segment table for this manikin
    constraintMap consMap; // Constraint table for this manikin

    // References to the manikin attributes
    ECSwManIKSpecsPtr ikSpecs;
    ECSwReachAndVisionPtr reachAndVision;
    ECSwManAppearancePtr apr;

    // References to the constraint attibutes
    constraintAttrMap consAttrMap; // Constraint table for this manikin

    // These indicate the completeness of the manikin
    int totalSegs;  
    int totalCons;
    int totalAttrs;

    int loadedSegs;
    int loadedCons;
    int loadedRoot;
    
    int deletedSegs;
    int deletedCons;
    int deletedRoot;
    int deletedAttrs;
    // Used to maintain the update state of the manikin
    bool _parsing;
    int _manikinUpdateFlag;
    _ECBaseItem::ECCallbackIterator _regUpdateHandle;

    dvSwRetType updateSafeworkRootPosition();  // Update Safework from dvise
    dvSwRetType updateRootPositionFromSafework(); // Update dvise from Safework
    dvSwRetType updateLocalPosture();
    dvSwRetType updateGlobalPosture();
    dvSwRetType parsePostureUpdate(API_ManPost posture);
    dvSwRetType updateAnthropometry();
    dvSwRetType updatePosturalScore();

    // Postural score stuff
    dvSwPosturalScoreStruct _posturalScore;

    char * _attributeName; // Name of this attribute
    char * _manikinName; // Name of the manikin handle

    void initialiseVars(); // Initialise all private vars.
    int setManikinHandle(char *newName); // Sets the manikin's name
    
    typedef set<int, lti> _updateSegSet_t;
    typedef STLPORT::set<int, lti>::iterator _updateSegSet_iterator;  // keeps track of which segments have to be recalculated
    _updateSegSet_t  _updateSegSet;  // keeps track of which segments have to be recalculated
    
    dvSwRetType resetUpdateSegSet();
    // Regex utilities
    static const char * const _footRegex;
    static const char * const _torsoRegex;
    static const char * const _pelvisName;
    static const char * const _armRegex;
    static const char * const _legRegex;
    static const char * const _headRegex;
    static const char * const _headName;
    static const char * const _handRegex;
    static const char * const _lumbarRegex; 
    static const char * const _thoracicRegex;
    static const char * const _leftRegex;

    static bool regexCmp(const char * str, const char * regex);


};   

#endif
