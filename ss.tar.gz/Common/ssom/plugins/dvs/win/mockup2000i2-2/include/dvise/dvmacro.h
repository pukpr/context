/****************************************************************************
 *
 *  			Copyright 1995 Division Limited.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Assembly Name   : $RCSfile: dvmacro.h,v $
 *  Revision      : $Revision: 1.11 $
 *  Date          : $Date: 2000/05/08 17:41:19 $
 *  Author        : $Author: jeff $
 *  Last Modified : <040495.1926>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 ****************************************************************************
 *
 *  Copyright (c) 1995 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 *  This Document may not, in whole or in part, be copied,
 *  photocopied, reproduced, translated, or reduced to any
 *  electronic medium or machine readable form without prior
 *  written consent from Division Ltd.
 ****************************************************************************/

#ifndef __DVMACRO_H__
#define __DVMACRO_H__


#ifdef __cplusplus
extern "C" {
#endif

typedef enum { dvNONE=0, dvSINGLE=1, dvDOUBLE=2, dvTRIPLE=3 } dvFUNCTYPE ;

#define	DEFFUN(v,s,t)	v,

typedef enum {
#include "dvmacro.def"
    dvNOFUNCS			/* Number of functions */
} dvFUNCTION ;

#undef	DEFFUN

#define dvMAXBUF 1024

#ifdef __cplusplus
}
#endif

#ifndef DV_EXPORT
#include <dvise/dvexport.h>
#endif

#include "ecatools.h"

#ifdef __cplusplus
extern "C" {
#endif


DV_EXPORT extern DP_FTIME thisTime;

/* Externally defined fuctions - THESE FUNCTIONS SHOULD BE REPLACED */
/* Get the name of the current object
DV_EXPORT void dvGetAssemblyName(char *oname) ;
*/

/* Externally callable functions */
/* Look-up the value of the given variable returning a NULL if undefined
 * or the value otherwise
 */
DV_EXPORT char *ECGetVariable(char *vname, ECItem *item) ;
/* Set the variable vname to the evaluated result of exp.
 * if the variable doesnt exist then a new one is created.
 * 
 * if the name is not a vaiable name OR
 *    couldn't malloc a new variable (if needed) OR
 *    the exp was invalid
 * then an error has occured and NULL is returned
 * else returns a pointer to the new value.
 */
DV_EXPORT char *ECSetVariable(char *vname, char *exp, ECItem *item);
DV_EXPORT char *ECSetVariableEventData(char *vname, char *exp, ECEventData *eventData);

/* evaluate the given expression and return the numeric result */
DV_EXPORT int   ECEvaluateExpression(char *exp, ECItem *item);
DV_EXPORT int   ECEvaluateExpressionEventData(char *exp, ECEventData *data);

/* Get the value from an ECArgReference structure - either
 * directly from its own data field, or by evaluating a
 * variable or macro.
 */
DV_EXPORT int ECArgReferenceGetValue(ECArgReference *, void *, ECEventData *);

DV_EXPORT void EC_SetSenderEntity(void *);

#ifdef __cplusplus
}
#endif

#endif /* __DVMACRO_H__ */
