#ifndef DV_EXPORT
#if defined (_WIN32)  && ! defined(_WINDU_SOURCE) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `DV_EXPORT'
 */
#pragma warning(disable: 4231) // Non standard extension extern used in template instantiation
#pragma warning(disable: 4251) // Needs to have dll interface

#pragma warning(disable: 4660) // Allready instantiated
#pragma warning(disable: 4666) // functions Differ only by calling type
#pragma warning(disable: 4786) // greater than 255 characters not stored in debug file
#ifdef  _LIB_DV
#define DV_EXPORT __declspec(dllexport)
#define DV_TEMPLATE_EXPORT 
#define DVPLUGIN_EXPORT __declspec(dllimport)
#else
#define DV_EXPORT __declspec(dllimport)
#define DVPLUGIN_EXPORT __declspec(dllexport)
#define DV_TEMPLATE_EXPORT extern
#endif /* IN_A_DIVISION_LIB */
#else
#define DV_EXPORT 
#define DV_TEMPLATE_EXPORT 
#define DVPLUGIN_EXPORT 
#endif /* ! _WIN32 */
#endif /* ifndef DV_EXPORT */



