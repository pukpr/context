/* -*- C++ -*-
-- ----------------------------------------------------------------------------
--
--  			Copyright 1999 Division Limited.
--			      All Rights Reserved
--
--
--  System       : 
--  Module       : 
--  Object Name  : $RCSfile: skip.h,v $
--  Revision     : $Revision: 1.1 $
--  Date         : $Date: 2000/02/09 16:10:23 $
--  Author       : $Author: john $
--
--  Description	
--	Skip list based table
--
--	See article "Skip Lists : A Probabilistic Alternative to 
--	Balanced Trees" by William Pugh in the June 1990 Communications of
--	the ACM and "Skip Lists" by Bruce Schneier in the January 1994  
--	Dr Dobb's Journal for details of the data structures and algorthms. 
--
--
--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __SKIP_H__
#define __SKIP_H__

#ifdef _UNIX
extern "C"
{
    extern int rand();
}
#endif

#define  MAX_NUMBER_OF_LEVELS 16
#define MAX_LEVEL (MAX_NUMBER_OF_LEVELS - 1)
#define BITS_IN_RANDOM 31

template<class D, class K> class SkipListIter; // forward ref so we can make it a friend 
template<class D, class K> class SkipList; // forward ref so we can make it a friend 

    // A node within the skip list
    //
    // Everything is private, only accessible to the friend
    // classes.

template<class D, class K> class SkipListNode
{
    friend class SkipListIter<D,K>;
    friend class SkipList<D,K>;

    D* data;
    SkipListNode<D,K>** forward;
    
    SkipListNode(const int levels) 
    {
        data = 0;
        forward = new SkipListNode<D,K>*[levels + 1];
        for (int i = 0; i < levels + 1; i++)
            forward[i] = 0;
    }
    ~SkipListNode() { delete [] forward; }
};

    // The skip list class itself
    // 
    // The data class D must provide a member function of
    // the form:
    //
    //           K key()
    //
    // which returns the value of the key.
    //
    // A copy constructor is also required, of the form:
    //
    //           D(const D&)
    //
    // The key class K must support the < and == operators (via friend operators),
    // providing total order and equality respectively.


template<class D, class K> class SkipList // the actual skip list itself
{
    friend class SkipListIter<D,K>;

    int level;
    SkipListNode<D,K>* header;
    int randomBits;
    int randomsLeft;

    int randomLevel();
  public:
    
    typedef void (*SkipListMapFunc)(D*, void*);

    SkipList()
    {
        header = new SkipListNode<D,K>(MAX_NUMBER_OF_LEVELS);
        for (int i = 0; i <= MAX_NUMBER_OF_LEVELS; i++)
            header->forward[i] = 0;
        level = -1;
        randomBits = rand();
        randomsLeft = BITS_IN_RANDOM / 2;
    }

    ~SkipList()
    {
        empty();
        delete header;
    }

    int add(const D* d);        // add a new item
    int update(const D* d);     // update or add an item
    int remove(const K& k);     // remove an item
    D* find(const K& k);        // find an item

    void empty()                // remove all items
    {
        SkipListNode<D,K>* p = header->forward[0];
        while (p != 0) 
        {
            SkipListNode<D,K>* temp = p->forward[0];
            delete p->data;
            delete p;
            p = temp;
        }
        level = -1;
        for (int x = 0; x <= MAX_NUMBER_OF_LEVELS; x++) 
            header->forward[x] = 0;
    }

    void map(SkipListMapFunc f, void* data) // in order iteration
    {
        SkipListNode<D,K>* p = header->forward[0];
        
        while (p != 0) 
        {
            f(p->data, data);
            p = p->forward[0];
        }
    }

    void removeFront()          // remove the front element
    {
        SkipListNode<D,K>* f = header->forward[0];
        if (f)
            remove(f->data->key());
    }

    D* look()                   // peek at the front element
    {
        SkipListNode<D,K>* f = header->forward[0];
        return (f == 0) ? 0 : f->data;
    }
};

    // An iterator over skip lists

template<class D, class K> class SkipListIter // an iterator over a skip list
{
    SkipListNode<D,K> *n;         // current node

public:
    SkipListIter(SkipList<D,K>& skip) { n = skip.header->forward[0]; }

    D* data() { return n->data; }

    D* operator++()             // prefix
    {
        if (n)
        {
            n = n->forward[0];
            return n->data;
        }
        return 0;
    }

    D* operator++(int)          // postfix
    {
        D* ret = 0;
        if (n)
        {
            ret = n->data;
            n = n->forward[0];
        }
        return ret;
    }
};

    //
    // implementation for the skip list class
    //

template<class D, class K>
int SkipList<D,K>::randomLevel(void)
{
#if 0
    int l = 0 ;
    int rr = rand();
    int ii = 1 ;
    
    while(rr & ii)
    {
        if (l > MAX_LEVEL)
            return MAX_LEVEL ;
        l++ ;
        ii <<= 1 ;
    }
    return l;
#else
    int l = 0;
    int b;

    do 
    {
        b = randomBits & 3;
        if (!b) 
            l++;
        randomBits >>= 2;
        if (--randomsLeft == 0)
        {
            randomBits  = rand();
            randomsLeft = BITS_IN_RANDOM / 2;
        }
    } while(!b);

    return (l > MAX_LEVEL ? MAX_LEVEL : l);
#endif
}

template<class D, class K>
D* SkipList<D,K>::find(const K& k)
{
    SkipListNode<D,K>* search = 0;
    SkipListNode<D,K>* path = header;
    
    for (int l = level; l >= 0; --l) 
    {
        search = path->forward[l];
        while (search != 0)
        {
            K sk = search->data->key(); 

            if (!(sk < k))
                break;
            path = search;
            search = path->forward[l];
        }
    }
    
    if (search == 0 || !(search->data->key() == k))
        return 0;
        
    return search->data;
}

template<class D, class K>
int SkipList<D,K>::add(const D* d)
{
    SkipListNode<D,K>* path = header;
    SkipListNode<D,K>* search = 0;
    SkipListNode<D,K>* update[MAX_NUMBER_OF_LEVELS];
    int l = level;
    const K k = d->key();

    for (l = level; l >= 0; --l) 
    {
        while (search = path->forward[l],
               search != 0 && (search->data->key() < k))
            path = search;
        update[l] = path;
    }

    if (search != 0 && (search->data->key() == k))
        return 0;

    l = randomLevel();
    if (l > level) 
    {
        l = ++level;
        update[l] = header;
    }
 
    if ((search = new SkipListNode<D,K>(l)) == 0)
        return 0;

    search->data = (D*) d;

    while (l >= 0) 
    {
        path = update[l];
        if (path == 0) 
            search->forward[l] = 0;
        else 
        {
            search->forward[l] = path->forward[l];
            path->forward[l] = search;
        }
        l--;
    }
    
    return 1;
}

template<class D, class K>
int SkipList<D,K>::update(const D* d)
{
    SkipListNode<D,K>* path = header;
    SkipListNode<D,K>* search = 0;
    SkipListNode<D,K>* update[MAX_NUMBER_OF_LEVELS];
    const K k = d->key();
    int l = level;
    void *temp;
 
    for (l = level; l >= 0; --l) 
    {
        while (search = path->forward[l],
               search != 0 && (search->data->key() < k))
            path = search;
        update[l] = path;
    }

    if (search != 0 && (search->data->key() == k))
    {
        delete search->data;
        search->data = d;
        return 1;
    }

    l = randomLevel();
    if (l > level) 
    {
        l = ++level;
        update[l] = header;
    }
 
    if ((search = new SkipListNode<D,K>(l)) == 0)
        return 0;
 
    search->data = d;

    while (l >= 0) 
    {
        path = update[l];
        if (path == 0) 
            search->forward[l] = 0;
        else 
        {
            search->forward[l] = path->forward[l];
            path->forward[l] = search;
        }
        l--;
    }

    return 1;
}

template<class D, class K>
int SkipList<D,K>::remove(const K& k)
{
    int l;
    int toplevel = level;
    SkipListNode<D,K>* update[MAX_NUMBER_OF_LEVELS];
    SkipListNode<D,K>* path = header;
    SkipListNode<D,K>* search = 0;
    
        // Search for element and keep a record of search path 

    for (l = level; l >= 0; --l) 
    {
        while (search = path->forward[l],
               search != NULL && (search->data->key() < k))
            path = search;
        update[l] = path;
    }

    if (search == NULL || !(search->data->key() == k))
        return 0;

        // Update pointers 

    l = 0;
    while (l <= toplevel 
           && update[l] != 0 
           && update[l]->forward[l] == search) 
    {        
        update[l]->forward[l] = search->forward[l];
        l++;
    }

    delete search->data;
    delete search;

    while (toplevel >= 0 && header->forward[toplevel] == 0) 
        toplevel--; 
    level = toplevel;

    return 1;
}

#endif /* __SKIP_H__ */
