//-*-C++-*-
#ifndef _ECITEM_LIST_H
#define _ECITEM_LIST_H
#include <list.h>
#include <hash_set.h>

#ifndef _ECSMARTPTR_H
#include "ecsmartptr.h"
#endif

//lists of nulling smart-pointers to base items.

DV_TEMPLATE_EXPORT template class DV_EXPORT STLPORT::list<ECBaseItemNullingPtr>;
typedef list<ECBaseItemNullingPtr> _ECNullingBaseItemPtrList;


// Heavyweight list! doesn't fail changes while being called back,
// keeps lists of delayed changes instead. Also has lists of added
// and removed items kept handy for convenience. Things you can do to
// lists is radically reduced.


class DV_EXPORT _ECItemList: public _ECBaseItem
{
    friend class ECSmartPtr<_ECItemList>;
    
    typedef  hash_set< ECBaseItemNullingPtr,
                     ECPtrHash<ECBaseItemNullingPtr>,
                     equal_to<ECBaseItemNullingPtr> > _ECBasePtrSet;

    _ECBasePtrSet	m_list;
    _ECBasePtrSet	m_addedList;
    _ECBasePtrSet	m_removedList;
    _ECBasePtrSet	m_delayedAddList;
    _ECBasePtrSet	m_delayedRemoveList;

    static void callback(ECCallbackInfo *, void *);

public:
    typedef  _ECBasePtrSet::iterator       ECItemListIterator;

protected:
    _ECItemList(){};
    ~_ECItemList();

public:
    int          getId(void) const;
    char * getIdString(void) const;
    static int getMyId();

    static ECCallbackIterator attachGlobalCreateCallback(ecGlobalCallbackFunc func, void *data)
        {
            return _ECBaseItem::attachGlobalCreateCallback(getMyId(), func, data);
        }

    static ECCallbackIterator attachGlobalUpdateCallback(ecGlobalCallbackFunc func, void *data)
        {
            return _ECBaseItem::attachGlobalUpdateCallback(getMyId(), func, data);
        }

    static ECCallbackIterator attachGlobalDeleteCallback(ecGlobalCallbackFunc func, void *data)
        {
            return _ECBaseItem::attachGlobalDeleteCallback(getMyId(), func, data);
        }

    static void detachGlobalCreateCallback(ECCallbackIterator iter)
        {
            _ECBaseItem::detachGlobalCreateCallback(getMyId(), iter);
        }
    static void detachGlobalUpdateCallback(ECCallbackIterator iter)
        {
            _ECBaseItem::detachGlobalUpdateCallback(getMyId(), iter);
        }
    static void detachGlobalDeleteCallback(ECCallbackIterator iter)
        {
            _ECBaseItem::detachGlobalDeleteCallback(getMyId(),iter);
        }

    void callCallbacks(void) ;
    static _ECItemList *create()
        { 
            _ECItemList *newItem = new _ECItemList;
            newItem->_create(0);
            return newItem;
        }
    _ECBaseItem               *clone(void) const { 
            _ECItemList *newItem= new _ECItemList(*this);
            newItem->_create(0);
            return newItem;
        }

    ECItemListIterator    list_begin(void) { return m_list.begin(); };
    ECItemListIterator      list_end(void) { return m_list.end(); };
    int                    list_size(void) { return m_list.size(); };
    bool                  list_empty(void) { return m_list.empty(); };

    ECItemListIterator   added_begin(void) { return m_addedList.begin(); };
    ECItemListIterator     added_end(void) { return m_addedList.end(); };
    int                   added_size(void) { return m_addedList.size(); };

    ECItemListIterator        removed_begin(void) { return m_removedList.begin(); };
    inline ECItemListIterator   removed_end(void) { return m_removedList.end(); };
    inline int                 removed_size(void) { return m_removedList.size(); };
     
    int                      addItem(ECBaseItemPtr &item);
    int                   removeItem(ECBaseItemPtr &item);
    bool                  containsItem(ECBaseItemPtr &item);
};

class DV_EXPORT ECItemListPtr: public  ECSmartPtr<_ECItemList>
{
public:
    ECItemListPtr()                       :ECSmartPtr<_ECItemList>(){};
    ECItemListPtr(_ECBaseItem* s)         :ECSmartPtr<_ECItemList>(s){};
    ECItemListPtr(const ECBaseItemPtr& s) :ECSmartPtr<_ECItemList>(s){};
    ECItemListPtr(const ECItemListPtr& s) :ECSmartPtr<_ECItemList>(s){};
};

DV_TEMPLATE_EXPORT template class DV_EXPORT   STLPORT::hash_set< ECBaseItemNullingPtr,
    ECPtrHash<ECBaseItemNullingPtr>,
    equal_to<ECBaseItemNullingPtr> >;


#endif
