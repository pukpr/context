/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    FUNCTION: defines data structures used in the EC file read/writer
 * 
 *
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */


#ifndef _VDI1_H
#define _VDI1_H


DV_EXPORT int32 EC_GetVDIVersion(void);
DV_EXPORT void EC_SetVDIVersion(int32);


#endif /* _VDI1_H */
