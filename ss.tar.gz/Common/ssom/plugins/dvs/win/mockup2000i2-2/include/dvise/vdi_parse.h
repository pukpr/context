/*
 *      PROJECT:
 *      SUBSYSTEM:
 *      MODULE:
 *
 *      FILE:           $RCSfile: vdi_parse.h,v $
 *      REVISION:       $Revision: 1.60 $
 *      Date:           $Date: 2000/03/15 11:48:41 $
 *      Author:         $Author: jeff $
 *      RCS Ident:      $Id: vdi_parse.h,v 1.60 2000/03/15 11:48:41 jeff Exp $
 *
 *      FUNCTION:
 *
 * Copyright (c) 1992,1993,1994 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */

#ifndef VDI_PARSE_H
#define VDI_PARSE_H

#include "ec_parser.h"
#ifdef __cplusplus
extern "C" {
#endif

#define DEF_TOKEN(a, b, c) a,

typedef enum {
tStartValue = 256,
#include "vdi_parse.def"
tEndValue
} ParseTokens;

#undef DEF_TOKEN

#define tDCITokensOffset 167

typedef struct DCIMessage {
    int inUse;  /* TRUE if we are reading a message from the DCI link */
    int server; /* TRUE if we are in dVISE (not in a client) */
} DCIMessage;

typedef struct {
ECAssembly *object;
ECFile *file;
ECRole *role;
ECLibrary *library;
ECUserData *userData;
} hierarchy;

/*
 * Parser / Writer settings held in ECFile flags
 */
#define EC_SAVE_LOAD_STATES      0x01
#define EC_PLUGIN_FILE           0x02
#define EC_FILE_MODIFIED         0x04
#define EC_MATERIAL_FILE         0x08

/*
 * VDI PARSER ROUTINE PROTOTYPES  ===========================================
 */
DV_EXPORT ECFile *parseVDIFile(char *, ECFile *, void *, ECItemType);
DV_EXPORT ECFile *parseVDIFragment(char *fileName);

DV_EXPORT extern void *dVDIPaths;
DV_EXPORT extern void *dBMFPaths;
DV_EXPORT extern void *dBGFPaths;
DV_EXPORT extern void *dTEXPaths;
DV_EXPORT extern void *dWAVPaths;

DV_EXPORT extern char8 **dVDIExts1;
DV_EXPORT extern char8 **dVDIExts2;
DV_EXPORT extern char8 **dVDIExts3;
DV_EXPORT extern char8 **dBMFExts;
DV_EXPORT extern char8 **dBGFExts;
DV_EXPORT extern char8 **dTEXExts;
DV_EXPORT extern char8 **dWAVExts;

#ifndef _UNIX
#define SPL_PATH_LOCAL   ".;./splines"
#define VDI_PATH_LOCAL   ".;./vdifiles"
#define BMF_PATH_LOCAL   ".;./material"
#define BGF_PATH_LOCAL   ".;./geometry"
#define TEX_PATH_LOCAL   ".;./texture"
#define WAV_PATH_LOCAL   ".;./audio"
#else
#define SPL_PATH_LOCAL   ".:./splines"
#define VDI_PATH_LOCAL   ".:./vdifiles"
#define BMF_PATH_LOCAL   ".:./material"
#define BGF_PATH_LOCAL   ".:./geometry"
#define TEX_PATH_LOCAL   ".:./texture"
#define WAV_PATH_LOCAL   ".:./audio"
#endif

#define VDI_PATH_ENV     "VDI_PATH"
#define VDI_PATH_OFFSET  "vdifiles"

#define BMF_PATH_ENV     "BMF_PATH"
#define BMF_PATH_OFFSET  "material"

#define BGF_PATH_ENV     "BGF_PATH"
#define BGF_PATH_OFFSET  "geometry"

#define TEX_PATH_ENV     "TEX_PATH"
#define TEX_PATH_OFFSET  "texture"

#define WAV_PATH_ENV     "WAV_PATH"
#define WAV_PATH_OFFSET  "audio"

DV_EXPORT int matchMagic( dParseFilePtr );
DV_EXPORT int matchKeyword( dParseFilePtr, int * );
DV_EXPORT int checkKeyword( dParseFilePtr, int );
DV_EXPORT ECHeader *buildHeader( dParseFilePtr, int * );
DV_EXPORT ECSystem *buildSystem( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECFile *useLibrary( dParseFilePtr, int *, void *, ECItemType, hierarchy * );
DV_EXPORT ECFile *parseMaterialsFile(char *pathname, char *filename, ECFile *, char *libraryName, ECLibrary **libCreated);
DV_EXPORT ECFile *loadPlugin(char *filename);
DV_EXPORT ECAssembly *buildAssembly( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECEventList *buildEventList( dParseFilePtr, int *, ECEventList *, hierarchy * );
DV_EXPORT ECEvent *buildEvent( dParseFilePtr, int *, char *, ECEventList *, hierarchy * );
DV_EXPORT ECAction *buildAction( dParseFilePtr, int *, char *, ECEvent *, hierarchy * );
DV_EXPORT ECConstraints *buildConstraints( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECIcon *buildIcon( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECLibrary *defLibrary( dParseFilePtr, int *, void *, ECItemType, hierarchy * ,int *libraryRemoved  );
DV_EXPORT ECList *buildList(  dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECItem *buildItem( dParseFilePtr, int *, hierarchy * );
DV_EXPORT EC_DCI_EventData *buildEventData(dParseFilePtr, int *, hierarchy *);
DV_EXPORT ECVisual *buildVisual( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECPivot *buildPivot( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECPosition * buildPosition( dParseFilePtr IS, int *tkout, hierarchy *pH);
DV_EXPORT ECLight *buildLight( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECCollision *buildCollision( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECAudio *buildAudio( dParseFilePtr, int *, hierarchy * );
DV_EXPORT void buildBodyInfo( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECRole *buildRole( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECTools *buildTools( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECUserData *buildUserData( dParseFilePtr, int *, hierarchy * );
DV_EXPORT ECBinaryData *buildBinaryData(dParseFilePtr, int *, hierarchy *);
DV_EXPORT ECField *buildUserDataField(dParseFilePtr IS, int *tkIn, hierarchy *pH);
DV_EXPORT int parseSpecifiers(dParseFilePtr, int *, hierarchy *, char **,
			   char **, int *length, int *mode, char **, ECItemType *);
DV_EXPORT void *buildMaterial( dParseFilePtr, int * );
DV_EXPORT void *buildTexture( dParseFilePtr, int * );
DV_EXPORT int skipBlock( dParseFilePtr, int, char, char );
DV_EXPORT int findBlockend( dParseFilePtr, hierarchy *, int, char * );
DV_EXPORT float32 matchReal( dParseFilePtr, hierarchy *, int * );
DV_EXPORT float32 matchBracedReal( dParseFilePtr, hierarchy *, int * );
DV_EXPORT int matchNum( dParseFilePtr, hierarchy * );
DV_EXPORT ECVec3 *matchECVec3( dParseFilePtr, hierarchy *, int * );
DV_EXPORT float32 *matchOrient( dParseFilePtr, hierarchy *, int * );
DV_EXPORT float32 *matchXYZOrient( dParseFilePtr, hierarchy *, int * );
DV_EXPORT float32 *matchVector( dParseFilePtr, hierarchy *, int * );
DV_EXPORT float32 *matchQuaternion( dParseFilePtr, hierarchy *, int * );
DV_EXPORT int matchTemplate( dParseFilePtr, hierarchy *, int *, char **, char ** );
DV_EXPORT ECStateType matchOnOff( dParseFilePtr, hierarchy *, int * );
DV_EXPORT int matchSingleLock(dParseFilePtr, hierarchy *, ECConstraints *, int);
DV_EXPORT int matchGridCommands(dParseFilePtr, hierarchy *, ECConstraints *);
DV_EXPORT float32 matchTime( dParseFilePtr, hierarchy *, int * );
DV_EXPORT char *matchName(dParseFilePtr, hierarchy *, int *);
DV_EXPORT char *matchExpression(dParseFilePtr, hierarchy *, int *);
DV_EXPORT DCIMessage *DCIMessageInfoGet(void);
DV_EXPORT void DCIMessageInfoSet(int, int);
DV_EXPORT dParseKeyTab *ECSetVDIKeyTab(dParseKeyTab *newKeyTab);
DV_EXPORT dParseKeyTab * ECGetVDIKeyTab();
DV_EXPORT void EC_ResolveExtTemplates(int mode);
DV_EXPORT void ECResolveNamesAndFSP( ECAssembly *obj );
DV_EXPORT void ECStartParsing(int32 checkNames, ECAssembly *root);
DV_EXPORT void ECStopParsing(void);
DV_EXPORT void VDI_ErrorStdOut(void);
DV_EXPORT void VDI_ErrorStdErr(void);
DV_EXPORT ECAssembly * ECAssembly_GetPlaceHolder(ECAssembly *parent, ECAssembly *object);
DV_EXPORT void ECAssembly_MergeWithPlaceHolder( ECAssembly *place, ECAssembly *object );

DV_EXPORT void VDI_EOF_Error(dParseFilePtr IS, hierarchy *pH);
DV_EXPORT void VDI_Error(dParseFilePtr IS, hierarchy *pH, char *message, ...) ;
DV_EXPORT void VDI_Warn(dParseFilePtr IS, hierarchy *pH, char *message, ...) ;
ECAssembly *parseGetCurrentAssembly();
char *parseGetOverridenLibName();
DV_EXPORT void parseDataTypeAssemblyVar(dParseFilePtr IS, int *tkout, char *func, hierarchy *pH, ECAction *action, int parameterNum);
DV_EXPORT void parseDataTypeSentence(dParseFilePtr IS, int *tkout, char *func, hierarchy *pH, ECAction *action, int parameterNum);
DV_EXPORT void parseDataTypeSentenceVar(dParseFilePtr IS, int *tkout, char *func, hierarchy *pH, ECAction *action, int parameterNum);
DV_EXPORT void parseDataTypeState(dParseFilePtr IS, int *tkout, char *func, hierarchy *pH, ECAction *action, int parameterNum);
DV_EXPORT void parseDataTypeIntVar(dParseFilePtr IS, int *tkout, char *func, hierarchy *pH, ECAction *action, int parameterNum);
    

#ifdef __cplusplus
}
#endif

#endif
