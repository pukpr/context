/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: vwframe.h,v $
 *    Revision:     $Revision: 1.3 $
 *    Date:         $Date: 1997/04/22 12:33:56 $
 *    Author:       $Author: simon $
 *    RCS Ident:    $Id: vwframe.h,v 1.3 1997/04/22 12:33:56 simon Exp $
 *
 *    FUNCTION: Frame public function prototypes.
 * 
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _Frame_H
#define _Frame_H
#ifdef __cplusplus
extern "C" {
#endif
/* PUBLIC FUNCTIONS ======================================*/


VW_EXPORT VWidget *VWFrame_CreateManaged(VWidget *, char *, VWArg [], int);
VW_EXPORT VWidget *VWFrame_Create(VWidget *, char *, VWArg [], int);


#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /*_Frame_H */
