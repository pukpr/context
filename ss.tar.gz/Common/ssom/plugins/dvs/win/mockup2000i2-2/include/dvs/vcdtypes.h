/***************************************************************************
 *
 *    PROJECT:      dVS
 *    SUBSYSTEM:    VC Toolkit.
 *    MODULE:       VC Type definitions.
 *
 ***************************************************************************
 *
 *    File:         $RCSfile: vcdtypes.h,v $
 *    Revision:     $Revision: 1.38 $
 *    Date:         $Date: 1999/07/13 13:18:56 $
 *    Author:       $Author: rajini $
 *    RCS Ident:    $Id: vcdtypes.h,v 1.38 1999/07/13 13:18:56 rajini Exp $
 *
 *    FUNCTION:
 *
 *
 *
 **************************************************************************
 *                                                                        *
 * Copyright (c) 1995 Division Ltd.                                       *
 *                                                                        *
 * All Rights Reserved.                                                   *
 *                                                                        *
 * This Document may not, in whole  or in part, be copied, photocopied,   *
 * reproduced, translated,  or  reduced  to  any  electronic  medium or   *
 * machine readable  form without  prior written  consent from Division   *
 * Ltd.                                                                   *
 *                                                                        *
 *************************************************************************/

#ifndef	_VCDTYPES_H
#define	_VCDTYPES_H

typedef float32	VCColour[3];

#define	VCColor VCColour		/* For our American Friends !! */


typedef struct
{
    dmPosition		dmPos;
    uint32		mode;
} VCPositionData;

typedef struct
{
    VCAttribute *section;
    float32     *corners;
    uint32      mode;
} VCSectionBoundsData;

typedef struct
{
    uint32	 mode;
    uint32	 visualMode;
    uint32	 intersectMask;
    char 	*name;
    float32 *corners;
} VCSectionData;

typedef struct
{
    uint32     mode;
    float32    frameRate;
    float32    iod;
    float32    convergence;
    VCColour   background;
    float32    nearClip;
    float32    farClip;
    VCColour   fogColour;
    float32    nearFog;
    float32    farFog;
    float32    lodScale;
    uint32     frameSyncTime;
    uint8      statisticsLevel;
    uint8      maxStatisticsLevel;
    uint16     accumSamples;
    uint16     flatten;
    uint32     capability;
    uint32     actorId;
    char      *renderer;
    char      *name;
} VCVisualResourceData;

typedef struct
{
    VCAttribute	*visualResource;
    uint32     	 mode;
    dmPoint    	 offset;
    dmEuler    	 orientation;
    float32    	 size[2];
    char      	*name;
} VCVisualViewResourceData;


typedef struct
{
    char      	*name;
} VCVisualSourceResourceData;

typedef struct
{
        uint32          mode;
        uint32		flags;
        float32		translation[6];
        float32		rotation[6];
} VCConstraintsData;

typedef struct
{
    uint32		 mode;
    VCInput		*input;
    char		*name;
} VCInputResourceData;

typedef struct {
    uint32		 mode;
    VCTracker		*tracker;
    uint32 		 sensorId;
    float32 		 translationScale[3];
    float32 		 rotationScale[3];
    float32 		 rotationCurveOrder[3];
    float32 		 translationCurveOrder[3];
    dmPoint 		 prePosition;
    dmPoint 		 postPosition;
    dmEuler 		 preEuler;
    dmEuler 		 postEuler;
    float32 		 relativeSphere[6];
    VCPosition		*position;
    VCConstraintsData 	 constraints;
    char       		*name;
} VCSensorResourceData;

typedef struct
{
    uint32		 updateRate;
    uint32		 transmissionDelay;
    dmPoint		 sourcePosition;
    dmEuler		 sourceEuler;
    uint32		 baudRate;
    char		*deviceType;
    char		*name;
} VCTrackerData;


typedef struct
{
    uint32           mode;
    VCColour         colour;
    float32	     exponent;
    float32	     theta;
} VCLightData;

typedef struct
{
    VCAttribute		*visual;
    float32		*boundingBox;
    uint32		 mode;
} VCVisualBoundingBoxData;

typedef struct
{
    uint32          	 mode;
    uint32		 intersectMask;
    VCDynamicVisual	*dynamicVisual;
    char		*geometryName;
    char		*frontMaterial;
    char		*backMaterial;
    char		*lod;
    float32		*boundingBox;
} VCVisualData;

typedef struct
{
    uint32   mode;
    uint16   numberLights;
    float32  radius;
    float32  length;
    float32  lightWidth;
    float32  power;
    float32  startAngle;
    float32  endAngle;
    VCColour lightColour;
    VCColour background;
} VCLightTubeData;

typedef struct
{
    VCAttribute	*boundaryAttr;
    uint16       flags;
    dmPoint      point;
    dmVector     direction;
    dpVtime       time;
} VCCollisionReportData;

typedef struct
{
    VCAttribute			*boundary;
    uint32			 numberCollisions;
    uint32			 numberReportedCollisions;
    VCCollisionReportData	*collReportData;
} VCCollisionData;

typedef struct
{
    float32		 bound[VC_BOUND_SIZE];
    uint32		 mode;
    int32		 numberCollisions;
    VCCollision		*collision;
    VCDynamicVisual	*dynamicVisual;
    char		*geometry;
    char		*lod;
} VCBoundaryData;

typedef struct
{
    VCEntity    *entity;
    VCAttribute *visual;
    InstanceNo  patch;
    dmPoint     point;
    dmVector    normal;
    dmPoint     nearestVertex;
    char8       *object;
    char8       *lod;
    char8       *geogroup;
    char8       *frontMaterial;
    char8       *backMaterial;
} VCIntersectionReportData;

typedef struct
{
    VCAttribute              *vectorIntersect;
    uint32                   numberIntersections;
    uint32                   numberReportedIntersections;
    VCIntersectionReportData *collReportData;
} VCIntersectionData;

typedef struct
{
    uint32         mode;
    float32        length;
    uint32         intersectMask;
    int32          numberIntersections;
    VCIntersection *intersection;
} VCVectorIntersectData;

typedef struct
{
    uint32         mode;
    float32        x;
    float32        y;
    uint32         intersectMask;
    int32          numberIntersections;
    VCIntersection *intersection;
    char8          *pipeName;
} VC2dIntersectData;

typedef struct
{
    uint32          	 mode;
    int32	    	 loopCount;
    float32         	 gain;
    uint16		 play;
    uint8		 velocity;
    int8		 priority;
    VCAttribute		*audioResource;
    char		*voice;
    char		*radiatorName;
    char		*radiatorFileName;
} VCAudioData;

typedef struct
{
    uint32          	 mode;
    uint16		 startRecord;
    uint16		 stopRecord;
    VCAttribute		*audioResource;
    char		*fileName;
} VCAudioRecordData;

typedef struct
{
    uint32		 mode;
    float32		 iad;
    float32	      	 volume;
    float32		 spreadingRollOff;
    float32		 atmosphericAbsorption;
    float32		 worldScale;
    char		*name;
    char		*hrtf;
    char		*resourceFile;
} VCAudioResourceData;

typedef struct
{
    VCEntity	      	*pickEntity;
    uint32		 mode;
    uint32		 pickActorId;
} VCPickObjectData;

/* Hoppy, 11/07/98 */
typedef struct
{
    VCEntity	      	*selectEntity;
    uint32		 mode;
    uint32		 selectActorId;
} VCSelectObjectData;

typedef struct
{
    uint32	 mode;
    VCColour	 ambient;
    VCColour     diffuse;
    VCSpecular   specular;
    VCColour     emissive;
    VCColour     opacity;
    char        *name;
    char	*textureName;
    char	*ramp;
    char	*environmentMap;
} VCMaterialData;

typedef struct
{
    char 	*path1;
    char 	*path2;
    char 	*path3;
    char 	*path4;
} VCSearchPathData;

typedef struct
{
    uint32	 	 mode;
    uint8	 	 minify;
    uint8        	 magnify;
    uint8        	 alpha;
    uint8        	 wrapU;
    uint8        	 wrapV;
    uint8        	 detailType;
    VCTextureImage	*textureImage;
    char     		*name;
    char		*textureMap;
    char		*detailMap;
} VCTextureData;

typedef struct
{
    uint32	 mode;
    uint16	 width;
    uint16	 height;
    uint8	 numComponents;
    uint8	*image;
} VCTextureImageData;

typedef struct
{
    int16		 doPlay;
    int16		 status;
    VCTextureImage	*textureImage;
    int16		 width;
    int16		 height;
    char		*fileName;
    char 		*viewName;
} VCVisualScreenDumpData;

typedef struct
{
    uint16 doSave;
    VCAttribute *first;
    VCAttribute *second;
    char *fileName;
} VCSectionImageSaveData;

typedef struct
{
    uint32	 actorId;
    char	*name;
    uint32	 numAliases;
    char       **aliases;
} VCBodyPartData;

typedef struct
{
    char8	*name;
    int32       numPoints;
    float32	points[VC_RADIATOR_MAX_POINTS];
} VCRadiatorData;

typedef struct
{
    uint32   	 mode;
    uint32    	 type;
    dmPoint   	 offset;
    float32    	 info[72];
    char     	*texture;
} VCVisualEffectData;

typedef struct
{
    uint32	 mode;
    uint32	 actorMask;
} VCZoneData;

typedef struct
{
    uint32	mode;
    float32	iMass;
    float32	gMass;
    dmPoint	centre;
    float32	iTensor[6];
    float32	spring;
    float32	damper;
    float32	staticFriction;
    float32	dynamicFriction;
} VCDynamicsData;

typedef struct
{
    uint32	mode;
    dmVector	force;
    dmPoint	point;
} VCForceData;

typedef struct
{
    uint32	 windowId;
    char	*serverName;
    char	*actorName;
} VCXWindowIdData;

typedef struct
{
    uint16		paint;
    uint16		size;
    uint16		queryNewPallete;
    uint16		palleteChanged;
    uint16		mapped;
    uint32		windowHandle;
    uint16	 	state;
} VCWindowData;

typedef struct
{
    uint32	mode;
    dmVector	direction;
    float32	gravity;
} VCPseudoGravityData;

typedef struct {
    float32 mass;
    dmPoint centre;
    float32 iTensor[6];
} VCInertialProps;

typedef struct
{
    float32	slow_speed;
    float32	fast_speed;
    float32	acceleration;
    float32	max_speed;
    uint32	slow_key;
    VCEntity   *slow_keyLimb;
    uint32	fast_key;
    VCEntity   *fast_keyLimb;
    uint32	accelerate_key;
    VCEntity   *accelerate_keyLimb;
} VCBodyFlyInfoData;

typedef struct
{
    uint32	 	 actorId;
    VCEntity 		*bodyRoot;
    VCEntity		*bodyPosEntity;
    VCBodyFlyInfoData	 fly_forward;
    VCBodyFlyInfoData	 fly_backward;
    VCBodyFlyInfoData	 fly_up;
    VCBodyFlyInfoData	 fly_down;
    VCBodyFlyInfoData	 fly_left;
    VCBodyFlyInfoData	 fly_right;
    VCBodyFlyInfoData	 rot_left;
    VCBodyFlyInfoData	 rot_right;
    VCBodyFlyInfoData	 rot_up;
    VCBodyFlyInfoData	 rot_down;
    uint32		 verticalFly_key;
    VCEntity		*verticalFly_keyLimb;
    uint32		 altFly_key;
    VCEntity		*altFly_keyLimb;
    VCEntity		*flyDirectionLimb;
    VCEntity		*altFlyDirectionLimb;
    VCEntity		*altFlyLimb;  
    uint32		 flyMode;
    uint32		 extraMode;
    char		*name;
    char		*user;
    char		*role;
    char		*display;
    char		*displayUnits;
    char 		*message;
    char		*paramaters;
    char		*syncActor;
    char		*syncName;
    int32		 interruptRate;
    uint32		 displayNavigator;
    uint32               parentWindow;
    int32                x, y;
    dmDistanceUnit	 distanceUnit;
    dmPoint		 orbitPoint;
} VCBodyData;

typedef struct
{
    float32	 objectInRate;
    float32	 objectInActive;
    float32	 objectTests;
    char 	*name;
} VCCollideMonitorData;

typedef struct
{
    float32	 sensorRate[VC_MAX_SENSORS];
    int		 sensorBaseNumber;
    char	*name;
} VCTrackerMonitorData;

typedef struct
{
    float32      headUpdateRate;     /* No updates / second */
    float32      geometryUpdates;    /* No updates / second */
    float32      frameRate;          /* No frames drawn/second */
    float32      drawRate;           /* Tri's per second */
    char8       *name;               /* Name of the actor. */
} VCVisualMonitorData;

typedef struct
{
    uint32	mode;
    VCColour	minRgb;
    VCColour	maxRgb;
    char*	name;
} VCRampData;


typedef struct
{
    char	*name;
    uint32	 mode;
    uint32	 state;
    char	*sessionFile;
    int32	 loopCount;
    float32	 rate;
} VCReplayResourceData;

typedef struct
{
    char	*name;
    char	*domainName;
    uint32	 mode;
    uint32	 status;
} VCActorResourceData;

typedef struct
{
    VCAttribute		*boundary1;
    VCAttribute		*boundary2;
    dmMatrix		 position1;
    dmMatrix		 position2;
    float32              distance;
    float32             *polylines;
} VCCollisionRequest_ReportData;

#endif
