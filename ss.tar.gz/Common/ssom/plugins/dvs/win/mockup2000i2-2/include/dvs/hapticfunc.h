HAPTIC_EXPORT VCAttribute 	*VCHaptic_Create (char *geometry_name, uint32 mode, char *lod,
                                                  char *material, char *behaviour, float32 mass);
HAPTIC_EXPORT VCAttribute 	*VCHaptic_CreateData(VCHapticData *hapticData);
HAPTIC_EXPORT int		 VCHaptic_SetData (VCAttribute *attribute,VCHapticData *hapticData);
HAPTIC_EXPORT int		 VCHaptic_Get (VCAttribute *attribute, char **haptic_name, uint32 *mode,
                                               char **lod, char **material, char **behaviour,
                                               float32 *mass);
HAPTIC_EXPORT int		 VCHaptic_GetData (VCAttribute *attribute, VCHapticData *hapticData);
HAPTIC_EXPORT VCAttribute 	*VCEntity_AddHapticData(VCEntity *entity, VCHapticData *hapticData);
HAPTIC_EXPORT VCAttribute 	*VCEntity_AddHaptic (VCEntity *entity, char *haptic_name, uint32 mode,
                                                     char *lod, char *material,char *behaviour, float32 mass);
HAPTIC_EXPORT int		 VCHaptic_SetGeometry (VCAttribute *attribute, char *haptic_name);
HAPTIC_EXPORT int		 VCHaptic_SetMode (VCAttribute *attribute, uint32 mode);
HAPTIC_EXPORT int		 VCHaptic_ModifyMode (VCAttribute *attribute, uint32 setMode, uint32 clearMode);
HAPTIC_EXPORT int		 VCHaptic_SetMaterial (VCAttribute *attribute, char *material);
HAPTIC_EXPORT int		 VCHaptic_SetBehaviour (VCAttribute *attribute, char *behaviour);
HAPTIC_EXPORT int		 VCHaptic_SetLod (VCAttribute *attribute, char *lod);
HAPTIC_EXPORT int		 VCHaptic_SetMass (VCAttribute *attribute, float32 mass);
HAPTIC_EXPORT int		 VCHaptic_GetGeometry (VCAttribute *attribute, char **haptic_name);
HAPTIC_EXPORT int		 VCHaptic_GetMode (VCAttribute *attribute, uint32 *mode);
HAPTIC_EXPORT int		 VCHaptic_GetMaterial (VCAttribute *attribute, char **material);
HAPTIC_EXPORT int		 VCHaptic_GetBehavioour (VCAttribute *attribute, char **behaviour);
HAPTIC_EXPORT int		 VCHaptic_GetLod (VCAttribute *attribute, char **lod);
HAPTIC_EXPORT int		 VCHaptic_GetMass (VCAttribute *attribute, float32 *mass);

HAPTIC_EXPORT VCAttribute *VCHapticResource_Create (char *name, uint32 mode);
HAPTIC_EXPORT VCAttribute *VCHapticResource_CreateData (VCHapticResourceData *hapticData);
HAPTIC_EXPORT VCAttribute *VCEntity_AddHapticResourceData(VCEntity *entity, VCHapticResourceData *data);
HAPTIC_EXPORT VCAttribute *VCEntity_AddHapticResource (VCEntity *entity, char *name, uint32 mode);
HAPTIC_EXPORT int VCHapticResource_Set (VCAttribute *attribute, uint32 setMode, uint32 clearMode);
HAPTIC_EXPORT int VCHapticResource_SetData (VCAttribute *attribute, VCHapticResourceData *hapticData);
HAPTIC_EXPORT int VCHapticResource_Get (VCAttribute *attribute, char **name, uint32 *mode);
HAPTIC_EXPORT int VCHapticResource_GetData (VCAttribute *attribute, VCHapticResourceData *hapticData);

#define VCHaptic_Delete(a) VCAttribute_Delete(a)
#define VCHapticResource_Delete(a) VCAttribute_Delete(a)
