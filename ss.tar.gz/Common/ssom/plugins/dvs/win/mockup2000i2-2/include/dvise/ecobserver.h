/*    -*-C++-*-
 *    PROJECT:      dvise
 *    SUBSYSTEM:    ec
 *    MODULE:       observer.h
 *
 *    FUNCTION:
 * Implement details of a simple observer pattern.
 * It is, however safe for removes and adds to the list of
 * observers while the observer list is being traversed.
 *
 * This is all inline, low-level hackery. The sort of thing
 * you want to protect your clients from. This should NEVER be
 * visible in your interface '.h' file for instance.
 *
 * So: you might have something like:-
 *
 * class Foo;
 * class FooObserver {
 * public:
 *     virtual void FooUpdated( Foo *) = 0:
 * };
 * class Foo {
 * protected:
 *              Foo();
 * public:
 *     virtual ~Foo();
 *     static  Foo         *create(void);
 *     virtual void AttachObserver(FooObserver *) = 0;
 *     virtual void DetachObserver(FooObserver *) = 0;
 *        .
 *        .
 *        .
 *     virtual void DoStuff(void) = 0;
 * };
 *
 * in your interface (.h) file, and something like:-
 *
 * #include "foo.h"
 * #include "ecobserver.h"
 *
 * class FooImpl: public Foo {
 *     ECSubjectImpl<FooObserver, Foo&, false > m_subject;
 *     .
 *     .
 *     .
 * public:
 *     void AttachObserver(FooObserver *o)
 *     {
 *         m_subject.AttachObserver(&FooObserver::FooUpdated, o);
 *     }
 * 
 *     void DetachObserver(FooObserver *o)
 *     {
 *         m_subject.DetachObserver(&FooObserver::FooUpdated, o);
 *     }
 *     .
 *     .
 *     .
 *     void DoStuff(void)
 *     {
 *         //do something to the state of foo 
 *        .
 *        .
 *        .
 *        m_subject.Notify(*this);
 *     }
 *     .
 *     .
 *     .
 * };
 * .
 * .
 * .
 * Foo:Foo(){}
 * Foo:~Foo(){}
 * Foo *
 * Foo::create(void)
 * {
 *     return new FooImpl();
 * }
 *
 *
 * in your implementation (.cc) file. Then any client can derrive
 * themselves from FooObserver, and AttachObserver() themselves to any
 * Foo objects they are interested in.  They will get told about
 * updates via their FooUpdated() function, which they override, of
 * course.
 *
 * Copyright (c) 2000 Parametric Technology Inc.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Parametric Technology Inc.  */
#ifndef _ECOBSERVER_H
#define _ECOBSERVER_H

#include <list.h>

#ifndef DV_EXPORT
#include "dvexport.h"
#endif

#ifndef _ECASSERT_H
#include "ecassert.h"
#endif

/*
 * One of these is used to keep track of each observer
 * watching a subject.
 */
template <class OBSERVER, class SUBJECT> 
class DV_EXPORT ECObserver
{
public:
    typedef void (OBSERVER::*updateFunc)(SUBJECT );

    ECObserver(updateFunc pmf, OBSERVER *obs)
            :m_delayedRm(false),
             m_pmf(pmf),
             m_obs(obs){};

    ECObserver()
            :m_delayedRm(false),
             m_pmf(0),
             m_obs(0){};

    ECObserver(const ECObserver &x)
            :m_delayedRm(false),
             m_pmf(x.m_pmf),
             m_obs(x.m_obs){};

    void  DeleteObserver(void)       {delete m_obs;}

    bool    NeedsRemoval(void) const {return m_delayedRm;}

    void  MarkForRemoval(void)       {m_delayedRm = true;}

    void          Notify(SUBJECT s)  {if (!NeedsRemoval()) (m_obs->*m_pmf)(s);}

    bool      operator==(const ECObserver &o) const 
        {
            return ((m_obs==o.m_obs)&&(m_pmf==o.m_pmf));
        }
    
private:
    bool        m_delayedRm;
    updateFunc  m_pmf;
    OBSERVER   *m_obs;
};
   
//
// The basic Subject implementation.
// OBSERVER is the class of observing objects.
// SUBJECT is the type passed back to the OBSERVERs notify function.
// DELETE_OBSERVERS should be set to 'true' if you want observers
// removed from the list to be deleted as well, to 'false' otherwise.
// 
template <class OBSERVER, class SUBJECT, bool DELETE_OBSERVERS>
class DV_EXPORT ECSubjectImpl
{
    /*
     * member types. We use a list for simplicity here.
     * There might be an efficiency problem if many detaches 
     * are performed on long lists. In which case maybe
     * a set or hash set would be more suitable.
     */
public:
    typedef ECObserver<OBSERVER, SUBJECT> Observer;
    typedef typename Observer::updateFunc updateFunc;
    
private:
    typedef list<Observer> obList;
    typedef typename obList::iterator iterator;
    
    bool   m_inUse;
    bool   m_delayedRm;
    obList m_delayedAdd;
    obList m_observers;

    void emptyObList(obList &l)
        {
            if (DELETE_OBSERVERS) {
                iterator y;
                while ((y= l.begin()) != l.end() ) {
                    (*y).DeleteObserver();
                    l.erase(y);
                }
            }
            else{
                l.erase(l.begin(),l.end());
            }
        }
    
public:
             //TODO: do we need specific copy constructor???
    ECSubjectImpl()
            :m_inUse(false),
             m_delayedRm(false) {}
    
        //remove all records of all observers
    void Flush(void)
        {
            if(m_inUse) {
                iterator y    = m_observers.begin();
                iterator last = m_observers.end();
                while( y != last) {
                    (*y).MarkForRemoval();
                    y++;
                }
            }
            else 
                emptyObList(m_observers);
            emptyObList(m_delayedAdd);
        }

        // Two ways to attach an observer object.  either with a
        // prebuild ECObserver, or by ptr to observer object & to
        // update func.
    void AttachObserver(const Observer  &ob)
        {
            if(m_inUse)
                m_delayedAdd.push_back(ob);
            else 
                m_observers.push_back(ob);
        }

    void AttachObserver(updateFunc pmf, OBSERVER *o)
        {
            AttachObserver(Observer(pmf,o));
        }


        //A pair of dettach functions to mirror the attaches.
        //We don't use iterators (returned by the attaches) to do the delete
        // in the interest of insulating client from the implementation deail.
    bool DetachObserver(const Observer  &ob)
        {
            iterator y    = m_observers.begin();
            iterator last = m_observers.end();
            while ( y != last) {
                if (ob == *y){
                    if (m_inUse){
                        m_delayedRm = true;
                        (*y).MarkForRemoval();
                    }
                    else {
                        if (DELETE_OBSERVERS)
                            (*y).DeleteObserver();
                        m_observers.erase(y);
                    }
                    return true;
                }
                ++y;
            }

                //Hm, not found, look through delayed adds...
                // Can just remove these immediately with no worries.
            y    = m_delayedAdd.begin();
            last = m_delayedAdd.end();
            while ( y != last) {
                if (ob == *y){
                    if (DELETE_OBSERVERS)
                        (*y).DeleteObserver();
                    m_delayedAdd.erase(y);
                    return true;
                }
                ++y;
            }
            return false;
        }

    bool DetachObserver(updateFunc pmf, OBSERVER *o)
        {
            return DetachObserver(Observer(pmf,o));
        }
    
        //Notify all observers that the subject has changed in someway
        // Also checks for any delayed adds & Rms that are needed.
    void Notify(SUBJECT s)
        {
            m_inUse = true;
            iterator y    = m_observers.begin();
            iterator last = m_observers.end();
            while( y != last) {
                (*y).Notify(s);
                y++;
            }
            m_inUse = false;


                // do any delayed adds
            m_observers.splice(m_observers.end(),m_delayedAdd);
            ECAssert (m_delayedAdd.empty());
    
                // do any delayed removes.
            if(m_delayedRm) {
                    //would like to use 'remove_if()'
                    //- but get 'internal compiler error' messages
                iterator first = m_observers.begin();
                iterator last  = m_observers.end();
                while (first != last) {
                    iterator next = first;
                    ++next;
                    if ((*first).NeedsRemoval()){
                        if (DELETE_OBSERVERS)
                            (*first).DeleteObserver();
                        m_observers.erase(first);
                    }
                    
                    first = next;
                }
                m_delayedRm = false;   
            }    
        }

        //Determin if there is anyone actually observing this subject...
    bool UnderObservation(void) const
        {
            return !m_observers.empty();
        }
};
#endif /*_ECOBSERVER_H */
