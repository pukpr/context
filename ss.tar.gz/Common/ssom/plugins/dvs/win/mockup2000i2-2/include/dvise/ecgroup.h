//-*-C++-*-
#include "eclist.h"
#include "ecsmartptr.h"
#include <hash_map.h>

class _ECGroupInfo;



class DV_EXPORT hashFuncClass
/*
 * this is a simple class that is used to allow hashing of assembly *'s.
 * it contains one func which hashes the ptr
 */
{
public:
    // hash func used by hash_map - just convert ptr to size_t
    size_t operator()(const ECAssembly *pAss) const { return((size_t)pAss); }
};

class _ECGroupUpdateInfo;

// hash_map<Key, Data, HashFcn, EqualKey, Alloc>
typedef hash_map<ECAssembly *,
                 _ECGroupUpdateInfo *,
                 hashFuncClass,
                 equal_to<ECAssembly *> > _ECAssToInfoMap; 
typedef _ECAssToInfoMap::iterator _ECAssToInfoMapIterator;
typedef _ECAssToInfoMap::value_type _ECAssToInfoMapPair;

class DV_EXPORT _ECGroupUpdateInfo
/* implemented in _ecgroup.cc
 * this is a class that is created with an assembly.  It will then monitor that
 * assembly, calling back if it is being deleted for real - or removed from functional
 * tree (ECASSEMBLY_UPDATE_DELETE).
 */
{
public:
// types
    // callback func when assembly is deleted, if bFuncOnly it's only being deleted from functional tree
    typedef void DeleteCbFunc(ECAssemblyPtr &assPtr, bool bFuncOnly, void *userData);
    
// public functions
    _ECGroupUpdateInfo(ECAssemblyPtr &assPtr, DeleteCbFunc *cbFunc, void *cbData);
    ~_ECGroupUpdateInfo(void);
    
// public variables
    int m_instances; // used to work out how many copies of assembly are in parent data structure
    
protected:
// private fuctions
    // removes any callback's added, and delete's smart ptr to assembly
    void DetachFromAssembly(void);
    // called on assembly update
    static void AssUpdateCb(ECCallbackInfo *pInfo, void *pUserData);
    // called on assembly delete
    static void AssDeleteCb(ECCallbackInfo *pInfo, void *pUserData);
    
// variables
    ECAssemblyPtr *m_pAssPtr; // ptr to ptr of assembly we are monitoring or NULL
    _ECAssembly::ECCallbackIterator m_updateHandle; // handle for the assembly update callback
    _ECAssembly::ECCallbackIterator m_deleteHandle; // handle for the assembly delete callback
    DeleteCbFunc  *m_pCbFunc; // The function to call on delete
    void          *m_pCbFuncData; // user data for m_pCbFunc
};

class DV_EXPORT _ECGroup : public _ECBaseItem
{
friend class _ECGroupInfo;
public:
    int         getId(void) const;
    char       *getIdString(void) const;
    static int  getMyId();
    int         writeVdiFile();
    char       *GetName(void) const;
    ECError	SetName(char *name);
    ECError	SetNameNoCopy(char *name);
    _ECBaseItem *clone(void) const;

    int         SetMode(ECGroupType mode);
    int         SetAssembly(ECAssembly *assembly);

    ECItemListPtr *GetAssemblyList(void) { return _assemblyList;};
    ECGroupType    GetMode(void);
    int         GetNumEntries(void);
    
    int32       RemoveAllAssemblies(void);
    int32       Add(ECAssembly *assembly);
    int32       Add(ECAssembly *assembly1, ECAssembly *assembly2);
    int32       Remove(ECAssembly *assembly);
    int32       Remove(ECAssembly *assembly1, ECAssembly *assembly2);

    int32       IsEmpty(void);

   _ECGroup();
  ~_ECGroup(void);
    
    // simon 14/9/99 remove update cb's for that assembly
    void removeInfoOnAss(ECAssemblyPtr &assPtr);
    // simon 14/9/99 add update cb's for that assembly
    void addInfoOnAss(ECAssemblyPtr &assPtr);
    // simon 14/9/99 internal function to remove assembly from group list
    int internalRemoveAss(ECAssemblyPtr &assPtr);
    // simon 14/9/99 internal function to remove assembly from pair group list
    void internalRemovePairAss(ECItemListPtr &pairList, ECAssemblyPtr &assPtr);
    // simon 14/9/99 internal function to remove pair list, from assembly list
    void internalRemovePairList(ECItemListPtr &pairList);
    // simon 14/9/99 internal function to add assembly to group list
    void internalAddAss(ECAssemblyPtr &assPtr);
    // simon 14/9/99 internal function to add assembly to pair group list
    void internalAddPairAss(ECItemListPtr &pairList, ECAssemblyPtr &assPtr);
    // simon 14/9/99 internal function to add pair list, to assembly list
    void internalAddPairList(ECItemListPtr &pairList);
    // called when assPtr is being deleted, if bFuncOnly then only from functional view
    static void assemblyDeletedCb(ECAssemblyPtr &assPtr, bool bFuncOnly, void *userData);
    
private:
    char          *_name;
    ECGroupType    _mode;
    ECAssembly    *_groupAssembly;
    ECItemListPtr *_assemblyList;
    _ECItemList::ECCallbackIterator _updateCallback;
    _ECAssToInfoMap _assInfoMap;
};

DV_EXPORT ECItemListPtr * ECGroup_GetAssemblyList(ECGroup *group);

