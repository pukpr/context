#ifndef ES_EXPORT
#if defined (_WIN32) && ! defined (_UNIX) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `DV_EXPORT'
 */
#ifdef  _LIB_ES
#define ES_EXPORT __declspec(dllexport)
#else
#define ES_EXPORT __declspec(dllimport)
#endif /* IN_A_DIVISION_LIB */
#else
#define ES_EXPORT 
#endif /* ! _WIN32 */
#endif /* ifndef DV_EXPORT */
