/* -*- C++ -*-
-- ----------------------------------------------------------------------------
--
--  			Copyright 1998 Division Limited.
--			      All Rights Reserved
--
--
--  System       : 
--  Module       : 
--  Object Name  : $RCSfile: esmodules.h,v $
--  Revision     : $Revision: 1.2 $
--  Date         : $Date: 2000/04/01 09:34:25 $
--  Author       : $Author: john $
--
--  Description	
--
--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __MODULES_H__
#define __MODULES_H__

#include <list.h>
#include <divstring.h>

class Level
{
    string n;                   // level name
    int m;                      // bit mask 

public:
    
    Level(const char* const name, const int mask) : n(name), m(mask) {}

};

typedef list<Level> LevelList;

class Module 
{
    char* n;                    // module name
    int i;                      // id
    LevelList l;                // list of levels

public:
    
    Module(const char* const name, const int id) : i(id) { 
        if (name)
            n = strdup(name);
        else
            n = 0;
    }
    Module(const Module& m) {
        i = m.i;
        if (m.n)
            n = strdup(m.n);
        else 
            n = 0;
    }
    const Module& operator=(const Module& m) {
        i = m.i;
        if (m.n)
            n = strdup(m.n);
        else 
            n = 0;
        return *this;
    }

            
    ~Module() { if (n) free(n);}
    const char* name() const { return n; }
    int id() const { return i; }
};

typedef list<Module> ModuleList;

#endif /* __MODULES_H__ */
