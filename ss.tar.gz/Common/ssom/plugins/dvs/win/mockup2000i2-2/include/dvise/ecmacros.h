/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: ecmacros.h,v $
 *    Revision:     $Revision: 1.5 $
 *    Date:         $Date: 1996/09/11 15:44:10 $
 *    Author:       $Author: clives $
 *    RCS Ident:    $Id: ecmacros.h,v 1.5 1996/09/11 15:44:10 clives Exp $
 *
 *    FUNCTION:
 *
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, _in whole or in part, _be copied,
 * photocopied, _reproduced, _translated, _or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _ECMACROS_H
#define _ECMACROS_H

/*
 *
 * CAVEAT:  Macros are allowed 1 level of reference.
 *          It is the responsibility of the user to check
 *          for null return values from macros and functions alike.
 *
 */

/* PUBLIC DEFINES =======================================*/


#define ECAllocate(type) (type *)calloc(1, sizeof(type))

/* PUBLIC TYPES =========================================*/


/* PUBLIC VARIABLES ======================================*/


/* PUBLIC FUNCTIONS ======================================*/


#endif /*_ECMACROS_H */
