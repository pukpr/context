/* -*- C -*- ****************************************************************
 *
 *  			Copyright 1999 Division Ltd.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: dvfol.h,v $
 *  Revision      : $Revision: 1.1 $
 *  Date          : $Date: 1999/05/12 11:41:12 $
 *  Author        : $Author: bill $
 *  Created By    : Steven Phillips
 *  Created       : Wed May 5 11:24:02 1999
 *  Last Modified : <050599.1312>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 *  $Log: dvfol.h,v $
 *  Revision 1.1  1999/05/12 11:41:12  bill
 *  Added new cgos and path naming conventions, improved the support for missing dependancies.
 *  Broke out the ol tokens into a def file for olchange. Moved over to using dfu
 *
 *
 ****************************************************************************
 *
 *  Copyright (c) 1999 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 * This  document  may  not, in  whole  or in  part, be  copied,  photocopied,
 * reproduced,  translated,  or  reduced to any  electronic  medium or machine
 * readable form without prior written consent from Division Ltd.
 *
 ****************************************************************************/

#ifndef __DVFOL_h
#define __DVFOL_h

#define DOLFILE_INTEL      0xFF
#define	DOLFILE_SUN_HP     0xFE
#define DOLUNIT_INCH       1
#define	DOLUNIT_MM         2
#define	DOLUNIT_CM         3
#define	DOLUNIT_M          4

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif


dfuFile *
dolFileOpen(char *fileName) ;

#define dolFileColor(olf)    ((float32 *) olf->usrData)

int32
dolFileWriteColor(dfuFile *olf, float32 rr, float32 gg, float32 bb) ;

int32
dolFileWriteToken(dfuFile *olf, uint8 code, int32 addRet) ;
#define dolFileWriteAsciiToken(olf,code,addRet) \
((dvconOutputOLAscii()) ?                       \
 dolFileWriteToken(olf,code,addRet):dpgSUCCESS)

int32
dolFileWriteAsciiTokenInt32(dfuFile *olf, uint8 code, int32 num, int32 addRet) ;

int32
dolFileWriteTokenSize(dfuFile *olf, uint8 code, int32 num) ;

int32
dolFileWriteString(dfuFile *olf, char *str) ;

#define DOLMAXARRAYSIZE 10
int32
dolFileWriteInt32Array(dfuFile *olf, int32 num, int32 *aa) ;

int32
dolFileWriteFloat32Array(dfuFile *olf, int32 num, float32 *aa) ;

int32
dolFileWriteFloat64Array(dfuFile *olf, int32 num, float64 *aa) ;

int32
dolFileWriteSurfaceRange(dfuFile *olf, int32 orien, dnrbRange rangeU, dnrbRange rangeV) ;

int32
dolFileWriteUnit(dfuFile *olf) ;

int32
dolFileWriteCurveBound(dfuFile *olf, int32 dir, dmdPoint end1, dmdPoint end2) ;

int32
dolFileWriteLayerDefs(dfuFile *olf, int32 noLayerDefs, char **layerName) ;
int32
dolFileWriteLayerRef(dfuFile *olf, int32 index) ;

int32
dolFileWriteBeginSolid(dfuFile *olf) ;
int32
dolFileWriteEndSolid(dfuFile *olf) ;

int32
dolFileWriteBeginQuilt(dfuFile *olf) ;
int32
dolFileWriteEndQuilt(dfuFile *olf) ;

int32
dolFileWriteBeginDatum(dfuFile *olf) ;
int32
dolFileWriteEndDatum(dfuFile *olf) ;

int32
dolFileWriteBeginFace(dfuFile *olf) ;
int32
dolFileWriteEndFace(dfuFile *olf) ;

int32
dolFileWriteBeginFaceSet(dfuFile *olf) ;
int32
dolFileWriteEndFaceSet(dfuFile *olf) ;

int32
dolFileWriteBeginFacet(dfuFile *olf) ;
int32
dolFileWriteEndFacet(dfuFile *olf) ;

int32
dolFileWriteBeginLoop2D(dfuFile *olf, int32 noCurves, int32 loopNo) ;
int32
dolFileWriteEndLoop2D(dfuFile *olf) ;

int32
dolFileWriteBeginVertices(dfuFile *olf, int32 num) ;
#define dolFileWriteFloat64Vertex(olf,vv)  dolFileWriteFloat64Array(olf,3,vv)
#define dolFileWriteFloat32Vertex(olf,vv)  dolFileWriteFloat32Array(olf,3,vv)
int32
dolFileWriteEndVertices(dfuFile *olf) ;
int32
dolFileWriteBeginNormals(dfuFile *olf, int32 num) ;
#define dolFileWriteFloat64Normal(olf,nn)  dolFileWriteFloat64Array(olf,3,nn)
#define dolFileWriteFloat32Normal(olf,nn)  dolFileWriteFloat32Array(olf,3,nn)
int32
dolFileWriteEndNormals(dfuFile *olf) ;
int32
dolFileWriteBeginPolygons(dfuFile *olf, int32 num) ;
#define dolFileWritePolygon(olf,pp)        dolFileWriteInt32Array(olf,3,pp)
int32
dolFileWriteEndPolygons(dfuFile *olf) ;

#define dolWRITE_CURVE   0
#define dolWRITE_PSCURVE 1
#define dolWRITE_MSCURVE 2
int32
dolFileWriteNurbCurve(dfuFile *olf, dnrbCurve *curve, int32 outType, dglSurface *surf) ;
int32
dolFileWriteCircleCurve(dfuFile *olf, dmdPoint point, dmdVector xAxis, dmdVector yAxis,
                        float64 radius, dnrbRange range, dmdPoint sttPnt, dmdPoint endPnt) ;
int32
dolFileWriteEllipseCurve(dfuFile *olf, dmdPoint point, dmdVector xAxis, dmdVector yAxis, float64 radius1,
                         float64 radius2, dnrbRange range, dmdPoint sttPnt, dmdPoint endPnt) ;
int32
dolFileWriteLineCurve(dfuFile *olf, dmdPoint sttPnt, dmdPoint endPnt) ;
int32
dolFileWritePolylineCurve(dfuFile *olf, int32 noPoints, dmdPoint *points) ;


int32
dolFileWriteNurbSurface(dfuFile *olf, dnrbSurface *surface, int32 orien,
                        dnrbRange rangeU, dnrbRange rangeV) ;
int32
dolFileWriteConeSurface(dfuFile *olf, dmdPoint point, dmdVector xAxis, dmdVector zAxis,
                        float64 radius, float64 semiAngle, int32 orien,
                        dnrbRange rangeU, dnrbRange rangeV) ;
int32
dolFileWriteCylinderSurface(dfuFile *olf, dmdPoint point, dmdVector xAxis, dmdVector zAxis,
                            float64 radius, int32 orien, dnrbRange rangeU, dnrbRange rangeV) ;
int32
dolFileWritePlaneSurface(dfuFile *olf, dmdPoint point, dmdVector xAxis, dmdVector zAxis,
                         int32 orien, dnrbRange rangeU, dnrbRange rangeV) ;
int32
dolFileWriteSphereSurface(dfuFile *olf, dmdPoint point, dmdVector xAxis, dmdVector zAxis,
                          float64 radius, int32 orien, dnrbRange rangeU, dnrbRange rangeV) ;

int32
dolFileWriteGDT(dfuFile *olf, dmdPoint point, char *text) ;
int32
dolFileWriteLeaderLine(dfuFile *olf, int32 noPoints, dmdPoint *points) ;

int32
dvfAssemblyWriteOlCurve(dfuFile *olf, dglCurve *curve, int32 outType, int32 secondaryFlag,
                        dglSurface *surf) ;
int32
dvfAssemblyWriteOlSurface(dfuFile *olf, dglSurface *surf, int32 secondaryFlag) ;

int32
dvfAssemblyWriteOlFile(dvfFile *file, dvfAssembly *assembly) ;

int32
dvfFileWriteEdFile(dvfFile * file) ;


#if defined(__cplusplus) || defined(c_plusplus)
}
#endif
#endif /* __DVFOL_h */
