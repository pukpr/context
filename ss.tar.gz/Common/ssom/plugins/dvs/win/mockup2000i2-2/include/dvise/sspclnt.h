/******************************************************************************/
/*									      */
/*	######    ###   #     #   ###    #####    ###   ####### #     #	      */
/*	#     #    #    #     #    #    #     #    #    #     # ##    #	      */
/*	#     #    #    #     #    #    #          #    #     # # #   #	      */
/*	#     #    #    #     #    #     #####     #    #     # #  #  #	      */
/*	#     #    #     #   #     #          #    #    #     # #   # #	      */
/*	#     #    #      # #      #    #     #    #    #     # #    ##	      */
/*	######    ###      #      ###    #####    ###   ####### #     #	      */
/*									      */
/*									      */
/*			#####    ###     ###     ###			      */
/*			     #  #   #   #   #   #   #			      */
/*			     # #     # #     # #     #			      */
/*			#####  #     # #     # #     #			      */
/*			#      #     # #     # #     #			      */
/*			#       #   #   #   #   #   #			      */
/*			######   ###     ###     ###			      */
/*									      */
/* 		Copyright (c) Division Limited. All rights reserved	      */
/*									      */
/* This Document may not, in whole or in part, be copied, photocopied,	      */
/* reproduced, translated, or reduced to any electronic medium or machine     */
/* readable form without prior written consent from Division Ltd.	      */
/*									      */
/******************************************************************************/

#if !defined _SSPCLNT_H_
#define _SSPCLNT_H_

#include <dsys/dp.h>
#include <dvise/ss.h>

#define SSP_DATA_NUM_STRINGS 3
#define SSP_DATA_NUM_NUMBERS 6

typedef struct SSP_DATA * SSP_DATA_PTR;
typedef struct SSP_DATA
{
  uint16 command;
  char * string[SSP_DATA_NUM_STRINGS];
  uint32 number[SSP_DATA_NUM_NUMBERS];

  bool gotCommand;
  bool gotString[SSP_DATA_NUM_STRINGS];
  bool gotNumber[SSP_DATA_NUM_NUMBERS];

} SSP_PROT_DATA;

typedef int (*SSP_HANDLER_FUNC) (SS_HANDLE ss, SSP_DATA_PTR sdp, void * userData);

typedef struct SSP_HANDLER * SSP_HANDLER_PTR;
typedef struct SSP_HANDLER
{
  SS_HANDLE        ss;
  void           * userData;

  SSP_HANDLER_FUNC selectHandler;
  SSP_HANDLER_FUNC deselectHandler;
  SSP_HANDLER_FUNC assCreateHandler;
  SSP_HANDLER_FUNC assUpdateHandler;
  SSP_HANDLER_FUNC assDeleteHandler;
  SSP_HANDLER_FUNC userHandler;

} SSP_HANDLER;

/* Handler numbers */
#define SSP_HANDLER_SELECT      1
#define SSP_HANDLER_DESELECT    2
#define SSP_HANDLER_ASSCREATE   3
#define SSP_HANDLER_ASSUPDATE   4
#define SSP_HANDLER_ASSDELETE   5
#define SSP_HANDLER_USER        99

/* Callback on/off flags */
#define SSP_CLB_ON         0x10000000
#define SSP_CLB_OFF        0x20000000
#define SSP_CLB_ONOFF_MASK 0xF0000000

/* Callback types */
#define SSP_CLB_TYPE_SELECT 0x00010000
#define SSP_CLB_TYPE_CREATE 0x00020000
#define SSP_CLB_TYPE_DELETE 0x00030000
#define SSP_CLB_TYPE_UPDATE 0x00040000
#define SSP_CLB_TYPE_MASK   0x0FFF0000

/* Callback flags..... */
#define SSP_CLB_FLAG_MASK   0x0000FFFF

/* These are the current flags that can be passed with the */
/* ssp_sendUpdateClbXXX commands. These are a copy of the */
/* flags in src/dvise/libec/ecassembly.h. I really wanted to */
/* #include them, but I also need to keep client side code free */
/* of EC stuff. Should be possible later with some hackery. */
#define SSP_CLB_UPD_FLAG_DELETE                0x00000001
#define SSP_CLB_UPD_FLAG_MARKDELETED           0x00000002
#define SSP_CLB_UPD_FLAG_UNDELETE              0x00000004
#define SSP_CLB_UPD_FLAG_FUNCTIONALONLY        0x00000008
#define SSP_CLB_UPD_FLAG_ADDATTRIBUTE          0x00000010
#define SSP_CLB_UPD_FLAG_REMOVEATTRIBUTE       0x00000020
#define SSP_CLB_UPD_FLAG_POSITIONCHANGE        0x00000040

extern int ssp_sendExit          (SS_HANDLE ss);
extern int ssp_sendEvent         (SS_HANDLE ss, char * path, char * event);
extern int ssp_sendFileOpen      (SS_HANDLE ss, char * filename);
extern int ssp_sendFileMerge     (SS_HANDLE ss, char * assy, char * filename);
extern int ssp_sendFileReplace   (SS_HANDLE ss, char * assy, char * filename);
extern int ssp_sendFileDelete    (SS_HANDLE ss, char * assy, char * filename);
extern int ssp_sendFileNew       (SS_HANDLE ss);
extern int ssp_sendLoad          (SS_HANDLE ss, char * path, int doBranch);
extern int ssp_sendUnload        (SS_HANDLE ss, char * path, int doBranch);
extern int ssp_sendEnable        (SS_HANDLE ss, char * path, int doBranch);
extern int ssp_sendDisable       (SS_HANDLE ss, char * path, int doBranch);
extern int ssp_sendHeadlight     (SS_HANDLE ss, int headlightOn);
extern int ssp_sendSelect        (SS_HANDLE ss, char * path, int doBranch);
extern int ssp_sendDeselect      (SS_HANDLE ss, char * path, int doBranch);
extern int ssp_sendCallbackOnOff (SS_HANDLE ss, uint32 type, int on, uint32 flags);
extern int ssp_sendFileName      (SS_HANDLE ss, char * path);
extern int ssp_sendAttrFileName  (SS_HANDLE ss, char * path);
extern int ssp_sendOpenMatrlLib  (SS_HANDLE ss, char * path);

extern int ssp_sendAssCreate        (SS_HANDLE ss, char * path);
extern int ssp_sendAssDelete        (SS_HANDLE ss, char * path);
extern int ssp_sendAssUpdate        (SS_HANDLE ss, char * path, uint32 flags);
extern int ssp_sendAssGeomFile      (SS_HANDLE ss, char * path, char * file);
extern int ssp_sendAssPos           (SS_HANDLE ss, char * path, float xPos, float yPos, float zPos, float xAng, float yAng, float zAng);
extern int ssp_sendAssResetViz      (SS_HANDLE ss, char * path, int doBranch);
extern int ssp_sendAssMatrlOverride (SS_HANDLE ss, char * path, char * frontMat, char * backMat, int doBranch);
extern int ssp_sendAssRename        (SS_HANDLE ss, char * path, char * newPath);

extern int ssp_sendWindowCreate         (SS_HANDLE ss, uint32 id);
extern int ssp_sendWindowSize           (SS_HANDLE ss);
extern int ssp_sendWindowPaint          (SS_HANDLE ss);
extern int ssp_sendWindowNewPalette     (SS_HANDLE ss);
extern int ssp_sendWindowPaletteChanged (SS_HANDLE ss);
extern int ssp_sendWindowMapped         (SS_HANDLE ss, int visible);
extern int ssp_sendWindowDestroy        (SS_HANDLE ss);

extern int ssp_sendOptionAnim           (SS_HANDLE ss, int enable);
extern int ssp_sendOptionNav            (SS_HANDLE ss, int show);
extern int ssp_sendOptionOrtho          (SS_HANDLE ss, int ortho);
extern int ssp_sendOptionWire           (SS_HANDLE ss, int wire);
extern int ssp_sendOptionLodapt         (SS_HANDLE ss, int lod);
extern int ssp_sendOptionPick           (SS_HANDLE ss, int pickOn);
extern int ssp_sendOptionDetail         (SS_HANDLE ss, int detail);
extern int ssp_sendOptionOcc            (SS_HANDLE ss, int occOn);
extern int ssp_sendOptionHlight         (SS_HANDLE ss, int bbox, int colour);
extern int ssp_sendOptionTxtmv          (SS_HANDLE ss, int staticOn, int movingOn);
extern int ssp_sendOptionAA             (SS_HANDLE ss, int aaOn, int samples);
extern int ssp_sendOptionLodscl         (SS_HANDLE ss, float lodVal);

extern int ssp_collectCommandData       (SS_HANDLE ss, SSP_DATA_PTR sdp);
extern int ssp_collectCommandAndData    (SS_HANDLE ss, SSP_DATA_PTR sdp);

extern int ssp_isCmdExit         (SSP_DATA_PTR sdp);
extern int ssp_isCmdEvent        (SSP_DATA_PTR sdp);
extern int ssp_isCmdFileOpen     (SSP_DATA_PTR sdp);
extern int ssp_isCmdFileMerge    (SSP_DATA_PTR sdp);
extern int ssp_isCmdFileReplace  (SSP_DATA_PTR sdp);
extern int ssp_isCmdFileDelete   (SSP_DATA_PTR sdp);
extern int ssp_isCmdFileNew      (SSP_DATA_PTR sdp);
extern int ssp_isCmdLoad         (SSP_DATA_PTR sdp);
extern int ssp_isCmdUnload       (SSP_DATA_PTR sdp);
extern int ssp_isCmdEnable       (SSP_DATA_PTR sdp);
extern int ssp_isCmdDisable      (SSP_DATA_PTR sdp);
extern int ssp_isCmdHeadlight    (SSP_DATA_PTR sdp);
extern int ssp_isCmdSelect       (SSP_DATA_PTR sdp);
extern int ssp_isCmdDeselect     (SSP_DATA_PTR sdp);
extern int ssp_isCmdClbOnOff     (SSP_DATA_PTR sdp);
extern int ssp_isCmdFileName     (SSP_DATA_PTR sdp);
extern int ssp_isCmdAttrFileName (SSP_DATA_PTR sdp);
extern int ssp_isCmdOpenMatrlLib (SSP_DATA_PTR sdp);

extern int ssp_isAssCreate        (SSP_DATA_PTR sdp);
extern int ssp_isAssUpdate        (SSP_DATA_PTR sdp);
extern int ssp_isAssDelete        (SSP_DATA_PTR sdp);
extern int ssp_isAssGeomFile      (SSP_DATA_PTR sdp);
extern int ssp_isAssPos           (SSP_DATA_PTR sdp);
extern int ssp_isAssResetViz      (SSP_DATA_PTR sdp);
extern int ssp_isAssMatrlOverride (SSP_DATA_PTR sdp);
extern int ssp_isAssRename        (SSP_DATA_PTR sdp);

extern int ssp_isOptAnim      (SSP_DATA_PTR sdp);
extern int ssp_isOptNav       (SSP_DATA_PTR sdp);
extern int ssp_isOptOrtho     (SSP_DATA_PTR sdp);
extern int ssp_isOptWire      (SSP_DATA_PTR sdp);
extern int ssp_isOptLodApt    (SSP_DATA_PTR sdp);
extern int ssp_isOptPick      (SSP_DATA_PTR sdp);
extern int ssp_isOptDetail    (SSP_DATA_PTR sdp);
extern int ssp_isOptOcc       (SSP_DATA_PTR sdp);
extern int ssp_isOptHlight    (SSP_DATA_PTR sdp);
extern int ssp_isOptTxtMv     (SSP_DATA_PTR sdp);
extern int ssp_isOptAA        (SSP_DATA_PTR sdp);
extern int ssp_isOptLodScl    (SSP_DATA_PTR sdp);

extern int ssp_isWinCreate    (SSP_DATA_PTR sdp);
extern int ssp_isWinSize      (SSP_DATA_PTR sdp);
extern int ssp_isWinPaint     (SSP_DATA_PTR sdp);
extern int ssp_isWinNewPal    (SSP_DATA_PTR sdp);
extern int ssp_isWinPalchg    (SSP_DATA_PTR sdp);
extern int ssp_isWinMapped    (SSP_DATA_PTR sdp);
extern int ssp_isWinDestry    (SSP_DATA_PTR sdp);

extern SSP_HANDLER_PTR ssp_openHandler    (SS_HANDLE ss, void * userData);
extern void            ssp_closeHandler   (SSP_HANDLER_PTR shp);
extern int             ssp_setHandler     (SSP_HANDLER_PTR shp, int handler, SSP_HANDLER_FUNC newFunc);
extern int             ssp_removeHandler  (SSP_HANDLER_PTR shp, int handler);
extern int             ssp_defaultHandler (SSP_HANDLER_PTR shp, int handler);
extern int             ssp_clntHandler    (SSP_HANDLER_PTR shp);

extern void            ssp_sdpToFile      (SSP_DATA_PTR sdp, char * filename);
extern int             ssp_sendCmdFile    (SS_HANDLE ss, char * filename);

#endif /* _SSPCLNT_H */
