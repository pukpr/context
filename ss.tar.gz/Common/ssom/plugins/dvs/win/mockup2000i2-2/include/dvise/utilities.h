/****************************************************************************
 *
 *  			Copyright 1998 Division Ltd.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: utilities.h,v $
 *  Revision      : $Revision: 1.11 $
 *  Date          : $Date: 2000/04/04 18:11:07 $
 *  Author        : $Author: simon $
 *  Created       : Mon Feb 2 11:44:29 1998
 *  Last Modified : <000404.1739>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 *  $Log: utilities.h,v $
 *  Revision 1.11  2000/04/04 18:11:07  simon
 *  Changed autoupdate so it gives you the chance to specify mouse position
 *  if you require.
 *
 *  Revision 1.10  2000/03/16 17:12:04  john
 *  fixes to make it compile in a clean build
 *
 *  Revision 1.9  2000/03/14 16:49:12  simon
 *  Stopped compilation of distance.c, made a few upgrades for latest
 *  version of tool.
 *
 *  Revision 1.8  1999/08/26 12:45:27  jeff
 *  moved all #include lines out of extern C blocks. I hope.
 *
 *  Revision 1.7  1999/07/08 13:23:26  simon
 *  extern c'd it so functions can be used in dvisegui.
 *
 *  Revision 1.6  1998/09/08 09:29:10  simon
 *  fixed problem locking to tape points.
 *
 *  Revision 1.5  1998/05/05 12:09:54  simon
 *  fixed header include stuff
 *
 *  Revision 1.4  1998/04/16 16:53:01  simon
 *  Added code so tape point will follow you around on the background
 *
 *  Revision 1.3  1998/04/03 09:46:38  simon
 *  minor change to get lock to closest point to work on failed intersect
 *
 *  Revision 1.2  1998/04/01 12:27:40  simon
 *  Added stuff for mindist
 *
 *  Revision 1.1  1998/03/30 10:39:24  simon
 *  Added min-dist functionality
 *
 *  Revision 1.2  1998/03/19 15:55:29  simon
 *  stuff for distance tool, and stuff to get around (hopefully) temporary
 *  problem of attribute interest.
 *
 *  Revision 1.1  1998/03/17 11:01:57  simon
 *  the dvise side of the distance tool
 *
 *
 ****************************************************************************
 *
 *  Copyright (c) 1998 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 * This  document  may  not, in  whole  or in  part, be  copied,  photocopied,
 * reproduced,  translated,  or  reduced to any  electronic  medium or machine
 * readable form without prior written consent from Division Ltd.
 *
 ****************************************************************************/

#ifndef __DISTANCEUTILITIES_H__
#define __DISTANCEUTILITIES_H__

#include "distance.h"

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

/* verbose flags */
#define DCI_VERBOSE 0x1000
#define GENERAL_VERBOSE 0x2000

/* this is the percentage of the screen that counts as a valid selection 
 * when selecting a point with the mouse
 */
#define ECDIST_MINMOUSEDISTPERC 5

/* currently will always be 1, but in the future specifies the max number of assemblies
 * a locking vector intersect can intersect in its attempt to find the one cloest to the
 * mouse */
#define ECDIST_MAXINTERSECT 100
/* defines the body part from which the 2d mouse sensor can be found */
#define ECDIST_SENSORBODYPART "head"

/* 
 * this is an object that will monitor the mouse pointer on the screen, fire intersects out
 * from it, and return the position, and assembly hit.  It can do this continously i.e. as
 * the mouse moves intersects are continuously fired, or one at a time.  An obvious 
 * pre-requisit for its use is a 2d mouse must exist
 */
typedef struct ECAutoUpdateDistT ECAutoUpdateDistT;
/* the structure for the callback when an object is intersected */
typedef int ECAutoUpdateDistCallBack(ECAutoUpdateDistT *update, void *callData);

/*
 * this is an object that given 2 lists of assemblies will callback with the 2 points that
 * define the minimum distance between the assembly lists
 */
typedef struct ECDistMinDistT ECDistMinDistT;
/* callback structure in which the minimum distance info will be returned */
typedef void ECDistMinDistDistanceCallBack(ECDistMinDistT *minDist, ECAssembly *assemblyA, dmPoint pointA, 
                                                ECAssembly *assemblyB, dmPoint pointB, void *distanceCd);
/* callback structure in which the minimum distance calculation status will be returned */
typedef void ECDistMinDistProgressCallBack(ECDistMinDistT *minDist, float32 progress, void *progressCd);

/*
 * this is an object that given a 2 points on 2 entities will find the point
 * on an object that is closest to the second given point, and which is along the cordinate
 * axes of the first given point
 */
typedef struct ECDistLockT ECDistLockT;
/* the callback structure from witch the closest point can be extracted */
typedef void ECDistLockCallback(ECDistLockT *lock, void *callData);

/*
 * this is an object that given a list of distance assemblies, and a mouse position on the screen
 * can find the point on the tape of a distance assembly that is closest to the mouse pointer, 
 * up to a max of ECDIST_MINMOUSEDISTPERC
 */
typedef struct ECDistClosestPointT ECDistClosestPointT;

/* creates an object for the given body.  The body part should have the mouse sensor 
 * hanging off it.  Set useLocalPoints if you want the point returned in local coordinates */
DV_EXPORT ECAutoUpdateDistT *ECAutoUpdateDist_Create(VCBody *body, char *bodyPartName, int useLocalPoints,
                                                     ECAutoUpdateDistCallBack *succeedCallBack, 
                                                     ECAutoUpdateDistCallBack *failCallBack,
                                                     void *callData);
/* activates the continuous vector intersects from mouse pointer, requires the
 * sensor too have been activated first */
DV_EXPORT void ECAutoUpdateDist_Activate(ECAutoUpdateDistT *update);
/* stops continous vector intersects from mouse */
DV_EXPORT void ECAutoUpdateDist_Deactivate(ECAutoUpdateDistT *update);
/* starts monitoring mouse position on the screen */
DV_EXPORT void ECAutoUpdateDist_ActivateSensor(ECAutoUpdateDistT *update);
/* stops monitoring mouse position */
DV_EXPORT void ECAutoUpdateDist_DeactivateSensor(ECAutoUpdateDistT *update);
/* gets the currently intersected assembly - meaningful from within the updatecallback */
DV_EXPORT ECAssembly *ECAutoUpdateDist_GetCurrentAssembly(ECAutoUpdateDistT *update);
/* fires a single intersection from the mouse pointer, requires sensor to be active,
 will callback on success or failure*/
DV_EXPORT int ECAutoUpdateDist_FireSingeIntersect(ECAutoUpdateDistT *update, 
                                    ECAutoUpdateDistCallBack *succeedCallBack,
                                    ECAutoUpdateDistCallBack *failCallBack,
                                    void *callData);
/* fires a single intersection from the position as a fraction accross the screen (mouseX, mouseY), 
   will callback on success or failure*/
DV_EXPORT int ECAutoUpdateDist_FireSingeIntersectFromPos(ECAutoUpdateDistT *update, 
                                    float32 mouseX, float32 mouseY,                    
                                    ECAutoUpdateDistCallBack *succeedCallBack,
                                    ECAutoUpdateDistCallBack *failCallBack,
                                    void *callData);
/* get the (0..1, 0..1) position of the mouse in the visual window */
DV_EXPORT void ECAutoUpdateDist_GetMouseScreenPosition(ECAutoUpdateDistT *update, dmPoint pos);
/* get the currently intersected point - meaningful from within the update callback */
DV_EXPORT void ECAutoUpdateDist_GetCurrentPoint(ECAutoUpdateDistT *update, dmPoint interPos);

/* creates a distlock structure for the given limb, and its vis attribute, this is required
 * to make the limb unintersectable */
DV_EXPORT ECDistLockT *ECDistLock_Create(VCEntity *limb,VCAttribute *visAttr, 
                               ECDistLockCallback *callBack, void *callData);
/* find the position as specified in object description using the global coordiates scheme */
DV_EXPORT void ECDistLock_FindGlobal(ECDistLockT *lock, VCEntity *fromEntity, dmPoint fromPoint,
                      VCEntity *toEntity, dmPoint toPoint);
/* find the position as specified in object description using the fromEntity local coordiates scheme */
DV_EXPORT void ECDistLock_FindLocal(ECDistLockT *lock, VCEntity *fromEntity, dmPoint fromPoint,
                                    VCEntity *toEntity, dmPoint toPoint);
/* returns the entity intersected - meaningful from within the dist lock callback */
DV_EXPORT VCEntity *ECDistLock_GetIntersectedEntity(ECDistLockT *lock);
/* returns the entity intersected - meaningful from within the dist lock callback */
DV_EXPORT void ECDistLock_GetIntersectionPoint(ECDistLockT *lock, dmPoint pos);

/* create a closest point object.  visEntity should be the entity from which the screen visual view
 * resource in visView can be found */
DV_EXPORT ECDistClosestPointT *ECDistClosestPoint_Create(VCEntity *visEntity,  VCVisualViewResource *visView);
/* no callback needed returns the best tape in bestAss, and the best point on that tape as the
 * return value, if numPoints also returns numPoints in existance, if useMinMouseDist then 
 points > ECDIST_MINMOUSEDISTPERC of screen away will not be considered */
DV_EXPORT int ECDistClosestPoint_FindClosestPoint(ECDistClosestPointT *closest, ECItem *assList, 
                                  dmPoint mouseScreenPos, ECDistance **bestAss,  int *numPoints,
                                  int includeCircleCentres, int useMinMouseDist);
/* find the global point in the same x,y as mouse pointer, and z as oldPos relative to "eyes" */
DV_EXPORT int ECDistClosestPoint_FindAtMousePosition(ECDistClosestPointT *closest, dmPoint mouseScreenPos,
                                       dmPoint oldPos, dmPoint newPos);

/* creates a min dist object */
DV_EXPORT ECDistMinDistT *ECDistMinDist_Create(ECDistMinDistDistanceCallBack *distanceCb, void *distanceCd,
                                               ECDistMinDistProgressCallBack *progressCb, void *progressCd);
/* starts calculating the min dist between assembly lists, will callback with distanceCb when it is done */
DV_EXPORT int ECDistMinDist_BetweenTwoAssemblies(ECDistMinDistT *minDist, ECItem *assListA, ECItem *assListB);
/* resets it i.e. stops any calculations currently happening */
DV_EXPORT int ECDistMinDist_Reset(ECDistMinDistT *minDist);

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif
#endif /* __DISTANCEUTILITIES_H__ */

