/*
 *    PROJECT:      DVS
 *    SUBSYSTEM:    collide
 *    MODULE:       callback.h
 *
 *    File:         $RCSfile: ducallback.h,v $
 *    Revision:     $Revision: 1.3 $
 *    Date:         $Date: 2000/04/01 09:30:36 $
 *    Author:       $Author: john $
 *    RCS Ident:    $Id: ducallback.h,v 1.3 2000/04/01 09:30:36 john Exp $
 *
 *    FUNCTION:
 * provide classes to manage C++ callback functionality
 *
 *
 * Copyright (c) 1998 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _CALLBACK_H
#define _CALLBACK_H

#include <list.h>

template <class ClassCalled, class Argument>
class duCallback
{
public:
        //define a type forptr to member function 
        //of 'ClassCalled' that takes an 'Argument' argument
        //& returns void.
    typedef void (ClassCalled::*ptrToMemberFunc)(Argument);
    
private:
bool                active;
    bool                delayedRm;
    ClassCalled        *pc;
    ptrToMemberFunc     pmf; //xfunc to call back
    
public:
// This needs to be here to keep windows happy
    inline duCallback(ClassCalled *x, ptrToMemberFunc xmf) :active(false),delayedRm(false),pc(x),pmf(xmf){};
    duCallback(const duCallback &);
    bool   needsRemoval(void) const;
    void markForRemoval(void);
    void           call(Argument);

    bool      refsClass(ClassCalled *x);
};
  
    
//
// the basic callback list. 
// Is really just a basic STL list of callback items, 
// with some safety features to cope with adding to and
// deleting from a list that is being traversed.
// recursive calls to the same callback node are also trapped.

template <class ClassCalled, class Argument>
class duCallbackList
{
public:
    /*
     * member types
     */
    typedef duCallback<ClassCalled,Argument> cbNode;
    typedef typename cbNode::ptrToMemberFunc ptrToMemberFunc;
    typedef list<cbNode>      cbList;
    typedef typename cbList::iterator        iterator;
    
private:
    bool   inUse;
    bool   delayedRm;
    cbList delayedAdd;
    cbList callbacks;

public:
        //TODO: do we need specific copy constructor???
             duCallbackList();
    void              flush(void);
    iterator    addCallback(ClassCalled *c, ptrToMemberFunc pmf);
    void     removeCallback(iterator &);
    void     removeReferencingCallbacks(ClassCalled *c);

        // Also checks for any delayed adds & Rms that are needed.
    void      callCallbacks(Argument a);
    bool              empty(void);
    
};

/*
 * From here on its just defs of member functions.
 */

template <class ClassCalled, class Argument>
inline
duCallback<ClassCalled,Argument>::duCallback(const duCallback &x)
                   :active(false),delayedRm(false),pc(x.pc),pmf(x.pmf){}

template <class ClassCalled, class Argument>
inline bool
duCallback<ClassCalled,Argument>::needsRemoval(void) const
{
    return delayedRm;
}

template <class ClassCalled, class Argument>
inline void
duCallback<ClassCalled,Argument>::markForRemoval(void)
{
    delayedRm = true;
}

template <class ClassCalled, class Argument>
inline void
duCallback<ClassCalled,Argument>::call( Argument a)
{
    if(active){
//TODO - implement the throw properly
        ;// throw some error
    }
    active = true;
    (pc->*pmf)(a);
    active = false;
}

template <class ClassCalled, class Argument>
inline    bool
duCallback<ClassCalled,Argument>::refsClass(ClassCalled *c)
{
    return (c == pc);
}

//member funcs for duCallbackList
template <class ClassCalled, class Argument>
inline
duCallbackList<ClassCalled, Argument>::duCallbackList()
        :inUse(false),
         delayedRm(false)
{}

template <class ClassCalled, class Argument>
inline void
duCallbackList<ClassCalled, Argument>::flush(void)
{
    if(inUse) {
        iterator y    = callbacks.begin();
        iterator last = callbacks.end();
        while( y != last) {
            (*y).markForRemoval();
            y++;
        }
    }
    else
        callbacks.erase(callbacks.begin(),callbacks.end());
    
    delayedAdd.erase(delayedAdd.begin(),delayedAdd.end());
}

template <class ClassCalled, class Argument>
inline typename duCallbackList<ClassCalled, Argument>::iterator
duCallbackList<ClassCalled, Argument>::addCallback(ClassCalled *c, ptrToMemberFunc pmf)
{
    cbNode cb(c,pmf);
    
    if(inUse) {
        delayedAdd.push_back(cb);
        return (--delayedAdd.end());
    }
    else {
        callbacks.push_back(cb);
        return (--callbacks.end());
    }
}

template <class ClassCalled, class Argument>
inline void
duCallbackList<ClassCalled, Argument>::removeCallback(iterator &x)
{
    if (inUse){
        delayedRm       = true;
        (*x).markForRemoval();
    }
    else
        callbacks.erase(x);
}

template <class ClassCalled, class Argument>
inline void
duCallbackList<ClassCalled, Argument>::removeReferencingCallbacks(ClassCalled *c)
{
    if ( inUse) {
        delayedRm  = true;
      
        iterator i = callbacks.begin();
        iterator last = callbacks.end();
        while ( i != last) {
            if ( (*i).refsClass(c)) {
                (*i).markForRemoval();
            }
            i++;
        }
    }
    else {
        iterator i    = callbacks.begin();
        iterator last = callbacks.end();
        while ( i != last) {
            if ( (*i).refsClass(c)) {
                iterator tmp =i;
                i++;
                callbacks.erase(tmp);
            }
            else
                i++;
        }
    }
}



template <class ClassCalled, class Argument>
inline void
duCallbackList<ClassCalled, Argument>::callCallbacks(Argument a)
{
    inUse = true;
    iterator y    = callbacks.begin();
    iterator last = callbacks.end();

    while( y != last) {
        (*y).call(a);
        y++;
    }
    inUse = false;
    
        // do delayed adds
    callbacks.splice(callbacks.end(), delayedAdd);
        //assert (delayedAdd.empty());
    
        // do delayed removes.
    if(delayedRm) {
            //would like to use 'remove_if()'
            //- but get 'internal compiler error' messages
        iterator first = callbacks.begin();
        iterator last  = callbacks.end();
        while (first != last) {
            iterator next = first;
            ++next;
            if ((*first).needsRemoval())
                callbacks.erase(first);
            first = next;
        }
        delayedRm = false;   
    }
}

template <class ClassCalled, class Argument>
inline bool 
duCallbackList<ClassCalled, Argument>::empty(void)
{
    return callbacks.empty();
}

#endif /*_CALLBACK_H */
