/****************************************************************************
 *
 *  			Copyright 1998 Division Ltd.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: queryparser.h,v $
 *  Revision      : $Revision: 1.13 $
 *  Date          : $Date: 1999/08/26 12:45:35 $
 *  Author        : $Author: jeff $
 *  Created       : Wed Apr 29 14:23:31 1998
 *  Last Modified : <130898.1618>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 *  $Log: queryparser.h,v $
 *  Revision 1.13  1999/08/26 12:45:35  jeff
 *  moved all #include lines out of extern C blocks. I hope.
 *
 *  Revision 1.12  1999/02/11 17:54:41  john
 *  uses new dvexport file for declspec stuff on windows
 *  added lots of C++/Smart pointer things
 *
 *  Revision 1.11  1998/08/13 17:11:16  simon
 *  Added function.
 *
 *  Revision 1.10  1998/06/04 16:29:45  simon
 *  *** empty log message ***
 *
 *  Revision 1.9  1998/05/29 15:52:34  simon
 *  *** empty log message ***
 *
 *  Revision 1.8  1998/05/27 17:06:15  simon
 *  *** empty log message ***
 *
 *  Revision 1.7  1998/05/21 17:05:03  simon
 *  *** empty log message ***
 *
 *  Revision 1.6  1998/05/15 15:55:23  simon
 *  *** empty log message ***
 *
 *  Revision 1.5  1998/05/14 17:00:45  simon
 *  *** empty log message ***
 *
 *  Revision 1.4  1998/05/11 17:03:37  simon
 *  *** empty log message ***
 *
 *  Revision 1.4  1998/05/08 15:50:17  simon
 *  *** empty log message ***
 *
 *  Revision 1.3  1998/05/07 13:42:06  simon
 *  *** empty log message ***
 *
 *  Revision 1.2  1998/05/01 15:45:55  simon
 *  *** empty log message ***
 *
 *  Revision 1.1  1998/04/29 17:37:29  simon
 *  New assembly query code - not being built yet.
 *
 *
 ****************************************************************************
 *
 *  Copyright (c) 1998 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 * This  document  may  not, in  whole  or in  part, be  copied,  photocopied,
 * reproduced,  translated,  or  reduced to any  electronic  medium or machine
 * readable form without prior written consent from Division Ltd.
 *
 ****************************************************************************/

#ifndef __QUERYPARSER_H
#define __QUERYPARSER_H

#include "dvexport.h"
#include "queryrules.h"

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

struct QueryLine;
typedef struct QueryLine QueryLine;

struct Query;
typedef struct Query Query;

/* The one and only set of query rules */
DV_EXPORT extern QueryRules *Rules;

/* some useful pre-defined token sets */
DV_EXPORT extern QueryParseToken NullStatement[];
DV_EXPORT extern QueryParseToken AndandOrTokens[];
DV_EXPORT extern QueryParseToken DataTokens[];
DV_EXPORT extern QueryParseToken EndTokens[];
DV_EXPORT extern QueryParseToken NotEndTokens[];
DV_EXPORT extern QueryParseToken ExtendTokens[];


/* sets up, and creates the query parser */
DV_EXPORT void QueryParser_Setup(void);

DV_EXPORT Query *Query_Create(void);
DV_EXPORT int Query_Delete(Query **query);
/* removes all lines from query */
DV_EXPORT int Query_Reset(Query *query);
/* gets the name of the query - this is not in the string version of the query */
DV_EXPORT char *Query_GetName(Query *query);
/* sets the name of the query */
DV_EXPORT int Query_SetName(Query *query, char *name);
/* returns and identical query */
DV_EXPORT Query *Query_Copy(Query *query);
/* turns the query into a space separted string (name is not part of string) */
DV_EXPORT char *Query_ToString(Query *query, char *seperator);
/* turns query into a seperator seperated string with spaces in tokens, for
 * human reading only, as the string produced cannot be parsed */
DV_EXPORT char *Query_ToSpacedString(Query *query, char *seperator);
/* gets the first line in the list */
DV_EXPORT QueryLine *Query_GetLineList(Query *query);
/* adds the new line to the end of the list of lines */
DV_EXPORT int Query_AddLine(Query *query, QueryLine *newLine);
/* inserts a line after previous line, which must be a line in the query */
DV_EXPORT int Query_InsertLine(Query *query, QueryLine *newLine, QueryLine *previousLine);
/* overwrites overwrite line with new line, deletes overwrite line */
DV_EXPORT int Query_OverwriteLine(Query *query, QueryLine *newLine, QueryLine **overwriteLine);
/* deletes the line given from the query */
DV_EXPORT int Query_DeleteLine(Query *query, QueryLine **deleteLine);
/* sets query to contain string
 * returns VC_OK on success, on VC_ERR only the correct part of the
 * query will be returned in query. Remaining part of string is returned in string */
DV_EXPORT int Query_FromString(Query *query, char **string, char seperator, 
                               QueryRules *rules);
/* returns true if all the lines in the query are complete, and the query has at
 * least one line */
DV_EXPORT int Query_IsComplete(Query *query);
/* get the number of lines */
DV_EXPORT int Query_GetNumLines(Query *query);

DV_EXPORT QueryLine *QueryLine_Create(void);
/* re-initialises line to just created state */
DV_EXPORT int QueryLine_Reset(QueryLine *line);
DV_EXPORT int QueryLine_Delete(QueryLine **line);
/* turns the query line into a seperator seperated string */
DV_EXPORT char *QueryLine_ToString(QueryLine *line, char *seperator);
/* copys the query line */
DV_EXPORT QueryLine *QueryLine_Copy(QueryLine *original);
/* turns the given section of the queryline int a string, a value of
 * -1 for tooTokenNum means too the end of the line, if addSeperator then end
 * of line And, or Or will be added if appropriate*/
DV_EXPORT char *QueryLine_SectionToString(QueryLine *line, char *seperator, 
                                          int fromTokenNum, int tooTokenNum, int addSeperator);
/* turns query line into a seperator seperated string with spaces in tokens, for
 * human reading only, as the string produced cannot be parsed */
DV_EXPORT char *QueryLine_ToSpacedString(QueryLine *line, char *seperator);
/* as SectionToString, but with spaces in tokens, the produced string cannot be parsed,
 * and is for human reading only */
DV_EXPORT char *QueryLine_SectionToSpacedString(QueryLine *line, char *seperator, 
                          int fromTokenNum, int tooTokenNum, int addSeperator);
/* parses string into a query line, returns VC_OK on success, on VC_ERR only the 
 * correct part of the query will be returned in query.
 * remaining part of string is returned in string */
DV_EXPORT int QueryLine_FromString(QueryLine *line, char **string, char seperator, 
                                   QueryRules *rules);
/* gets the next query line from the current one */
DV_EXPORT QueryLine *QueryLine_GetNext(QueryLine *line);
/* sets the next query line */
DV_EXPORT int QueryLine_SetNext(QueryLine *line, QueryLine *nextLine);
/* adds the given token to the end of the line data should be ptr.  It will be
 * copied in the function */
DV_EXPORT int QueryLine_AddToken(QueryLine *line, QueryParseToken token, void *data);
/* sets the token at tokennum in the line to the one given. */
DV_EXPORT int QueryLine_SetToken(QueryLine *line, int tokenNum, QueryParseToken token, void *data);
/* checks line to see if it is valid, if not line is shortened until it is valid */
DV_EXPORT int QueryLine_MakeValid(QueryLine *line, QueryRules *rules);
/* valid connectors are qAnd, qOr, qEND */
DV_EXPORT int QueryLine_SetConnector(QueryLine *line, QueryParseToken connector);
DV_EXPORT QueryParseToken QueryLine_GetConnector(QueryLine *line);
/* gets the statement for this line, without the connector */
DV_EXPORT QueryParseToken *QueryLine_GetStatement(QueryLine *line);
/* gets the token at statement[number] */
DV_EXPORT QueryParseToken QueryLine_GetTokenForTokenNumber(QueryLine *line, int number);
/* gets the data at statement[number] */
DV_EXPORT void *QueryLine_GetDataForTokenNumber(QueryLine *line, int number);
/* gets the length of the statement in the query line */
DV_EXPORT int QueryLine_GetLength(QueryLine *line);
/* compares the two line's, except for seperators, returns TRUE if they are identical */
DV_EXPORT int QueryLine_Compare(QueryLine *line1, QueryLine *line2);
/* checks if a line is complete, i.e. end's with a qEND */
DV_EXPORT int QueryLine_IsComplete(QueryLine *line);

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif
#endif /* __QUERYPARSER_H */
