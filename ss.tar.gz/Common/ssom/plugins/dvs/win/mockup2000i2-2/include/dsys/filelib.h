/****************************************************************************
 *
 *  			Copyright 1995 Division Limited.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: filelib.h,v $
 *  Revision      : $Revision: 1.2 $
 *  Date          : $Date: 1999/05/12 16:38:16 $
 *  Author        : $Author: bill $
 *  Last Modified : <120599.1602>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 ****************************************************************************
 *
 *  Copyright (c) 1995 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 *  This Document may not, in whole or in part, be copied,
 *  photocopied, reproduced, translated, or reduced to any
 *  electronic medium or machine readable form without prior
 *  written consent from Division Ltd.
 ****************************************************************************/

#ifndef __FILELIB_H__
#define __FILELIB_H__

#ifndef DPG_EXPORT
#if defined(_WIN32) && !defined(_WINDU_SOURCE) && !defined(__EPP__) && !defined(BUILD_STATIC)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `extern'
 */
#if defined _LIB_DIVU
#define DPG_EXPORT __declspec(dllexport) extern 
#else
#define DPG_EXPORT __declspec(dllimport) extern 
#endif 
#else
#define DPG_EXPORT  extern
#endif
#endif

#include <dsys/divtypes.h>
#include "pgeneral.h"

#ifdef __cplusplus
extern "C" {
#endif
    
/*****************************************************************************/
/* filelib error numbers */
#define dflENO_READ   0x2001
#define dflENO_WRITE  0x2002
#define dflENO_CPATH  0x2003
#define dflENO_CNAME  0x2004
#define dflENO_PERMIT 0x2005
#define dflENO_DIR    0x2006
#define dflENO_RMFILE 0x2007
#define dflENO_RMDIR  0x2008
#define dflENO_USAGE  0x2009

#define dfl_STDIN_NAME  "stdin"
#define dfl_STDOUT_NAME "stdout"

#define dfl_SET_TO_LITTLE  0
#define dfl_SET_TO_BIG     1

#define dflPATHDIV    '/'
#define dflREPPATHDIV '\\'

#ifndef _UNIX
#define dflDRIVEDIV ':'
#endif

/****************************************************************************
 * File reading and writing routines.
 */
   
typedef struct dflFILETYPE
{
    char  *name ;
    FILE  *fp ;
    int32  endian ;
#ifdef __dfl_BUFFERING
    char *buf, *bufEnd;
    int32 remain ;
    int32 filePos, endPos ;
#endif
} dflFILE, *dflFILEPTR ;

#define dfl_BUFFER_SIZE 8192

DPG_EXPORT void
dflSetEndian(dflFILEPTR file, int32 OutEndian) ;
DPG_EXPORT dflFILEPTR
dflOpen(char *name, char *mode, int32 OutEndian) ;
DPG_EXPORT int32
dflClose(dflFILEPTR file) ;

/****************************************************************************
 * File reading routines
 */
#ifdef __dfl_BUFFERING
DPG_EXPORT int32
dflSeek(dflFILEPTR fl, int32 offset, int32 whence) ;
DPG_EXPORT int32
dflUngetc(char c, dflFILEPTR fl);
DPG_EXPORT int32
_dflGetc(dflFILEPTR fl) ;
DPG_EXPORT int32
_dflRead(void *ptr, int32 size, dflFILEPTR fl) ;

#define dflTell(fl)    ((fl)->filePos - (fl)->remain)
#define dflGetc(fl)                                               \
    (((fl)->remain) ?                                             \
        ((int32) *((fl)->bufEnd - ((fl)->remain)--))           :  \
        _dflGetc(fl))
#define dflRead(ptr,size,fl)                                      \
    (((fl)->remain >= (size))  ?                                  \
        ( memcpy((ptr),((fl)->bufEnd - (fl)->remain),(size)) ,    \
          (fl)->remain -= (size), (int32) dpgSUCCESS)          :  \
        _dflRead(ptr,size,fl))

#define dflError(fl)  ((int32) ferror(fl->fp))


DPG_EXPORT int32
dflRead1byte(dflFILEPTR fl, void *dest) ;
DPG_EXPORT int32
dflReadn1byte(dflFILEPTR fl, int32 n, void *dest) ;
DPG_EXPORT int32
dflRead2byte(dflFILEPTR fl, void *dest) ;
DPG_EXPORT int32
dflReadn2byte(dflFILEPTR fl, int32 n, void *dest) ;
DPG_EXPORT int32
dflRead4byte(dflFILEPTR fl, void *dest) ;
DPG_EXPORT int32
dflReadn4byte(dflFILEPTR fl, int32 n, void *dest) ;
DPG_EXPORT int32
dflRead8byte(dflFILEPTR fl, void *dest) ;
DPG_EXPORT int32
dflReadn8byte(dflFILEPTR fl, int32 n, void *dest) ;
#else

#define dflSeek(fl,offset,whence) fseek((fl)->fp,offset,whence)
#define dflTell(fl)               ((int32) ftell((fl)->fp))
#define dflUngetc(c,fl)           ungetc(c,(fl)->fp)
#define dflGetc(fl)               getc((fl)->fp)
#define dflRead(ptr,size,fl)      ((fread(ptr,1,size,(fl)->fp) == size) ? \
                                       dpgSUCCESS:dpgERROR)
#define dflError(fl)              ((int32) ferror((fl)->fp))

#define dflRead1byte(fl,dest)     dflRead(dest,1,fl)
#define dflReadn1byte(fl,n,dest)  dflRead(dest,n,fl)
DPG_EXPORT int32
dflRead2byte(dflFILEPTR fl, void *dest) ;
DPG_EXPORT int32
dflReadn2byte(dflFILEPTR fl, int32 n, void *dest) ;
DPG_EXPORT int32
dflRead4byte(dflFILEPTR fl, void *dest) ;
DPG_EXPORT int32
dflReadn4byte(dflFILEPTR fl, int32 n, void *dest) ;
DPG_EXPORT int32
dflRead8byte(dflFILEPTR fl, void *dest) ;
DPG_EXPORT int32
dflReadn8byte(dflFILEPTR fl, int32 n, void *dest) ;

#endif

/****************************************************************************
 * File writing routines
 */

DPG_EXPORT void
dflWriteint8(dflFILEPTR fl, int8 i) ;
DPG_EXPORT void
dflWriteuint8(dflFILEPTR fl, uint8 i) ;
DPG_EXPORT void
dflWriteint16(dflFILEPTR fl, int16 i) ;
DPG_EXPORT void
dflWriteuint16(dflFILEPTR fl, uint16 i) ;
DPG_EXPORT void
dflWriteint32(dflFILEPTR fl, int32 i) ;
DPG_EXPORT void
dflWritefloat32(dflFILEPTR fl, float32 f) ;
DPG_EXPORT void
dflWritefloat64(dflFILEPTR fl, float64 f) ;
DPG_EXPORT void
dflWritestr(dflFILEPTR fl, void *source, int32 size) ;


/***************************************************************************
 * File name manipulation routines
 *
 * Major re-write on 11/2/95 due to the introduction of material files. This
 * led to the need of hierarchical break down of files from all geometry
 * converters (i.e. dxf2vdi). As they all use the same structure the routines
 * have been placed into this library.
 */
/*****************************************************************************
* PLEASE NOTE:- These file name manipulation routines expect unix style      *
*               names, even on dos, a simple call to dflFormatName should    *
*               solve any potential problems.                                *
*****************************************************************************/

/****************************************************************************
 * dflFormatName
 * 
 * Converts all file names to unix style, i.e. all '\\' to '/'
 * Should be called for every file name!
 */
DPG_EXPORT void
dflFormatName(char *name) ;

/****************************************************************************
 * dflSplitName - splits the given file name into is 3 constituent parts.
 * If path, body or ext are NULL, no problems, that part isn't done.
 * returns dymanically allocated strings, the path will have the closing
 * '/' and neither the body ext will have the dividing '.'
 */
DPG_EXPORT void
dflSplitName(char *FName, char **path, char **body, char **ext) ;

/*****************************************************************************
 * dflComposeName - Opposite to SplitName, i.e. given the 3 parts, it joins 
 * them together. Any of them can be NULL. If the body starts with a '/' then
 * the path is ignored. if the path doesnt end with a '/' then one is inserted
 * if the extension is NULL or "" then no '.' is inserted at the end of body.
 */
DPG_EXPORT char *
dflComposeName(char *path, char *body, char *ext) ;

/****************************************************************************
 * dflCreateName - same as dflComposeName, only excepts 3 paths and joins 
 * them together, any can be NULL.
 */
DPG_EXPORT char *
dflCreateName(char *basePath, char *midPath, char *extPath, 
              char *base, char *ext) ;

/***************************************************************************
 * dflBackupName - Checks for existance of the file 'filename', if it exists,
 * it creates a backup filename 'BackName' by either inserting the 
 * "division.sav" directory into the path, or if the environment variable
 * ${division.sav} is set then it is asumed to be the absolute output path
 * and the base name of 'filename' is appended. If the file 'BackName' exists
 * then it is removed, and 'filename' is moved to 'BackName'.
 * 
 * Returns -1 if an error occured or the number of paths created.
 * 'BackName is a dynamically allocated string which must be freed be the
 * user
 */
DPG_EXPORT int32
dflBackupName(char *filename, char **Backup) ;

/****************************************************************************
 * dflRemoveBackup - removes everything generated from a call to dflBackupName
 * Requires the return value to determine how many directories are to be 
 * removed. If backing up 2 or more files it is important to Remove the backup 
 * in an reversed order, soley because the first one will have created any 
 * required directies and its return value will be non zero, these directies 
 * can only be removed after all the the backup files have been removed.
 * returns dpgERROR if failed to remove something, else returns dpgSUCCESS
 */
DPG_EXPORT int32
dflRemoveBackup(char *backName, int32 noDirs) ;

/****************************************************************************
 * dflTempName - Creates a temporary file name based on the given file name.
 * returns NULL on failure, dynamically allocated string otherwise.
 */
DPG_EXPORT char *
dflTempName(char *fname) ;

/* extFlag types
 * Use flags appropriate for the file type, other flags are ignored. 
 */
#define dflNAME_BINARY  0x01
#define dflNAME_ASCII   0x02
#define dflNAME_LIBRARY 0x04
#define dflNAME_V1      0x08
#define dflNAME_V2      0x10
DPG_EXPORT char *
dflCreateVtxName(char *basePath, int32 useMid, char *extPath, char *base) ;
DPG_EXPORT char *
dflCreateBgfName(char *basePath, int32 useMid, char *extPath, char *base,
                 int32 extFlag) ;
DPG_EXPORT char *
dflCreateBmfName(char *basePath, int32 useMid, char *extPath, char *base,
                 int32 extFlag) ;
DPG_EXPORT char *
dflCreateVdiName(char *basePath, int32 useMid, char *extPath, char *base,
                 int32 extFlag) ;
DPG_EXPORT char *
dflCreateOLName(char *basePath, int32 useMid, char *extPath, char *base,
                int32 extFlag) ;
DPG_EXPORT char *
dflCreateEDName(char *basePath, int32 useMid, char *extPath, char *base) ;
DPG_EXPORT char *
dflCreateDrawingName(char *basePath, int32 useMid, char *extPath,
                     char *base, char *extName) ;

/**************************************************************************
 * Create Path
 * creates a single path given the path string, last path must terminate in
 * a '/' else it will not be tested for.
 * If prompt is non-zero, the user is prompted using stdin/stdout, if user
 * enters n or N the function fails.
 * 
 * Return -1 on an error (dpgERROR), else the number of directories created.
 */
DPG_EXPORT int32
dflCreatePath(char *path, int32 prompt) ;
/**************************************************************************
 * dflCreatePaths - Sets up the division path structure given the base and
 * extended paths and whether to use mid paths, all required
 * paths are created, which includes material, geometry, texture, vdifiles 
 * and the vdi library path.
 */
DPG_EXPORT int32
dflCreatePaths(char *basePath, int32 useMid, char *extPath) ;

/************************************************************************
 * dflCreateBaseName
 * creates a base name (bit between the path and the extension) ready
 * for a Compose or CreateName. if the numb is less than zero, it is 
 * ignored, if dosName is non-zero then the output name will be no long
 * than 8 chars.
 */
DPG_EXPORT char *
dflCreateBaseName(char *base, int32 numb, int32 dosName) ;

DPG_EXPORT char *
dflCorrectFileName(char *oldName) ;

DPG_EXPORT void
dflVersion(FILE *fp) ;


#define byte8_flip(p) do { \
    char ___t; \
    ___t=p[0]; \
    p[0]=p[7]; \
    p[7]=___t; \
    ___t=p[1]; \
    p[1]=p[6]; \
    p[6]=___t; \
    ___t=p[2]; \
    p[2]=p[5]; \
    p[5]=___t; \
    ___t=p[3]; \
    p[3]=p[4]; \
    p[4]=___t; \
} while (0)

#define byte4_flip(p) do { \
    char ___t; \
    ___t=p[0]; \
    p[0]=p[3]; \
    p[3]=___t; \
    ___t=p[1]; \
    p[1]=p[2]; \
    p[2]=___t; \
} while (0)

#define byte2_flip(p) do { \
    char ___t; \
    ___t=p[0]; \
    p[0]=p[1]; \
    p[1]=___t; \
} while (0)


#ifdef __cplusplus
}
#endif

#endif /* __FILELIB_H__ */

