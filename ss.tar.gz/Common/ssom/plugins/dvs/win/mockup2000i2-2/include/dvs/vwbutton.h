/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: vwbutton.h,v $
 *    Revision:     $Revision: 1.10 $
 *    Date:         $Date: 1998/08/10 14:50:59 $
 *    Author:       $Author: simon $
 *    RCS Ident:    $Id: vwbutton.h,v 1.10 1998/08/10 14:50:59 simon Exp $
 *
 *    FUNCTION: Button public function prototypes.
 *
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _Button_H
#define _Button_H
#ifdef __cplusplus
extern "C" {
#endif

/* PUBLIC FUNCTIONS ======================================*/
VW_EXPORT VWidget *VWButton_CreateManaged(VWidget *parent, char *name, VWArg wargs[], int nargs);
VW_EXPORT VWidget *VWButton_Create(VWidget *parent, char *name, VWArg wargs[], int nargs);

VW_EXPORT void VWButton_Highlight(VWidget *button);
VW_EXPORT void VWButton_Unhighlight(VWidget *button);
VW_EXPORT void VWButton_Activate(VWidget *button, VWEventInfo *info);
VW_EXPORT int VWButton_ForceDrop(VWidget *ButtonWig);
VW_EXPORT void VWButton_Pick(VWidget *ButtonWig, VCBody *body, VCAttribute *vc_bodyPartAttr);
VW_EXPORT void VWButton_Drop(VWidget *ButtonWig, VCBody *body, VCAttribute *vc_bodyPartAttr);
VW_EXPORT void VWButton_DropAny(VCBody *body, VCAttribute *vc_bodyPartAttr);
VW_EXPORT void VWButton_GetCurrentUser(VWidget *ButtonWig, VCBody **body, VCAttribute **vc_bodyPartAttr);

/*
 * Visual Functions
 */
VW_EXPORT void VWButton_SetBaseVisual(VWidget *button, char *geometryFile);
VW_EXPORT void VWButton_SetBaseMaterial(VWidget *button, char *materialName);
VW_EXPORT void VWButton_SetBaseHighlightVisual(VWidget *button, char *geometryFile);
VW_EXPORT void VWButton_SetBaseHighlightMaterial(VWidget *button, char *materialName);
VW_EXPORT void VWButton_SetIconVisual(VWidget *button, char *iconGeom);
VW_EXPORT void VWButton_SetIconMaterial(VWidget *button, char *iconMaterial);
VW_EXPORT void VWButton_SetIconVisualAttribute(VWidget *button, VCAttribute *visAttribute);
VW_EXPORT void VWButton_SetBaseMaterials(VWidget *button, char *widgetMaterial, char *highlightMaterial);
VW_EXPORT void VWButton_SetBaseVisuals(VWidget *button, char *widgetGeom, char *highlightGeom);

/*
 * Button Audio Functions.
 */
VW_EXPORT void VWButton_SetActivateAudio(VWidget *buttonWig, char *audioFile);
VW_EXPORT void VWButton_SetActivateAudioAttribute(VWidget *buttonWig, VCAttribute *audioAttr);
VW_EXPORT void VWButton_PlayActivateAudio(VWidget *buttonWig);
VW_EXPORT void VWButton_SetArmAudio(VWidget *button, char *audioFile);
VW_EXPORT void VWButton_SetArmAudioAttribute(VWidget *button, VCAttribute *audioAttr);
VW_EXPORT void VWButton_PlayArmAudio(VWidget *button);
VW_EXPORT void VWButton_StopDragAudio(VWidget *button);
VW_EXPORT void VWButton_PlayDragAudio(VWidget *button);
VW_EXPORT void VWButton_SetDragAudioAttribute(VWidget *button, VCAttribute *audioAttr);
VW_EXPORT void VWButton_SetDragAudio(VWidget *button, char *audioFile);

/*
 * Constraint Functions.
 */
VW_EXPORT VCAttribute *VWButton_GetConstraints(VWidget *buttonWig);
VW_EXPORT void VWButton_SetConstraints(VWidget *button, VCAttribute *c, int deleteOldConst);

VW_EXPORT void VWButton_SetDoubleClickDelay(VWidget *ButtonWig, float32 delay);
VW_EXPORT void VWButton_Set2DHighlightDelay(VWidget *ButtonWig, float32 delay);

/*
 * Callback management functions.
 */
VW_EXPORT void VWButton_AddDragCallback(VWidget *, VWCallback* , void *);
VW_EXPORT void VWButton_RemoveAllDragCallbacks(VWidget *button);
VW_EXPORT void VWButton_AddDoubleClickCallback(VWidget *, VWCallback* , void *);
VW_EXPORT void VWButton_RemoveAllDoubleClickCallbacks(VWidget *button);
VW_EXPORT void VWButton_AddEnterCallback(VWidget *button, VWCallback *cb, void *cd);
VW_EXPORT void VWButton_RemoveAllEnterCallbacks(VWidget *button);
VW_EXPORT void VWButton_AddArmCallback(VWidget *button, VWCallback *cb, void *cd);
VW_EXPORT void VWButton_RemoveAllArmCallbacks(VWidget *button);
VW_EXPORT void VWButton_AddDisarmCallback(VWidget *button, VWCallback *cb, void *cd);
VW_EXPORT void VWButton_RemoveAllDisarmCallbacks(VWidget *button);
VW_EXPORT void VWButton_AddLeaveCallback(VWidget *button, VWCallback *cb, void *cd);
VW_EXPORT void VWButton_RemoveAllLeaveCallbacks(VWidget *button);
VW_EXPORT void VWButton_AddActivateCallback(VWidget *button, VWCallback *cb, void *cd);
VW_EXPORT void VWButton_RemoveActivateCallback(VWidget *button, VWCallback *cb);
VW_EXPORT void VWButton_RemoveAllActivateCallbacks(VWidget *button);

    /*
     * This function returns TRUE and fills in the intersection point 
     * if the last interaction with the button was via the 2D interface.
     */
VW_EXPORT int VWButton_GetLastIntersectionPoint(VWidget *ButtonWig, dmPoint pnt);
    /*
     * set up the geom ratio for a button with wierd sized geometry
     * set menuAdjust = TRUE if used for text in a toolbar
     */
VW_EXPORT int VWButton_CalcGeomRatioForIcon(VWidget *ButtonWig, int menuAdjust);    
    
    /*
     * set up the sizing and positioning for non normalised geometry
     */
VW_EXPORT int VWButton_CalcNonNormalisedGeomForIcon(VWidget *ButtonWig);

    /* PUBLIC TYPES =======================================================*/

enum VWbuttonargtypes {
  VWrDragCallback = VW_RESOURCES_BUTTON,
  VWrDragCalldata, 
  VWrActivateAudio, 
  VWrArmAudio, 
  VWrDragAudio
};



#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /*_Button_H */
