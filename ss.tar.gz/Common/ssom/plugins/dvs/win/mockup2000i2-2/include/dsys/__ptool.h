/****************************************************************************
 *
 *  			Copyright 1995 Division Limited.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: __ptool.h,v $
 *  Revision      : $Revision: 1.2 $
 *  Date          : $Date: 1999/01/15 13:24:44 $
 *  Author        : $Author: bill $
 *  Last Modified : <140199.1249>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 ****************************************************************************
 *
 *  Copyright (c) 1995 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 *  This Document may not, in whole or in part, be copied,
 *  photocopied, reproduced, translated, or reduced to any
 *  electronic medium or machine readable form without prior
 *  written consent from Division Ltd.
 ****************************************************************************/

#ifndef ____PTOOL_H__
#define ____PTOOL_H__

#include <dsys/__pfile.h>
#include "ptool.h"

#ifdef __cplusplus
extern "C" {
#endif
    
/* ver   change
 * 2.01  Initial version for tools library
 * 2.02  New line definitions and coping with texture etc
 * 2.03  New material stuff
 * 2.04  New STRIP_LIST and POINTLIST 
 * 2.05  New Reduce utility and Xbgftool suppot
 * 2.5.1 dgp -> dpg, rm progname, use divvers
 * 2.5.2 Patch -> Geogroup
 * 2.5.3 3.1 release
 */
#define dpt_LIBRARY_VER_STR   "2.5.3" 

#define dpt_TINY_float32 1.0e-24



/*************************************************************
*   ptmesh Routines used by other dptOols                    *
*************************************************************/

dpfVERTEXPTR
dptCreateVertex(void) ;
dpfVERTEXPTR
dptMeshAddVertex ( dptMESHPTR mesh, dpfVERTEXPTR Fvert ) ;
dpfVERTEXPTR
dptMeshAddNewVertex(dptMESHPTR mesh, dpfGEOGROUPPTR geogroup, dmVector point,
                    dmVector norm, dpfRGBA col, dpfTEXT text) ;
dptTRIANGLEPTR
dptMeshAddTriangle(dptMESHPTR mesh, dpfGEOGROUPPTR geogroup, dpfVERTEXPTR vert1, 
                   dpfVERTEXPTR vert2, dpfVERTEXPTR vert3) ;
void
dptMeshRemoveTriangle(dptMESHPTR mesh, dptTRIANGLEPTR trian) ;
void
dptMeshUnloadGeometry(dptTRIANGLEPTR start, dptMESHPTR mesh, dpfGEOGROUPPTR geogroup,
                     int32 usePmesh) ;
void
dptMeshDisconnectTriangle(dptMESHPTR mesh, dptTRIANGLEPTR trian) ;
void
dptMeshConnectTriangle(dptMESHPTR mesh, dptTRIANGLEPTR trian) ;
void
dptAddGeometryGeogroup(dptMESHPTR mesh, dpfGEOMETRYPTR geom) ;


/* reduce a mesh, used in ptbound */
int32
dptrReduceMesh(dptMESHPTR mesh, float32 Norm_tol, float32 Edge_tol,
               int32 Verbose) ;

/* ptreduce.c, used also in ptflip */
dptTRIANGLEPTR
dptGetTriangleDuplicate(dptTRIANGLEPTR tri) ;

/* pttessel.c - dirty level call for bgfreduce */
int32
__dptPolyTessellate(dpfCLISTPTR cl, int32 noPnts, int32 *vrtLst, 
                    dmVector **points) ;

/* pthedge.c - used in dv/doit plugin */
#define dptHedgehogNormalName  "show_Normal"
#define dptHedgehogBBoxName    "show_BBox"
#define dptHedgehogBSphereName "show_BSphere"
#define dptHedgehogBPmeshName  "show_BPmesh"
int32
dptHedgehogLOD(dpfLODPTR lod, char *matLib, float32 Pscale, float32 Bscale) ;

#ifdef __cplusplus
}
#endif

#endif /* ____PTOOL_H__ */


