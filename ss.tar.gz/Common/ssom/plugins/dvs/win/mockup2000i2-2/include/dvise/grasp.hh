#ifndef _GRASP_HH
#define _GRASP_HH

DV_EXPORT int
dvSwGraspListFunc(ECEvent *, ECEventData *, ECAction *);

DV_EXPORT int
dvSwGraspApplyFunc(ECEvent *, ECEventData *, ECAction *);

DV_EXPORT char **
dvSwGetGraspList(int *);

DV_EXPORT int
dvSwGraspApply(ECAssembly *, char *);

DV_EXPORT int
dvSwResetPosture(ECAssembly *);

DV_EXPORT int
dvSwToolsResetPostureFunc(ECEvent *, ECEventData *, ECAction *);

#endif
