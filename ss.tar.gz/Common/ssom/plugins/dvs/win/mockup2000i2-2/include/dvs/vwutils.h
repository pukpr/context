/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: vwutils.h,v $
 *    Revision:     $Revision: 1.8 $
 *    Date:         $Date: 2000/05/09 12:40:43 $
 *    Author:       $Author: jeff $
 *    RCS Ident:    $Id: vwutils.h,v 1.8 2000/05/09 12:40:43 jeff Exp $
 *
 *    FUNCTION: Generic widget function templates.
 *
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _VWUTILS_H
#define _VWUTILS_H
#ifdef __cplusplus
extern "C" {
#endif

/* PUBLIC TYPES =============================================*/

#include "vwtypes.h"

#ifndef _VCTOOLS_H
#include <dvs/vc.h>
#endif
    
/* PUBLIC FUNCTIONS ======================================*/

/*
 * Widget Utility Functions.
 */
VW_EXPORT void VWUtils_SetName(char **, char *);
VW_EXPORT void VWUtils_CopyMaterialName(char **, char *);
VW_EXPORT void VW_Error(char *, ...);
VW_EXPORT void VW_Warn(char *, ...);
VW_EXPORT int VWUtils_PositionWidgetPointToPoint(
    VWidget *widget, dmPoint fromPoint, dmPoint toPtn, 
    dmVector axis, float32 width, float32 preGap, float32 postGap,
    dmScale correctionScale);

VW_EXPORT void VWLimits_Set(VWLimits *limits, float32 min, float32 max);
VW_EXPORT VWLimits *VWLimits_Create(void);
VW_EXPORT void VWLimits_Delete(VWLimits *limits);
VW_EXPORT float32 VWLimits_GetMin(VWLimits *limits);
VW_EXPORT float32 VWLimits_GetMax(VWLimits *limits);

/*
 * WidgetList Functions
 */

VW_EXPORT void VWidgetList_FindNamedWidgets(VWidgetList **widgetList, 
                                    VWidget *topWidget, char *name);
VW_EXPORT void VWidgetList_Delete(VWidgetList *widgetList);
VW_EXPORT VWidgetList *VWidgetList_GetNext(VWidgetList *widgetList);
VW_EXPORT VWidget *VWidgetList_GetWidget(VWidgetList *widgetList);

/*
 * VWCallback functions
 */
VW_EXPORT void VWCallbackList_AddCallback(VWCallbackList **callbackList, 
			    VWCallback *callback, void *calldata);
VW_EXPORT void VWCallbackList_RemoveCallback(VWCallbackList **listPtr, VWCallback *func);
VW_EXPORT void VWCallbackList_RemoveMatchingCallback(VWCallbackList **listPtr, VWCallback *func, void *calldata);
VW_EXPORT void VWCallbackList_Execute(VWidget *, VWEventInfo *, VWCallbackList *);
VW_EXPORT VWCallbackList *VWCallbackList_GetNext(VWCallbackList *);
VW_EXPORT void *VWCallbackList_GetCalldata(VWCallbackList *thisCallbackList);
VW_EXPORT VWCallback *VWCallbackList_GetCallback(VWCallbackList *thisCallbackList);
VW_EXPORT void VWCallbackList_Remove(VWCallbackList **);


/*
 * DM Utilities
 */
VW_EXPORT void VWUtils_VectorGetEulerDirection(dmVector, dmEuler);
VW_EXPORT void VWUtils_PrintMatrix(uint32 mask, dmMatrix mat);
VW_EXPORT void VWUtils_PrintHexMatrix(uint32 mask, dmMatrix mat);


/*
 * VC Utilities
 */
VW_EXPORT int VW_EntityResize(VCEntity *entity, float32 sx, float32 sy, float32 sz);
VW_EXPORT void VW_Group(void);
VW_EXPORT void VW_UnGroup(void);

/*
 * Widget touched functions - used by ec to check if a pick is ok
 */
VW_EXPORT int VW_IsAWidgetTouched(VCBody *body, VCAttribute *bodyPart);    
    
#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /* _VWUTILS_H */
