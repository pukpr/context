#ifndef _ECCALLBACKS_H
#define  _ECCALLBACKS_H
#include "ecsmartptr.h"
#include <list.h>


class ECCallbackContext
{

    /*
     * member types
     */
public:
    
    typedef unsigned int context;  
    enum {
        EC_IGNORE_CONTEXT = 0,
        EC_BASE_CONTEXT 
    } ;


    static context currentContext(void)       {return m_current;}
    static context newContext(void)       {return ++m_generator;}

private:
    static context m_generator;
    static context m_current;
};




class DV_EXPORT ECCallbacks
{
public:
    static void addCallback(ECBaseItemPtr *trigger);
    static int callCallbacks();
    static size_t size(void) {return m_callbackList.size();}
    // stop callbacks happening
    static void freezeCallbacks(void) { m_freezeCallbacks++; }
    // allow callbacks to happen
    static void thawCallbacks(void) { m_freezeCallbacks--; }
private:
    static list<ECBaseItemPtr *> m_callbackList;
    static list<ECBaseItemPtr *> m_delayedCallbackList;
    typedef STLPORT::list<ECBaseItemPtr *>::iterator callbackListIterator;
    static int m_doingCallbacks;
    static int m_freezeCallbacks; // semaphore which stops callbacks happening
   
};

extern "C" 
{

    DV_EXPORT int ECCallbacks_callCallbacks(void);
}
#endif
