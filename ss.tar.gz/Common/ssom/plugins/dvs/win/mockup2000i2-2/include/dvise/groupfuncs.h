
#ifndef _GROUPFUNCS_H
#define _GROUPFUNCS_H

#ifdef __cplusplus
extern "C" {
#endif

DV_EXPORT int ECAction_CallGroup(ECAssembly *group, ECEvent *event, ECEventData *eventData, ECAction *action);
DV_EXPORT int EC_IsGroupAction(void);
DV_EXPORT ECAssembly *EC_GetActionGroup(void);

#ifdef __cplusplus
}
#endif

#endif /* GROUPFUNCS_H */
