/*
 *    PROJECT:
 *    SUBSYSTEM:
 *    MODULE:
 *
 *    File:         $RCSfile: dvtools.h,v $
 *    Revision:     $Revision: 1.6 $
 *    Date:         $Date: 2000/06/07 13:54:53 $
 *    Author:       $Author: john $
 *    RCS Ident:    $Id: dvtools.h,v 1.6 2000/06/07 13:54:53 john Exp $
 *
 *    FUNCTION: generic tool include
 *
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _DVTOOLS_H_
#define _DVTOOLS_H_
#ifdef __cplusplus
extern "C" {
#endif

#include <dvise/dvexport.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <dvs/vc.h>
/*#include <dsys/parser.h> 
 * simon 5/12/97 changed to use the ec parser */
#include <dvise/ec_parser.h>
#include <dvise/ecatools.h>
#include <dvise/event.h>
#include <dvs/vgtools.h>
#include <dvs/vwidgets.h>
#include <dvise/tbtools.h>


/* GLOBAL #DEFINES ======================================*/

/* PUBLIC DEFINES =======================================*/
    
DV_EXPORT void EC_PluginEntryPoint(ECPlugin *plg, char *stuff);
DV_EXPORT void dloadVersionFunction(int * major, int * minor);

/***********************************************************************
 * Toolbox Initialisation functions.
***********************************************************************/

DV_EXPORT int TB_InitMenuTool(dParseFilePtr , TBTool *);
DV_EXPORT int TB_InitLinkTool(dParseFilePtr , TBTool *);
DV_EXPORT int TB_InitAnimationTool(dParseFilePtr , TBTool *);
DV_EXPORT int TB_InitBackgroundTool(dParseFilePtr , TBTool *);
DV_EXPORT int TB_InitConstTool(dParseFilePtr , TBTool *);
DV_EXPORT int TB_InitCreateTool(dParseFilePtr , TBTool *);
DV_EXPORT int TB_InitLightTool(dParseFilePtr , TBTool *);
DV_EXPORT int TB_InitBodyTool(dParseFilePtr , TBTool *);
DV_EXPORT int TB_InitVisionTool(dParseFilePtr , TBTool *);
DV_EXPORT int TB_InitFogTool(dParseFilePtr , TBTool *);
DV_EXPORT int TB_InitTestTool(dParseFilePtr, TBTool *);
DV_EXPORT int TB_InitSaveTool(dParseFilePtr, TBTool *);
DV_EXPORT int TB_InitDistanceTool(dParseFilePtr, TBTool *);
DV_EXPORT int TB_InitCameraTool(dParseFilePtr, TBTool *);
/*DV_EXPORT int TB_InitImmTestTool(dParseFilePtr, TBTool *);
  DV_EXPORT int TB_InitGenericTool(dParseFilePtr, TBTool *);
*/
#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /*_DVTOOLS_H_ */
