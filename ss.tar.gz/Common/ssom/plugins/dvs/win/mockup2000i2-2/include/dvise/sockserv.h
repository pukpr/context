/******************************************************************************/
/*									      */
/*	######    ###   #     #   ###    #####    ###   ####### #     #	      */
/*	#     #    #    #     #    #    #     #    #    #     # ##    #	      */
/*	#     #    #    #     #    #    #          #    #     # # #   #	      */
/*	#     #    #    #     #    #     #####     #    #     # #  #  #	      */
/*	#     #    #     #   #     #          #    #    #     # #   # #	      */
/*	#     #    #      # #      #    #     #    #    #     # #    ##	      */
/*	######    ###      #      ###    #####    ###   ####### #     #	      */
/*									      */
/*									      */
/*			#####    ###     ###     ###			      */
/*			     #  #   #   #   #   #   #			      */
/*			     # #     # #     # #     #			      */
/*			#####  #     # #     # #     #			      */
/*			#      #     # #     # #     #			      */
/*			#       #   #   #   #   #   #			      */
/*			######   ###     ###     ###			      */
/*									      */
/* 		Copyright (c) Division Limited. All rights reserved	      */
/*									      */
/* This Document may not, in whole or in part, be copied, photocopied,	      */
/* reproduced, translated, or reduced to any electronic medium or machine     */
/* readable form without prior written consent from Division Ltd.	      */
/*									      */
/******************************************************************************/

#if !defined _SOCKSERV_H_
#define _SOCKSERV_H_

#if defined __cplusplus
extern "C"
{
#endif

extern void sockserv_stop (void);
extern int  sockserv_run  (void);

#if defined __cplusplus
}
#endif
#endif /* _SOCKSERV_H */
