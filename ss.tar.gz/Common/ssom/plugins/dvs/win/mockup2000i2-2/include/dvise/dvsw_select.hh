#ifndef _DVSW_SELECT_HH
#define _DVSW_SELECT_HH

#include "man_register.hh"
#include "man_handle.hh"

/*****************************************************************************/

/* This class will provide the manikin selection service to whoever is
   interested (GUI, SAFEWORK for panels, etc.)

   For each body that appears in the world, a _dvSwSelection object will be
   made to manage the manikin selection for that body.  It will monitor the
   selection list of that body and then convert it to the Manikin, Segment and
   Constraint selections. */

					// Implementation class to hide lots of
					// private gunge from this header, and
					// so the rest of the world.

typedef class _dvSwSelectionImpl _dvSwSelectionImpl;


class _dvSwSelection;

typedef ECSmartPtr<_dvSwSelection> dvSwSelectionPtr;


class DV_EXPORT _dvSwSelection : public _ECBaseItem
{
public:

    /* Methods that overwrite virtual methods in the base class. */

    _dvSwSelection(VCBody *vc_body);	// Constructor (Nb. Base class's
					// constructor is called automatically)

    ~_dvSwSelection(void);		// Destructor.

    int		getId(void) const;	// Stuff relating to Info class...?
    static int	getMyId(void);
    char	*getIdString(void) const;


    /* Methods for the implementation of the _dvSwSelection class. */


					// Ways of getting the _dvSwSelection
					// for a particular VC body and vice
					// versa.

    static const dvSwSelectionPtr getFromVCBody(VCBody *const);
    VCBody *get_vc_body(void) const;


    // This is the inteface that interested parties will use to get at the
    // manikin, segment and constraint selection.  Note that it is a restricted
    // interface as the modules using this class aren't allowed to add or
    // remove segments or constriants from the segment/constraint lists (though
    // they are from the manikin list).


    // Manikin selection.

					// Callback interface.
    ECCallbackIterator
    attachManikinSelectionUpdateCallback(ecCallbackFunc func, void *data)
    {
	return (manikin_selection->attachUpdateCallback(func, data));
    }

    void
    detachManikinSelectionUpdateCallback(ECCallbackIterator it)
    {
	manikin_selection->detachUpdateCallback(it);
    }

					// List access interface.

					// Whole list.
    const _ECItemList::ECItemListIterator
    manikin_list_begin(void)
    {
	return manikin_selection->list_begin();
    }

    const _ECItemList::ECItemListIterator
    manikin_list_end(void)
    {
	return manikin_selection->list_end();
    }

    int
    manikin_list_size(void)
    {
	return manikin_selection->list_size();
    }

    bool
    manikin_list_empty(void)
    {
	return manikin_selection->list_empty();
    }

					// Added list.
    const _ECItemList::ECItemListIterator
    manikin_added_begin(void)
    {
	return manikin_selection->added_begin();
    }

    const _ECItemList::ECItemListIterator
    manikin_added_end(void)
    {
	return manikin_selection->added_end();
    }

    int
    manikin_added_size(void)
    {
	return manikin_selection->added_size();
    }

					// Removed list.
    const _ECItemList::ECItemListIterator
    manikin_removed_begin(void)
    {
	return manikin_selection->removed_begin();
    }

    const _ECItemList::ECItemListIterator
    manikin_removed_end(void)
    {
	return manikin_selection->removed_end();
    }

    int
    manikin_removed_size(void)
    {
	return manikin_selection->removed_size();
    }

					// Selection manipulation.
    int
    manikin_addItem(ECBaseItemPtr &item)
    {
	return manikin_selection->addItem(item);
    }

    // Selection manipulation. simon 12/4/00 put this in until Ian adds his own func.
    int
    manikin_removeItem(ECBaseItemPtr &item)
    {
	return manikin_selection->removeItem(item);
    }


					// Class that is used to find out which
					// man handles are selected for a given
					// manikin.

    typedef class ManikinSelectionManHandles
    {
	void *set_data;
	void *iterator_data;

    public:

					// Constructor

	ManikinSelectionManHandles(_dvSwSelection *dvswselection,
				   ECSwManRegisterPtr man_register_ptr);

	~ManikinSelectionManHandles();	// Destructor


	_ECSwManHandle *
	get_first_selected_handle(void);

	_ECSwManHandle *
	get_next_selected_handle(void);

    } ManikinSelectionManHandles;


    friend class ManikinSelectionManHandles;


    bool
    manikin_containsItem(ECBaseItemPtr &item)
    {
	return manikin_selection->containsItem(item);
    }


    // Root selection.

					// Callback interface.
    ECCallbackIterator
    attachRootSelectionUpdateCallback(ecCallbackFunc func, void *data)
    {
	return (root_selection->attachUpdateCallback(func, data));
    }

    void
    detachRootSelectionUpdateCallback(ECCallbackIterator it)
    {
	root_selection->detachUpdateCallback(it);
    }

					// List access interface.

					// Whole list.
    const _ECItemList::ECItemListIterator
    root_list_begin(void)
    {
	return root_selection->list_begin();
    }

    const _ECItemList::ECItemListIterator
    root_list_end(void)
    {
	return root_selection->list_end();
    }

    int
    root_list_size(void)
    {
	return root_selection->list_size();
    }

    bool
    root_list_empty(void)
    {
	return root_selection->list_empty();
    }

					// Added list.

    const _ECItemList::ECItemListIterator
    root_added_begin(void)
    {
	return root_selection->added_begin();
    }

    const _ECItemList::ECItemListIterator
    root_added_end(void)
    {
	return root_selection->added_end();
    }

    int
    root_added_size(void)
    {
	return root_selection->added_size();
    }

					// Removed list.

    const _ECItemList::ECItemListIterator
    root_removed_begin(void)
    {
	return root_selection->removed_begin();
    }

    const _ECItemList::ECItemListIterator
    root_removed_end(void)
    {
	return root_selection->removed_end();
    }

    int
    root_removed_size(void)
    {
	return root_selection->removed_size();
    }

					// Selection manipulation.
    bool
    root_containsItem(ECBaseItemPtr &item)
    {
	return root_selection->containsItem(item);
    }


    // Segment selection.

					// Callback interface.
    ECCallbackIterator
    attachSegmentSelectionUpdateCallback(ecCallbackFunc func, void *data)
    {
	return (segment_selection->attachUpdateCallback(func, data));
    }

    void
    detachSegmentSelectionUpdateCallback(ECCallbackIterator it)
    {
	segment_selection->detachUpdateCallback(it);
    }

					// List access interface.

					// Whole list.
    const _ECItemList::ECItemListIterator
    segment_list_begin(void)
    {
	return segment_selection->list_begin();
    }

    const _ECItemList::ECItemListIterator
    segment_list_end(void)
    {
	return segment_selection->list_end();
    }

    int
    segment_list_size(void)
    {
	return segment_selection->list_size();
    }

    bool
    segment_list_empty(void)
    {
	return segment_selection->list_empty();
    }

					// Added list.

    const _ECItemList::ECItemListIterator
    segment_added_begin(void)
    {
	return segment_selection->added_begin();
    }

    const _ECItemList::ECItemListIterator
    segment_added_end(void)
    {
	return segment_selection->added_end();
    }

    int
    segment_added_size(void)
    {
	return segment_selection->added_size();
    }

					// Removed list.

    const _ECItemList::ECItemListIterator
    segment_removed_begin(void)
    {
	return segment_selection->removed_begin();
    }

    const _ECItemList::ECItemListIterator
    segment_removed_end(void)
    {
	return segment_selection->removed_end();
    }

    int
    segment_removed_size(void)
    {
	return segment_selection->removed_size();
    }

					// Selection manipulation.
    bool
    segment_containsItem(ECBaseItemPtr &item)
    {
	return segment_selection->containsItem(item);
    }


    // Constraint selection.

					// Callback interface.
    ECCallbackIterator
    attachConstraintSelectionUpdateCallback(ecCallbackFunc func, void *data)
    {
	return (constraint_selection->attachUpdateCallback(func, data));
    }

    void
    detachConstraintSelectionUpdateCallback(ECCallbackIterator it)
    {
	constraint_selection->detachUpdateCallback(it);
    }

					// List access inteface.

					// Whole list.

    const _ECItemList::ECItemListIterator
    constraint_list_begin(void)
    {
	return constraint_selection->list_begin();
    }

    const _ECItemList::ECItemListIterator
    constraint_list_end(void)
    {
	return constraint_selection->list_end();
    }

    int
    constraint_list_size(void)
    {
	return constraint_selection->list_size();
    }

    bool
    constraint_list_empty(void)
    {
	return constraint_selection->list_empty();
    }

					// Added list.

    const _ECItemList::ECItemListIterator
    constraint_added_begin(void)
    {
	return constraint_selection->added_begin();
    }

    const _ECItemList::ECItemListIterator
    constraint_added_end(void)
    {
	return constraint_selection->added_end();
    }

    int
    constraint_added_size(void)
    {
	return constraint_selection->added_size();
    }

					// Removed list.

    const _ECItemList::ECItemListIterator
    constraint_removed_begin(void)
    {
	return constraint_selection->removed_begin();
    }

    const _ECItemList::ECItemListIterator
    constraint_removed_end(void)
    {
	return constraint_selection->removed_end();
    }

    int
    constraint_removed_size(void)
    {
	return constraint_selection->removed_size();
    }

					// Selection maipulation
    bool
    constraint_containsItem(ECBaseItemPtr &item)
    {
	return constraint_selection->containsItem(item);
    }


private:

    // The implementation class that hides most of the private gunge from any
    // module that includes this header file.  Nb. anything left in this
    // private section is for inline member functions to access (and so is
    // relatively simple).

    _dvSwSelectionImpl	*m_impl;

    friend class _dvSwSelectionImpl;
    

    // The selection lists that hold the different manikin selections.

    ECItemListPtr manikin_selection;	// A list of ECSwManRegisters.

    ECItemListPtr root_selection;	// A list of ECSwManHandlePtr.
    ECItemListPtr segment_selection;	// A list of ECSwManHandlePtr.
    ECItemListPtr constraint_selection;	// A list of ECSwManHandlePtr.


    VCBody	*vc_body;		// The ECBody and VCBody to which this
    ECBody	*ec_body;		// selection relates.
};


/*****************************************************************************/

#endif
