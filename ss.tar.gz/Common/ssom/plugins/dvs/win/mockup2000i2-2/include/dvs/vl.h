/*
 *    PROJECT:      DVS
 *    SUBSYSTEM:    vl
 *    MODULE:       vl.h
 *
 *    File:         $RCSfile: vl.h,v $
 *    Revision:     $Revision: 1.33 $
 *    Date:         $Date: 2000/04/12 14:30:24 $
 *    Author:       $Author: john $
 *    RCS Ident:    $Id: vl.h,v 1.33 2000/04/12 14:30:24 john Exp $
 *
 *    FUNCTION:
 *
 *      This file contains all the external definitions needed to use
 *       the vl library.
 *
 * Copyright (c) 1994, 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _VL_H
#define _VL_H

#ifdef __cplusplus
extern "C" {
#endif
        
/* #include <stdio.h> */
#include <dsys/dp.h>

#ifndef _VLTYPES_H
#include <dvs/vltypes.h>
#endif



#ifndef VL_EXPORT
#if defined(_WIN32) && !defined(_WINDU_SOURCE) && !defined(__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `extern'
 */
#ifdef  _LIB_VL
#define VL_EXPORT __declspec(dllexport) extern 
#else
#define VL_EXPORT __declspec(dllimport) extern 
#endif /* IN_A_DIVISION_LIB */
#else
#define VL_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ndef VL_EXPORT */

/*
 * type for return of event info
 */
typedef union  VLEventData           VLEventData;
typedef struct VLInstanceEvent       VLInstanceEvent;

typedef struct VLSignalEvent         VLSignalEvent;
typedef struct VLInstInterestEvent   VLInstInterestEvent;
typedef struct VLElemInterestEvent   VLElemInterestEvent;
typedef struct VLElementConfirmEvent VLElementConfirmEvent;
typedef struct VLElemCreateEvent     VLElemCreateEvent;
typedef struct VLTimeServiceEvent    VLTimeServiceEvent;
typedef struct VLPeerEvent           VLPeerEvent;
typedef struct VLBadEvent            VLBadEvent;
typedef struct VLSystemHandleEvent   VLSystemHandleEvent;
typedef struct VLFileEvent           VLFileEvent;


struct VLInstanceEvent{
    ElementHandle handle;
    InstanceNo    ino;
    int32         repCount;
};

struct VLSignalEvent{
    uint32        signal;
};

struct VLInstInterestEvent{
    InstanceNo    ino;
    uint32        type;
    ActorId       actor;
    EventQ        queue;
};
    
struct VLElemInterestEvent{
    ElementHandle handle;
    uint32        type;
    ActorId       actor;
    EventQ        queue;
};

struct VLElementConfirmEvent{
    ElementHandle reference;
    ElementHandle confirmed;
};

struct VLElemCreateEvent{
    ElementHandle handle;
    uint32        descSize;
};

struct VLTimeServiceEvent{
    dpVtime time;
    ActorId who;
};

struct  VLPeerEvent{
    ActorId peer;
};

struct VLBadEvent {
    VLStatus stat;
};

struct VLSystemHandleEvent 
{
    dpHandle   handle;
};

struct VLFileEvent 
{
    int   fd;
    int   ioType;
};


union VLEventData {
    VLInstanceEvent       instanceEvent;
    VLSignalEvent         signalEvent;
    VLInstInterestEvent   instInterestEvent;
    VLElemInterestEvent   elemInterestEvent;
    VLElementConfirmEvent elementConfirmEvent;
    VLElemCreateEvent     elemCreateEvent;
    VLTimeServiceEvent    timeServiceEvent;
    VLPeerEvent           peerEvent;
    VLSystemHandleEvent   systemHandleEvent;
    VLFileEvent           fileEvent;
    VLBadEvent            badEvent;
};

/*
 * fundemenatal element handles, always around.
 */
VL_EXPORT const ElementHandle el_char8;
VL_EXPORT const ElementHandle el_int8;
VL_EXPORT const ElementHandle el_uint8;
VL_EXPORT const ElementHandle el_int16;
VL_EXPORT const ElementHandle el_uint16;
VL_EXPORT const ElementHandle el_int32;
VL_EXPORT const ElementHandle el_uint32;
VL_EXPORT const ElementHandle el_float32;
VL_EXPORT const ElementHandle el_float64;

/*
 * get the version
 */
VL_EXPORT void          vlVersion(FILE *fp);

/*
 * Connecting to a  database, finding out name etc.
 */
VL_EXPORT ActorId  	 VLAttachActor(const char8 *agentName);
VL_EXPORT VLStatus  	 VLDetachActor(VLExitMode);
VL_EXPORT uint32    	 VLDomainName(char8 *name, uint32 maxNameLen);
VL_EXPORT AgentId     	 VLDomainId(void);
VL_EXPORT char8 	*VLSystemName(void);
VL_EXPORT char8 	*VLNetworkName(void);
VL_EXPORT ActorId   	 VLAttachAgent(const char8 *domain);
VL_EXPORT VLStatus  	 VLSetDomainId(AgentId id);
VL_EXPORT void		 VLShutdownMode(VLCleanupMode shutdown);
VL_EXPORT VLCleanupMode	 VLGetShutdownMode(void);
VL_EXPORT VLStatus VLAddFile(int fd, int mode);
VL_EXPORT VLStatus VLRemoveFile(int fd, int mode);
VL_EXPORT dpHandle VLGetFd(void);
VL_EXPORT int VLSetSleepFlag(int val);
VL_EXPORT void VLErrorServerModeSet(VLErrorServerMode mode);
VL_EXPORT VLErrorServerMode VLErrorServerModeGet(void);
VL_EXPORT void VLErrorServerPort(int port);
VL_EXPORT void VLExit(int code);



/*
 * Creating elements
 */
VL_EXPORT VLStatus VLCreateElement(int32 (*efunc)(void));


/*  how epp generated code defines elements..
 * For error free code..
 *
 * THIS ROUTINE IS FOR USE BY EPP-GENERATED CODE
 *                 ONLY!
 * That is why its name is prefixed with 'vl' not 'VL'.
 */
VL_EXPORT ElementHandle   vlCreateElement(char8 *name,
                                       int32 size,
                                       int32 alignment,
                                       int32 atomic,
                                       int32 dynamic,
                                       int32 subelems, ...);

/*
 * extract an element description into a buffer
 * that could be transmited to a remote data base and 
 * used to recreate the element there. Used by agents
 * to exchange element information.
 */
VL_EXPORT VLStatus      VLExtractElemDesc(ElementHandle h,
                                       ElementDesc *d);


/*
 * take an element description, probably transmitted from a remote
 * machine, and create an element from it. Such an element cannot be
 * properly used on the local database, without a 'vlCreateElement()'
 * being performed, as offset and alignment information (which is machine
 * dependant) is not available here, but the form will be created here
 * with a valid element handle. This will speed up future
 * vlCreateElement(), or ' VLCreateElemFromDesc()' calls at this database.
 *
 *                THIS CREATE IS ASYNCHRONOUS. 
 *
 * If the element creation needs to be further negotiated with a peer
 * database, then a potential for deadlock in the database coms exists.
 * To avoid this, VLCreateElemFromDesc() always returns imediately, with
 * no status. All return info is put onto the event queue for async handling.
 */
VL_EXPORT VLStatus VLPeerElement(ElementDesc *d,
                              uint32 descSize,
                              EventQ q,
                              VLFormat format);

/*
 * Setting the database peer.
 */
VL_EXPORT VLStatus VLSetPeerActor(EventQ q);

/*
 * Arrange to get an event when the peer attatches to the database, 
 * error status if there will be no peer.
 */
VL_EXPORT VLStatus VLGetPeerActor(void);

/*
 * check to see if tha database is a master or not.
 */
VL_EXPORT int VLIsMasterP(void);

/*
 * Define the data format (alignment, endianess etc) of a remote
 * database to this database. Return value is used to identify
 * the source type of remote machines for updates with reformating.
 * returns negative if there is any form of error.
 */
VL_EXPORT VLFormat VLDefineFormat(dpTypeSpec *s);


/*
 * The following calls are needed to find out when a time keeper has
 * connected, and to set up the timekeeper, used on those systems that
 * use a timekeeper. on systems that have a local timer, these calls will
 * always fail.
 */
VL_EXPORT VLStatus VLGetTimeKeeper(void);
VL_EXPORT VLStatus VLSetTimeKeeper(EventQ q);

/*
 * used by a timekeeper to wakeup actors waiting on alarms, on systems
 * without a timekeeper this funcion will still work. returns
 * VL_ERR_BAD_AGENT if the actor id is not recognised.
 */
VL_EXPORT VLStatus VLWakeUpActor(ActorId actor);

/*
 * change the state of an element to confirmed. This may involve a change
 * of element handle , from 'oldh' to 'newh'. To delete an element awaiting
 * confirmation set the 'newh' element handle to 0. Will return
 * VL_ERR_BAD_ELEM if 'oldh' is not waiting for confirmation or is not an
 * element. else returns VL_ERR_OK.
 */
VL_EXPORT VLStatus      VLConfirmElement(ElementHandle oldh, ElementHandle newh);


/*
 * requesting info about other actors interest at this database.
 */
#define   VLRegisterElementInterest()   VLQRegisterElementInterest(0)
#define VLDeRegisterElementInterest() VLQDeRegisterElementInterest(0)

VL_EXPORT VLStatus   (VLRegisterElementInterest)(void);
VL_EXPORT VLStatus (VLDeRegisterElementInterest)(void);
VL_EXPORT VLStatus    VLQRegisterElementInterest(EventQ q);
VL_EXPORT VLStatus  VLQDeRegisterElementInterest(EventQ q);
VL_EXPORT VLStatus      VLRequestElementInterest(EventQ q, ElementHandle h);

#define   VLRegisterInstanceInterest(x)   VLQRegisterInstanceInterest(0,x)
#define VLDeRegisterInstanceInterest(x) VLQDeRegisterInstanceInterest(0,x)

VL_EXPORT VLStatus   (VLRegisterInstanceInterest)(AgentId id);
VL_EXPORT VLStatus (VLDeRegisterInstanceInterest)(AgentId id);
VL_EXPORT VLStatus    VLQRegisterInstanceInterest(EventQ q, AgentId);
VL_EXPORT VLStatus  VLQDeRegisterInstanceInterest(EventQ q, AgentId);


/*
 * Low-level routines  to create/delete/update/extract
 * instances from the database.
 *
 * THESE  ROUTINES SHOULD BE CALLED FROM EPP-GENERATED CODE ONLY
 *
 * Epp will write type-safe access routines for you,
 *
 *                          USE THEM.
 */
#define vlCreateInstance(e,i,d,t,m)             vlQCreateDynamicFormattedInstance(  0,(e),(i),(d),(t),(m),-1, -1 ) 
#define vlCreateDynamicInstance(e,i,d,t,m,c)    vlQCreateDynamicFormattedInstance(  0,(e),(i),(d),(t),(m),-1, (c))
#define vlQCreateInstance(q,e,i,d,t,m)          vlQCreateDynamicFormattedInstance((q),(e),(i),(d),(t),(m),-1, -1 )
#define vlQCreateDynamicInstance(q,e,i,d,t,m,c) vlQCreateDynamicFormattedInstance((q),(e),(i),(d),(t),(m),-1, (c))

VL_EXPORT InstanceNo                 (vlCreateInstance)(ElementHandle elem,
                                                         InstanceNo    ino,
                                                         void         *data,
                                                         dpVtime       *vtime,
                                                         uint32        mode);
VL_EXPORT InstanceNo                (vlQCreateInstance)(EventQ     qid,
                                                         ElementHandle elem,
                                                         InstanceNo    ino,
                                                         void         *data,
                                                         dpVtime       *vtime,
                                                         uint32        mode);

VL_EXPORT InstanceNo          (vlCreateDynamicInstance)(ElementHandle elem,
                                                         InstanceNo    ino,
                                                         void         *data,
                                                         dpVtime       *vtime,
                                                         uint32        mode,
                                                         int32        count);

VL_EXPORT InstanceNo         (vlQCreateDynamicInstance)(EventQ        qid,
                                                         ElementHandle elem,
                                                         InstanceNo    ino,
                                                         void         *data,
                                                         dpVtime       *vtime,
                                                         uint32        mode,
                                                         int32        count);

VL_EXPORT InstanceNo  vlQCreateDynamicFormattedInstance(EventQ        qid,
                                                         ElementHandle elem,
                                                         InstanceNo    ino,
                                                         void         *data,
                                                         dpVtime       *vtime,
                                                         uint32        mode,
                                                         VLFormat      format,
                                                         int32        count);

#define vlDeleteInstance(i,m)            vlQDeleteInstance(0,(i),(m))

VL_EXPORT VLStatus          (vlDeleteInstance)(InstanceNo   ino,
                                                uint32       mode);
VL_EXPORT VLStatus           vlQDeleteInstance(EventQ     qid,
                                                InstanceNo   ino,
                                                uint32       mode);

VL_EXPORT VLStatus            vlUpdateInstance(InstanceNo   ino,
                                                void        *data,
                                                dpVtime      *vtime,
                                                uint32       mode);

VL_EXPORT VLStatus           vlQUpdateInstance(EventQ     qid,
                                                InstanceNo   ino,
                                                void        *data,
                                                dpVtime      *vtime,
                                                uint32       mode);

VL_EXPORT VLStatus     vlUpdateDynamicInstance(InstanceNo    ino,
                                                void         *data,
                                                dpVtime       *vtime,
                                                uint32        mode,
                                                int32        count);

VL_EXPORT VLStatus    vlQUpdateDynamicInstance(EventQ        qid,
                                                InstanceNo    ino,
                                                void         *data,
                                                dpVtime       *vtime,
                                                uint32        mode,
                                                int32        count);

VL_EXPORT VLStatus     vlQUpdateInstanceFormat(EventQ        qid,
                                                VLFormat      format,
                                                InstanceNo    ino,
                                                void         *data,
                                                dpVtime       *vtime,
                                                uint32        mode,
                                                int32        count);


VL_EXPORT VLStatus           vlExtractInstance(InstanceNo ino,
                                                void *data,
                                                dpVtime *vtime);




/*
 * Miscellaneous instance routines
 */
VL_EXPORT uint32     VLInstanceSubInstCount(InstanceNo ino);

VL_EXPORT ElementHandle      VLInstanceType(InstanceNo ino);
VL_EXPORT uint32             VLInstanceSize(InstanceNo ino, uint32 *icount);
VL_EXPORT int32         VLInstanceOwnership(InstanceNo ino);
VL_EXPORT uint32        VLInstanceFlags( InstanceNo ino );
VL_EXPORT uint32        VLInstanceWhoUpdated( InstanceNo ino );
VL_EXPORT void           *VLInstanceAddress(InstanceNo ino,
                                             VLStatus    *status, 
                                             dpVtime      *time,
                                             uint32       mode,
                                             uint32       count);
VL_EXPORT VLStatus         VLInstanceUpdate(InstanceNo   ino,
                                             dpVtime      *vtime,
                                             uint32       mode);


/*
 * (de)registering of interest in elements and instances.
 */
#define    VLRegisterElement(e, t)    VLQRegisterElement(0,(e),(t))
#define  VLDeRegisterElement(e, t)  VLQDeRegisterElement(0,(e),(t))
#define   VLRegisterInstance(i, t)   VLQRegisterInstance(0,(i),(t))
#define VLDeRegisterInstance(i, t) VLQDeRegisterInstance(0,(i),(t))

VL_EXPORT VLStatus    (VLRegisterElement)(ElementHandle e, uint32 type);
VL_EXPORT VLStatus  (VLDeRegisterElement)(ElementHandle e, uint32 type);
VL_EXPORT VLStatus   (VLRegisterInstance)(InstanceNo ino,  uint32 type);
VL_EXPORT VLStatus (VLDeRegisterInstance)(InstanceNo ino,  uint32 type);

VL_EXPORT VLStatus    VLQRegisterElement(EventQ q,
                                          ElementHandle e,
                                          uint32 type);
VL_EXPORT VLStatus  VLQDeRegisterElement(EventQ q,
                                          ElementHandle e,
                                          uint32 type);
VL_EXPORT VLStatus   VLQRegisterInstance(EventQ q,
                                          InstanceNo ino,
                                          uint32 type);
VL_EXPORT VLStatus VLQDeRegisterInstance(EventQ q,
                                          InstanceNo ino,
                                          uint32 type);


/*
 * Events, and their queues.
 */
#define VLAwaitEvent(e,w) VLQAwaitEvent((e),NULL,(w))

VL_EXPORT VLAction     (VLAwaitEvent)(VLEventData *ev,
                                       VLWaitMode   wait);
VL_EXPORT VLAction      VLQAwaitEvent(VLEventData *ev,
                                       EventQ      *q,
                                       VLWaitMode   wait);
VL_EXPORT VLAction      VLQOnlyPollEvent(VLEventData *ev,
                                         EventQ      *q);
VL_EXPORT VLAction 	VLSnoopEvent(EventQ qid,VLEventData *ev);
VL_EXPORT VLStatus     	VLSnoopConfirm(EventQ qid);
VL_EXPORT int		VLFastPeekEvent (void);

VL_EXPORT EventQ      VLNewEventQueue(void);
VL_EXPORT VLStatus VLDeleteEventQueue(EventQ q);
VL_EXPORT VLStatus  VLBlockEventQueue(EventQ q);
VL_EXPORT VLStatus  VLClearEventQueue(EventQ q);


/*
 * signals
 */
VL_EXPORT void   VLSigSet(int32 sig);
VL_EXPORT void VLSigUnset(int32 sig);

/*
 * Locking and groups
 */
VL_EXPORT VLStatus     VLLock(void);
VL_EXPORT VLStatus	VLPollLock (void);
VL_EXPORT VLStatus   VLUnlock(void);
VL_EXPORT int32  VLLockStatus(void);

#define VLGroup()       VLQGroup(0)
#define VLUnGroup()     VLQUnGroup(0)
#define VLGroupStatus() VLQGroupStatus(0)

VL_EXPORT int32       (VLGroup)(void);
VL_EXPORT int32     (VLUnGroup)(void);
VL_EXPORT int32 (VLGroupStatus)(void);
VL_EXPORT int32        VLQGroup(EventQ qid);
VL_EXPORT int32      VLQUnGroup(EventQ qid);
VL_EXPORT int32  VLQGroupStatus(EventQ qid);

/*
 * Virtual time and timers
 */

VL_EXPORT VLStatus        VLVirtualTime(dpVtime *t);
VL_EXPORT VLStatus VLSetVirtualTimeSkew(dpVtime *t);
VL_EXPORT VLStatus VLGetVirtualTimeSkew(dpVtime *t);

VL_EXPORT VLStatus VLTimer(dpVtime *period, VLTimerMode mode);
VL_EXPORT VLStatus VLAddSystemHandle (dpHandle handle);
VL_EXPORT VLStatus VLRemoveSystemHandle(dpHandle handle);
VL_EXPORT VLStatus VLAddWindowsMessage (uint32 mask);
VL_EXPORT VLStatus VLRemoveWindowsMessage(uint32 mask);



/*
 * converting status numbers, element handles  to meaningful messages
 */
VL_EXPORT const char *VLErrorString(VLStatus s);
VL_EXPORT const char *VLElementName(ElementHandle h);

VL_EXPORT int VLActorAlwaysWakeUp(ActorId actor);
#if !defined(_UNIX) && !defined(__EPP__)
VL_EXPORT void VLSetUserWindow(HWND window, UINT message);
VL_EXPORT HWND VLGetUserWindow();
#endif

/*
 * for use by vcrun only. This interface needs sorting out!
 */
VL_EXPORT int32 (*__vlAttachTryAgainFunc)(void);

#ifdef __cplusplus
}
#endif
#endif /* _VL_H */
