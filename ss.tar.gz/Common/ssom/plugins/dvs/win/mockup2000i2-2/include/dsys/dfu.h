/* -*- C -*- ****************************************************************
 *
 *  			Copyright 1999 Division Ltd.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: dfu.h,v $
 *  Revision      : $Revision: 1.4 $
 *  Date          : $Date: 1999/06/23 08:34:55 $
 *  Author        : $Author: bill $
 *  Created By    : Steven Phillips
 *  Created       : Tue Apr 27 05:34:55 1999
 *  Last Modified : <990623.0934>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 *  $Log: dfu.h,v $
 *  Revision 1.4  1999/06/23 08:34:55  bill
 *  Missed a functional export for windows
 *
 *  Revision 1.3  1999/06/17 14:39:25  bill
 *  Fixed dfuFileGetSize macro bug
 *
 *  Revision 1.2  1999/05/12 16:37:49  bill
 *  Fixed windows exporting
 *
 *  Revision 1.1  1999/05/12 11:10:29  bill
 *  Moved dpg dfl pfparser from utils/libdpf to misc/libdpg
 *  Moved utils/libdvcon to misc/libdvcon
 *  added misc/libdfu
 *  Added the 3 new componants to libdivu
 *
 *
 ****************************************************************************
 *
 *  Copyright (c) 1999 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 * This  document  may  not, in  whole  or in  part, be  copied,  photocopied,
 * reproduced,  translated,  or  reduced to any  electronic  medium or machine
 * readable form without prior written consent from Division Ltd.
 *
 ****************************************************************************/

#ifndef __DFU_h
#define __DFU_h

#ifndef DFU_EXPORT
#if defined(_WIN32) && !defined(_WINDU_SOURCE) && !defined(__EPP__) && !defined(BUILD_STATIC)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `extern'
 */
#if defined _LIB_DIVU
#define DFU_EXPORT __declspec(dllexport) extern 
#else
#define DFU_EXPORT __declspec(dllimport) extern 
#endif 
#else
#define DFU_EXPORT  extern
#endif
#endif

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

#include <dsys/divtypes.h>

#include <dsys/pgeneral.h>
#include <zlib.h>

#ifdef __cplusplus
extern "C" {
#endif
    
/* On calls which either succeed or fail, dpgSUCCESS (0) or dpgERROR (-1)
 * is returned. On calls to get next token however the following 
 * return values are also used
 */
#define dfuSUCCESS      dpgSUCCESS
#define dfuERROR        dpgERROR
#define dfuEOF          -2
#define dfuSTRING       -3
#define dfuNUMBER       -4

#define dfuBUFFER_SIZE  8192

/****************************************************************************
 * File reading parsing and writing routines.
 */

typedef struct
{
    int32  token ;
    int32  length ;
    char  *name;
} dfuToken ;

typedef uint8 dfuComment[2] ;

typedef struct
{
    char       *name ;
    int32       flags ;
    int32       sttPos ;
    int32       endPos ;
    /* non-compressed file info */
    FILE       *fp ;
    /* compressed file info */
    gzFile      zfp ;
    int32       curStt ;
    int32       curOff ;
    int32       curLen ;
    char       *zbuffer ;
    /* user data fields */
    int32       usrFlag ;
    void       *usrData ;
    /* read specific */
    /* read specific */
    uint8       ungetChar ;
    /* parse specific */
    int32       lineNo ;
    uint8      *ctable ;
    int32       comCount ;
    dfuComment *comStart ;
    dfuComment *comEnd ;
    int32       token ;
    float64     number ;
    uint32      uiNumber ;
    int32       strLen ;
    uint8      *buffer ;
    int32       bufSize ;
    dfuToken   *tokens ;
} dfuFile ;

#define dfuREAD               0x001
#define dfuPARSE              0x002
#define dfuWRITE              0x004
#define dfuFILE_COMPRESS      0x010     /* Use gzopen to get compression? */
#define dfuFILE_LITTLE_ENDIAN 0x020     /* Write int32 etc in little endian form? */
#define dfuFILE_BIG_ENDIAN    0x040     /* Write int32 etc in big endian form? */
#define dfuFILE_FREE_USRDATA  0x080     /* Free usrData on a close? */

/* internal flags */
#define dfuFILE_NO_CLOSE      0x01000   /* Internal - close the file point in dfuFileClose */
#define dfuFILE_ENDIAN_SWAP   0x02000   /* Internal - required endianess different to platform? */
#define dfuREAD_UNGET_CHAR    0x04000   /* Internal - Flag indicating the next char is ungetChar */ 
#define dfuPARSE_IGNORE_CASE  0x08000   /* Internal - match tokens case insensitively */ 
#define dfuPARSE_COMPLEX_STR  0x10000   /* Internal - use complex c style string extensions */
#define dfuPARSE_JOIN_STR     0x20000   /* Internal - join "a" "b" together, ie "ab"        */
#define dfuPARSE_UNGET_TOKEN  0x40000   /* Internal - Flag indicating the next token is token */ 

DFU_EXPORT void
dfuFileSetEndian(dfuFile *fp, int32 endian) ;
DFU_EXPORT int32
dfuFileClose(dfuFile *fp) ;

#define dfuFileError(dfp)              \
(((dfp)->flags & dfuFILE_COMPRESS) ?   \
 1:((int32) ferror((dfp)->fp)))

#define dfuFileTell(dfp)               \
(((dfp)->flags & dfuFILE_COMPRESS) ?   \
 ((dfp)->curStt+(dfp)->curOff):ftell((dfp)->fp))

DFU_EXPORT int32
__dfuFileGetSize(dfuFile *fp) ;
#define dfuFileGetSize(dfp)            \
((dfp->endPos < 0) ?                   \
 __dfuFileGetSize(dfp):(dfp)->endPos)
DFU_EXPORT int32
__dfuFileSeekCompress(dfuFile *fp, int32 offset, int32 whence) ;
#define dfuFileSeek(dfp,offset,whence) \
((dfp->flags & dfuFILE_COMPRESS) ?     \
 __dfuFileSeekCompress(dfp,offset,whence):fseek((dfp)->fp,offset,whence))


/****************************************************************************
 * dfuFile reading routines
 */

DFU_EXPORT dfuFile *
dfuFileReadOpen(char *name, FILE *file, int32 flags) ;
DFU_EXPORT int32
dfuFileUnreadChar(dfuFile *fp, int cc) ;
DFU_EXPORT int32
__dfuFileRead(dfuFile *fp, int32 nelem, int32 elsize, void *dest) ;
DFU_EXPORT int32
dfuFileReadChar(dfuFile *fp) ;
DFU_EXPORT int32
dfuFileReadLine(dfuFile *fp, int32 maxLen, char *buf) ;
#define dfuFileRead(fp,size,dest)     __dfuFileRead(fp,size,1,dest)

#define dfuFileRead1byte(fp,dest)     __dfuFileRead(fp,1,1,dest)
#define dfuFileReadN1byte(fp,n,dest)  __dfuFileRead(fp,n,1,dest)
#define dfuFileRead2byte(fp,dest)     __dfuFileRead(fp,1,2,dest)
#define dfuFileReadN2byte(fp,n,dest)  __dfuFileRead(fp,n,2,dest)
#define dfuFileRead4byte(fp,dest)     __dfuFileRead(fp,1,4,dest)
#define dfuFileReadN4byte(fp,n,dest)  __dfuFileRead(fp,n,4,dest)
#define dfuFileRead8byte(fp,dest)     __dfuFileRead(fp,1,8,dest)
#define dfuFileReadN8byte(fp,n,dest)  __dfuFileRead(fp,n,8,dest)

/****************************************************************************
 * dfuFile parsing routines
 */

/* ctable is a bit-field class identifier - where the following bits are used */
#define dfuBIT_WHITE          0x01
#define dfuBIT_TOKSTRT        0x02
#define dfuBIT_TOKEND         0x04
#define dfuBIT_COMMENT        0x08

DFU_EXPORT dfuFile *
dfuFileParseOpen(char *name, FILE *fp, int32 flags, const char *whites,
                 const char *tokStrt, const char *tokEnd, dfuToken *tokens);
/* dfuFileParseAddComment Notes:
 * 1) Any number of comments can be added
 * 2) The comStart and comEnd strings must be a maximum of 2 chars, any more
 *    and it will do a dpgDie!
 * 3) comEnd can be NULL, indicating the comment ends at the end of the line.
 */
DFU_EXPORT void
dfuFileParseAddComment(dfuFile *fp, char *comStart, char *comEnd) ;
DFU_EXPORT char *
dfuFileParseTokenToString(dfuFile *fp) ;
DFU_EXPORT int32
dfuFileUnparseToken(dfuFile *fp);
DFU_EXPORT int32
dfuFileParse(dfuFile *fp);
DFU_EXPORT int32
dfuFileParseToken(dfuFile *fp, int32 token);
DFU_EXPORT int32
dfuFileParseString(dfuFile *fp);
#define dfuFileParseInt32(fptr,num)    dfuFileParseNInt32(fptr,1,num)
DFU_EXPORT int32
dfuFileParseNInt32(dfuFile *fp, int32 n, int32 *num);
#define dfuFileParseUInt32(fptr,num)   dfuFileParseNUInt32(fptr,1,num)
DFU_EXPORT int32
dfuFileParseNUint32(dfuFile *fp, int32 n, uint32 *num);
#define dfuFileParseFloat32(fp,num)    dfuFileParseNFloat32(fp,1,num)
DFU_EXPORT int32
dfuFileParseNFloat32(dfuFile *fp, int32 n, float32 *num);
#define dfuFileParseFloat64(fp,num)    dfuFileParseNFloat64(fp,1,num)
DFU_EXPORT int32
dfuFileParseNFloat64(dfuFile *fp, int32 n, float64 *num);
DFU_EXPORT int32
dfuFileParseToNextChar(dfuFile *fp, uint8 endChr) ;
DFU_EXPORT int32
dfuFileParseToNextLine(dfuFile *fp) ;

/****************************************************************************
 * dfuFile writing routines
 */

DFU_EXPORT dfuFile *
dfuFileWriteOpen(char *name, int32 flags) ;
DFU_EXPORT int32
__dfuFileWrite(dfuFile *fp, int32 nelem, int32 elsize, void *src) ;
#define dfuFileWrite(fp,size,src)     __dfuFileWrite(fp,size,1,src)

#define dfuFileWriteN1byte(fp,n,src)  __dfuFileWrite(fp,n,1,src)
#define dfuFileWriteN2byte(fp,n,src)  __dfuFileWrite(fp,n,2,src)
#define dfuFileWriteN4byte(fp,n,src)  __dfuFileWrite(fp,n,4,src)
#define dfuFileWriteN8byte(fp,n,src)  __dfuFileWrite(fp,n,8,src)

DFU_EXPORT int32
dfuFileWriteInt8(dfuFile *fp, int8 i) ;
DFU_EXPORT int32
dfuFileWriteUint8(dfuFile *fp, uint8 i) ;
DFU_EXPORT int32
dfuFileWriteInt16(dfuFile *fp, int16 i) ;
DFU_EXPORT int32
dfuFileWriteUint16(dfuFile *fp, uint16 i) ;
DFU_EXPORT int32
dfuFileWriteInt32(dfuFile *fp, int32 i) ;
DFU_EXPORT int32
dfuFileWriteFloat32(dfuFile *fp, float32 f) ;
DFU_EXPORT int32
dfuFileWriteFloat64(dfuFile *fp, float64 f) ;

/****************************************************************************
 * dfuFile byte order swapping routines
 */

#define dfu8byteFlip(p) do { \
    char ___t; \
    ___t=p[0]; \
    p[0]=p[7]; \
    p[7]=___t; \
    ___t=p[1]; \
    p[1]=p[6]; \
    p[6]=___t; \
    ___t=p[2]; \
    p[2]=p[5]; \
    p[5]=___t; \
    ___t=p[3]; \
    p[3]=p[4]; \
    p[4]=___t; \
} while (0)

#define dfu4byteFlip(p) do { \
    char ___t; \
    ___t=p[0]; \
    p[0]=p[3]; \
    p[3]=___t; \
    ___t=p[1]; \
    p[1]=p[2]; \
    p[2]=___t; \
} while (0)

#define dfu2byteFlip(p) do { \
    char ___t; \
    ___t=p[0]; \
    p[0]=p[1]; \
    p[1]=___t; \
} while (0)


#ifdef __cplusplus
}
#endif

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif
#endif /* __DFU_h */
