#ifndef _ECASSSEMBLY_UPDATE_FLAGS_H
#define _ECASSSEMBLY_UPDATE_FLAGS_H

/* This header file is needed so that these defines can be used in C files, as
   ecassembly.h (where this stuff was originally defined) is a C++ header file
   and can't be included and compiled by C compilers.

   This was first done so that the ECAssembly_MarkUpdated() function can be
   called in libecapp/object.c to inform anybody with a callback that a
   load/unload has taken place. */

#define ECASSEMBLY_UPDATE_DELETE		0x00000001
#define ECASSEMBLY_UPDATE_MARKDELETED		0x00000002
#define ECASSEMBLY_UPDATE_UNDELETE		0x00000004
#define ECASSEMBLY_UPDATE_FUNCTIONALONLY	0x00000008
#define ECASSEMBLY_UPDATE_ADDATTRIBUTE		0x00000010
#define ECASSEMBLY_UPDATE_REMOVEATTRIBUTE	0x00000020
#define ECASSEMBLY_UPDATE_POSITIONCHANGE	0x00000040
#define ECASSEMBLY_UPDATE_LOAD			0x00000080
#define ECASSEMBLY_UPDATE_UNLOAD		0x00000100

#endif  /* _ECASSSEMBLY_UPDATE_FLAGS_H */
