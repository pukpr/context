#ifndef _DVSW_HH
#define _DVSW_HH

/*****************************************************************************/

typedef enum
{
    dvSwSuccess,
    dvSwFailure

} dvSwRetType;


/*****************************************************************************/

#endif
