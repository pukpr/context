/*
 *    PROJECT:
 *    SUBSYSTEM:
 *    MODULE:
 *
 *    File:         $RCSfile: ecatools.h,v $
 *    Revision:     $Revision: 1.121 $
 *    Date:         $Date: 2002/06/27 16:44:41 $
 *    Author:       $Author: anng $
 *    RCS Ident:    $Id: ecatools.h,v 1.121 2002/06/27 16:44:41 anng Exp $
 *
 *    FUNCTION:
 *
 * Copyright (c) 1992 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _ECATOOLS_H
#define _ECATOOLS_H

#include <stdio.h>
#include <dvise/ectools.h>
#include <dvise/camera.h>

#ifdef __cplusplus
extern "C" {
#endif


typedef void (*ECAssemblyChainFunc)
    (VCBody *body, VCAttribute *attr, ECAssembly *obj,
     void *userData);
typedef int (*ECFileLoadFunc)(char *srcFileName);
typedef int (*ECFileUnloadFunc)();
typedef void (*ECExitFunc)(int exitStatus);


/* WMan struct ECBodyList; */
struct ECBoundaryList;
typedef struct ECAppZone {
    ECColour *backgroundColour;
    float32 *nearClip;
    float32 *farClip;
    ECStateType *state;
    float32 *nearFog;
    float32 *farFog;
    ECColour *fogColour;
    float32 *bodyMotionMin;
    float32 *bodyMotionMax;
    float32 *bodyMotionMinRot;
    float32 *bodyMotionMaxRot;
    float32 *bodyMotionAcc;
    float32 *bodyMotionRotAcc;

    dmPoint *bodyStartupPosition;
    dmEuler *bodyStartupOrientation;
    struct ECBody *bodyList;
    ECZone *ecZone;
    ECAssemblyChain *animatedAssemblys;
    ECAction  *appActions;
    ECItem	        *lightAssemblys;
    ECAssemblyCallbackList *lightAssemblysUpdateCbList;
    VCPseudoGravity *gravity;
    void		*timerHandle;
    int		alarmTick;
    int		clockSet;
    float	realTime;
    float	lastRealTime;
    double	dStartTime;
    struct ECBoundaryList *bndryList;
    struct ECBoundaryList *excludeBndryList;
} ECAppZone;

typedef struct _ECLimbVisualList {
    int priority;
    char *visualName;
    uint32 visId;
    struct _ECLimbVisualList *next;
} ECLimbVisualList;

struct TBselectionList;
typedef struct TBselectionList TBselectionList;

typedef struct ECLimb {
    uint32             selectMode;    /* multiple or single selection */
    void              *selectList;    /* list of selected entities */
    TBselectionList    *TBselection; /* toolbox selection override stuff */
    int                widgetPickOverride; /* widget pick override flag */
    VCEntity *collidedEntity;
    VCEntity *pickedEntity;
    VCEntity *last2dEntity;
    VCBodyPartData *part;
    InstanceNo visualIno;
    ECAssembly *dropAssembly;
    uint32 *dropEvent;
    ECLimbVisualList *visualsList;
    char *defaultVisualName;
    ECItem *visualCache;
    VCAttribute *bodyPart;
} ECLimb;


typedef struct
{
    float32  verts[3][3];
    float32  lines[3][3];
} BNDTRI, *BNDTRI_ptr ;

typedef struct ECBoundary
{
    char           *name;
    int32          noTris;
    BNDTRI_ptr     tris;
    ECZone         *zone;
    struct ECBoundaryList *list;
    ECStateType    state;
} ECBoundary, *ECBoundary_ptr;

typedef struct ECBoundaryList
{
    ECBoundary     *boundary;
    char           *name;
    struct ECBoundaryList *next;
    struct ECBoundaryList *previous;
    uint32         eventId;
    ECAssembly       *object;
    float32        *minHeight;
    float32        *maxHeight;
    uint32         active;
} ECBoundaryList;

typedef struct ECBody {
    ECLimb *limbs;
    /* Boundary Stuff */
    ECBoundary *boundary; /* Current boundary that the body is in */
    int32       triNo;
    float32	terrainHeight;
    dmPoint	prevPos;
    dmPoint	prevExcludePos;

    ECRole *role;		/* the current role */
    VCBody *vcBody;
    void *defaultTool;
    struct ECBody *next;
    struct ECBody *nextInZone;
    void *applicationData;
    int highlightAssemblys;
    int guiPID; /* process id of associated control panel */
    int nowPicking; /* must be TRUE before we can do a pick-release */
    int dontPick;   /* must not be TRUE if we are to do a pick */
    dmDistanceUnit distUnit; /* Unit used for displaying
                             ** distance measurements */

    void        *assemblySelectionList;
    VCAttribute *headlight;
    int lastAssSelByIntersect;
    int          headlightState;
} ECBody;


/* WMan
typedef struct ECBodyList {
  ECBody *body;
  struct ECBodyList *next;
} ECBodyList;
*/

/* PUBLIC DEFINES =======================================*/
#define ECKeepAction 0
#define ECRemoveAction 77
#define EC_DEFAULT_TICK_RATE 20
#define EC_FLASH_SELECT 0
#define EC_FLASH_HLIGHT 1

/* PUBLIC VARIABLES ======================================*/


/* PUBLIC FUNCTIONS ======================================*/
DV_EXPORT void ECDropCallback(VCEntityDrop_CallbackData *callData, void *data);

DV_EXPORT int EC_Noload(void);


/*
 * Version Control
 */

DV_EXPORT void ecappVersion(FILE *);


/*
 * Caveat: Hierarchy processing functions follow the following naming
 *         convention
 *
 *                  EC.....Tree.....() operates on the specified structure
 *                                     and all its children, grandchildren...
 *
 *                                     e.g. ECZoneTree_Disable
 *
 *
 *                  EC.....List.....() operates on the specified structure,
 *                                     all of its peers, and all of its and
 *                                     their children, grandchildren...
 *
 *                                     e.g. ECZoneListDisable
 *
 */

/* ================== WORLD functions ================== */

DV_EXPORT int EC_WorldToVC(void);

/*
 * Converts the ec zone and object structure hierarchy stored within
 * the ec library into VCEntities.
 */
DV_EXPORT int EC_InitialiseWorld(void);
/*
 * Opens the EC_Log file, performs a EC_WorldToVC call to create the VC
 * representation of the previously created ec hierarchy, adds a body
 * create handler, which in turn adds the other (pick, drop etc.) handlers
 * and enables the first defined zone tree, creates an alarm callback
 * based on the ECZone frame rate values and sets up other signal
 * handlers.
 */
DV_EXPORT int EC_WorldSave(char *filename);
/*
 * Calls ECWorldRetrieve and then saves the EC representation in
 * the given filename.  This call disables SIGTERM so that in the
 * event of the application quiting before the save has completed,
 * the signal will be held until the save is complete.
 */
DV_EXPORT char *EC_GetDefAttrFile(void);
DV_EXPORT void EC_SetDefAttrFile(char *filename);
DV_EXPORT int EC_SaveAttributes(char *filename, ECAssembly *root, int dynamicNames, int lmrks);
DV_EXPORT ECFileLoadFunc ECSet_FileLoadFunc(ECFileLoadFunc newFunc);
DV_EXPORT ECFileUnloadFunc ECSet_FileUnloadFunc(ECFileUnloadFunc newFunc);
DV_EXPORT int ECSSP_File_Load(char *srcFileName);
DV_EXPORT int ECSSP_File_Unload();
DV_EXPORT int ECFile_Load(char *filename);
DV_EXPORT int ECFile_Unload(void);
DV_EXPORT int ECFile_New(void);
DV_EXPORT int ECFile_SearchPathToVC(ECFile *f);

DV_EXPORT int EC_MaterialLibraryToVC(ECLibrary *library);
/* just loads a material library to vc */

DV_EXPORT void EC_Exit(int exitstatus);
DV_EXPORT ECExitFunc ECSet_ExitFunc(ECExitFunc newFunc);

/* ================== ZONE based functions ================== */

DV_EXPORT int ECArgReference_GetZone(ECArgReference *, ECZone **, ECItem *);
DV_EXPORT ECAppZone *ECZone_GetAppZone(ECZone *zone);
DV_EXPORT int ECZone_ChangeState(ECZone *zone, ECStateType state);
DV_EXPORT ECZone *ECAppZone_GetZone(ECAppZone *zone);
DV_EXPORT int ECAppZone_SetZone(ECAppZone *appZone, ECZone *zone);
DV_EXPORT int32 ECAppZone_Destroy(ECAppZone *);
DV_EXPORT ECAction *EC_FindActionToStop(char *actName, ECAssembly *obj);

DV_EXPORT int ECZone_GenerateAppEvents(ECZone *zone);
/* Generate the app events (for self-animating action functions */
DV_EXPORT uint32 ECZone_AddTimerCallback(ECZone *);

/* Backwards compatible zone background colour/bodyPosition calls */
DV_EXPORT int ECBody_SetPositionFromZone(VCBody *body, ECZone *zone);
/* Startup zone positions */
DV_EXPORT int ECZone_SetBodyStartupPosition(ECZone *zone, dmPoint point);
DV_EXPORT int ECZone_GetBodyStartupPosition(ECZone *zone, dmPoint point);
/* Startup zone orientations */
DV_EXPORT int ECZone_SetBodyStartupOrientation(ECZone *zone, dmEuler euler);
DV_EXPORT int ECZone_GetBodyStartupOrientation(ECZone *zone, dmEuler euler);
/* Startup zone background colours */
DV_EXPORT int ECZone_SetBodyStartupBackgroundColour(ECZone *zone, ECColour *colour);
DV_EXPORT int ECZone_GetBodyStartupBackgroundColour(ECZone *zone, ECColour **colour);
/* Startup zone clip planes */
DV_EXPORT int ECZone_SetBodyStartupClipPlanes(ECZone *zone, float32 *nearVar, float32 *farVar);
DV_EXPORT int ECZone_GetBodyStartupClipPlanes(ECZone *zone, float32 **nearVar, float32 **farVar);
/* Startup zone fog details */
DV_EXPORT int ECZone_SetBodyStartupFog(ECZone *zone, ECStateType *state, float32 *nearVar, float32 *farVar, ECColour *colour);
DV_EXPORT int ECZone_GetBodyStartupFog(ECZone *zone, ECStateType **state, float32 **nearVar, float32 **farVar, ECColour **colour);
/* Startup zone motion details */
DV_EXPORT int ECZone_SetBodyStartupMotion(ECZone *zone, float32 *bodyMotionMin, float32 *bodyMotionMax,
                                       float32 *bodyMotionMinRot, float32 *bodyMotionMaxRot,
                                       float32 *bodyMotionAcc, float32 *bodyMotionRotAcc);
DV_EXPORT int ECZone_GetBodyStartupMotion(ECZone *zone, float32  **bodyMotionMin, float32 **bodyMotionMax,
                                       float32 **bodyMotionMinRot, float32 **bodyMotionMaxRot,
                                       float32 **bodyMotionAcc, float32 **bodyMotionRotAcc);
/* Bouondary functions */
DV_EXPORT ECBoundaryList *ECZone_GetBoundaryList(ECZone *zone);
DV_EXPORT ECZone *ECBoundary_GetZone(ECBoundary *bndry);
DV_EXPORT int ECZone_AddBoundary(ECZone *, ECBoundaryList *);
DV_EXPORT ECBoundary *ECZone_FindBoundary(ECZone *zone, char *name);
DV_EXPORT int ECZone_RemoveBoundary(ECZone *zone, char *name);
/* Exclude bouondary functions */
DV_EXPORT ECBoundaryList *ECZone_GetExcludeBoundaryList(ECZone *zone);
DV_EXPORT int ECZone_AddExcludeBoundary(ECZone *, ECBoundaryList *);
DV_EXPORT int ECZone_RemoveExcludeBoundary(ECZone *zone, char *name);


DV_EXPORT int ECBody_SetBackgroundColourFromZone(VCBody *body, ECZone *zone);

/* ======================= App Zone functions ====================== */


DV_EXPORT int ECZone_AddAnimateAction(ECZone *zone, ECEvent *event, ECAction *a);
/* Adds func to the list of functions called whenever
   the event of given type is generated. */
DV_EXPORT ECAction *ECZone_FindAnimateAction(ECZone *zone, char *name, char *argName, void *data);
DV_EXPORT int ECZone_RemoveAnimateAction(ECZone *zone, ECAction *action);
DV_EXPORT int ECZone_ChangeTickRate(ECZone *zone, float rate);
DV_EXPORT int ECZone_AddLightAssembly(ECZone *zone, ECAssembly *o);
DV_EXPORT int ECZone_AddLightAssemblysUpdateCallback(ECZone *zone,
                                               ECAssemblyCallbackPtr callback,
                                               void *calldata);
DV_EXPORT int ECZone_RemoveLightAssemblysUpdateCallback(ECZone *zone,
                                           ECAssemblyCallbackPtr callback,
                                           void *calldata);
DV_EXPORT int EC_ZoneRemoveAllLightAssemblysUpdateCallbacks(ECZone *zone);
DV_EXPORT int ECZone_RemoveLightAssembly(ECZone *zone, ECAssembly *o);
DV_EXPORT ECItem *ECZone_GetLightAssemblys(ECZone *zone);
DV_EXPORT int ECZone_RemoveEventAssemblyReferences(ECZone *zone, ECAssembly *obj, int eventId);

DV_EXPORT ECAssembly *ECAppAssembly_GetFirst(ECAssembly_Traverse *trav);
DV_EXPORT ECAssembly *ECAppAssembly_GetNext(ECAssembly_Traverse *trav);
DV_EXPORT int ECAppAssembly_ChangeState(ECAssembly *appAssembly, ECStateType state);


/* ================== BODY based functions ================== */

DV_EXPORT VCBody *ECBodyGetVCBody(ECBody *body);
DV_EXPORT ECRole *ECBody_AssignRole(VCBody *body);
/* Assigns roles defined either on the command line or the default role */
DV_EXPORT ECZone *ECBody_GetZone(VCBody *body);
DV_EXPORT ECAssembly *ECBody_GetAppAssembly(VCBody *body);
DV_EXPORT ECBoundary *ECBody_GetBoundary(VCBody *body);
DV_EXPORT int ECBody_SetBoundary(VCBody *body, ECBoundary *boundary);
DV_EXPORT int ECBody_GetDistanceUnit(VCBody *body, dmDistanceUnit *unit);
DV_EXPORT int ECBody_SetDistanceUnit(VCBody *body, dmDistanceUnit unit);
DV_EXPORT int32 ECBody_GetTriNo(VCBody *body);
DV_EXPORT int ECBody_SetTriNo(VCBody *body, int32 triNo);
DV_EXPORT float32 ECBody_GetTerrainHeight(VCBody *body);
DV_EXPORT int ECBody_SetTerrainHeight(VCBody *body, float32 terrainHeight);
DV_EXPORT int ECBody_GetPrevPos(VCBody *body, dmPoint point);
DV_EXPORT int ECBody_SetPrevPos(VCBody *body, dmPoint prevPos);
DV_EXPORT int ECBody_GetPrevExcludePos(VCBody *body, dmPoint point);
DV_EXPORT int ECBody_SetPrevExcludePos(VCBody *body, dmPoint prevExcludePos);
DV_EXPORT ECRole *ECBody_GetRole(VCBody *body);
void *ECBodyGetTool(VCBody *body);
DV_EXPORT void *ECBody_GetToolBox(VCBody *body);
DV_EXPORT int ECBody_SetToolBox(VCBody *body, void *toolbox);
DV_EXPORT int ECBody_SetApplicationData(VCBody *body, void *applicationData);
DV_EXPORT int ECBody_EnterZone(VCBody *body, ECZone *ecZone);
DV_EXPORT int ECBody_LeaveZone(VCBody *body, ECZone *ecZone);
/* Used by the toolbox to store the current active tool */
DV_EXPORT void *ECBody_GetApplicationData(VCBody *body);
/* Used by dvise to get the current active tool */
/* Any of the vectors can be NULL */
DV_EXPORT int ECBody_GetPosition(VCBody *body, dmPoint pos, dmEuler euler, dmScale s);
/* Fills any of the three vectors which are not null pointers. */
DV_EXPORT int ECBody_SetBackgroundColour(VCBody *body, ECColour *col);
DV_EXPORT int ECBody_SetHeadlight(ECBody *, int);
DV_EXPORT int ECBody_GetHeadlightState(ECBody *body);
DV_EXPORT int ECBody_GetLastAssSelByIntersect(ECBody *body);
DV_EXPORT int ECBody_SetLastAssSelByIntersect(ECBody *body, int selByInter);
DV_EXPORT int ECLimb_GetPosition(VCBody *body, VCAttribute *bodyPartAttribute,
                              dmPoint pos, dmEuler rot, dmScale s);
DV_EXPORT void ECLimb_DisableContextSensitive(void);
DV_EXPORT uint32 ECLimb_SetVisual(VCAttribute *limbAttr, char *visualName, short priority);
DV_EXPORT int ECLimb_UnsetVisual(VCAttribute *limbAttr, uint32 handle);

DV_EXPORT VCAttribute *ECBody_FindNamedBodyPart(VCBody *body, char *name);
DV_EXPORT void ECBody_ToggleHighlight(VCBody *body);
DV_EXPORT ECAssemblyChain *ECLimb_GetAssemblyChains(VCAttribute *bodyPartAttribute);
DV_EXPORT ECAssemblyChain *ECLimb_GetNamedAssemblyChain(VCAttribute *bodyPartAttribute,
						char *name);
DV_EXPORT int ECLimb_RemoveNamedAssemblyChain(VCAttribute *bodyPartAttribute,
					char *name);
/* Removes the named chain from the body limb's list and destroys it.
 * Returns 1 if the named chain was found and removed, 0 if not.
 */
DV_EXPORT int ECLimb_SetAssemblyChains(VCAttribute *bodyPartAttribute,
				 ECAssemblyChain *chain);
DV_EXPORT ECBody *ECBody_GetFromVC(VCBody *body);
DV_EXPORT ECBody *EC_FindBodyFromName(char *name);
DV_EXPORT ECLimb *ECLimb_GetFromVC(VCAttribute *bodyPartAttribute);
DV_EXPORT int ECLimb_SetFromVC(VCAttribute *bodyPartAttribute, ECLimb *limb);
DV_EXPORT int EC_DropAssembly(ECAssembly *pAss, VCAttribute *pBodyPart);

/* get/set the master body which defines for which body EC_ASSEMBLY_MASTER_SELECTED applies. */
DV_EXPORT void EC_SetMasterBody(VCBody *body);
DV_EXPORT VCBody *EC_GetMasterBody(void);

/* ================== OBJECT based functions ================== */

/* Get the relevant ECAssembly from the VCEntity equvalent. */
DV_EXPORT ECAssembly *ECAssembly_GetFromVCEntity(VCEntity *hnode);

DV_EXPORT int ECAssembly_ViewEnable(ECAssembly *);
DV_EXPORT int ECAssembly_ViewDisable(ECAssembly *);
DV_EXPORT int ECAssembly_Enable(ECAssembly *);
DV_EXPORT int ECAssembly_Disable(ECAssembly *);
DV_EXPORT int ECAssembly_DisableLeaveLights(ECAssembly *);
DV_EXPORT int ECAssembly_Load(ECAssembly *);
DV_EXPORT int ECAssembly_UnloadLeaveLights(ECAssembly *);
DV_EXPORT int ECAssembly_Unload(ECAssembly *);
DV_EXPORT int ECAssembly_Select(ECAssembly *, VCBody *, VCAttribute *);
DV_EXPORT int ECAssembly_Deselect(ECAssembly *, VCBody *, VCAttribute *);
DV_EXPORT int ECAssembly_ViewEnable(ECAssembly *);
DV_EXPORT int ECAssembly_ViewDisable(ECAssembly *);
DV_EXPORT int ECAssembly_Touch(ECAssembly *, VCBody *, VCAttribute *, int);
DV_EXPORT int ECAssembly_Untouch(ECAssembly *, VCBody *, VCAttribute *);
DV_EXPORT int ECAssembly_Pick(ECAssembly *, VCBody *, VCAttribute *, int);
DV_EXPORT int ECAssembly_Drop(ECAssembly *, VCBody *, VCAttribute *);
DV_EXPORT int ECAssembly_RemoveFromFuncView(ECAssembly *a);
DV_EXPORT int ECAssembly_Undelete(ECAssembly *ass);

DV_EXPORT ECAssembly *ECAssemblyReference_GetAssembly(ECAssemblyReference *objectReference,
					    VCBody *body,
					    ECAssembly *defaultAssembly);
/* Support for the object parameter type for action functions.
 * Finds the object refered to by name in the object reference structure.
 * This function assumes that if the object reference structure already has
 * an object value then that value is still valid so if used to reference
 * an object which has been deleted will return a pointer to the freed
 * memory area.  Hence if the object is ever going to be deleted then
 * this parameter type should not be used.
 */
DV_EXPORT ECAssembly *ECAssembly_GetFromFocus(char *name, ECItem *focus);
DV_EXPORT int ECArgReference_GetAssembly(ECArgReference *, ECAssembly **, ECItem *);
DV_EXPORT ECAssembly *ECReferenceAssembly(ECAssemblyReference *objectRef, ECItem *focus);
DV_EXPORT ECAssembly *ECBody_FindNamedAssembly(char *name, ECAssembly *orig,
					  VCBody *body);
/* Looks for an object with the given name within a zone enabled by the
 * given body.  Checks the object orig first for a name match.
 */
DV_EXPORT int ECAppAssembly_Create(ECAssembly *object);
DV_EXPORT int ECAppAssembly_Destroy(ECAssembly *object);
/* As ECAssembly_Destroy but also removes the object from any animation
 * lists, parent or zone as well as destroying all vc structures.
 */
DV_EXPORT int ECAppAssemblyTree_Destroy(ECAssembly *object);
/* As ECAssembly_Destroy but also removes the object from any animation
 * lists, parent or zone as well as destroying all vc structures
 * and does the same for all children
 */
DV_EXPORT int ECAssembly_RemoveAnimateActions(ECAssembly *object);
DV_EXPORT int ECAssembly_EnableVisuals(ECAssembly *ec_object);
/* Will only enable visual if the EC state is correct */
DV_EXPORT int ECAssembly_EnableLights(ECAssembly *ec_object);
/* Will only enable if the EC state is correct */
DV_EXPORT int ECAssembly_EnableCollisions(ECAssembly *ec_object);
DV_EXPORT int ECAssemblyAddCollideHandler(ECAssembly *ec_object);
/* Will only enable if the EC state is correct */
DV_EXPORT int ECAssembly_SetLightsVCState(ECAssembly *object, ECStateType state);
/*
 * Turns the VCLight(s) connected to the ECAssembly on or off
 */
DV_EXPORT int ECAssembly_SetVisualsVCState(ECAssembly *ec_object, ECStateType state);
/*
 * Turns the VCVisual(s) connected to the ECAssembly on or off
 */
DV_EXPORT int ECAssembly_SetCollisionsVCState(ECAssembly *ec_object, ECStateType state);

/*
 * Handles the touch interaction between a limb and an ECAssembly.
 */
int ECAssemblyTouch(ECAssembly *ecObj, VCBody *body, VCAttribute *limb);
int ECAssemblyUntouch(ECAssembly *ecObj, VCBody *body, VCAttribute *limb);
void ECAssembly_Flash(ECAssembly *ecObj, int type, VCBody *body);
void ECAssembly_StopFlash(ECAssembly *ecObj, int type);
int ECAssembly_SetIntersectData(ECAssembly *assembly, float32 *data);
float32 * ECAssembly_GetIntersectData(ECAssembly *assembly);

DV_EXPORT int ECAnimatedAssemblyUpdate(ECAssembly *obj);
/* also DV_EXPORT int EC_WorldToVC(void); as above */
DV_EXPORT int ECZone_ToVC(ECZone *zone);
DV_EXPORT int ECAssemblyList_ToVC(ECAssembly *assemblyList);
DV_EXPORT int ECAssembly_ToVC(ECAssembly *object);
DV_EXPORT int ECAssembly_SendLightsToVC(ECAssembly *object);
DV_EXPORT int ECAssembly_SendConstraintsToVC(ECAssembly *object);
DV_EXPORT int ECAssembly_SendItemListToVC(ECAssembly *ecAssembly);
DV_EXPORT int ECAssembly_RemoveFromVC(ECAssembly *object);
DV_EXPORT int ECAudio_ToVC(ECAssembly *, ECAudio *);
DV_EXPORT int ECAudio_RemoveFromVC(ECAudio *);
DV_EXPORT int ECVisual_ToVC(ECAssembly *, ECVisual *);
DV_EXPORT int ECVisual_RemoveFromVC(ECVisual *);
DV_EXPORT int ECSect_ToVC(ECAssembly *) ;
DV_EXPORT int ECLight_ToVC(ECAssembly *, ECLight *);
DV_EXPORT int ECLight_RemoveFromVC(ECLight *);
DV_EXPORT int ECConstraints_ToVC(ECAssembly *, ECConstraints *);
DV_EXPORT int ECConstraints_RemoveFromVC(ECConstraints *);
DV_EXPORT char *ECSetVariable_ForIncludeNode(ECAssembly *incNode);

/* Assembly movement procedures.
 *
 * For each of the folowing procedures to work the ECAssembly passed
 * should have previously been converted to VC using ECAssembly_ToVC.

 * ECAssemblyEpdateVCPosition will move the VCAssembly to the position
 * specified by the position information within the ECAssembly.
 *
 * ECAssembly_GetDMPosition extracts the ECAssembly's positional information
 * and stores it in the DMPosition structure passed by pointer.
 *
 * ECAssemblyPositionSetInVC allows the application to move an object within
 * VC without changing the ECAssembly structure.
 */
DV_EXPORT int ECAssembly_UpdateVCPosition(ECAssembly *ec_object);
DV_EXPORT int ECAssembly_SendPositionToVC(ECAssembly *ec_object);
/* Update VCPosition of this object if it differs from the ec position
 * unless the object has a keyframes section */
DV_EXPORT int ECAssembly_ForcedUpdateVCPosition(ECAssembly *ec_object);
/* as above but even if it has a keyframes section */
DV_EXPORT int ECAssembly_GetDMPosition(ECAssembly *ec_object, dmPosition *position);
DV_EXPORT int ECPosition_GetDMPosition(ECPosition *, dmPosition *);
DV_EXPORT int ECPosition_GetDMPoint(ECPosition *, dmPoint);
DV_EXPORT int ECPosition_GetDMEuler(ECPosition *, dmEuler);
DV_EXPORT int ECPosition_GetDMScale(ECPosition *, dmScale);
/* Updates EC structures from current vc position */
DV_EXPORT int ECCollision_ToVC(ECAssembly *ec_object, ECCollision *ec_collision);
DV_EXPORT int ECCollision_RemoveFromVC(ECCollision *);
DV_EXPORT int ECCollisionGeometry_ToVC(ECAssembly *ec_object, ECCollision *ec_collision, char *geometry);
DV_EXPORT int ECAssembly_SetPosFromBody(ECAssembly *a, VCBody *body);
DV_EXPORT int ECAssembly_Snap(ECAssembly *object);
/* Causes the (supposedly recently moved) object to be snapped to
 * a grid position and orientation if one is defined in the ECAssembly
 */
DV_EXPORT ECUserData *ECCollision_DoEventUD(dmVector pnt, dmVector nrml);
DV_EXPORT void ECCollision_GetEventData(ECUserData *ud, dmVector pnt, dmVector nrml);

/* ================== ECAssembly data recovery From VC functions ================== */
/*
 * These functions recover object attributes from VC and
 * match up the ECAssembly(s) to them. ECAssembly_FromVC calls
 * all other ECAssembly***FromVC functions. Any functions like
 * EC***FromVC apply to that ECItemType only and are used
 * from within their ECAssembly***FromVC counterparts.
 */
DV_EXPORT int ECAssembly_FromVC(ECAssembly *object);
DV_EXPORT int ECAssembly_GetPositionFromVC(ECAssembly *ec_object);
DV_EXPORT int ECAssembly_GetConstraintsFromVC(ECAssembly *);
DV_EXPORT int ECAssembly_GetLightsFromVC(ECAssembly *ec_object);
DV_EXPORT int ECConstraints_GetFromVC(ECConstraints *);
DV_EXPORT int ECLight_FromVC(ECLight *ec_light);

/* ================== General conversion functions ================== */

DV_EXPORT int ECColourToVC(ECColour *col, VCColour vcc);
DV_EXPORT int ECMaterial_ToVC(ECMaterial *mat);
DV_EXPORT int ECTexture_ToVC(ECTexture *txtr);
DV_EXPORT int ECVector_ToDMPoint(ECVec3 *vec, dmPoint vcp);
DV_EXPORT int ECVector_ToDMScale(ECVec3 *vec, dmScale vcs);
DV_EXPORT int ECVector_ToDMEuler(ECVec3 *vec, dmEuler vco);
DV_EXPORT int ECVector_FromDMPoint(ECVec3 *vec, dmPoint);
DV_EXPORT int ECVector_FromDMScale(ECVec3 *vec, dmScale);
DV_EXPORT int ECVector_FromDMEuler(ECVec3 *vec, dmEuler);
DV_EXPORT int ECAssemblyExtractAbsolutePosition(ECAssembly *ecAssembly,
				     float *ecPos,
				     float *ecOr,
				     float *ecScale);
/* Returns the ABSOLUTE position of the object as stored in VC.
 * Fills each of the ECVec3 parameters which are not null pointers. */
DV_EXPORT int ECAssemblyInjectAbsolutePosition(ECAssembly *ecAssembly,
				     float *ecPos,
				     float *ecOr,
				     float *ecScale);
/* First extracts the current position, orientation and scale,
 * then sets the position, orientation and scale according to
 * each of the parameters which are set.
 */
DV_EXPORT int ECAssemblyInjectRelativePosition(ECAssembly *ecAssembly,
				   float *pos, float *euler, float *scale);
/* First extracts the current position, orientation and scale,
 * then sets the relative position, orientation and scale according to
 * each of the parameters which are set.
 */
DV_EXPORT int ECAssemblyExtractRelativePosition(ECAssembly *ecAssembly,
				    float *pos, float *euler, float *scale);
/* Returns the RELATIVE position of the object as stored in VC.
 * Fills each of the ECVec3 parameters which are not null pointers. */
DV_EXPORT int ECAssembly_UpdatePositionFromVC(ECAssembly *object);
/* Will update the ECAssembly's (possibly relative) position value
 * from the current position within VC.
 */
DV_EXPORT int ECAssembly_AddAbsoluteChild(ECAssembly *parent, ECAssembly *child);
/* Adds the given child to a parent using the child's current absolute
 * VCPosition.  The normal ECAssembly_AddChild uses the EC positional info
 * as the relative position to the new parent.
 */
DV_EXPORT int ECAssembly_RemoveAbsoluteChild(ECAssembly *parent, ECAssembly *child);
/* As ECAssembly_RemoveChild except that the child's positional information
 * is corrected so that its absolute position remains constant.
 */

/* ================== SELECTION functions ================== */

DV_EXPORT void *ECLimb_SetSelectFuncs(VCBody *body, VCAttribute *,
                          ECAssemblyChainFunc selectCallback,
                          ECAssemblyChainFunc unselectCallback,
                          ECAssemblyChainFunc touchCallback,
                          ECAssemblyChainFunc untouchCallback,
                          ECAssemblyChainFunc select_2D_Callback,
                          ECAssemblyChainFunc unselect_2D_Callback,
                          ECAssemblyChainFunc touch_2D_Callback,
                          ECAssemblyChainFunc untouch_2D_Callback,
                          void *userData);
/* Causes a single object to be selected (by picking) and returned
 *to the given callback */
DV_EXPORT int ECLimb_UnsetSelectFuncs(VCBody *body, VCAttribute *, void *handle);
DV_EXPORT VCEntity * ECPickedEntity_Get(VCAttribute *bodyPartAttribute);
DV_EXPORT int ECPickedEntitySet(VCAttribute *bodyPartAttribute, VCEntity * e);
DV_EXPORT int ECForceToolBoxDrop(VCAttribute *bodyPartAttribute, VCBody *body, ECAssembly *assembly);
DV_EXPORT int ECForceToolBoxTouch(VCAttribute *bodyPartAttribute, VCBody *body, ECAssembly *assembly);
DV_EXPORT int ECForceToolBoxDrop_2D(VCAttribute *bodyPartAttribute, VCBody *body, ECAssembly *assembly);
DV_EXPORT int ECForceToolBoxTouch_2D(VCAttribute *bodyPartAttribute, VCBody *body, ECAssembly *assembly);
DV_EXPORT int ECForceToolBoxPick(VCAttribute *bodyPartAttribute, VCBody *body, ECAssembly *assembly);

#ifdef HACKED_OUT
DV_EXPORT int32 ECAssemblyChain_Select(VCBody *body, VCAttribute *bodyPartAttribute,
				 char *name,
				 ECAssemblyChainFunc	selectionCallback,
				 ECAssemblyChainFunc	deselectionCallback,
				 ECAssemblyChainFunc	touchCallback,
				 ECAssemblyChainFunc	untouchCallback,
				 void *userData);
/* Causes object picking to add the selected object to an object list.
 * If name matches a current object list name for the given body and limb
 * then the objects are added to the named list, if the list does not exist
 * it is created and if the name passed was null a default name
 * "selectionList" is used.  If a callback function is specified then each
 * time an object is added to the list the callback function is called.
 * Similarly, the deselection callback is called when an item is removes from
 * the list, which occurs on double selection.  The userData field is passed
 * back to each of the callbacks.
 */
DV_EXPORT int ECAssemblyChain_EndSelect(VCBody *body, VCAttribute *);
/* Causes any selection specified by a call to ECAssemblyChain_Select for
 * the given body and limb to be terminated.
 */
#endif                                  /* HACKED_OUT */

/* ================= SIGNAL based functions ================= */

DV_EXPORT int ECDisableAlarm(void);

/* ===================== Audio functions ==================== */

DV_EXPORT int ECAssemblySetAudiosVCState(ECAssembly *ec_object, ECStateType state);
DV_EXPORT int ECAssembly_EnableAudios(ECAssembly *ec_object);

/* ========== VC structure and reference functions ========== */

/* The following functions can be used to retreive local vc structures
 * and instance numbers so that the application can alter the vc database
 * directly using VCSetXxxx.
 */
DV_EXPORT VCAttribute *ECAssembly_GetVCAudio(ECAssembly *ec_object);
/* DV_EXPORT int ECAssemblyGetVCLight(ECAssembly *ec_object, ECLight *ec_light,
			      VCLight **vc_light, InstanceNo *ino); */
/* DV_EXPORT int ECAssemblyGetVCBoundary(ECAssembly *ec_object,
				     ECCollision *ec_collision,
				     VCBoundary **vc_boundary,
				     InstanceNo *ino); */

/* ================= Miscellaneous functions ================ */

DV_EXPORT int ECArgumentsParse(int *argc, char **argv, char *agentName);
DV_EXPORT int EC_ReferencesComplete(void);
/* Complete action function references for all the zones in the world */
/* turn animation on or off */
DV_EXPORT float ECTime(void);
/* Returns the time (seconds) since animation events began. */
DV_EXPORT float32 ECZone_GetTime(ECZone *zone);
DV_EXPORT int ECAlarmSet(void);
DV_EXPORT int EC_ResetTime(float time);
/* Resets internal values so that it appears
 * that the time is now the value passed here.
 */
DV_EXPORT int EC_ToolboxEnabled(void);
DV_EXPORT char *EC_ToolboxGetDefaultFile(void);
/* If 0 toolbox is disabled */
DV_EXPORT int EC_Logging(void);
DV_EXPORT char *EC_GetAppName(void);
DV_EXPORT char *EC_GetIDPFileName(int, int *);
/* Returns the name of the application (i.e. dvise) */
DV_EXPORT char *EC_ConvertMessageString(ECEvent *event, ECEventData *data, char *message);
DV_EXPORT int EC_PrintEventMessage(ECEvent *event, ECEventData *data, ECAction *action);
DV_EXPORT int EC_PrintMessage(char *message, ...);
DV_EXPORT int EC_HandlersCheckLastCollide(ECAssembly *);
DV_EXPORT VCVisualViewResource *ECVisView_FindForBody(VCBody *bod);
DV_EXPORT int ECDelayedEvent_Add(int eventId, ECItem *focus, float delay, void **handle, ECEventData *data);
DV_EXPORT int ECDelayedEvent_Remove(void *handle);
DV_EXPORT int EC_GetHlightFlag(void);
DV_EXPORT int EC_GetQuietFlag(void);
DV_EXPORT int EC_GetTimingFlag(void);
DV_EXPORT int EC_GetDynamicLicenseingFlag(void);
DV_EXPORT int32 EC_OrthographicOn(VCBody *body);
DV_EXPORT void dVISE_SetRendererOptions(VCBody *b, VCAttribute *a, ECUserData *options);
DV_EXPORT void dVISE_QueryRendererOptions(VCBody *b, ECUserData *qryOpts);
DV_EXPORT ECUserData *dVISE_ConstructRendOptsQry(char *name, ...);
DV_EXPORT void EC_GetCamGroupState(int *recState, int *replState);
DV_EXPORT void EC_SetCamGroupState(int recState, int replState);
DV_EXPORT void toggleOrthographic(VCBody *body);
DV_EXPORT int EC_Preload(void);
DV_EXPORT int EC_Noload(void);
DV_EXPORT void EC_SetPreload(int);
DV_EXPORT void EC_SetNoload(int);
DV_EXPORT void EC_GetSyncInfo( char **actorName, char **actorType);

/* =================== DCI Link Functions ================== */

DV_EXPORT int ECClientSetSelectionMode(uint32 mode);
DV_EXPORT uint32 ECClient_GetSelectionMode(void);
DV_EXPORT int ECClient_SelectAssembly(ECAssembly *object);
DV_EXPORT int ECClient_UpdateUserEventList(void);
DV_EXPORT void ECClient_SecureClipboards(void);
DV_EXPORT void ECClient_DeleteClipboards(void);

/* ====================Boundary calculating Functions  =============== */

#define BIZIDstrLen     31
#define BIZ_PATCH       34
#define BIZ_STRIP       35
#define BIZ_TRISTRIP     0
#define BIZ_POLYSTRIP    1
#define BIZ_DONE        37

#define BND_BODY_PART    VC_HEAD

DV_EXPORT ECBoundary_ptr BIZgetFile(char *name);
DV_EXPORT void setup_boundary_paths();
DV_EXPORT int32 BND_testInTriangle(BNDTRI_ptr tri, float32 *point);
DV_EXPORT int32 BND_testBoundary(ECBoundary_ptr bound, float32 *point);
DV_EXPORT float32 BND_calcBodyHeight(BNDTRI_ptr tri, dmPoint p);
DV_EXPORT void BND_calcNewBodyPosition(dmPoint p, BNDTRI_ptr tri);

/* ============== UserRole Dlg and Navigation Dlg function prototypes =================== */
DV_EXPORT char *ECBody_GetList(void);
DV_EXPORT int ECBody_GetAbsolutePointFromRelative(VCBody *body, dmPoint relPos, dmPoint *retPoint);
DV_EXPORT int ECBody_GetAbsoluteEulerFromRelative(VCBody *body, dmEuler relEuler, dmEuler *retEuler);


DV_EXPORT void ECBody_SelectAssembly(ECBody *body, ECAssembly *assembly);
DV_EXPORT void ECBody_DeSelectAssembly(ECBody *body, ECAssembly *assembly);
/* ======================= Reset position stuff ====================== */

DV_EXPORT void ECReset_Store(ECItem *assList, int useTree);
DV_EXPORT void ECReset_RestorePosition(ECItem *assList, int useTree);
DV_EXPORT void ECReset_RestoreState(ECItem *assList, int useTree);
DV_EXPORT void ECReset_RestoreHierarchy(ECItem *assList, int useTree);
DV_EXPORT void ECReset_CopyInfo(ECAssembly *fromAss, ECAssembly *toAss);

/* ================ Turn on/off Pick and Touch Mode ================= */

DV_EXPORT void EC_PickEnable(void);
DV_EXPORT void EC_PickDisable(void);
DV_EXPORT void EC_TouchEnable(void);
DV_EXPORT void EC_TouchDisable(void);
DV_EXPORT int32 EC_TouchOn(void);
DV_EXPORT int32 EC_PickOn(void);

/* Animation control. */
DV_EXPORT void EC_PauseAnimations(void);
DV_EXPORT void EC_ContinueAnimations(void);

/* =============== Bodge since timers dont work in dvisegui ===============*/
DV_EXPORT void ECAttachDelayedRelocateHandlers();

#ifdef __cplusplus
}
#include "ecatoolsxx.h"
#endif /* _cplusplus */
#endif /*_ECATOOLS_H */
