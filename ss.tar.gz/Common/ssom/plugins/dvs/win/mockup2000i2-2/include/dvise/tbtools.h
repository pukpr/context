/*
 *    PROJECT:
 *    SUBSYSTEM:
 *    MODULE:
 *
 *    File:         $RCSfile: tbtools.h,v $
 *    Revision:     $Revision: 1.45 $
 *    Date:         $Date: 2000/05/08 17:41:47 $
 *    Author:       $Author: jeff $
 *    RCS Ident:    $Id: tbtools.h,v 1.45 2000/05/08 17:41:47 jeff Exp $
 *
 *    FUNCTION: generic tool include
 *
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _TBOX_H_
#define _TBOX_H_

#include <dvise/dvexport.h>
#include <stdio.h>
#include <dvs/vc.h>
#include <dsys/parser.h>
/* simon 5/12/97 changed to use the ec parser 
#include <dvise/ec_parser.h>
*/
#include <dvise/ecatools.h>
#include <dvise/event.h>
#include <dvs/vgtools.h>
#include <dvs/vwidgets.h>
#include "tbtypes.h"


#ifdef __cplusplus
extern "C" {
#endif

#define TB_DEBUG_LOW 0x1000
#define TB_DEBUG_HIGH 0x800

#define TB_AUDIO_ENV "DV_TOOLBOX_AUDIO"
#define TB_LEFTHAND_NAME "leftHand"     
    

/*
 * levels of error for tbmanager
 */
#define TB_DELETED -1
#define TB_NOERROR 0
#define TB_TOOL_INVALID 1
#define TB_TOOL_RESET 2
#define TB_TOOL_RECREATE 3
#define TB_TOOL_DESTROY 4
#define TB_TOOLBOX_INVALID 5
#define TB_TOOLBOX_RESET 6
#define TB_TOOLBOX_RECREATE 7
#define TB_TOOLBOX_DESTROY 8

/*****************************************************************
 * ToolBox & Tool manager functions
****************************************************************/

DV_EXPORT void TBManager_Create(void);
DV_EXPORT void TBManager_Destroy(void);
    
DV_EXPORT void TBManager_AddTool(TBTool *tool_PO);
DV_EXPORT void TBManager_RemoveTool(TBTool *tool_PO);
DV_EXPORT int TBManager_CheckTool(TBTool *tool_PO);
DV_EXPORT int TBManager_ErrorTool(TBTool *tool_PO,int level_I);
DV_EXPORT void TBManager_ToolDeleted(TBTool *tool_PO);

DV_EXPORT void TBManager_AddToolBox(TBToolBox *toolBox_PO);
DV_EXPORT void TBManager_RemoveToolBox(TBToolBox *toolBox_PO);
DV_EXPORT int TBManager_CheckToolBox(TBToolBox *toolbox_PO);
DV_EXPORT int TBManager_ErrorToolBox(TBToolBox *toolbox_PO,int level_I);
DV_EXPORT void TBManager_ToolBoxDeleted(TBToolBox *toolBox_PO);

/******************************************************************
 * ToolBox Functions
******************************************************************/

DV_EXPORT char *TBToolBox_GetName(TBToolBox *toolbox);
DV_EXPORT VCBody *TBToolBox_GetBody(TBToolBox *toolbox);
DV_EXPORT TBBodyPart *TBToolBox_GetDefaultBodyPart(TBToolBox *toolbox);
DV_EXPORT TBBodyPart *TBToolBox_GetNamedBodyPart(TBToolBox *toolbox, char *name);
DV_EXPORT TBBodyPart *TBToolBox_GetAvailableBodyPartList(TBToolBox *toolbox);
DV_EXPORT int TBToolBox_IsDefaultLocked(TBToolBox *toolbox_PO);

DV_EXPORT TBTool *TBToolBox_GetNamedTool(TBToolBox *toolbox, char *name);
DV_EXPORT TBTool *TBToolBox_GetCurrentTool(TBToolBox *toolbox);
DV_EXPORT int TBToolBox_IsToolActive(TBToolBox *toolbox, TBTool *tool);

DV_EXPORT int TBToolBox_GetManId(TBToolBox *toolBox_PO);
DV_EXPORT int TBToolBox_SetManId(TBToolBox *toolBox_PO, int newId_I);

/******************************************************************
 * TOOLBOX File search extensions and paths.
 ******************************************************************/
DV_EXPORT char8 **TB_GetToolBoxExts(void);
DV_EXPORT void *TB_GetToolBoxPaths(void);


/******************************************************************
 * TBTool related functions 
******************************************************************/

#define TBTool_GetToolBox(t) (t)->toolbox
#define TBTool_GetCachedStatus(t) ((t)->flags&_TBTOOL_CACHED)
#define TBTool_SetCachedStatus(t) ((t)->flags|=_TBTOOL_CACHED)
#define TBTool_UnsetCachedStatus(t) ((t)->flags&=~_TBTOOL_CACHED)
#define TBTool_GetName(t) ((t)?(t->name):((char *)NULL))

DV_EXPORT TBTool *TBTool_Create(TBToolBox *toolbox);
DV_EXPORT int TBTool_Invalid(TBTool *tool);
DV_EXPORT int TBTool_Reset(TBTool *tool_PO);
DV_EXPORT int TBTool_Recreate(TBTool *tool_PO);
DV_EXPORT int TBTool_Delete(TBTool **tool);
DV_EXPORT int TBTool_Stop(TBTool *);
DV_EXPORT int TBTool_StartNextNamed(TBTool *);
DV_EXPORT int TBTool_Position(TBTool *);
DV_EXPORT int TBTool_Release(TBTool *);
DV_EXPORT int TBTool_Instance(TBTool *tool);
DV_EXPORT int TBTool_Start(TBTool *tool);
DV_EXPORT int TBTool_StartFunc(TBTool *tool);
DV_EXPORT int TBTool_ParseResources(TBTool *tool, dParseFilePtr IS);

/*
 * this manages/unmanages all the tools in the toolbox
 */
DV_EXPORT int TBToolBox_Unmanage(TBToolBox *toolbox);
DV_EXPORT int TBToolBox_Manage(TBToolBox *toolbox);

DV_EXPORT int TBTool_CreateToplevelShell(TBTool *ToolData, char *labelIcon);

DV_EXPORT int TBTool_Iconise(TBTool *ToolData);
DV_EXPORT int TBTool_Uniconise(TBTool *ToolData);

DV_EXPORT int TBTool_RegisterExplicitBodyPart(TBTool *tool, TBBodyPart *newBP);
DV_EXPORT int TBTool_LockToBodyPart(TBTool *ToolData, TBBodyPart *bpl);
DV_EXPORT int TBTool_UnlockFromBodyPart(TBTool *ToolData);
DV_EXPORT TBBodyPart *TBTool_GetNamedBodyPart(TBTool *tool, char *name);
DV_EXPORT TBBodyPart *TBTool_GetDefaultBodyPart(TBTool *tool);
DV_EXPORT int TBToolBox_RegisterBodyPart(TBToolBox *toolbox, TBBodyPart *newBP);
DV_EXPORT int TBTool_SetToolOriginForBodyPart(TBTool *tool, dmScale origin, TBBodyPart *bodyPart);
DV_EXPORT int TBTool_SetToolOrientForBodyPart(TBTool *tool, dmScale orient, TBBodyPart *bodyPart);
DV_EXPORT int TBTool_SetToolSizeForBodyPart(TBTool *tool, dmScale size, TBBodyPart *bodyPart);
DV_EXPORT VCBody *TBTool_GetBody(TBTool *tool);
DV_EXPORT int TBTool_IsFuncTool(TBTool *tool_PO);

/* required so dvise, and the toolbox don't simutaneously alter flightpaths */
DV_EXPORT int TBCameraTool_Active(void);
DV_EXPORT void TBCameraTool_SetActive(int status);

/***********************************************************************
 * libtb error and debugging functions
***********************************************************************/
DV_EXPORT void tbVersion(FILE *);
DV_EXPORT void TB_Error(char *, ...);
DV_EXPORT int TB_PrintMessage(VCBody *body,char *, ...);
DV_EXPORT void TBUtils_SuppressMessages(int val_b);

/*******************************************************************************************
 * Highlevel functional interface to the Toolbox (from an application)
 ******************************************************************************************/

DV_EXPORT int TBToolBox_Init(void);
DV_EXPORT int TBToolBox_Invalid(TBToolBox *toolBox_PO);
DV_EXPORT int TBToolBox_Reset(TBToolBox *toolBox_PO);
DV_EXPORT int TBToolBox_Recreate(TBToolBox **toolBox_PO);
DV_EXPORT int TBToolBox_Delete(TBToolBox **toolbox);
DV_EXPORT int TBToolBox_DeleteTool(TBToolBox **toolBox_PO, TBTool **tool_PO);
DV_EXPORT TBToolBox *TBToolBox_Create(char *filename, VCBody *body, TBVerbosityType verbosity);
DV_EXPORT int TBToolBox_StartTool(TBToolBox *, TBTool *);

/*******************************************************************************************
 * Keyboard Input Functions
 ******************************************************************************************/
DV_EXPORT void TBInputTrigger_StartTool(
                                     VCBodyInput_CallbackData *callData, void *data);
DV_EXPORT void TBInputTrigger_QuitTool(
                                    VCBodyInput_CallbackData *callData, void *data);
DV_EXPORT void TBInputTrigger_NextInput(
                                     VCBodyInput_CallbackData *callData, void *data);
DV_EXPORT void TBInputTrigger_PrevInput(
                                     VCBodyInput_CallbackData *callData, void *data);
#ifdef COMMENTED_OUT
DV_EXPORT void TBInputTrigger_PressInput(
                                      VCBodyInput_CallbackData *callData, void *data);
#endif /* COMMENTED_OUT */
DV_EXPORT void TBInputTrigger_HitInput(VCBodyInput_CallbackData *callData, 
                                    void *data);

DV_EXPORT char *TBTool_GetIconName(TBTool *);

/***************************************************************************************
 * Register Callback Functions
 **************************************************************************************/
DV_EXPORT int TB_RegisterToolTypeFunc(char *, ToolTypeFunc *);
DV_EXPORT ToolTypeFunc *TB_GetRegisteredToolTypeFunc(char *);
DV_EXPORT int TB_RegisterToolCreationCallback(char *namedFunc, TBCallback *func);
DV_EXPORT TBCallback *TB_GetRegisteredToolCreationCallback(char *namedFunc);
DV_EXPORT int TB_RegisterToolStartCallback(char *namedFunc, TBCallback *func);
DV_EXPORT TBCallback *TB_GetRegisteredToolStartCallback(char *namedFunc);
DV_EXPORT int TB_RegisterToolStopCallback(char *namedFunc, TBCallback *func);
DV_EXPORT TBCallback *TB_GetRegisteredToolStopCallback(char *namedFunc);


/*********************************************************************************
 * TBCallbackList handling functions
 *********************************************************************************/
DV_EXPORT int TBCallbackList_AddCallback(TBCallbackList **cbListPtr, 
                                         TBCallback *functionPtr);
DV_EXPORT int TBCallbackList_RemoveCallback(TBCallbackList **listPtr, TBCallback *func);
DV_EXPORT int TBCallbackList_Execute(TBTool *ToolData, TBCallbackList *cbList);
DV_EXPORT int TBSetName(char **pointer, char *text);


DV_EXPORT VCAttribute *TBUtils_CreateAudioAttribute(char *audioFile);
DV_EXPORT int TBUtils_AttachAudioAttribute(TBTool *ToolData, VCAttribute *audioAttr);
DV_EXPORT int TBUtils_PlayAudioAttribute(VCAttribute *audioAttr);

DV_EXPORT void TBUtils_AudioSetGlobalMode(uint32 mode);
DV_EXPORT uint32 TBUtils_AudioGetGlobalMode(void);
DV_EXPORT VWidgetList *TBUtils_FindNamedWidgets(TBTool *ToolData, char *widgetName);

/*********************************************************************
 * ********* Generic Code to do a 3D vector intersect ****************
 * ******************************************************************/

DV_EXPORT TBIntersect * TBUtils_CreateVectorIntersect(VCEntity *limb,VCAttribute *visAttr);
DV_EXPORT int TBUtils_SetupVectorIntersect(TBIntersect *inter, VCEntity *limb,VCAttribute *visAttr);
DV_EXPORT int TBUtils_VectorIntersect(TBIntersect *InterData, VCIntersection_Func cb, void *cbdata, 
                             dmMatrix *direction, int32 numIntersect, int forceCallback);
DV_EXPORT int TBUtils_VectorIntersectFinish(TBIntersect *InterData);
DV_EXPORT int TBUtils_VectorIntersectDestroy(TBIntersect *InterData);


/***********************************************************************
 * Generic Toolbox public functions
 ***********************************************************************/

DV_EXPORT void TBRegisterGenericWidgetCallback(char *name, VWCallback *func);
DV_EXPORT VWCallback *TBGetRegisteredGenericWidgetCallback(char *namestring);
DV_EXPORT void TBRegisterGenericWidgetCreationCallback(char *name, TBGenWigCreationCb *func);
DV_EXPORT TBGenWigCreationCb *TBGetRegisteredGenericWidgetCreationCallback(char *namestring);
DV_EXPORT void TBRegisterGenericAssemblySelectCallback(char *name, TBGenObjSelCb *func);
DV_EXPORT TBGenObjSelCb *TBGetRegisteredGenericAssemblySelectCallback(char *name);

DV_EXPORT TBTool *TBGenGetTool(void *data);
DV_EXPORT void *TBGenGetCalldata(void *data);
DV_EXPORT ECAction *TBGenGetActionList(void *data);
DV_EXPORT void TBGen_PerformActions(VWidget *thisWig, VWEventInfo *info, void *data);
DV_EXPORT ECAssembly *TBGenGetSelectedAssembly(TBTool *ToolData);
DV_EXPORT void TBGenForgetSelectedAssembly(TBTool *ToolData);

DV_EXPORT void *TBGenGetUserData(TBTool *ToolData);
DV_EXPORT void TBGenSetUserData(TBTool *ToolData, void *dataPtr);

DV_EXPORT char **TBUtils_GetTextureFilesFromDirectory(TBTool *ToolData, char *textureDirectory, 
                                                      int *numTextures);

/***********************************************************************
 * Toolbox configuration file parsing routines & macros
***********************************************************************/

#define TB_MIN_TOKEN 257
#define TB_DEF_TOKEN(a, b, c)  { a, b, c },
#define TB_END_TOKEN TB_DEF_TOKEN( 0, "", PARSER_ANY_CASE)
#define TB_OPEN_BRACKET '{'
#define TB_CLOSE_BRACKET '}'
/*
 * parserGoto functions will skip the file untill the a match is found
 *     and stop after the matched token.
 * 
 * parserMatch functions will try to match the next token reading it if 
 *     matched and returning TRUE otherwise pushing it back onto the
 *     input stream and returning FALSE.
 * 
 * parserRead functions are similar to Match functions only cannot retrace
 *     their steps on a failure and will try to read to the end of the 
 *     corrupt data specifier section in to file...ie the next colsing
 *     bracket if in the middle of a bracketed section. 
 */
DV_EXPORT void TBParser_Error(dParseFilePtr IS, char *format, ...);
DV_EXPORT int TBParser_GotoCharInString( dParseFilePtr IS, char *match );
DV_EXPORT int TBParser_GotoToken( dParseFilePtr InputStream, int matchTok);
DV_EXPORT int TBParser_NextToken( dParseFilePtr IS );
DV_EXPORT int TBParser_MatchToken( dParseFilePtr IS, int matchTok);
DV_EXPORT int TBParser_MatchInt( dParseFilePtr IS, int *intPtr);
DV_EXPORT int TBParser_MatchFloat( dParseFilePtr IS, float32 *floatPtr);
DV_EXPORT int TBParser_MatchString( dParseFilePtr InputStream, char **stringPtr);
DV_EXPORT int TBParser_MatchCallData( dParseFilePtr IS, void **dataPtr);

DV_EXPORT int TBParser_ReadActionList( dParseFilePtr InputStream, ECAction **actionListPtr); 
DV_EXPORT int TBParser_ReadScale( dParseFilePtr InputStream, dmScale orient); 
DV_EXPORT int TBParser_ReadPoint( dParseFilePtr InputStream, dmPoint orient); 
DV_EXPORT int TBParser_ReadOrientation( dParseFilePtr InputStream, dmEuler orient); 
DV_EXPORT int TBParser_ReadVector( dParseFilePtr InputStream, float32 []); 
DV_EXPORT int TBParser_ReadLimit( dParseFilePtr IS, VWLimits *limit);
DV_EXPORT int TBParser_MatchBoolean( dParseFilePtr InputStream , int* boolPtr);
/*
 * Set the FileParser lookup table to a new lookup table.
 */
DV_EXPORT int TBParser_SetKeyTab( dParseFilePtr IS, dParseKeyTab *newTable);

DV_EXPORT int TBParser_MatchMagic( dParseFilePtr IS);
DV_EXPORT TBBodyPart *TBParser_ReadToolPositionConfig(dParseFilePtr IS);


/*****************************************************************************
 * TBBodyPart functional interface
 *****************************************************************************/

DV_EXPORT TBBodyPart *TBBodyPart_Create(char *idName, char *bodyPartName, char *iconGeometry, 
                              char *audioName, dmPoint origin, dmEuler orient, 
                              dmScale size, int defaultBP);

        /* set the bodypart out of the list given to be the default body part
     */
DV_EXPORT int TBBodyPart_SetAsDefault(TBBodyPart *newDefaultBP_PO, TBBodyPart *listBP_PO);
    /*
     * should be called when adding bodypart to a list of them, as this
     * correctly sets up defaults
     */
DV_EXPORT int TBBodyPart_AddToList(TBBodyPart *newBP_PO, TBBodyPart **listBP_PO);


/***********************************************************************
 * Toolbox action functions...(tbfunc.c)
***********************************************************************/

DV_EXPORT int TB_InitFuncTool(dParseFilePtr , TBTool *);
DV_EXPORT void TBRegisterActionFunction(char *, TBActionFunc *);

/***********************************************************************
 * Toolbox Initialisation functions.
***********************************************************************/
/* now in dvtools.h 
DV_EXPORT int TB_InitMenuTool(dParseFilePtr , TBTool *);
DV_EXPORT int TB_InitLinkTool(dParseFilePtr , TBTool *);
DV_EXPORT int TB_InitAnimationTool(dParseFilePtr , TBTool *);
DV_EXPORT int TB_InitBackgroundTool(dParseFilePtr , TBTool *);
DV_EXPORT int TB_InitConstTool(dParseFilePtr , TBTool *);
DV_EXPORT int TB_InitCreateTool(dParseFilePtr , TBTool *);
DV_EXPORT int TB_InitLightTool(dParseFilePtr , TBTool *);
DV_EXPORT int TB_InitBodyTool(dParseFilePtr , TBTool *);
DV_EXPORT int TB_InitVisionTool(dParseFilePtr , TBTool *);
DV_EXPORT int TB_InitFogTool(dParseFilePtr , TBTool *);
DV_EXPORT int TB_InitTestTool(dParseFilePtr, TBTool *);
DV_EXPORT int TB_InitSaveTool(dParseFilePtr, TBTool *);
DV_EXPORT int TB_InitDistanceTool(dParseFilePtr, TBTool *);
DV_EXPORT int TB_InitCameraTool(dParseFilePtr, TBTool *);
*/
DV_EXPORT int TB_InitGenericTool(dParseFilePtr, TBTool *);
DV_EXPORT int TB_InitImmTestTool(dParseFilePtr, TBTool *);


/***********************************************************************
 * Toolbox Utility Functions
***********************************************************************/

DV_EXPORT int TB_InitUtilityData(TBTool *);

/*
 * TOOLBOX Highlighing functions
 * =============================
 * 
 * These functions should always be used to highlight an
 * entity from the toolbox, since it's original colour
 * needs to be remembered for unhighlighting etc.
 */

DV_EXPORT int TB_HighlightVCEntity(VCEntity *, TBTool *);
DV_EXPORT int TB_UnhighlightVCEntity(VCEntity *, TBTool *);
DV_EXPORT int TB_SetUnhighlightMaterial(char *, TBTool *);
DV_EXPORT int TB_SetHighlightMaterial(char *, TBTool *);
DV_EXPORT int TB_ResetHighlightMaterial(TBTool *);
DV_EXPORT int TB_ForgetUnhighlight(TBTool *);

/*
 * TOOLBOX 'DATABASE' FUNCTIONS
 * ============================
 * 
 * These functions can be used to remember the properties
 * of an ECAssembly eg for use with the cancel button...
 */

DV_EXPORT int TB_SaveObjData(ECAssembly *, TBTool *);
DV_EXPORT int  TB_RemoveSavedObjData(ECAssembly*, TBTool *);
DV_EXPORT int TB_RemoveAllSavedObjData(TBTool *);
DV_EXPORT TBDefaultList *TB_FindSavedObjData(ECAssembly *, TBTool *);
DV_EXPORT int TB_RestoreAllObjMaterial(TBTool *);
DV_EXPORT int TB_RestoreObjMaterial(ECAssembly *, TBTool *);
DV_EXPORT int TB_RestoreObjHierarchy(ECAssembly *, TBTool *);
DV_EXPORT int TB_RestoreAllObjHierarchy(TBTool *);
DV_EXPORT int TB_RestoreAllObjData(TBTool *);

/*
 * VC FUNCTION UTILITIES
 * =====================
 */
DV_EXPORT int TB_EntityGetOrientation(VCEntity *, dmEuler);
DV_EXPORT int TB_EntitySetAbsOrientation(VCEntity *, dmEuler);
DV_EXPORT int TB_EntitySetMaterials(VCEntity *, char *);
DV_EXPORT int TB_EntitySetFrontMaterial(VCEntity *, char *);
DV_EXPORT int TB_EntitySetBackMaterial(VCEntity *, char *);

DV_EXPORT void TB_Group(void);
DV_EXPORT void TB_UnGroup(void);
    
DV_EXPORT int32 TBActionList_Perform(ECAction *action, ECAssembly *object,
                                     VCBody *body, VCAttribute *bodyPartAttribute, 
                                     uint32 input, ECExtraEventData *extraEventData);

    
/******************************************************************
 * Toolbox Action Functions.
******************************************************************/

void TB_SaveWorld(TBTool *tool, VCBody *body, 
                  VCAttribute *limbAttribute, void *data);


#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /*_TBOX_H_ */
