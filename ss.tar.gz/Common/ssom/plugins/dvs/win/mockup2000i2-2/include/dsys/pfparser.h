/*
 *      PROJECT:
 *      SUBSYSTEM:
 *      MODULE:
 *
 *      FILE:           $RCSfile: pfparser.h,v $
 *      REVISION:       $Revision: 1.2 $
 *      Date:           $Date: 1999/05/12 16:38:17 $
 *      Author:         $Author: bill $
 *      RCS Ident:      $Id: pfparser.h,v 1.2 1999/05/12 16:38:17 bill Exp $
 *
 *      FUNCTION:
 *
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */

#ifndef __PFPARSER_H__
#define __PFPARSER_H__

#ifndef DPG_EXPORT
#if defined(_WIN32) && !defined(_WINDU_SOURCE) && !defined(__EPP__) && !defined(BUILD_STATIC)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `extern'
 */
#if defined _LIB_DIVU
#define DPG_EXPORT __declspec(dllexport) extern 
#else
#define DPG_EXPORT __declspec(dllimport) extern 
#endif 
#else
#define DPG_EXPORT  extern
#endif
#endif

#include <dsys/divtypes.h>
#include "pgeneral.h"

#ifdef __cplusplus
extern "C" {
#endif
    
/* error numbers */
#define dppENO_FORM     0x020001

#define dpp_MATCH_CASE  0
#define dpp_ANY_CASE    1

/* On calls which either succeed or fail, dpgSUCCESS (0) or dpgERROR (-1)
 * is returned. On calls to get next token however the following 
 * return values are also used
 */
#define dppSUCCESS       0              /* Same as dpgSUCCESS */
#define dppERROR        -1              /* Same as dpgERROR   */
#define dppEOF          -2
#define dppSTRING       -3
#define dppNUMBER	-4

/* flags */
#define dppFLAG_COMPLEX_STR   0x01      /* use complex c style string extensions */
#define dppFLAG_JOIN_STR      0x02      /* join "a" "b" together, ie "ab"        */

/* ctable is a bit-field class identifier - where the following bits are used */
#define dppBIT_UPPER          0x01
#define dppBIT_WHITE          0x02
#define dppBIT_TOKSTRT        0x04
#define dppBIT_TOKEND         0x08

typedef struct dppKEYTAB 
{
    int32	 tok;
    char 	*name;
    int32	 matchCase;
} dppKEYTAB ;


typedef struct dppFILE 
{
    int32	 lineNo;
    int32	 errorFlag;
    char	*fileName;
    int32	 fileSize;
    FILE	*file;
    char        *ctable ;
    char         comment ;
    uint8        flags ;
    int32	 pushedBackToken;
    float64      number;
    uint32       uiNumber;
    int32	 strLen;
    char	*buffer;
    int32	 bufSize;
    int32	 bufPos;
    dppKEYTAB	*keyTab;
} dppFILE, *dppFILEPTR ;


DPG_EXPORT dppFILEPTR
dppOpenFile(char *name, FILE *fp, uint8 flags, const char *whites,
            const char *tokStrt, const char *tokEnd,
            char comment, dppKEYTAB *keyTable);
DPG_EXPORT void
dppCloseFile (dppFILEPTR fPtr);
DPG_EXPORT char *
dppTokenToString (dppFILEPTR fptr, const int32 token);
DPG_EXPORT int32 
dppPushToken (dppFILEPTR fptr, const int32 token);
DPG_EXPORT int32
dppNextToken (dppFILEPTR fptr);
DPG_EXPORT int32
dppReadToNextChar(dppFILEPTR fPtr, char endChr) ;
DPG_EXPORT int32
dppMatchString(dppFILEPTR fptr);
DPG_EXPORT int32
dppMatchInt32(dppFILEPTR fptr, int32 *num);
DPG_EXPORT int32
dppMatchUint32(dppFILEPTR fptr, uint32 *num);
DPG_EXPORT int32
dppMatchFloat32(dppFILEPTR fptr, float32 *num);
DPG_EXPORT int32
dppMatchFloat64(dppFILEPTR fptr, float64 *num);
DPG_EXPORT int32
dppMatchToken(dppFILEPTR fptr, int32 token);
DPG_EXPORT void
dppMoveToNextLine(dppFILEPTR fptr) ;

DPG_EXPORT void
dppVersion(FILE *fp) ;
#ifdef __cplusplus
}
#endif

#endif /* __PFPARSER_H__ */

