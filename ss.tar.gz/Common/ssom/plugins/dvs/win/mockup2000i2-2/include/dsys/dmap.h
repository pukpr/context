/* -*- C -*- ****************************************************************
 *
 *  			Copyright 1998 Division Ltd.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: dmap.h,v $
 *  Revision      : $Revision: 1.2 $
 *  Date          : $Date: 1999/03/16 19:25:55 $
 *  Author        : $Author: bill $
 *  Created By    : Steven Phillips
 *  Created       : Mon Mar 2 17:32:22 1998
 *  Last Modified : <160399.1628>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 *  $Log: dmap.h,v $
 *  Revision 1.2  1999/03/16 19:25:55  bill
 *  Ungraded the map file support for the new gui.
 *
 *  Revision 1.1  1998/11/23 20:02:28  bill
 *  New dvconvert version
 *
 *
 ****************************************************************************
 *
 *  Copyright (c) 1998 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 * This  document  may  not, in  whole  or in  part, be  copied,  photocopied,
 * reproduced,  translated,  or  reduced to any  electronic  medium or machine
 * readable form without prior written consent from Division Ltd.
 *
 ****************************************************************************/

#ifndef __DMAP_H
#define __DMAP_H

#include <dsys/pgeneral.h>
#include <dsys/pfile.h>
#include <dsys/dreg.h>

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

typedef struct {
    Registry *registry ;
    Registry *filter ;
    Registry *split ;
    Registry *mmap ;
    Registry *mmaps ;
    char     *fileName ;
    int32     bmfCount ;
    char    **bmfFileName ;
    dpfFILEPTR *bmfFile ;
    int32     changed ;
} dmapFile ;

/* dmapFileOpen
 * 
 * Open the given file as a map file. Makes basic file type test to check that
 * the file is a map file. Returns a Non-NULL pointer to a valid dmapFile
 * structure if call was successful. Returns NULL if the file could not be
 * opened or the file was not found to be a map file.
 */
dmapFile *dmapFileOpen(char *fileName) ;
/* dmapFileClose
 * 
 * Closes the given dmapFile freeing off all used memory. If the map file has
 * been changed in any way (flagged by the dmapFile changed flag) then the
 * changes are saved to the file (set by the initial call to dmapFileOpen and
 * stored in dmapFile fileName.
 */
int32    dmapFileClose(dmapFile *file) ;
/* dmapFileIsFiltered
 * 
 * Looks up the given filter name in the given map file. The function returns
 * 1 iff the filter name was found and it was set to 'ignore', else 0 is
 * returned. If the filter name was not found then it is added to the file and
 * flagged as changed.
 */
int32    dmapFileIsFiltered(dmapFile *file, char *filterName) ;
/* dmapFileGetSplitString
 * 
 * Looks up the given split name in the given map file. The function returns a
 * pointer to a different string iff the split name was found and the value
 * was a none empty string. The function returns a pointer to the given string
 * otherwise. If the split name was not found then it is added to the file,
 * its value set to an empty string and the file is flagged as changed.
 * 
 * The user MUST NOT free of the returned string pointer. The user is
 * responsible for freeing off splitName if required.
 */
char    *dmapFileGetSplitString(dmapFile *file, char *splitName) ;

/* dmapFileMaterialMapGeogroup
 * dmapFileMaterialMapFile
 * 
 * Material maps the given pfile file and geogroup
 */
void dmapFileMaterialMapGeogroup(dmapFile *file, dpfGEOGROUPPTR geogroup, dpfFILEPTR matFile) ;
void dmapFileMaterialMapFile(dmapFile *file, dpfFILEPTR geomFile, dpfFILEPTR matFile) ;

void dmapVersion(FILE *fp) ; 

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif
#endif /* __DMAP_H */
