/******************************************************************************/
/*									      */
/*	######    ###   #     #   ###    #####    ###   ####### #     #	      */
/*	#     #    #    #     #    #    #     #    #    #     # ##    #	      */
/*	#     #    #    #     #    #    #          #    #     # # #   #	      */
/*	#     #    #    #     #    #     #####     #    #     # #  #  #	      */
/*	#     #    #     #   #     #          #    #    #     # #   # #	      */
/*	#     #    #      # #      #    #     #    #    #     # #    ##	      */
/*	######    ###      #      ###    #####    ###   ####### #     #	      */
/*									      */
/*									      */
/*			#####    ###     ###     ###			      */
/*			     #  #   #   #   #   #   #			      */
/*			     # #     # #     # #     #			      */
/*			#####  #     # #     # #     #			      */
/*			#      #     # #     # #     #			      */
/*			#       #   #   #   #   #   #			      */
/*			######   ###     ###     ###			      */
/*									      */
/* 		Copyright (c) Division Limited. All rights reserved	      */
/*									      */
/* This Document may not, in whole or in part, be copied, photocopied,	      */
/* reproduced, translated, or reduced to any electronic medium or machine     */
/* readable form without prior written consent from Division Ltd.	      */
/*									      */
/******************************************************************************/

#if !defined _SSC_H_
#define _SSC_H_


#if defined __cplusplus
extern "C" {
#endif 

#if defined _WIN32 && !defined(_WINDU_SOURCE) && !defined (__EPP__) && !defined (BUILD_STATIC)
/*
 * only  Windoze needs this baroque construct.
 * On sensible systems simply use `extern'
 */
#if defined _LIB_DIVU
#define SSC_EXPORT __declspec(dllexport) extern
#else
#define SSC_EXPORT __declspec(dllimport) extern
#endif /* _LIB_DIVU */
#else
#define SSC_EXPORT extern
#endif /* WIN32 */

#include <dsys/dp.h>				/* For uint32 */

typedef struct SSC_INTERFACE * SSC_HANDLE;
typedef int  (*SSC_HANDLER_FUNC) (SSC_HANDLE ssc, void * udp);

SSC_EXPORT SSC_HANDLE	ssc_openServer			(void);
SSC_EXPORT SSC_HANDLE	ssc_openClient			(short port);
SSC_EXPORT SSC_HANDLE	ssc_openServerFile		(char * filename);
SSC_EXPORT SSC_HANDLE	ssc_openClientFile		(char * filename);
SSC_EXPORT int		ssc_openClientFileWait		(char * filename, int secsTimeout, SSC_HANDLE * ssc);
SSC_EXPORT SSC_HANDLE   ssc_openConnectedServer         (SSC_HANDLE ssc);
SSC_EXPORT void		ssc_close			(SSC_HANDLE ssc);

SSC_EXPORT int		ssc_getSocket			(SSC_HANDLE ssc);
SSC_EXPORT short	ssc_getPort			(SSC_HANDLE ssc);
SSC_EXPORT int          ssc_setBlockedReadHandler       (SSC_HANDLE ssc, SSC_HANDLER_FUNC func, void * udp);
SSC_EXPORT int          ssc_setBlockedWriteHandler      (SSC_HANDLE ssc, SSC_HANDLER_FUNC func, void * udp);

SSC_EXPORT int          ssc_addInt                      (SSC_HANDLE ssc, uint32 data);
SSC_EXPORT int          ssc_addData                     (SSC_HANDLE ssc, char * data, size_t sizeData);
SSC_EXPORT int          ssc_addString                   (SSC_HANDLE ssc, char * string);
SSC_EXPORT int          ssc_addCommand                  (SSC_HANDLE ssc, int   isSystem, uint16   command);

#if defined HOPPY
SSC_EXPORT int		ssc_addUpdateableInt		(SSC_HANDLE ssc, uint32 data, int * index);
SSC_EXPORT int		ssc_updateInt			(SSC_HANDLE ssc, uint32 data, int index);
#endif

SSC_EXPORT int          ssc_getInt                      (SSC_HANDLE ssc, uint32 * number);
SSC_EXPORT int          ssc_getData                     (SSC_HANDLE ssc, char ** data, size_t * sizeData);
SSC_EXPORT int          ssc_getString                   (SSC_HANDLE ssc, char ** string);
SSC_EXPORT int          ssc_getCommand                  (SSC_HANDLE ssc, int * isSystem, uint16 * command);
SSC_EXPORT int          ssc_eraseTxBuffer               (SSC_HANDLE ssc);
SSC_EXPORT int          ssc_startRxBuffer               (SSC_HANDLE ssc);
SSC_EXPORT int          ssc_moreRxData                  (SSC_HANDLE ssc);

SSC_EXPORT int		ssc_write			(SSC_HANDLE ssc);
SSC_EXPORT int		ssc_read			(SSC_HANDLE ssc);

#if defined __cplusplus
}
#endif /* __cplusplus */
#endif /* _SSC_H */
