/****************************************************************************
 *
 *  			Copyright 1995 Division Limited.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: doctree.h,v $
 *  Revision      : $Revision: 1.14 $
 *  Date          : $Date: 2000/04/27 14:10:33 $
 *  Author        : $Author: john $
 *  Last Modified : <000422.1049>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 ****************************************************************************
 *
 *  Copyright (c) 1995 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 *  This Document may not, in whole or in part, be copied,
 *  photocopied, reproduced, translated, or reduced to any
 *  electronic medium or machine readable form without prior
 *  written consent from Division Ltd.
 ****************************************************************************/

#ifndef __DOCTREE_H__
#define __DOCTREE_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <assert.h>
#include <dsys/__pfile.h>
#include <dsys/dvcon.h>
#include <dsys/ptool.h>

#define doFALSE 0
#define doTRUE  1

#define doVOXEL_MAX_NO_POINT 10
#define do_OPT_PMESH  0x010000
#define do_OPT_PSTRIP 0x020000

#define doCONNECT_FLIP  0x01
#define doCONNECT_POINT 0x02
#define doCONNECT_GEOG  0x04

#define doGEOM_MAX_NO_VERT 65536
#define doGEOM_MAX_NO_TRIS 21844

extern int32 doOptimOutput ;
extern int32 doOctreeDisableSizeCheck ; 

typedef struct doCONNECT {
    struct doTRIANGLE *triangle ;
    struct doCONNECT  *next ;
    uint8              p1 ;
    uint8              flag ;
} doCONNECT, *doCONNECTPTR ;

typedef struct doTRIANGLE {
    dpfGEOGROUPPTR   geogroup ;
    uint32           gid ;
    struct doVERTEX *vertex[3] ;
    doCONNECTPTR     connect ;
    dmVector         normal ;
    struct doTRIANGLE *next, *prev, *link ;
} doTRIANGLE, *doTRIANGLEPTR ;

typedef struct doTLIST {
    doTRIANGLEPTR  triangle ;
    struct doTLIST *next ;
} doTLIST, *doTLISTPTR ;

typedef struct doVERTEX {
    struct doPOINT  *point ;
    struct doVERTEX *next ;
    struct doVERTEX *link ;
    doTLISTPTR       tlist ;
    union {
        dmVector normal ;
        dpfRGBA  rgba ;
    } nr ;
    dpfTEXT  texture ;
    uint32   gid ;
    uint8    vertFlag ;
} doVERTEX, *doVERTEXPTR ;

typedef struct doPOINT {
    doVERTEXPTR     vertex ;
    dmVector        point ;
    struct doPOINT *next ;
    uint32          flag ;
} doPOINT, *doPOINTPTR ;

typedef struct doVOXEL {
    int32 noPoint ;
    union {
        struct {
            struct doVOXEL *child[8] ;
            dmVector centre ;
        } divide ;
        struct {
            doPOINTPTR point ;
        } leaf ;
    } dl ;
} doVOXEL, *doVOXELPTR ;

typedef struct doOCTREE {
    duBlkCtrl      connectBC, tlistBC, triangleBC, vertexBC, pointBC, voxelBC ;
    doVOXELPTR     tree ;
    doVERTEXPTR    vertexHd ;
    doTRIANGLEPTR  triangleHd ;
    dpfGEOMETRYPTR geometryHd ;
    uint32         noTriangle ;
    uint32         noPoint ;
    uint32         noVertex ;
    uint32         dropTriangle ;
    uint32         nextTriGid ;
    uint8          connectFlag ;
} doOCTREE, *doOCTREEPTR ;

typedef enum {
    doABORT = 0,
    doCONTINUE,
    doBREAK
} doLOOP_RETURN ;

typedef doLOOP_RETURN (* doOCTREEPTFNPTR)(dmPoint pt, void *) ;

typedef doLOOP_RETURN (* doOCTREEDOPTFNPTR)(doPOINTPTR pt, void *) ;

extern int32 doCurrentTool ;
#define doTOOL_GENERAL   0x000
#define doTOOL_RDUP      0x001
#define doTOOL_WELD      0x002
#define doTOOL_RSMT      0x003
#define doTOOL_FLIP      0x004
#define doTOOL_NORMAL    0x005
#define doTOOL_DECIMATE  0x006
#define doTOOL_BOUNDVOL  0x007
#define doTOOL_REDGE     0x008
#define doTOOL_DIVIDE    0x009

doOCTREEPTR
doOctreeCreate(void) ;
void
doOctreeFree(doOCTREEPTR octree) ;
#define doOctreeFindVoxel(octree,point) \
    doVoxelFindVoxel((octree)->tree,point)
#define doOctreeFindPoint(octree,point) \
    doVoxelFindPoint(doOctreeFindVoxel(octree,point),point)
#define doOctreeSetConnectFlag(octree,flag) \
    ((octree)->connectFlag=(flag))

void
doOctreeResetTriangleUsed(doOCTREEPTR octree) ;
void
doOctreeResetTriangleGid(doOCTREEPTR octree) ;
void
doVoxelResetVertexGid(doVOXELPTR voxel) ;
#define doOctreeResetVertexGid(octree) \
    doVoxelResetVertexGid(octree->tree)
void
doOctreeClean(doOCTREEPTR octree) ;
int32
doOctreeGetBBox(doOCTREEPTR octree, dmVector min, dmVector max) ;

#define doOPTIM_FAST            0x00
#define doOPTIM_BEST            0x01
#define doOPTIM_TRISTRIP        0x02
#define doOPTIM_PMESHSTRIP      0x04
#define doOPTIM_PMESHCONNECT    0x08
#define doOPTIM_FASTTRISTRIP    (doOPTIM_TRISTRIP|doOPTIM_FAST)
#define doOPTIM_BESTTRISTRIP    (doOPTIM_TRISTRIP|doOPTIM_BEST)
#define doOPTIM_FASTPMESHSTRIP  (doOPTIM_PMESHSTRIP|doOPTIM_FAST)
#define doOPTIM_BESTPMESHSTRIP  (doOPTIM_PMESHSTRIP|doOPTIM_BEST)
void
doOctreeUnload(doOCTREEPTR octree) ;
void
doOctreeUnloadAsSingleGeometry(doOCTREEPTR octree) ;
void
doSetupOptim(int32 outType, int32 stripSize, int32 stripSwaps, int32 polySize) ;

doVOXELPTR
doVoxelCreate(doOCTREEPTR octree) ;
doVOXELPTR
doVoxelFindVoxel(doVOXELPTR voxel, dmVector point) ;
doPOINTPTR
doVoxelFindPoint(doVOXELPTR voxel, dmVector pnt) ;

doPOINTPTR
doPointCreate(doOCTREEPTR octree) ;
#define doPointSetPoint(pnt,pp) \
    dmVectorCopy((pnt)->point,pp)
void
doPointAdd(doOCTREEPTR octree, doVOXELPTR voxel, doPOINTPTR point) ;
extern int32
doPointClean(doOCTREEPTR octree, doPOINTPTR point) ;

doVERTEXPTR
doVertexCreate(doOCTREEPTR octree) ;
doVERTEXPTR
doVertexFindCreate(doOCTREEPTR octree, uint8 vertFlag, dmVector point, dmVector normal,
                   dpfRGBA rgba, dpfTEXT text) ;
#define doVertexSetVertFlag(vertex,vertFlag) \
    ((vertex)->vertFlag = (vertFlag))
#define doVertexSetNormal(vertex,nn) \
    dmVectorCopy((vertex)->nr.normal,nn)
#define doVertexSetRgba(vertex,_rgba) \
    dpfRGBACpy((vertex)->nr.rgba,_rgba)
#define doVertexSetTexture(vertex,_texture) \
    dpfTextCpy((vertex)->texture,_texture)
#define doVertexAdd(octree,_point,_vertex) \
(((octree)->noVertex)++,                   \
 (_vertex)->next=(_point)->vertex,         \
 (_vertex)->point=(_point),                \
 (_point)->vertex=(_vertex))

int32
doTriangleCalcNormal(dmVector normal, 
                     dmVector pnt1, dmVector pnt2, dmVector pnt3) ;
doVERTEXPTR
doTriangleGetThirdVertex(doTRIANGLEPTR tri, 
                         doVERTEXPTR vert1, doVERTEXPTR vert2) ;
void
doTriangleConnect(doOCTREEPTR octree, doTRIANGLEPTR trian) ;
doTRIANGLEPTR
doTriangleLoad(doOCTREEPTR octree, dpfGEOGROUPPTR geogroup, doVERTEXPTR vert0,
               doVERTEXPTR vert1, doVERTEXPTR vert2) ;
void
doTriangleDisconnect(doOCTREEPTR octree, doTRIANGLEPTR trian) ;
void
doTriangleFree(doOCTREEPTR octree, doTRIANGLEPTR trian) ;


doVERTEXPTR
doPfileVertexAdd(doOCTREEPTR octree, dpfVERTEXPTR vert, uint8 vertFlag) ;
int32
doPfileGeometryAdd(doOCTREEPTR octree, dpfGEOMETRYPTR geom) ;
int32
doPfileGeometryAddNoFree(doOCTREEPTR octree, dpfGEOMETRYPTR geom) ;
doTRIANGLEPTR
doPfileTriangleLoad(doOCTREEPTR octree, dpfVERTEXPTR vert1,
                    dpfVERTEXPTR vert2, dpfVERTEXPTR vert3) ;
void
doPfileFileAdd(doOCTREEPTR octree, dpfFILEPTR pff) ;

/*
 * Exports from doutils.c
 *     
 *     doOctreeAllPointsDo applies a function to all the points in an 
 *     Octree (including Voxel centres).
 * 
 *     doOctreeAlldoPointsDo applies a function to all the doPOINTs in an 
 *     Octree. 
 * 
 *     doOctreeXlate translates the entire octree by a given vector
 *     doOctreeCalcExtent finds the range occupied by an octree in a given direction
 *          (you should use a unit vector)
 *     a similar funciton doOctreeCalcExtreme finds the furthest point in an octree
 *           in a given direction (any non-zero vector will do)
 *     doOctreeBBox finds a bounding box for an octree using the actual points in
 *          the octree. bbox returned is set to (Xlow, Xhigh, Ylow, Yhigh, Zlow, Zhigh)
 *     doOctreeRadius calculates the maximum distance from "centre" of the points in 
 *          the octree.
 *     doOctreeFindTriangle returns which triangle the given point lies on.
 */
void
doOctreeXlate(doOCTREEPTR octree, dmVector xlate) ;

doLOOP_RETURN
doOctreeAllPointsDo(doOCTREEPTR octree, doOCTREEPTFNPTR fn, void * data) ;

doLOOP_RETURN
doOctreeAlldoPointsDo(doOCTREEPTR octree, doOCTREEDOPTFNPTR fn, void * data) ;

void
doOctreeCalcExtent(doOCTREEPTR octree, const dmVector dir, float32 * low, float32 * high) ;

void 
doOctreeCalcExtreme(doOCTREEPTR octree, const dmVector dir, dmVector extreme) ;

float32
doOctreeRadius(doOCTREEPTR octree, dmVector centre) ;

doTRIANGLEPTR 
doOctreeFindTriangle(doOCTREEPTR octree, dmVector point);

/*
 * Exports from dobound.c
 *     
 *     doOctreeBBox finds a bounding box for an octree using the actual points in
 *          the octree. bbox returned is set to (Xlow, Xhigh, Ylow, Yhigh, Zlow, Zhigh)
 *     doOctreeBBox finds a bounding box for an octree using the actual points in
 *          the octree rotated about rot. bbox returned is set to 
 *          (Xlow, Xhigh, Ylow, Yhigh, Zlow, Zhigh)
 *     doCalcMin******BBox calculates the bbox of closest fit for the given 
 *          object.  The resultant rotation is returned in rot,
 */

void 
doOctreeBBoxSortAxes(dmMatrix R, dmVector d, int32 axis[3]);


void
doOctreeCalcMinBBox(doOCTREEPTR octree, dmMatrix m, float32 * bbox);

void
doOctreeBBox(doOCTREEPTR octree, float32 * bbox) ;

void
doOctreeRotBBox(doOCTREEPTR octree, float32 * bbox, dmMatrix mat); 


/* dormdup - Routines for finding and removing duplicate triangles
 * 
 * doTriangleFindDuplicate - finds the next duplicate of the given triangle.
 *     Simple routine, if the duplicate is not removed then this function
 *     will return the same triangle on the next call.
 * 
 * doTriangleRemoveDuplicates - Finds and removes all duplicates of the
 *     given triangle.
 * 
 * doOctreeRemoveDuplicateTriangles - Finds and removes all duplicate
 *     triangles in the given octree. Has percentage and graphical verbosity.
 */
doTRIANGLEPTR
doTriangleFindDuplicate(doTRIANGLEPTR tri) ;
int32
doTriangleRemoveDuplicates(doOCTREEPTR octree, doTRIANGLEPTR tri) ;
void
doOctreeRemoveDuplicateTriangles(doOCTREEPTR octree) ;


/* doweld.c - Performs welding operations.
 * 
 * doPointJoin - Effectively moves pntFm to pntTo updating all the triangles asociated.
 *     This routine can remove triangles so if used by a routine which goes down the 
 *     list of triangles a pointer to your next triangle pointer is required incase it
 *     deletes that triangle. Always updates it to the next valid triangle (Note: it does
 *     not set it, only update itif theroutine is about to delete the triangle it is
 *     set to). Can be passed in a NULL.
 * 
 * doPointPointWeld - Find nearest point to given point and is valid weld
 *     them together using doPointJoin. Valid if:
 *     1. They are maxDist away or closer.
 *     2. They do not share any triangles.
 *     3. Both have a triangle with a free edge which runs maxAngl or more
 *        parallel.
 * 
 * doOctreePointWeld - For each point find closest neighbouring point and if 
 *     Valid then weld them together using doPointJoin.
 * 
 * maxDist - maximum physical distance between to points and still be a valid weld
 *           given in m (default use 1mm (0.001)).
 * maxAngl - how parallel 2 free edges must be to still be a valid weld given as cos(A)
 *           (default use 0.984808 (10 degrees))
 * 
 * doPointEdgeWeld - Use edge weld algorithm to weld cracks starting at the 
 *     given point.
 * doOctreeEdgeWeld - Use edge weld algorithm to weld all cracks.
 * 
 * initAngle - Set how parallel the first 2 edges must be given as cos(A)
 *             (default use 0.9659 (15 degrees))
 * contAngle - Set how parallel subsequent edges must be given as cos(A)
 *             (default use 0.7071 (45 degrees))
 */
extern void
doPointJoin(doOCTREEPTR octree, doPOINTPTR pntTo, doPOINTPTR pntFm,
            doTRIANGLEPTR *nTri) ;
extern doPOINTPTR
doPointMove(doOCTREEPTR octree, doPOINTPTR pnt, dmVector point,
            doTRIANGLEPTR *nTri) ;
extern void
doPointInsert(doOCTREEPTR octree, doPOINTPTR pA, doPOINTPTR pB, 
              doPOINTPTR pC, doTRIANGLEPTR *nTri) ;


extern int32
doPointWeld(doOCTREEPTR octree, doPOINTPTR point) ;
extern void
doOctreeWeld(doOCTREEPTR octree) ;
extern void
doSetupWeld(float32 weldDist, float32 weldJoinDist, float32 initAngle, float32 contAngle) ;

extern int32
doPointNormalWeld(doOCTREEPTR octree, doPOINTPTR point) ;
extern void
doOctreeNormalWeld(doOCTREEPTR octree) ;
extern void
doSetupNormalWeld(float32 angle) ;

/* dotiny.c - removes small and thin triangles.
 * 
 * smallAreaTol - Min. allowable area of any triangle given in m^2
 *                (default use 0.1mm square (0.00000001))
 * thinAnglTol  - Min. allowable angle of any triangle vertex given as cos(A)
 *                (default use 0.99985 (1 degree))
 * thinAreaTol  - Min. allowable area of any thin triangle given in m^2
 *                (default use 1cm^2 (0.0001))
 * 
 * doTriangleTestRemoveTiny - Tests and corrects given triangle if it is Tiny.
 *     This routine can remove triangles so if used by a routine which goes down the 
 *     list of triangles a pointer to your next triangle pointer is required incase it
 *     deletes that triangle. Always updates it to the next valid triangle (Note: it does
 *     not set it, only update itif theroutine is about to delete the triangle it is
 *     set to). Can be passed in a NULL.
 *     Returns doTRUE if the given triangle is tiny, doFALSE otherwise.
 *
 * doOctreeRemoveTinyTriangles - Tests and corrects all triangles in the octree.
 */
extern int32
doTriangleTestRemoveSmall(doOCTREEPTR octree, doTRIANGLEPTR tri, doTRIANGLEPTR *nTri) ;
extern void
doOctreeRemoveSmallTriangles(doOCTREEPTR octree) ;
void
doSetupRemoveSmallTriangles(float32 smallTol, float32 maxPerc) ;

/* doflip - Routines for triangle flipping.
 * 
 * doTriangleFlip - Flip the given triangle
 * 
 * doOctreeTriangleLogicFlip - Intelligently flip triangles in the given
 *     octree. NOTE this blows away triangle gid's, reseting them to 0
 * 
 * doTriangleSeedFlip - Intelligently flips using the given triangle 
 *     as a seed.
 * 
 * enableConvexFlip - Attempts to flip a section so that it is outward facing
 */
void
doTriangleFlip(doOCTREEPTR octree, doTRIANGLEPTR tri) ;
void
doOctreeTriangleLogicFlip(doOCTREEPTR octree) ;
int32
doTriangleSeedFlip(doOCTREEPTR octree, doTRIANGLEPTR seedtri);
void
doSetupLogicFlip(int32 enableConvexFlip) ;

/* dodiv.c - routines for dividing up an octree using the GID
 *
 * doOctreeDivideTriangleConnectively - Divide the octree based on
 *     triangle connectivity. Resets the GID and any triangle connected
 *     directly or indirectly to the first triangle gets gid = 1. Then
 *     moves on to the next triangle with gid = 0
 * 
 * doOctreeDivideVertexConnectively - Divide the octree based on
 *     triangle vertex connectivity. Resets the GID and any triangle
 *     connected directly or indirectly to the first triangle gets
 *     gid = 1. Then moves on to the next triangle with gid = 0
 */

extern void
doOctreeGeogroupDice(doOCTREEPTR octree, dpfGEOGROUPPTR geog, int32 *Dim, uint32 triGid) ;
extern void
doOctreeDice(doOCTREEPTR octree, int32 *Dim, uint32 triGid) ;
void
doOctreeGeogroupOctize(doOCTREEPTR octree, dpfGEOGROUPPTR geog, dmVector centre, uint32 triGid) ;
void
doOctreeOctize(doOCTREEPTR octree, dmVector centre, uint32 triGid) ;
extern void
doOctreeDivideTriangleConnectively(doOCTREEPTR octree, uint8 connectFlag) ;
extern void
doOctreeDivideVertexConnectively(doOCTREEPTR octree, uint8 connectFlag) ;

/* donormal - Routines for creating vertex normals
 * 
 * doPointNormalise - Normalises all vertices at the given point unless they
 *     have cooked colour.
 * 
 * doOctreeNormalise - Normalises all vertices at all the points unless they
 *     have cooked colour.
 *
 * angTol - Max. allowable angle between two triangle normals, if the angle
 *          is greater then a break-away is created, given as cos(A).
 *          (default use 0.34202 (70 degrees))
 */
extern int32
doPointNormalise(doOCTREEPTR octree, doPOINTPTR point) ;
extern void
doOctreeNormalise(doOCTREEPTR octree) ;
extern void
doSetupNormalise(float32 angleTol) ;


#define doTESSELLATE_NOCREATE  0x01
#define doTESSELLATE_FLIP      0x02
#define doTESSELLATE_NOERROR   0x04
#define doTESSELLATE_ALLOW_DUP 0x08
typedef float32 dm2dVector[2] ;

extern int32
doPolygonTessellate(doOCTREEPTR octree, int32 mode, dpfGEOGROUPPTR geog, 
                    int32 noPnts, doVERTEXPTR *vrtLst, dm2dVector *paramList,
                    dmVector normal, doTRIANGLEPTR *triHead) ;

#define doDECIMATE_KILL         0x01
#define doDECIMATE_MIN_PERCENT  0x02

extern int32
doPointDecimate(doOCTREEPTR octree, doPOINTPTR point, int32 mode,
                float32 convexTol, float32 concaveConv,
                float32 normConv, float32 rgbaConv, float32 textConv) ;
extern void
doOctreeDecimate(doOCTREEPTR octree, int32 mode, float32 minPercent,
                 float32 convexTol, float32 concaveTol,
                 float32 normTol, float32 rgbaTol, float32 textTol) ;

/****************************************************************************/
int32
doPointEdgeReduce(doOCTREEPTR octree, doPOINTPTR point, float32 distTol) ;
void
doOctreeEdgeReduce(doOCTREEPTR octree, float32 distTol) ;

/****************************************************************************/
#define doFLOATLIST_NO_LEVELS (16)

typedef struct doLISTNODE
{
    struct doFLOATLIST *flist ;
    struct doLISTNODE  *next ;
} doLISTNODE, *doLISTNODEPTR ;

typedef struct doFLOATLIST
{
    float32             value ;
    struct doFLOATLIST *next[doFLOATLIST_NO_LEVELS] ;
    doLISTNODEPTR       child ;
} doFLOATLIST, *doFLOATLISTPTR ;


extern duBlkCtrl      doListNodeBC ;
extern doFLOATLISTPTR doFloatListHeader ;

void
doFloatListInit(size_t size) ;
void
doFloatListKill(void) ;
void
doFloatListInsert(doLISTNODEPTR nd, float32 value) ;
doLISTNODEPTR
doFloatListCreate(void) ;
void
doFloatListRemove(doLISTNODEPTR nd) ;
#define doFloatListFree(nd)       (duBlkFree(&(doListNodeBC),(nd)))
#define doFloatListGetValue(nd)   (nd->flist->value)
#define doFloatListGetHead()      (doFloatListHeader->next[0])
#define doFloatListGetHeadValue() (doFloatListHeader->next[0]->value)

/*
 * dotext.c
 * 
 * Texture mapping routines
 * ------------------------
 * 
 * There are 6 main types of texturing catered for.
 * 1. Cylindrical Mapping
 * 2. Spherical Mapping
 * 3. Planar Mapping
 * 4. Ball Mapping
 * 5. Cubic Mapping
 * 6. Tri-Planar Mapping
 *
 * doTextCreate()
 *     This must be used to create a texture and initialise it to the default values
 * 
 * doTextInit()
 *     This must be used after any of the texture variables are set.  It inverts the
 *     matrix for the inverse mapping, calcs the bounding box for the various wrapping
 *     options and calculates the USize and VSize in texture space for each wrap of the 
 *     texture.
 * 
 * doTextureOctree()
 *     This textures the given octree.
 * 
 * doTextSet...
 *     Sets the texture properties.
 * 
 * Standard mapping is
 * Cylindrical - around Z axis
 * Spherical - around Z axis
 * Planar - in XZ axis
 * Triplanar - N/A
 * Cubic     - N/A
 */
typedef enum 
{
    doTEXT_NONE = 0,
    doTEXT_BALL,
    doTEXT_CUBIC,
    doTEXT_CYLINDRICAL,
    doTEXT_PLANAR,
    doTEXT_SPHERICAL,
    doTEXT_TRIPLANAR
}doTEXT_TYPE;

typedef enum 
{
    doTEXTORIGIN_DEFAULT = 0,
    doTEXTORIGIN_WORLD
}doTEXTORIGIN_TYPE;

typedef struct
{
    doTEXT_TYPE        _Type;
    doTEXTORIGIN_TYPE  _Origin;
    
    /* Size of texture in units eg. 0.1m */
    int32   _GotSize;
    float32 _USize;
    float32 _VSize;
    
    /* texture axis */
    int32   _Axis[2]; /* which axis to use as standard */
    int32   _RevU;    /* Does the U need reversing? */
    
    /* 3D */
    dmMatrix _Mat;
    uint8    _Inverted;
    float32  _UWrap;
    float32  _VWrap;
    
    /* difference in bbox for x,y,z */
    dmVector _Differ;
    
    /* Correction wanted? */
    uint8    _Seam;
    uint8    _Align;
    uint8    _AxisAlign;
    uint8    _Orien;
    
    /* 2D texture manipulation */
    float32  _UScale; 
    float32  _VScale; 
    float32  _Rotate;
    float32  _UOffset;
    float32  _VOffset;
    int32    _Clamp; 
    int32    _HFlip; 
    int32    _VFlip;
    
}doTEXTURE, *doTEXTUREPTR;



doTEXTUREPTR doTextCreate();
void doTextInit(doOCTREEPTR octree, doTEXTUREPTR t);
void doTextureOctree(doOCTREEPTR octree, doTEXTUREPTR t);

void doCorrectOctreeTexture(doOCTREEPTR octree, float32 wraps, int32 *distort);

void doTextSetMatrix(doTEXTUREPTR t, dmMatrix m);
void doTextRotMatrixX(doTEXTUREPTR t, float32 angle);
void doTextRotMatrixY(doTEXTUREPTR t, float32 angle);
void doTextRotMatrixZ(doTEXTUREPTR t, float32 angle);
void doTextTransMatrix(doTEXTUREPTR t, dmVector dist);
void doTextScaleMatrix(doTEXTUREPTR t, dmVector scale);

#define doTextSetType(t,m)(t->_Type = m)
#define doTextSetWrap(t,u,v)(t->_UWrap = u, t->_VWrap = v)
#define doTextSetSize(t,u,v)(t->_USize = u, t->_VSize = v,t->_GotSize = 1)
/* Is seam correction required?  Only applicable for periodic textures */
#define doTextSetSeamCorrect(t,s)(t->_Seam = s)
/* Choose the correct axis */
#define doTextSetAutoAlign(t,a)(t->_Align = a) 
/* Rotate texture matrix to align with the smallest bbox possible */
#define doTextSetAutoAxisAlign(t,a)(t->_AxisAlign = a) 
#define doTextSetOriginType(t,c)(t->_Origin = c)
/* Only applicable for cubic/tri-planar. Makes them have 6 projections instead of 3 */
#define doTextSetAutoOrien(t,o)(t->_Orien = o)
/* these should be DM_X, DM_Y or DM_Z. They define the axis to be used for u,v directions */
#define doTextSetAxis(t,u,v)(t->_Axis[0] = u, t->_Axis[1] = v)

/* 2D transforms */
void doTextSet2DScale(doTEXTUREPTR t, float32 u, float32 v);
void doTextSet2DOffset(doTEXTUREPTR t, float32 u, float32 v);
void doTextSet2DFlip(doTEXTUREPTR t, float32 h, float32 v);
/* takes degrees */
void doTextSet2DRotate(doTEXTUREPTR t, float32 r);

void doText2DTransform(doTEXTUREPTR text, dpfTEXT texture);

/*
 * docheck.c
 * 
 * This checks Normals, cooks, textures and points for validity.
 * If autofix is set it will fix them all.
 * 
 * Also checks LODs and fixes.
 * 
 */

#define do_DEFAULTSIGFIG 6
#define do_DEFAULTDPS    4
#define do_DEFAULTWRAP   255

typedef struct 
{
    /* Check setup parameters */
    int32 dps ;               /* decimal places to check to        */
    int32 NoWraps ;           /* maximum no. of texture wraps      */
    int32 autoFix ;           /* autoFix on if non-zero            */
    int32 disableText ;       /* don't fix textures if non-zero    */

    /* Things calculated on setup */
    float32 MulFac ;           /* Normal modulus accuracy mul factor*/
    
    /* No. things found empty */
    int32  emptyLod ;
    int32  emptyGeogroup ;
    
    /* LOD error report */
    int32  badDummy ;         /* got a dummy with other lods       */
    int32  badOrder ;         /* lods in wrong order - flag only   */
    int32  distSame ;         /* switch-in == out count            */
    int32  distSwap ;         /* switch-in > out count             */ 
    int32  overLap ;          /* lod switch in overlaps others out */
    
    /* geometry bad report */
    int32  badPoint ;         /* No. points with nans, inc. lod ref*/
    int32  badNorm ;          /* No. normals with bad mod          */
    int32  badCook ;          /* No. rgb's out of range            */
    int32  badText ;          /* no. nan | text co-ords out of wrap*/
    int32  badVertCount ;     /* Too many vertices in the geometry */
    
    int32  isBad ;            /* Summary flag - if true then error found */
    
    /* auto-fix output */
    int32  dropLod ;          /* No dropped lods as empty          */
    int32  dropGeogroup ;     /* No dropped geogroups as empty       */
    int32  dropTri ;          /* No tri's dropped because duff     */
                              /* duff cos nan's or pmesh connect   */

    int32  normDistort ;      /* No normal 0 or nan mods           */
    int32  textDistort ;      /* No texture distorts (0 if split)  */

} doCHECK, *doCHECKPTR ;


int32 doCheckFile(dpfFILEPTR file, doCHECKPTR check, int32 dps, int32 NoWraps, 
                  int32 autoFix, int32 disableText);

int32 doCheckLODs(dpfFILEPTR file, doCHECKPTR check);

int32 doCheckOctree(doOCTREEPTR octree, doCHECKPTR check);

/*
 * BoundingVolume - Replaces all the triangles in the octree with
 * bounding volume equivalents, one per geogroup.
 */
void doOctreeBoundingVolume(doOCTREEPTR octree) ;


void doctVersion(FILE *fp) ;

#ifdef __cplusplus
}
#endif

#endif /* __DOCTREE_H__ */
