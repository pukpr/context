/****************************************************************************
 *
 *  			Copyright 1995 Division Limited.
 *			      All Rights Reserved
 *
 *
 *  System        :
 *  Module        :
 *
 *  Description
 *
 *  Notes
 *
 *  History
 *
 ****************************************************************************
 *
 *  Copyright (c) 1995 Division Ltd.
 *
 *  All Rights Reserved.
 *
 *  This Document may not, in whole or in part, be copied,
 *  photocopied, reproduced, translated, or reduced to any
 *  electronic medium or machine readable form without prior
 *  written consent from Division Ltd.
 ****************************************************************************/

/*
 * The following functions are provided in this module
 *
 * Return flags - to be used in all libs and converters
 *     dpgSUCCESS=0, dpgERROR=-1
 *
 * Verbose output setup (special "stderr" & "stdout")
 *     dpgSetOutput(n)
 *
 * Verbose warning setup and usage
 *     dpgSetWarnLevel(n)
 *     dpgWarn(n,(print stuff))
 *
 * Verbose error setup and usage
 *     variable dpgErrNo - set to the last error num ;
 *     dpgSetErrorLevel(n)
 *     dpgError(num, n,(print stuff))
 *
 * Verbose monitering setup and usage
 *     dpgSetMonitorFlag(n)
 *     dpgMonitor(flag,(print stuff))
 *
 * Verbose bad parameter passed error handler
 *     dpgBadAddress(addr,String)
 *
 * Dying routine, outputs to the log and if not stderr, out to stderr
 *     dpgDie(level,(print stuff))
 *
 * malloc and calloc routines that print out an error and exit on failure.
 *     dpgMalloc(size,string)
 *     dpgRealloc(pnt,size,string)
 *     dpgCalloc(nel,size,string)
 *
 * dm macro Extensions
 *
 */

#ifndef __PGENERAL_H__
#define __PGENERAL_H__

#ifndef DPG_EXPORT
#if defined(_WIN32) && !defined(_WINDU_SOURCE) && !defined(__EPP__) && !defined(BUILD_STATIC)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `extern'
 */
#if defined _LIB_DIVU
#define DPG_EXPORT __declspec(dllexport) extern
#else
#define DPG_EXPORT __declspec(dllimport) extern
#endif
#else
#define DPG_EXPORT  extern
#endif
#endif

#include <dsys/divtypes.h>
#include <dsys/dm.h>

#ifdef __cplusplus
extern "C" {
#endif

#define dpgTRUE     1
#define dpgFALSE    0

#define dpgSUCCESS  0
#define dpgERROR   -1

/* temporary addition while flex is sorted out */
DPG_EXPORT void
dpgCheckLicence(uint8 day, uint8 month, uint8 year) ;

/* General error numbers */

#define dpgENO_NULL 	0x1001
#define dpgENO_ROPEN 	0x1002
#define dpgENO_READ 	0x1003
#define dpgENO_WOPEN 	0x1004
#define dpgENO_WRITE 	0x1005

/* Verbose output setup (special "stderr" & "stdout") - returns dpgERROR
 * if couldn't open the file, SUCCESS otherwise
 */
DPG_EXPORT int32    dpgCon ;
DPG_EXPORT FILE    *dpgLog ;
DPG_EXPORT char    *dpgLogName ;
DPG_EXPORT char    *dpgProgname ;
DPG_EXPORT float32  dpgScaleUnitToMetre ;
DPG_EXPORT float32  dpgScaleMetreToUnit ;
#define dpgUnitToMetre(nn) ((nn)*dpgScaleUnitToMetre)
#define dpgMetreToUnit(nn) ((nn)*dpgScaleMetreToUnit)
DPG_EXPORT char    *dpgUnitSymbol ;

/* This function MUST be called before any routines are called with printing */
DPG_EXPORT void
dpgInit(char *progname) ;

DPG_EXPORT int32
dpgSetConsole(int32 out) ;
DPG_EXPORT int32
dpgSetLogFile(char *name) ;
DPG_EXPORT void dpgResetErrorCount();
DPG_EXPORT int dpgGetErrorCount(void);
DPG_EXPORT int dpgGetWarningCount(void);



#define dpgFlush() ((dpgLog != NULL) ? fflush(dpgLog):0)
/* internal functions */

/* If the next variable is non-zero then when any printing is done, a new
 * line will be inserted and the variable will be reset to 0 */
DPG_EXPORT int32 dpgNewLine ;
#define dpgSetNewLine(v) (dpgNewLine=(v))

/* Verbose warning setup and usage */
DPG_EXPORT int32 dpgWarnLvl ;

/* general printing routine */
DPG_EXPORT void dpgPrint(char *format, ...) ;
DPG_EXPORT void dpgPrintDynamic(char *format, ...) ;

#define dpgIncWarnLevel()  (dpgWarnLvl++)
#define dpgSetWarnLevel(n) (dpgWarnLvl = n)

DPG_EXPORT int32 __dpgWarn(char *format, ...) ;
#define dpgWarn(lvl,p)                                                       \
((lvl <= dpgWarnLvl) ? __dpgWarn p:dpgSUCCESS)

/* Verbose error setup and usage */
DPG_EXPORT int32 dpgErrorLvl ;
DPG_EXPORT int32 dpgErrNo ;

#define dpgIncErrorLevel()  (dpgErrorLvl++)
#define dpgSetErrorLevel(n) (dpgErrorLvl = n)
DPG_EXPORT int32 __dpgError(char *format, ...) ;
#define dpgError(num,lvl,p)                                                  \
((dpgErrNo = num),((lvl <= dpgErrorLvl) ? __dpgError p:dpgERROR))

/* Verbose process monitor setup and usage */
/* Bit usage should be registered here:- */
#define dpgPROCESS_INFO 0x01                /* General conversion info */
#define dpgPROCESS_LOD  0x02                /* LOD Verbosity */
#define dpgPROCESS_TOOL 0x04                /* Tool Verbosity */
#define dpgPROCESS_FLIP 0x08                /* Query Flip Verbosity */

DPG_EXPORT int32 dpgProcessFlg ;

#define dpgSetProcessFlag(n) (dpgProcessFlg = n)
#define dpgTestProcess(flag)                                                 \
((flag & dpgProcessFlg) ? dpgTRUE:dpgFALSE)

/* Verbose monitor setup and usage */
DPG_EXPORT int32 dpgMonitorFlg ;

#define dpgSetMonitorFlag(n) (dpgMonitorFlg = n)
DPG_EXPORT char *__dpgMonitorMess ;
#define dpgMonitor(flag,p)                                                   \
((flag & dpgMonitorFlg) ? (dpgPrint(__dpgMonitorMess,dpgProgname),dpgPrint p,dpgERROR):dpgSUCCESS)
#define dpgTestMonitor(flag)                                                 \
((flag & dpgMonitorFlg) ? dpgERROR:dpgSUCCESS)

/* Dying routine, outputs to the log and if not stderr, out to stderr - exits
 */
DPG_EXPORT void dpgDie(char *format, ...) ;

#define dpgQDie()                                                            \
do {                                                                         \
    fprintf(stderr,"Press q to quit.\n") ;                                   \
    if(getchar() == 'q')                                                     \
        dpgDie("User requested death\n") ;                                   \
} while(0)

/* Verbose bad parameter passed error handler - returns ERROR if addr is
 * NULL also does dpgError, returns SUCCESS otherwise
 */

/* malloc and calloc routines that print out an error and exit on failure. */
#if BUILD_DEBUGGING_VERSIONS
DPG_EXPORT void * __dpgMalloc(size_t size, char *fname, int32 lineNo) ;
DPG_EXPORT void * __dpgRealloc(void *pnt, size_t size, char *fname, int32 lineNo) ;
DPG_EXPORT void * __dpgCalloc(size_t noElm, size_t size, char *fname, int32 lineNo) ;
DPG_EXPORT char * __dpgStrdup(const char *ss, char *fname, int32 lineNo) ;
DPG_EXPORT void   __dpgBadAddress(char *fname, int32 lineNo) ;
#define dpgBadAddress(addr)                                           \
((addr == NULL) ? (__dpgBadAddress(__FILE__,__LINE__),dpgERROR) : dpgSUCCESS)

#define dpgMalloc(size)       __dpgMalloc(size,__FILE__,__LINE__)
#define dpgRealloc(pnt,size)  __dpgRealloc(pnt,size,__FILE__,__LINE__)
#define dpgCalloc(noElm,size) __dpgCalloc(noElm,size,__FILE__,__LINE__)
#define dpgStrdup(ss)         __dpgStrdup(ss,__FILE__,__LINE__)
#else
DPG_EXPORT void * dpgMalloc(size_t size) ;
DPG_EXPORT void * dpgRealloc(void *pnt, size_t size) ;
DPG_EXPORT void * dpgCalloc(size_t noElm, size_t size) ;
DPG_EXPORT char * dpgStrdup(const char *ss) ;
#define dpgBadAddress(addr)                                           \
((addr == NULL) ? dpgERROR : dpgSUCCESS)
#endif
DPG_EXPORT void   dpgFree(void *pnt) ;

/*****************************************************************************/
/* getparam error numbers */
#define dpgENO_STREXP   0x1011
#define dpgENO_UNKOPT   0x1012
#define dpgENO_USAGE    0x1013
#define dpgENO_RSRCF    0x1014

/****************************************************************************
 * getparam monitor numbers */
#define dpgMON_OPTIONS   0x00001000
#define dpgMON_FILES     0x00002000


#define dpg_END        0
#define dpg_NO_STR     1
#define dpg_D_STR      2
#define dpg_DJOIN_STR  3
#define dpg_DAFTER_STR 4
#define dpg_DBOTH_STR  5
#define dpg_O_STR      6
#define dpg_OJOIN_STR  7
#define dpg_OAFTER_STR 8
#define dpg_OBOTH_STR  9

typedef struct {
    char    optname[15] ;
    int32   opttype ;
    int32   optreturn ;
} dpgTABLE, *dpgTABLEPTR ;

DPG_EXPORT int32
dpgGetopt(int32 argc, char *argv[], char *envName, dpgTABLEPTR table,
          int32 *NoFiles, char **files[], char **str1, char **str2) ;

DPG_EXPORT void
dpgFreeFiles(int32 NoFiles, char *files[]) ;

DPG_EXPORT void
dpgVersion(FILE *fp) ;

/* This func parses buff and generates an argv argument list
 * It leaves argv[0] as NULL for the progname to be inserted
 */
DPG_EXPORT int32
dpgReadString(char *buff, int32 newArgc, char ***nargv);

/* The following are useful dm  extensions */

#define dmVectorCmp(a,b)           memcmp((a),(b),sizeof(dmVector))
#define dmdVectorCmp(a,b)          memcmp((a),(b),sizeof(dmdVector))
/* Single float checking utility */
#define dmBadFloat(f) (((*(uint32 *)&(f) & 0x7f800000U)==0x7f800000U))
/* Double float checking utility */
#ifdef _LITTLE_ENDIAN_MACHINE
#define dmdBadFloat(f) (((((uint16 *)&(f))[3] & 0x7ff0)==0x7ff0))
#else
#define dmdBadFloat(f) (((*(uint16 *)&(f) & 0x7ff0)==0x7ff0))
#endif


#define dmdVectorDoubleToSingle(d,s) do { \
    (d)[0] = (float32) (s)[0];  \
    (d)[1] = (float32) (s)[1];  \
    (d)[2] = (float32) (s)[2];  \
} while (0)

#define dmdVectorSingleToDouble(d,s) do { \
    (d)[0] = (float64) (s)[0];  \
    (d)[1] = (float64) (s)[1];  \
    (d)[2] = (float64) (s)[2];  \
} while (0)


#ifdef __cplusplus
}
#endif

#endif /* __PGENERAL_H__ */
