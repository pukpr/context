#ifndef __VCTYPES_H
#define __VCTYPES_H

typedef struct _VCTimer_CallbackInfo 	_VCTimer_CallbackInfo;
typedef struct _VCBodyPartList		_VCBodyPartList;
typedef struct _VCBody_InputFuncData	_VCBody_InputFuncData;
typedef struct _VCBody_CollideFuncData	_VCBody_CollideFuncData;
typedef struct _VCInput_FuncData	_VCInput_FuncData;

#endif
