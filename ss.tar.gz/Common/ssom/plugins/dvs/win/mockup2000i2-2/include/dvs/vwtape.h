/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: vwtape.h,v $
 *    Revision:     $Revision: 1.4 $
 *    Date:         $Date: 2000/03/15 11:28:50 $
 *    Author:       $Author: simon $
 *    RCS Ident:    $Id: vwtape.h,v 1.4 2000/03/15 11:28:50 simon Exp $
 *
 *    FUNCTION: Frame public function prototypes.
 * 
 * Copyright (c) 1996 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _VWTape_H
#define _VWTape_H
#ifdef __cplusplus
extern "C" {
#endif
#ifdef _dummyBrace_
}
#endif
/* INCLUDES ============================================== */
#include "vwidgets.h"
/* PUBLIC FUNCTIONS ====================================== */

enum {
    VWrTapeBeginMaterial = VW_RESOURCES_TAPE,
    VWrTapeEndMaterial,
    VWrTapeRopeMaterial,
    VWrTapeBeginVisual,
    VWrTapeEndVisual,
    VWrTapeRopeVisual,
    VWrTapeDisableCollide,
    VWrTapeRopeWidth,
    VWrTapeUpdateCallback,
    VWrTapeUpdateCalldata
};

VW_EXPORT VWidget *VWTape_CreateManaged(VWidget *Parent, char *name, VWArg args[], int argc);
VW_EXPORT VWidget *VWTape_Create(VWidget *Parent, char *name, VWArg args[], int argc);
VW_EXPORT void VWTape_AddUpdateCallback(VWidget *thisWig, VWCallback *cb, void *cd);
VW_EXPORT VWidget *VWTape_GetBeginWidget(VWidget *thisWig);
VW_EXPORT VWidget *VWTape_GetEndWidget(VWidget *thisWig);
VW_EXPORT VWidget *VWTape_GetRopeWidget(VWidget *thisWig);
VW_EXPORT VCEntity *VWTape_GetBeginEntity(VWidget *thisWig);
VW_EXPORT VCEntity *VWTape_GetEndEntity(VWidget *thisWig);
VW_EXPORT void VWTape_GetBeginWidgetAbsOrigin(VWidget *thisWig, dmPoint absPos);
VW_EXPORT void VWTape_GetEndWidgetAbsOrigin(VWidget *thisWig, dmPoint absPos);
VW_EXPORT float32 VWTape_GetDistance(VWidget *thisWig);
VW_EXPORT float32 VWTape_GetXDistance(VWidget *thisWig);
VW_EXPORT float32 VWTape_GetYDistance(VWidget *thisWig);
VW_EXPORT float32 VWTape_GetZDistance(VWidget *thisWig);
VW_EXPORT float32 VWTape_GetBeginScale(VWidget *thisWig);
VW_EXPORT float32 VWTape_GetEndScale(VWidget *thisWig);
VW_EXPORT char *VWTape_GetBeginVisual(VWidget *thisWig);
VW_EXPORT char *VWTape_GetEndVisual(VWidget *thisWig);
VW_EXPORT void VWTape_SetBeginScale(VWidget *thisWig, float32 scale);
VW_EXPORT void VWTape_SetEndScale(VWidget *thisWig, float32 scale);
VW_EXPORT void VWTape_SetBeginVisual(VWidget *thisWig, char *visual);
VW_EXPORT void VWTape_SetEndVisual(VWidget *thisWig, char *visual);
VW_EXPORT void VWTape_SetBeginPoint(VWidget *TapeWig, dmPoint absPnt, dmPoint relPnt, VCEntity *entity,
                                  int setEntity);
VW_EXPORT void VWTape_SetEndPoint(VWidget *TapeWig, dmPoint absPnt, dmPoint relPnt, VCEntity *entity,
                                int setEntity);

#ifdef _dummyBrace_
{
#endif
#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /*_VWTape_H */
