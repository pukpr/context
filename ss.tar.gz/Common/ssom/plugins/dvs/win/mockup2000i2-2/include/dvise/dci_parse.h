#ifndef DCI_PARSE_H
#define DCI_PARSE_H

#include <dvs/dm.h>  /* For dmDistanceUnit */

typedef enum {
 tdciINT = 257,
 tdciFLOAT,
 tdciSTRING,
 tAssemblyAttributes,
 tAssemblyLinkage,
 tAssemblies,
 tFileLibraries,
 tFileAttributes,
 tAssemblyAttribute,
 tAssemblyAddAttribute,
 tAssemblyRemoveAttribute,
 tAssemblyAttributeList,
 tAssemblyAddAttributeList,
 tAssemblyRemoveAttributeList,
 tAssemblyRename,
 tAssemblyLink,
 tAssemblyUnlink,
 tAssemblyCreate,
 tAttributeCreate,
 tAssemblyInstance,
 tAssemblyDestroy,
 tLandmarkCreate,
 tRoles,
 tImageSave,
 tToggleBranch,
 tTogglePicking,
 tToggleHighlightMode,
 tUsers,
 tSetBody,
 tSetBodyRole,
 tSetBodyPosition,
 tBodyPartSelectList,
 tActionFunctions,
 tdciEvent,
 tEventNames,
 tToggleTreeVisibility,
 tSave,
 tSaveInfo,
 tFileName,
 tPluginName,
 tSaveMaterials,
 tClipAssemblyCopy,
 tClipAssemblyPaste,
 tClipAttributeCopy,
 tClipAttributePaste,
 tError,
 tDCIendVDI,
 tInform,
 tQuery,
 tExit,
 tQuotedString,
 tMessage,
 tRegisterInterest,
 tDeregisterInterest,
 tResetVisual,
 tMatrlOverride,
 tEnableAll,
 tDisableAll,
 tDeselectAll,
 tFlyToAll,
 tFlightPathCreate,
 tSectionCreate,
 tLibraryCreate,
 tLibraryOpen,
 tLibraryImport,
 tLibraryExport,
 tInstanceInfo,
 tFailedDelete,
 tAnnotateCreate,
 tBodyUnits,
 tQueryAssemblies,
 tQueryList,
 tQueryCreate,
 tQueryDelete,
 tQueryUpdate,
 tZoneAssemblyLoadOnly,
 tZoneAssemblyEnableOnly,
 tAnnotationServiceInit,
 tAnnotationServiceSetContext,
 tAnnotationServiceViewAnnotation,
 tIncludeNode,
 tAllIncludeNodes,
 tSaveAttributes,
 tLoadAll,
 tUnloadAll,
 tIncludePath,
 tLandmarkData,
 tLandmarkDelete,
 tRendOpts,
 tAssemblyMakeNonInstance,
 tInstanceAlteration,
 tBodyNavigator,
 tLastToken
} DCIParseTokens;

/*
 * keep old-style message identifiers for backward compatibility */

#define tZoneAssemblyAttributes tAssemblyAttributes
#define tZoneAssemblyRename tAssemblyRename
#define tZoneAssemblyAttributeList tAssemblyAttributeList
#define tZoneAssemblyAddAttributeList tAssemblyAddAttributeList
#define tZoneAssemblyRemoveAttributeList tAssemblyRemoveAttributeList
#define tZoneAssemblyLink tAssemblyLink
#define tZoneAssemblyUnlink tAssemblyUnlink
#define tZoneAssemblyCreate tAssemblyCreate
#define tZoneAssemblyInstance tAssemblyInstance
#define tZoneAssemblyDestroy tAssemblyDestroy
#define tZoneAssemblyLinkage tAssemblyLinkage
#define tZoneAssemblys tAssemblies

typedef struct {
    char           *bodyName;
    dmDistanceUnit  distUnit;
} DCIBodyUnitsCallbackStruct;


#endif



