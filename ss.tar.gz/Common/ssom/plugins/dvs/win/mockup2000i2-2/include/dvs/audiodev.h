
/*
-- ----------------------------------------------------------------------------
--
--  			Copyright 1994 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS 2.1
--  Module       : Audio support library
--  Object Name  : $RCSfile: audiodev.h,v $
--  Revision     : $Revision: 1.6 $
--  Date         : $Date: 1997/05/27 10:07:23 $
--  Author       : $Author: mark $
--
--  Description	
--	Defines the structures needed to define generators and spatialisers
--      and to allow information to to be passed between the actor and the
--      devices.
--
--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __AUDIODEV_H__
#define __AUDIODEV_H__

#ifdef _BUILDING_AUDIOSUP
#include "params.h"             /* parameter definitions */
#include "resparam.h"           /* resource parameters */
#else
#include <dvs/params.h>         /* parameter definitions */
#include <dvs/resparam.h>       /* resource parameters */
#endif

typedef void *DeviceVoice;      /* handle to a device's voice table */

typedef Parameters * (*AudioDeviceDefaultParams)(void);

typedef void (*AudioDevStopCB)(void *, void *);


/* -- is a generator, spatialiser or recorder */

enum 
{
    AUDIO_DEV_CAT_GENERATOR   = 0x1,
    AUDIO_DEV_CAT_SPATIALISER = 0x2,
    AUDIO_DEV_CAT_RECORDER    = 0x4
};

typedef int AudioDevCategory;

/* -- what sort of looping can this device do? */

enum 
{
    AUDIO_DEV_LOOP_FOREVER = 0x1,     /* can do looping for ever */
    AUDIO_DEV_LOOP_SPECIFIC = 0x2     /* can do a specific number of iterations */
};

typedef int AudioDevLoop;

typedef void (*AudioDeviceBasicInfo)(int *mechMask,
                                     AudioDevCategory *cat,
                                     AudioDevLoop *loopMask);

/*
 * ------------------------------------------------------------
 *
 * AudioGenDevice
 *
 * ------------------------------------------------------------
 */

typedef void * (*AudioGenDeviceOpen)(const Parameters *parameters);
typedef int (*AudioGenDeviceClose)(void *data);
typedef float32 (*AudioGenDeviceVoiceDuration)(void *, const DeviceVoice);
typedef void (*AudioGenDeviceSetVoiceStoppedCallback)(void *,
                                                      const uint32 channel,
                                                      AudioDevStopCB stopCB,
                                                      void *userData);
typedef int (*AudioGenDeviceActivate)(void *data, 
                                      const uint32 channel,
                                      const void *activationHandle,
                                      const DeviceVoice voice,
                                      const uint8 velocity,
                                      const float32 gain,
                                      const int32 loopCnt);
typedef int (*AudioGenDeviceDeactivate)(void *data, 
                                        const uint32 channel,
                                        const void *activationHandle);
typedef int (*AudioGenDeviceVelocity)(void *data,
                                      const uint32 channel,
                                      const void *activationHandle,
                                      const uint8 velocity);
typedef int (*AudioGenDeviceGain)(void *data, 
                                  const uint32 channel,
                                  const void *activationHandle,
                                  const float32 gain);
typedef DeviceVoice (*AudioGenDeviceSetMechanism)(void *data,
                                                  const uint32 channel,
                                                  const AudioMechanism *mech);

typedef int (*AudioGenDeviceSetupChannel)(void *data,
                                          const uint32 channel,
                                          const uint32 polyphony);
typedef int (*AudioGenDeviceCheckConnection)(void *data,
                                             const uint32 channel,
                                             const uint32 type,
                                             void *spat,
                                             const uint32 spatChannel,
                                             const uint32 spatType);
typedef int (*AudioGenDeviceResourceParams)(void *data, ResParam *);

typedef struct AudioGenDevice
{
    AudioDeviceDefaultParams      defaultParameters;
    AudioGenDeviceOpen            open;
    AudioGenDeviceClose           close;
    AudioGenDeviceVoiceDuration   duration;
    AudioGenDeviceSetVoiceStoppedCallback setCB;
    AudioGenDeviceActivate        activate;
    AudioGenDeviceDeactivate      deactivate;
    AudioGenDeviceVelocity        velocity;
    AudioGenDeviceGain            gain;
    AudioGenDeviceSetMechanism    setMech;
    AudioGenDeviceSetupChannel    setupChannel;
    AudioGenDeviceCheckConnection checkConnection;
    AudioGenDeviceResourceParams  resourceParams;
} AudioGenDevice;

/*
 * ------------------------------------------------------------
 *
 * Spatialiser function types
 *
 * ------------------------------------------------------------
 */

typedef void * (*AudioSpatDeviceOpen)(const Parameters *parameters);
typedef int (*AudioSpatDeviceClose)(void *data);
typedef int (*AudioSpatDeviceActivate)(void *data,
                                      const uint32 channel,
                                      const uint32 spatialise,
                                      const float32 gain);
typedef int (*AudioSpatDeviceDeactivate)(void *data,
                                        const uint32 channel);
typedef int (*AudioSpatDeviceLocateListener)(void *data, 
                                             const dmPoint position, 
                                             const dmEuler orientation);
typedef int (*AudioSpatDeviceLocateSource)(void *data, 
                                           const uint32 channel, 
                                           const dmPoint position, 
                                           const dmEuler orientation);
typedef int (*AudioSpatDeviceSetGain)(void *data, 
                                      const uint32 channel, 
                                      const float32 gain);
/* do we really need this! */
typedef int    (*AudioSpatDeviceUpdateAudio)(void *data);

/* not sure about these ones */
typedef int (*AudioSpatDeviceModelListener)(void *data, 
                                            const uint32 channel,
                                            const float32 * const earOffset, 
                                            const char * const hrtf);
/* isn't this a radiation pattern */
typedef int (*AudioSpatDeviceRadiation)(void *data,
                                        const uint32 channel,
                                        const VCRadiatorData * const radiator);
typedef int (*AudioSpatDeviceDirectSource)(void *data,
                                           const uint32 channel, 
                                           const float32 rfld,
                                           const float32 ifld);
typedef int (*AudioSpatDeviceSelectInput)(void *data,
                                          const uint32 channel,
                                          const int input);
typedef int (*AudioSpatDeviceSetupChannel)(void *data,
                                          const uint32 channel);
typedef int (*AudioSpatDeviceCheckConnection)(void *data,
                                              const uint32 channel,
                                              const uint32 type,
                                              void *gen,
                                              const uint32 genChannel,
                                              const uint32 genType);
typedef int (*AudioSpatDeviceResourceParams)(void *data, ResParam *);

typedef struct AudioSpatDevice
{
    AudioDeviceDefaultParams       defaultParameters;
    AudioSpatDeviceOpen            open;
    AudioSpatDeviceClose           close;
    AudioSpatDeviceActivate        activate;
    AudioSpatDeviceDeactivate      deactivate;
    AudioSpatDeviceModelListener   modelListener;
    AudioSpatDeviceLocateListener  locateListener;
    AudioSpatDeviceRadiation       radiation; 
    AudioSpatDeviceDirectSource    directSource; /* ?? */
    AudioSpatDeviceLocateSource    locateSource;
    AudioSpatDeviceSelectInput     selectInput; /* ?? */
    AudioSpatDeviceSetGain         setGain; 
    AudioSpatDeviceUpdateAudio     update; 
    AudioSpatDeviceSetupChannel    setupChannel;
    AudioSpatDeviceCheckConnection checkConnection;
    AudioSpatDeviceResourceParams  resourceParams;
} AudioSpatDevice;

/*
 * ------------------------------------------------------------
 *
 * AudioRecDevice
 *
 * ------------------------------------------------------------
 */

typedef void * (*AudioRecDeviceOpen)(const Parameters *parameters);
typedef int (*AudioRecDeviceClose)(void *data);
typedef int (*AudioRecDeviceActivate)(void *data, const char * const fileName);
typedef int (*AudioRecDeviceDeactivate)(void *data);
typedef int (*AudioRecDevicePause)(void *data, const int pause);

typedef struct AudioRecDevice
{
    AudioDeviceDefaultParams defaultParameters;
    AudioRecDeviceOpen       open;
    AudioRecDeviceClose      close;
    AudioRecDeviceActivate   activate;
    AudioRecDeviceDeactivate deactivate;
    AudioRecDevicePause      pause;
} AudioRecDevice;

/*
 * ------------------------------------------------------------
 *
 * Prototypes for all the functions that an audio device needs to
 * export
 *
 */

#if defined(_WIN32)
#define DLL_EXPORT __declspec(dllexport) extern
#else
#define DLL_EXPORT extern
#endif

DLL_EXPORT void dloadVersionFunction(int *major, int *minor);
DLL_EXPORT char *dloadVersionStringFunction(void);
DLL_EXPORT char *dloadLibraryTypeFunction(void);
DLL_EXPORT void audioDeviceBasicInfo(int *mechMask,
                                     AudioDevCategory *cat,
                                     AudioDevLoop *loopMask);

DLL_EXPORT Parameters *audioGenDeviceDefaultParameters(void);
DLL_EXPORT void *audioGenDeviceOpen(const Parameters *parameters);
DLL_EXPORT int audioGenDeviceClose(void *data);
DLL_EXPORT float32 audioGenDeviceVoiceDuration(void *, const DeviceVoice);
DLL_EXPORT void audioGenDeviceSetVoiceStoppedCallback(void *,
                                                      const uint32 channel,
                                                      AudioDevStopCB stopCB,
                                                      void *userData);
DLL_EXPORT int audioGenDeviceActivate(void *data,
                                      const uint32 channel,
                                      const void *activationHandle,
                                      const DeviceVoice voice,
                                      const uint8 velocity,
                                      const float32 gain,
                                      const int32 loopCnt);
DLL_EXPORT int audioGenDeviceDeactivate(void *data,
                                        const uint32 channel,
                                        const void *activationHandle);
DLL_EXPORT int audioGenDeviceVelocity(void *data,
                                      const uint32 channel,
                                      const void *activationHandle,
                                      const uint8 velocity);
DLL_EXPORT int audioGenDeviceGain(void *data,
                                  const uint32 channel,
                                  const void *activationHandle,
                                  const float32 gain);
DLL_EXPORT DeviceVoice audioGenDeviceSetMechanism(void *data,
                                                  const uint32 channel,
                                                  const AudioMechanism *mech);
DLL_EXPORT int audioGenDeviceSetupChannel(void *data,
                                          const uint32 channel,
                                          const uint32 polyphony);
DLL_EXPORT int audioGenDeviceCheckConnection(void *data,
                                             const uint32 channel,
                                             const uint32 type,
                                             void *spat,
                                             const uint32 spatChannel,
                                             const uint32 spatType);

DLL_EXPORT int audioGenDeviceResourceParams(void *data, ResParam *);

DLL_EXPORT Parameters *audioSpatDeviceDefaultParameters(void);
DLL_EXPORT void *audioSpatDeviceOpen(const Parameters *parameters);
DLL_EXPORT int audioSpatDeviceClose(void *data);
DLL_EXPORT int audioSpatDeviceActivate(void *data,
                                       const uint32 channel,
                                       const uint32 spatialise,
                                       const float32 gain);
DLL_EXPORT int  audioSpatDeviceDeactivate(void *data,
                                          const uint32 channel);
DLL_EXPORT int audioSpatDeviceModelListener(void *data, 
                                            const uint32 channel,
                                            const float32 *const earOffset,
                                            const char * const hrtf);
DLL_EXPORT int audioSpatDeviceLocateListener(void *data,
                                             const dmPoint position,
                                             const dmEuler orientation);
DLL_EXPORT int audioSpatDeviceRadiation(void *data,
                                        const uint32 channel,
                                        const VCRadiatorData * const radiator); 
DLL_EXPORT int audioSpatDeviceDirectSource(void *data,
                                           const uint32 channel,
                                           const float32 rfld,
                                           const float32 ifrd);
DLL_EXPORT int audioSpatDeviceLocateSource(void *data,
                                           const uint32 channel,
                                           const dmPoint position,
                                           const dmEuler orientation);
DLL_EXPORT int audioSpatDeviceSelectInput(void *data,
                                          const uint32 channel,
                                          const int input);
DLL_EXPORT int audioSpateDeviceSetGain(void *data,
                                       const uint32 channel,
                                       const float32 gain); 
DLL_EXPORT int audioSpatDeviceUpdateAudio(void *data);
DLL_EXPORT int audioSpatDeviceSetupChannel(void *data,
                                           const uint32 channel);
DLL_EXPORT int audioSpatDeviceCheckConnection(void *data,
                                              const uint32 channel,
                                              const uint32 type,
                                              void *gen,
                                              const uint32 genChannel,
                                              const uint32 genType);
DLL_EXPORT int audioSpatDeviceResourceParams(void *data, ResParam *);


DLL_EXPORT Parameters *audioRecDeviceDefaultParameters(void);
DLL_EXPORT void *audioRecDeviceOpen(const Parameters *parameters);
DLL_EXPORT int audioRecDeviceClose(void *data);
DLL_EXPORT int audioRecDeviceActivate(void *data, const char * const fileName);
DLL_EXPORT int audioRecDeviceDeactivate(void *data);
DLL_EXPORT int audioRecDevicePause(void *data, const int pause);

#endif /* __AUDIODEV_H__ */
