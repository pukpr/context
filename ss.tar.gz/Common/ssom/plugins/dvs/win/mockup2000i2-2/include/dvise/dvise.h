/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: dvise.h,v $
 *    Revision:     $Revision: 1.25 $
 *    Date:         $Date: 2000/05/08 17:40:45 $
 *    Author:       $Author: jeff $
 *    RCS Ident:    $Id: dvise.h,v 1.25 2000/05/08 17:40:45 jeff Exp $
 *
 *    FUNCTION:
 *
 *
 *    $Log: dvise.h,v $
 *    Revision 1.25  2000/05/08 17:40:45  jeff
 *    sequencer upgrades, plus general header usage reduction
 *
 *    Revision 1.24  2000/03/15 11:48:23  jeff
 *    making stuff static that should be.
 *
 *    Revision 1.23  2000/02/04 10:09:55  steve
 *    moved from path defines to vdi_parse.h from dvise.h; include vdi_parse.h in dvise.c
 *
 *    Revision 1.22  2000/02/02 15:32:42  steve
 *    export of default search path settings (file extensions) and new dTEX and dWAV
 *    search table exports
 *
 *    Revision 1.21  1999/09/14 17:08:58  john
 *    split dviseInitialiseNew into 2 parts so error server can be set up earlier
 *
 *    Revision 1.20  1999/07/21 16:50:50  john
 *    removed licensing code
 *
 *    Revision 1.19  1999/06/03 10:58:16  steve
 *    changed interface to dVISE_Initialise/InitialiseNew to return int error
 *    value
 *
 *    Revision 1.18  1999/04/09 17:25:42  john
 *    dont include ecselection.h since it will disappear
 *
 *    Revision 1.17  1999/04/07 15:42:10  steve
 *    dded stuff to support BGF search paths
 *
 *    Revision 1.16  1999/03/02 14:57:00  rajini
 *    Added a new function dVISE_InitialiseNew for the gui to startup dvise without
 *    loading the vdifile.
 *
 *    Revision 1.15  1999/02/12 09:10:59  john
 *    removed #pragma lines that were for debugging and got commited acidentally
 *
 *    Revision 1.13  1998/07/27 17:53:50  john
 *    dvise main executable is now c++ to allow for C++ plugins
 *    Some structures and header files have had to change as a consequence
 *
 *    Revision 1.12  1998/07/22 10:59:12  clives
 *    Options dialogue DCI and EC support.
 *
 *    Revision 1.11  1998/07/16 13:56:09  clives
 *    Further additions to the renderer options support.
 *
 *    Revision 1.10  1998/05/25 09:58:39  hoppy
` *    New file searching stuff incorporated.
 *
 *    Revision 1.9  1997/07/14 10:23:35  mdj
 *    *** empty log message ***
 *
 *    Revision 1.8  1997/03/12 09:30:15  mdj
 *    *** empty log message ***
 *
 *    Revision 1.7  1997/02/18 17:29:06  clives
 *    *** empty log message ***
 *
 *    Revision 1.6  1997/01/21 17:38:53  clives
 *    *** empty log message ***
 *
 *    Revision 1.5  1997/01/16 15:19:53  clives
 *    *** empty log message ***
 *
 *    Revision 1.4  1996/12/20 16:13:34  simon
 *    *** empty log message ***
 *
 *    Revision 1.3  1996/12/17 15:24:46  clives
 *    *** empty log message ***
 *
 *    Revision 1.2  1996/11/11 14:10:55  wman
 *    Fixed hp build warnings.
 *
 *    Revision 1.1.1.1  1996/07/25 16:07:44  alex
 *    Initial import of dVISE
 *
 *    Revision 1.1.1.1  1996/07/24 17:30:18  alex
 *    Initial version of dVISE
 *
 * Revision 1.9  96/02/23  10:57:38  10:57:38  wman (William Man)
 * *** empty log message ***
 * 
 * Revision 1.7  1995/09/12  10:56:51  alex
 * Quick_RCS_Check
 *
 * Revision 1.6  95/07/25  10:22:04  alex
 * Quick_RCS_Check
 * 
 * Revision 1.5  1995/07/12  15:35:13  alex
 * Quick_RCS_Check
 *
 * Revision 1.4  95/04/13  17:10:51  alex
 * Quick_RCS_Check
 * 
 * Revision 1.3  95/04/06  15:12:24  alex
 * Quick_RCS_Check
 * 
 * Revision 1.2  95/03/13  17:02:46  alex
 * *** empty log message ***
 * 
 * Revision 1.1  1995/03/01  13:17:31  alex
 * Initial revision
 *
 * Revision 1.3  1995/02/13  12:55:26  alex
 * *** empty log message ***
 *
 * Revision 1.2  1995/01/20  12:33:09  michael
 * *** empty log message ***
 *
 * Revision 1.1  1995/01/19  17:22:43  alex
 * Initial revision
 *
 *
 * Copyright (c) 1992 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _DVISE_H
#define _DVISE_H

/* PRIVATE DEFINES =======================================*/

#define TOOLBOX

/* PUBLIC INCLUDES ====================================== */

#include <dvs/vc.h>
#ifdef __cplusplus
#include <dvise/eccallbacks.h>
#endif
#include <dvise/dvexport.h>
#include <dvise/ecatools.h>
#ifdef TOOLBOX
#include <dvise/tbtools.h>
#endif

#include <dvise/dcitools.h>
#include <dvise/dvmacro.h>
#include <dvise/event.h>
#include <dvise/camera.h>
#include <dvise/role.h>
#include <dvise/select.h>
#include <dvise/bodyfly.h>

#ifdef __cplusplus
extern "C" {
#endif

/* PUBLIC DEFINES ======================================= */
#define DCI_BLOCKED_WRITE_INTERVAL 2.0 /* seconds */

/* PUBLIC TYPES ========================================= */


/* PUBLIC VARIABLES ====================================== */

/* static (global) ints to control the record and replay state 
 * accessed via the camgroup routines prototyped below
 */


/* PUBLIC FUNCTIONS ====================================== */

DV_EXPORT void dviseExit(int code);
DV_EXPORT int dVISE_Initialise(int *argc, char **argv);
DV_EXPORT int dVISE_InitialiseNew(int *argc, char **argv);
DV_EXPORT int dVISE_InitialiseContinue(int *argc, char **argv, int loadFile);
DV_EXPORT void dviseLibVersion(FILE *fp);
DV_EXPORT void RegisterActionFunctions(void);
DV_EXPORT void dVISE_SetRendererOptions(VCBody *b, VCAttribute *a, ECUserData *options);
DV_EXPORT void dVISE_QueryRendererOptions(VCBody *b, ECUserData *qryOpts);
DV_EXPORT ECUserData *dVISE_ConstructRendOptsQry(char *name, ...);
DV_EXPORT void EC_GetCamGroupState(int *recState, int *replState);
DV_EXPORT void EC_SetCamGroupState(int recState, int replState);

#ifdef __cplusplus
}
#endif
#endif /*_DVISE_H */
