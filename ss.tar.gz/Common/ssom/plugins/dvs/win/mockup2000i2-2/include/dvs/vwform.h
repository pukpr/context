/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: vwform.h,v $
 *    Revision:     $Revision: 1.7 $
 *    Date:         $Date: 1997/04/22 12:33:54 $
 *    Author:       $Author: simon $
 *    RCS Ident:    $Id: vwform.h,v 1.7 1997/04/22 12:33:54 simon Exp $
 *
 *    FUNCTION: Frame public function prototypes.
 * 
 * Copyright (c) 1996 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _VWForm_H
#define _VWForm_H
#ifdef __cplusplus
extern "C" {
#endif
#ifdef _dummyBrace_
}
#endif
/* INCLUDES ============================================== */
#include "vwidgets.h"
#include "vwborder.h"
/* PUBLIC FUNCTIONS ====================================== */

enum {
    VWrFormSize = VW_RESOURCES_FORM,
    VWrFormSashSize,
    VWrFormSashVisual,            
    VWrFormSashDisable,
    VWrFormSashHighlightVisual,        
    VWrFormSashMaterial,        
    VWrFormSashHighlightMaterial,
    VWrFormEnableResizeSash,
    VWrFormDontRedrawOnDrag,
    VWrFormRelativeSashSize,
    VWrFormUseRelativeSashSize,
    VWrFormAllowDepthPositioning,
    VWrFormUseBorder
};

VW_EXPORT VWidget *VWForm_CreateManaged(VWidget *Parent, char *name, VWArg args[], int argc);
VW_EXPORT VWidget *VWForm_Create(VWidget *Parent, char *name, VWArg args[], int argc);
VW_EXPORT void VWForm_ManageSash(VWidget *FormWig);
VW_EXPORT void VWForm_UnmanageSash(VWidget *FormWig);
VW_EXPORT void VWForm_DisableRedrawChildren(VWidget *FormWig);
VW_EXPORT void VWForm_EnableRedrawChildren(VWidget *FormWig);

#ifdef _dummyBrace_
{
#endif
#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /*_VWForm_H */
