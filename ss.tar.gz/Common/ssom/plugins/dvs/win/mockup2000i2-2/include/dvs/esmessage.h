/* -*- C++ -*-
-- ----------------------------------------------------------------------------
--
--  			Copyright 1999 Division Limited.
--			      All Rights Reserved
--
--
--  System       : 
--  Module       : 
--  Object Name  : $RCSfile: esmessage.h,v $
--  Revision     : $Revision: 1.2 $
--  Date         : $Date: 2000/04/01 09:34:25 $
--  Author       : $Author: john $
--
--  Description	
--
--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __MESSAGE_H__
#define __MESSAGE_H__

#include <fstream.h>
//#include <divstring.h>

#include <dsys/du.h>
#include <dsys/dueserver.h>


#ifdef _LIB_ES
#include "esexport.h"
#include "skip.h"               // for skip list tables
#include "esmodules.h"          // for verbose/debug modules lists
#else
#include <dvs/esexport.h>
#include <dvs/skip.h>           // for skip list tables
#include <dvs/esmodules.h>      // for verbose/debug modules lists
#endif 

/*
 * ============================================================
 *
 * M E S S A G E 
 *
 * Classes to support the various message types
 *
 * The base class message maintains the information that all
 * mesages need and also used as the class used in the
 * table to store all message types
 *
 * ============================================================
 */

class ES_EXPORT MessageKey
{
    friend int operator==(MessageKey, MessageKey);
    friend int operator<(MessageKey, MessageKey);

    time_t time;                // time message created
    int seq;                    // sequence number of messages at this time
    int src;                    // source this message came from

public:
    MessageKey(time_t t, int _seq, int _src) : time(t), seq(_seq), src(_src) {}
    time_t stamp() const { return time; }
    int sequence() const { return seq; }
    int source() const { return src; }
};

int operator==(MessageKey a, MessageKey b);
int operator<(MessageKey a, MessageKey b);
  
    /* 
     * ------------------------------------------------------------
     *
     * A basic message -- all messages are derived from this 
     *
     * ------------------------------------------------------------
     */

enum MessageType 
{
    mt_none,
    mt_warning,
    mt_error,
    mt_fatal,
    mt_verbose,
    mt_debug
};

class ES_EXPORT Message
{
    MessageKey k;               // key for this message
    char* text;
    MessageType mt;             // what type of message is this

protected:
    void type(const MessageType t) { mt = t; }

public:
    Message(time_t t, int seq, int src, char* m) : k(t, seq, src), mt(mt_none) { text = strdup(m); }
    ~Message() { if (text) free(text); }
    MessageType type() const { return mt; } 
    time_t timestamp() const { return k.stamp(); }
    int sequence() const { return k.sequence(); }
    int source() const { return k.source(); }
    const char* message() const { return text; };
    virtual char* name() const = 0;       
    virtual long size() const { return (sizeof(Message) + strlen(text)); }
    MessageKey key() const  { return k; } // needed for skip lists

          void   Write          (FILE * o);
    const char * GetDateText    (void);
    const char * GetTimeText    (void);
    const char * GetSourceText  (void);
    const char * GetModuleText  (void);
    const char * GetLevelText   (void);
    const char * GetMessageText (void);
};


    /*
     * ------------------------------------------------------------
     * 
     * A warning message
     *
     * ------------------------------------------------------------
     */

class ES_EXPORT WarningMessage : public Message
{
public:
    WarningMessage(time_t t, int _seq, int _src, char* m) : Message(t, _seq, _src, m) { type(mt_warning); }
    char* name() const { return "WARN"; }
};

    /*
     *  ------------------------------------------------------------
     * 
     * An error message
     *
     * ------------------------------------------------------------
     */

class ES_EXPORT ErrorMessage : public Message
{
public:
    ErrorMessage(time_t t, int _seq, int _src, char* m) : Message(t, _seq, _src, m) { type(mt_error); }
    char* name() const { return "ERROR"; }
};
 
    /* 
     * ------------------------------------------------------------
     *
     * A fatal error message 
     * 
     * ------------------------------------------------------------
     */

class ES_EXPORT FatalMessage : public Message
{
public:
    FatalMessage(time_t t, int _seq, int _src, char* m) : Message(t, _seq, _src, m) { type(mt_fatal); }
    char* name() const { return "FATAL"; }
};
 
    /* 
     * ------------------------------------------------------------
     * 
     * A verbose message
     *
     * ------------------------------------------------------------
     */

class ES_EXPORT VerboseMessage : public Message
{
    int mod;
    int lev;

public:

    VerboseMessage(time_t t, int _seq, int _src, char* m, int mo, int l)
        : Message(t, _seq, _src, m), mod(mo), lev(l)
    { 
        type(mt_verbose);
    }

    int module() const { return mod; }
    int level() const { return lev; }
    virtual char* name() const { return "VERBOSE"; }
    virtual long size() const { return Message::size() - sizeof(Message) + sizeof(VerboseMessage); }

};

    /* 
     * ------------------------------------------------------------
     *
     * A debug message
     *
     * ------------------------------------------------------------
     */

class ES_EXPORT DebugMessage : public VerboseMessage
{
    int line;
    char* file;

public:
    DebugMessage(time_t t, int _seq, int _src, char* m, int modnum, int l, int lineno, char* f)
            : VerboseMessage(t, _seq, _src, m, modnum, l), line(lineno)
    {
        type(mt_debug);
        file = strdup(f);
    }
    ~DebugMessage() { if (file) free(file); }

    int lineNumber() const { return line; }
    const char* fileName() const { return file; }
    char* name() const { return "DEBUG"; }
    virtual long size() const 
    { 
        return VerboseMessage::size() - sizeof(VerboseMessage) + sizeof(DebugMessage) + strlen(file); 
    }
};

    /*
     * ------------------------------------------------------------
     * 
     * An ordered table of messages and an interator over the
     * table.
     *
     * ------------------------------------------------------------
     */

typedef SkipList<Message,MessageKey> MessageSL;
typedef SkipListIter<Message,MessageKey> MessageSLIter;

    /*
     * ------------------------------------------------------------
     *
     * A class for filtering messages based on type, source,
     * date, and module/level for verbose/debug messages
     *
     * ------------------------------------------------------------
     */

class ES_EXPORT Filter
{
    int _mask;                  // which fields to use for filtering
    MessageType _type;          // message type to match
    time_t startTime;           // no messages before this time
    time_t endTime;             // no messages after this time
    int _source;                // messages only from this client
    int _module;                // messages only from this module
    int _level;                 // messages only at the level

public:

    enum maskbits {
        FM_TYPE       = 0x01,   // messages of this typetype
        FM_START_TIME = 0x02,   // no messages earlier than start time
        FM_END_TIME   = 0x04,   // no messages later than end time
        FM_SOURCE     = 0x08,   // messages only from this source
        FM_MODULE     = 0x10,   // messages from this module 
        FM_LEVEL      = 0x20    // messages at this level
    };
    
    Filter() : _mask(0) {}
    
        // setting filter values

    void type(const MessageType t) { _type = t; }
    void start(const time_t t) { startTime = t; }
    void end(const time_t t) { endTime = t; }
    void source(const int s) { _source = s; }
    void module(const int m) { _module = m; } 
    void level(const int l) { _level = l; }

        // setting filter values

    MessageType type() const { return _type; }
    time_t start() const { return startTime; }
    time_t end() const { return endTime; }
    int source() const { return _source; }
    int module() const { return _module; }
    int level() const { return _level; }

        // setting/getting mask values for enable filter features

    int mask() const  { return _mask; }
    void mask(const int m) { _mask = m; }
    void mask(const int a, const int r) { _mask |= a; _mask &= ~r; } 

    int filter(Message* m);
};

    /*
     * ------------------------------------------------------------
     *
     * MessageClient
     *
     * Maintains information about a client that sends messages
     * to the error server
     *
     * ------------------------------------------------------------
     */

#define ES_LOCAL_CLIENT (-1)

class ES_EXPORT MessageClient
{
    friend class MessageTable;

    int s;                      // source
    char* n;                    // name of the client
    size_t lenString;		// Length of the currently malloc'd string 
    ModuleList verboseModules;  // list of all the defined verbose modules
    ModuleList debugModules;    // list of all the defined debug modules

public:
    /* Constructors and destructors */
    MessageClient        ()              : s(-1),  n(0), lenString(0) { }
    MessageClient        (const int src) : s(src), n(0), lenString(0) { }
    ~MessageClient       ()                                           { if (n) free(n); }

    /* These can be defined here */
    int          source  ()  const { return s; }
    char       * name    ()  const { return n; }
    int          key     ()  const { return source(); } // for skip lists
    ModuleList * verboseList ()        { return &verboseModules; }
    ModuleList * debugList   ()        { return &debugModules; }

    /* These are defined elsewhere */
    void         name    (const char * const str);
};

    /*
     * ------------------------------------------------------------
     * 
     * An ordered table of message clients and an iterator over
     * the table 
     * 
     * ------------------------------------------------------------
     */

typedef SkipList<MessageClient,int> MessageClientSL;
typedef SkipListIter<MessageClient,int> MessageClientSLIter;

    /* 
     * ------------------------------------------------------------
     * 
     * MessageTable
     *
     * A class representing a set of messages with an applied filter
     *
     * ------------------------------------------------------------
     */

#define MSG_TBL_MIN_LIMIT (50 * 1024)

class ES_EXPORT MessageTable
{
    typedef void (*MessageTableNewMessageCb)(const Message* const m, void* ud);
    typedef void (*MessageTableFlushCb)(void* ud);

    friend class MessageTableIter;
    
    MessageSL table;            // the table of all messages
    Filter f;                   // the filter to apply when iterating
    MessageClientSL clientTab;  // the set of clients providing the messages
    MessageTableNewMessageCb cb; // callback to call for each new message
    void* ud;                   // user data for the callback
    MessageTableFlushCb fcb;    // callback for when messages are flushed to disk
    void* fud;                  // user data for the flush callback
    long bytesUsed;             // space used by the messages
    long limit;                 // size limit for messages
    char* logFile;              // file to write messages to
    ofstream* out;

    void flushMCToFile(FILE* o);
    void pushToFile();          // push messages out to the logfile
    void skip(ifstream&, const char);
#if defined NOT_REQUIRED
    int msgRead(FILE* in, char*, const int);
    void messageRead(FILE* in);
    void loadFromFile(const char* const fname);
#endif
    void addAndFilter(Message* m);

public:
    MessageTable() : cb(0), bytesUsed(0), limit(MSG_TBL_MIN_LIMIT), logFile(0) {}
#if defined NOT_REQUIRED
    MessageTable(const char* fname)
    {
        MessageTable();
        limit = 0;
        loadFromFile(fname);
    }
#endif
    void client(const int source) { clientTab.add(new MessageClient(source)); }
    void message(const duEServerHeader header, const int source, const char* data);
    void message(Message* m) { if (m) addAndFilter(m); }
    Filter& filter() { return f; }
    MessageClientSL& clients() { return clientTab; }
    MessageClient* findClient(int source)  { return clientTab.find(source); }
    MessageClient* findNamedClient(const char* const name);
    void newMessageCallback(MessageTableNewMessageCb c, void* u) { cb = c; ud = u; }
    void messageFlushCallback(MessageTableFlushCb c, void* u) { fcb = c; fud = u; }
    void setLimit(const int l) { limit = (l < MSG_TBL_MIN_LIMIT) ? MSG_TBL_MIN_LIMIT : l; }
    void logFileName(const char* lf)  { 
        logFile = (lf == 0) ? 0 : strdup(lf); 
    }
    void flushToFile();
    int saveToNamedFile(const char* const);
};


    /* 
     * ------------------------------------------------------------
     *
     * An iterator over a message table, applying the filter
     *
     * ------------------------------------------------------------
     */

class ES_EXPORT MessageTableIter
{
    MessageSLIter i;            // iterator into the messages table
    Filter& f;                  // handle to the filter
    int filtering;              // do we perform filtering?

public:
    MessageTableIter(MessageTable& t, const int doFilter = 1) : i(t.table), f(t.filter()), filtering(doFilter) {}
    Message* next()
    {
        Message* m;
        
        while (m = i++)
            if ((filtering == 0) || f.filter(m))
                return m;
        return 0;
    }
};

    /*
     * ------------------------------------------------------------
     * 
     * The message table containing all the received messages
     *
     * ------------------------------------------------------------
     */

ES_EXPORT extern MessageTable messages;

#endif /* __MESSAGE_H__ */
