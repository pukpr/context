/*
 *      PROJECT:
 *      SUBSYSTEM:
 *      MODULE:
 *
 *      FILE:           $RCSfile: vcmacros.h,v $
 *      REVISION:       $Revision: 1.1.1.1 $
 *      Date:           $Date: 1996/04/09 15:52:29 $
 *      Author:         $Author: mark $
 *      RCS Ident:      $Id: vcmacros.h,v 1.1.1.1 1996/04/09 15:52:29 mark Exp $
 *
 *      FUNCTION:
 *
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine reable form without prior
 * written consent from Division Ltd.
 */



#ifndef _VCMACROS_H_
#define _VCMACROS_H_

#define VC_GetEntityRelocateMode()	VCEntity_GetRelocateMode(NULL)
#define VC_SetEntityRelocateMode(m)	VCEntity_SetRelocateMode(NULL,m)
#define VCBody_SetVisualResourceBackgroundColor(b,c) VCBody_SetVisualResourceBackgroundColour(b,c)
#define	VCBody_SetVisualResourceFogColor(b,c,t,m) VCBody_SetVisualResourceFogColour(b,c,t,m)
#define VCEntity_SpinX(e,a)    VCEntity_Spin(e,VC_X,a)
#define VCEntity_SpinY(e,a)    VCEntity_Spin(e,VC_Y,a)
#define VCEntity_SpinZ(e,a)    VCEntity_Spin(e,VC_Z,a)
#define VCApplicationHelp	VCActorHelp
#define VCApplicationExtraHelp	VCActorExtraHelp
#endif
