#ifndef _DVSW_POSTURAL_SCORE_HH
#define _DVSW_POSTURAL_SCORE_HH


/*****************************************************************************/

					// Information on the postural score.
typedef struct
{
    float32 current_score;
    float32 maximum_score;

} dvSwPosturalScoreStruct;


/*****************************************************************************/

#endif
