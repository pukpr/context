/****************************************************************************
 *
 *  			Copyright 1998 Division Ltd.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: tape.h,v $
 *  Revision      : $Revision: 1.9 $
 *  Date          : $Date: 2000/03/16 17:12:04 $
 *  Author        : $Author: john $
 *  Created       : Mon Feb 2 11:44:29 1998
 *  Last Modified : <000313.1748>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 *  $Log: tape.h,v $
 *  Revision 1.9  2000/03/16 17:12:04  john
 *  fixes to make it compile in a clean build
 *
 *  Revision 1.8  2000/03/14 16:49:12  simon
 *  Stopped compilation of distance.c, made a few upgrades for latest
 *  version of tool.
 *
 *  Revision 1.7  1998/07/15 10:14:31  clives
 *  Distance measurement annotation on tape if you have the appropriate
 *  registry entry. NOTE that this will only become a useful feature when
 *  we have raster text available. Also mods to make distance tools visible
 *  on section planes.
 *
 *  Revision 1.6.12.1  1998/07/03 17:18:21  simon
 *  Frigs for displaying val in section
 *
 *  Revision 1.6  1998/05/05 12:09:54  simon
 *  fixed header include stuff
 *
 *  Revision 1.5  1998/04/20 11:08:38  simon
 *  put setting of geometry, and materials for tapes in the registry
 *
 *  Revision 1.4  1998/04/16 16:53:01  simon
 *  Added code so tape point will follow you around on the background
 *
 *  Revision 1.3  1998/03/30 10:39:24  simon
 *  Added min-dist functionality
 *
 *  Revision 1.2  1998/03/19 15:55:29  simon
 *  stuff for distance tool, and stuff to get around (hopefully) temporary
 *  problem of attribute interest.
 *
 *  Revision 1.1  1998/03/17 11:01:57  simon
 *  the dvise side of the distance tool
 *
 *
 ****************************************************************************
 *
 *  Copyright (c) 1998 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 * This  document  may  not, in  whole  or in  part, be  copied,  photocopied,
 * reproduced,  translated,  or  reduced to any  electronic  medium or machine
 * readable form without prior written consent from Division Ltd.
 *
 ****************************************************************************/

#ifndef __DVDIST_H__
#define __DVDIST_H__

#include "distance.h"
#include <dvise/dvexport.h>
#include <dvise/camera.h>
#ifdef __cplusplus
extern "C" {
#endif

/* default geometry's used for tape points (can be overriden in registry) */
#define POINT_VISUAL "widgets/misc/sphere"
#define TAPE_SELECTED_POINT_VISUAL "widgets/misc/bigcross"
#define TAPE_SELECTED_POINT_ON_BACKGROUND_VISUAL "widgets/misc/bigdiamond"
/* default material's used for tape points, and rope's (can be overriden in registry) */
#define POINT_MATERIAL "widgets/simple:VW_RedishOrange_EH"
#define SELECTED_POINT_MATERIAL "widgets/simple:VW_White_EH"
#define ROPE_MATERIAL "widgets/simple:VW_Green_EH"
#define ANNOTATE_MATERIAL "widgets/simple:VW_Red_EH"

/* actual values to use */
extern char *PointVisual;
extern char *TapeSelectedPointVisual;
extern char *TapeSelectedPointOnBackgroundVisual;
extern char *PointMaterial;
extern char *SelectedPointMaterial;
extern char *RopeMaterial;

/*
 * the different dimentions a tape can be measured in
 */
typedef enum ECDistDimention {ECDistDimention_X, ECDistDimention_Y,
    ECDistDimention_Z } ECDistDimention;

/*
 * holds the tape information on a distance assembly, this is stored hanging off a 
 * pointer in the ecassembly structure.  Deals with all the non-ECAssembly 
 * parts of a ECDistance - such as the visuals, and distance information.  Provides
 * functions to alter these parts (e.g. add/move points) 
 */
typedef struct _ECDistAssemblyDataT ECDistAssemblyDataT;

/* setup at startup the geometry to be used for tapes */
DV_EXPORT void ECDist_SetupGeometry(void);
/* setup at startup the action func's, etc. so tape functionality can be used */
DV_EXPORT void ECDist_Setup(void);
/* used to setup dist manager in dist edit code */
/*DV_EXPORT void ECDistance_Setup(void); simon distance manager no longer available */

/* create distance data for given assembly */
DV_EXPORT ECDistAssemblyDataT *ECDist_Create(ECDistance *distAss);
/* delete the distance data on the given assembly */
DV_EXPORT int ECDist_Delete(ECDistance *distAss);
/* reset (i.e. remove all points on tape) tape on distance assembly */
DV_EXPORT int ECDist_Reset(ECDistance *distAss);
/* manage the vw tape/circle on the for the distAss */
DV_EXPORT int ECDist_Manage(ECDistance *distAss);
/* unmanage the vw tape/circle on the for the distAss */
DV_EXPORT int ECDist_Unmanage(ECDistance *distAss);
/* for the given point on a tape get it's position, and entity, if includeCircleCentre then
 point 3 on a circle will return its centre */
DV_EXPORT VCEntity *ECDist_GetPointPosition(ECDistance *distAss, int pointNum, 
                                  dmPoint pointPosition, int includeCircleCentre);
/* get the list of points for the tapes on the given distAss, if ignoreInvisible then don't
 * return points for partially complete, invisible, tapes */
DV_EXPORT ECItem *ECDist_GetPointList(ECDistance *distAss, int ignoreInvisible);
/* get the circle centre for tapes of type circle */
DV_EXPORT int ECDist_GetCircleCentre(ECDistance *distAss, dmPoint centre);
/* get the assemblies the tape in distAss is attached too */
DV_EXPORT ECItem *ECDist_GetAssemblyList(ECDistance *distAss);
/* get the length/radius of the tape in distAss */
DV_EXPORT float32 ECDist_GetDistance(ECDistance *distAss);
/* get the length of the single line tape in distAss in dimen */
DV_EXPORT float32 ECDist_GetLineDimentionDistance(ECDistance *distAss, ECDistDimention dimen);
/* add a new point to the single line tape in distAss */
DV_EXPORT int ECDist_AddPoint(ECDistance *distAss, dmPoint pos, VCEntity *entity);
/* update point pointNum so it is attached to entity, at pos */
DV_EXPORT int ECDist_UpdatePoint(ECDistance *distAss, int pointNum, dmPoint pos, 
                       VCEntity *entity);
/* remove the last point of the tape in distAss */
DV_EXPORT int ECDist_RemoveLastPoint(ECDistance *distAss);
/* returns widgets for the point given, there can be two for multi line tapes,
 * as the end of one segment, and the start of the next use seperate widgets */
DV_EXPORT int ECDist_GetWidgetsForPoint(ECDistance *distAss, int pointNum, 
                              VWidget **beginWidget, VWidget **endWidget);
/* returns true if the distAss is halfway through adding/updating a point */
DV_EXPORT int ECDist_CurrentlyAlteringPoint(ECDistance *distAss);
/* return number of points in tape of distAss */
DV_EXPORT int ECDist_GetNumPoints(ECDistance *distAss);
/* return type of tape in distAss */
DV_EXPORT EDistType ECDist_GetType(ECDistance *distAss);
/* converts type from ECAssembly type to an EDistType */
DV_EXPORT EDistType ECDist_GetDistTypeFromAssembly(ECDistance *distAss);
/* returns max number of points allowed for a type of tape */
DV_EXPORT int ECDist_GetMaxPointsForType(ECDistance *distAss);
/* get the size of points in the tape of distAss */
DV_EXPORT EDistPointSize ECDist_GetPointSize(ECDistance *distAss);
/* set the size of points in the tape of distAss */
DV_EXPORT int ECDist_SetPointSize(ECDistance *distAss, EDistPointSize size);
/* get the geometry being used for the points in this tape */
DV_EXPORT char *ECDist_GetPointVisual(ECDistance *distAss, char *visual);
/* set the geometry being used for the points in this tape */
DV_EXPORT int ECDist_SetPointVisual(ECDistance *distAss, char *visual);
/* add a callback to be called when the length/radius of the tape changes */
DV_EXPORT int ECDist_AddDistanceChangedCb(ECDistance *distAss, void(*callBack)(void *),
                                void *callData);
/* remove all instances of the callback given */
DV_EXPORT int ECDist_RemoveDistanceChangedCb(ECDistance *distAss, void *callData);

/* parse in distance information from the userdata of disAss, which will setup tape */
DV_EXPORT int ECDistParse_ParseInFromUserData(ECDistance *distAss);
/* create some new tape user data for distAss */
DV_EXPORT int ECDistParse_CreateUserData(ECAssembly *distAss);
/* write out dist structure into user data */
DV_EXPORT int ECDistParse_WriteOutToUserData(ECDistance *distAss);

#ifdef __cplusplus
}
#endif

#endif /* __DVDIST_H__ */

