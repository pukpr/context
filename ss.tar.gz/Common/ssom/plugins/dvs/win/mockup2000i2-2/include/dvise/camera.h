/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: camera.h,v $
 *    Revision:     $Revision: 1.62 $
 *    Date:         $Date: 2000/05/15 16:27:18 $
 *    Author:       $Author: simon $
 *    RCS Ident:    $Id: camera.h,v 1.62 2000/05/15 16:27:18 simon Exp $
 *
 *    FUNCTION: defines data structures used in the EC file read/writer
 * 
 *
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */


#ifndef _CAMERA_H
#define _CAMERA_H

#include "ectools.h"

#ifdef __cplusplus
extern "C" {
#endif

/* PUBLIC DEFINES =======================================*/

#define ECCamera ECAssembly
#define ECLandmark ECAssembly
#define ECAnnotation ECAssembly
#define ECDistance ECAssembly
#define ECEnvelope ECAssembly
#define ECManikin ECAssembly
#define ECSegment ECAssembly
#define ECIKConstraint ECAssembly

#define EC_ASSEMBLY_TYPE_MASK                0xffffffff
#define EC_ASSEMBLY_CAMERA                   0x00000001
#define EC_ASSEMBLY_HYPERLINK                0x00000002
#define EC_ASSEMBLY_LANDMARK                 0x00000004
#define EC_ASSEMBLY_ANNOTATION               0x00000008
#define EC_ASSEMBLY_LIBRARY                  0x00000010
#define EC_ASSEMBLY_SPARE_1                  0x00000020
#define EC_ASSEMBLY_SPARE_2                  0x00000040
#define EC_ASSEMBLY_FOLDER                   0x00000080
#define EC_ASSEMBLY_VDI2_FLIGHT_PATH         0x00000100
#define EC_ASSEMBLY_SECTION                  0x00000200
#define EC_ASSEMBLY_USE_LIBRARY              0x00000400
#define EC_ASSEMBLY_DISTANCE                 0x00000800
#define EC_ASSEMBLY_DISTANCE_LINE            0x00001000
#define EC_ASSEMBLY_DISTANCE_MULTI           0x00002000
#define EC_ASSEMBLY_DISTANCE_CIRCLE          0x00004000
#define EC_ASSEMBLY_ENVELOPE                 0x00008000
#define EC_ASSEMBLY_GROUP                    0x00010000
#define EC_ASSEMBLY_GROUP_PAIRS              0x00020000
#define EC_ASSEMBLY_GROUP_SELFINTERSECT      0x00040000
#define EC_ASSEMBLY_DVSW_MANIKIN_ROOT        0x00080000
#define EC_ASSEMBLY_DVSW_MANIKIN_SEGMENT     0x00100000
#define EC_ASSEMBLY_DVSW_MANIKIN_CONSTRAINT  0x00200000

    /*
     * flightpath status values for the local tick event */
#define FP_STATUS_PLAYING        0
#define FP_STATUS_RECORDING      1
#define FP_STATUS_STOPPED        2

/* 
 * General Assembly flags */
#define EC_ASSEMBLY_RUNTIME_FLAGS   0x309ff1 /* mask to separate run-time
                                            * flags from savable flags */
#define EC_ASSEMBLY_RESETONCOPY_FLAGS   0x4309ff1 /* mask of flags to reset when copying
                                                   * an assembly */
#define EC_ASSEMBLY_COLLIDE_HANDLER_ADDED 	0x1
#define EC_ASSEMBLY_CREATE_ABSOLUTE 		0x2
#define EC_ASSEMBLY_FREEZE 			0x4
#define EC_ASSEMBLY_FLATTEN                     0x8
/*
 * EC_ASSEMBLY_SELECTED is a bit mask for the two possible types
 * of object selection.
 */
#define EC_ASSEMBLY_SELECTED	    0x10
#define EC_ASSEMBLY_LOADED          0x20
#define EC_ASSEMBLY_ENABLED         0x40
/*
 * The following flags are set if the object has been
 * touched or highlighted
 */
#define EC_ASSEMBLY_HIGHLIGHTED		0x80
#define EC_ASSEMBLY_TOUCHED		0x300
#define EC_ASSEMBLY_TOUCHED_2D		0x100
#define EC_ASSEMBLY_TOUCHED_3D		0x200
/*
 * These are not used...yet....but might be useful
 * to prevent selecting a picked object.
 */
#define EC_ASSEMBLY_PICKED		0xC00
#define EC_ASSEMBLY_2D_PICKED		0x400
#define EC_ASSEMBLY_3D_PICKED		0x800
/*
 * This flag is set in an ECAssembly->flags field whilst the object
 * is begin deleted. 
 */
#define EC_ASSEMBLY_BEING_DELETED       0x1000
    /*
     * flag to force this assembly to be loaded on startup
     */
#define EC_ASSEMBLY_FORCE_LOAD          0x2000
#define EC_ASSEMBLY_LOAD_STATE          0x4000
    /*
     * This flag is set if an assembly is attached to the body,
     * by something other than a pick
     */
#define EC_ASSEMBLY_ATTACHED        0x8000



/*
 * This flag is set if an assembly ( at the moment just a section ) is being viewed from a
 * position pointing towards the centre of a surface down the normal vector of the surface
 */

#define EC_ASSEMBLY_VIEWED         0x10000


/* These three flags are used only by the parser */
#define EC_ASSEMBLY_MERGED                   0x20000
#define EC_ASSEMBLY_PLACE_HOLDER             0x40000
#define EC_ASSEMBLY_CONTAINS_PLACE_HOLDER    0x80000

/* Flsgs used by selection routines */
#define EC_ASSEMBLY_DO_COLLIDE               0x100000
#define EC_ASSEMBLY_DO_UNCOLLIDE             0x200000 

/* This flag is set for assemblies not in the product structure */
#define EC_ASSEMBLY_FUNCTIONAL_ONLY 0x01000000

/* This flga is set for "system" assemblies that should
 * Not be displayed by the viewer
 */
#define EC_ASSEMBLY_SYSTEM	    0x02000000
#define EC_ASSEMBLY_IN_LIBRARY  0x04000000

/* Hidden is for non-system assemblies which should not be displayed
 * in viewer unlike system assemblies they will be saved to disk */
#define EC_ASSEMBLY_HIDDEN      0x08000000

/* this flag incorporates all assembly types that should not be visible in
 * the gui */
#define EC_ASSEMBLY_VIEWER_HIDDEN (EC_ASSEMBLY_SYSTEM | EC_ASSEMBLY_HIDDEN)

/* this flag states assembly is selected by the master user, set using EC_SetMasterUser */
#define EC_ASSEMBLY_MASTER_SELECTED 0x10000000

struct ECAssembly_Traverse {
    ECAssembly *root;
    ECAssembly *here;
    int level;
    int32 *maxOrd;
    int maxLevel;
};


/* PUBLIC TYPES =========================================*/

typedef struct ECAssembly_Traverse ECAssembly_Traverse;
typedef struct ECImage ECImage;

/* FUNCTION DECLARATIONS ================================*/
DV_EXPORT ECLandmark *EC_GetFileOpenActivateLandmark(void);
DV_EXPORT void EC_SetFileOpenActivateLandmark(ECLandmark *pECLandmark);

DV_EXPORT ECCamera *ECCamera_Create(char *name, ECAssembly *parent);
DV_EXPORT int ECCamera_Delete(ECCamera *c);
DV_EXPORT int ECCamera_SetIconImage(ECCamera *c, char *f, int s, 
				 VCBody *b, int w, int h);
DV_EXPORT ECTextureImage *ECCamera_GetIconImage(ECCamera *c);
DV_EXPORT ECCamera *EC_GetFirstCamera(ECAssembly *, ECAssembly_Traverse *);
DV_EXPORT ECCamera *EC_GetNextCamera(ECAssembly_Traverse *);
DV_EXPORT int ECAssembly_IsCamera(ECAssembly *a);

DV_EXPORT ECLandmark *ECLandmark_Create(char *n, ECCamera *ref);
DV_EXPORT int ECLandmark_Delete(ECLandmark *ref);
DV_EXPORT int ECLandmark_SetReference(ECLandmark *l, ECCamera *ref);
DV_EXPORT ECCamera *ECLandmark_GetReference_Old(ECLandmark *l);
DV_EXPORT int ECLandmark_Link(ECLandmark *parent);
DV_EXPORT int ECLandmark_SetIconImage(ECLandmark *c, char *f, int s, 
				   VCBody *b, int w, int h);
DV_EXPORT ECCamera *ECLandmark_GetReference(ECLandmark *l);
DV_EXPORT int ECLandmark_ForIncludeNodes(ECAssembly *l);
DV_EXPORT int ECLandmark_ExIncludeNodes(ECAssembly *l);
DV_EXPORT char *ECLandmark_GetSequenceName(ECLandmark *l);

DV_EXPORT ECTextureImage *ECLandmark_GetIconImage(ECLandmark *c);
DV_EXPORT ECLandmark *EC_GetFirstLandmark(ECAssembly *, ECAssembly_Traverse *);
DV_EXPORT ECLandmark *EC_GetNextLandmark(ECAssembly_Traverse *);
DV_EXPORT int ECAssembly_IsLandmark(ECAssembly *a);


DV_EXPORT ECAnnotation *ECAnnotation_Create(char *name, ECAssembly *parent);
DV_EXPORT int ECAnnotation_Delete(ECAnnotation *c);
DV_EXPORT int ECAnnotation_SetIconImage(ECAnnotation *c, char *f, int s, 
				     VCBody *b, int w, int h);
DV_EXPORT ECTextureImage *ECAnnotation_GetIconImage(ECAnnotation *c);
DV_EXPORT ECAnnotation *EC_GetFirstAnnotation(ECAssembly *, ECAssembly_Traverse *);
DV_EXPORT ECAnnotation *EC_GetNextAnnotation(ECAssembly_Traverse *);
DV_EXPORT int ECAssembly_IsAnnotation(ECAssembly *a);

DV_EXPORT ECAssembly *ECSection_Create(char *name, ECAssembly *parent);
DV_EXPORT int ECSection_Delete(ECAssembly *c);
DV_EXPORT int ECAssembly_IsSection(ECAssembly *a);

DV_EXPORT ECDistance *ECDistance_CreateLine(char *name, ECAssembly *parent);
DV_EXPORT ECDistance *ECDistance_CreateMulti(char *name, ECAssembly *parent);
DV_EXPORT ECDistance *ECDistance_CreateCircle(char *name, ECAssembly *parent);
DV_EXPORT int ECDistance_Delete(ECDistance *c);
DV_EXPORT int ECAssembly_IsDistance(ECAssembly *a);
DV_EXPORT int ECAssembly_IsDistanceLine(ECAssembly *a);
DV_EXPORT int ECAssembly_IsDistanceMulti(ECAssembly *a);
DV_EXPORT int ECAssembly_IsDistanceCircle(ECAssembly *a);
DV_EXPORT int ECAssembly_IsLight(ECAssembly *a);
DV_EXPORT int ECAssembly_HasPivot(ECAssembly *a);
DV_EXPORT int ECAssembly_IsEnvelope(ECAssembly *a);
DV_EXPORT int ECAssembly_IsManikin(ECAssembly *a);
DV_EXPORT int ECAssembly_IsSegment(ECAssembly *a);
DV_EXPORT int ECAssembly_IsIKConstraint(ECAssembly *);

/*****************************************************************************
 * Generic assembly routines for cameras etc
 *****************************************************************************/

DV_EXPORT ECAssembly *ECAssembly_GetFirst(ECAssembly *a, ECAssembly_Traverse *t);
DV_EXPORT ECAssembly *ECAssembly_GetNext(ECAssembly_Traverse *t);
DV_EXPORT int32 ECAssembly_GetRelativeDepth(ECAssembly *a, ECAssembly *root);
DV_EXPORT int ECAssembly_SetIconImage(ECAssembly *c, char *f, int s, 
				   VCBody *b, int w, int h);
DV_EXPORT ECTextureImage *ECAssembly_GetIconImage(ECAssembly *c);
DV_EXPORT int ECAssembly_IsSelected(ECAssembly *a);
DV_EXPORT int ECAssembly_IsSelectedByMaster(ECAssembly *a);
DV_EXPORT int ECAssembly_IsLoaded(ECAssembly *a);
DV_EXPORT int ECAssembly_IsEnabled(ECAssembly *a);
DV_EXPORT int ECAssembly_IsEnabledAndLoaded(ECAssembly *a);
DV_EXPORT int ECAssembly_IsHighlighted(ECAssembly *a);
DV_EXPORT int ECAssembly_IsPicked(ECAssembly *a);
DV_EXPORT int ECAssembly_IsLibrary(ECAssembly *a);
DV_EXPORT int ECAssembly_IsInLibrary(ECAssembly *a);
DV_EXPORT int ECAssembly_IsSpare1(ECAssembly *a);
DV_EXPORT int ECAssembly_IsSpare2(ECAssembly *a);
DV_EXPORT int ECAssembly_IsAttached(ECAssembly *a);
DV_EXPORT int ECAssembly_CanFlyTo(ECAssembly *a);
DV_EXPORT ECAssembly *ECAssembly_GetIncludeNode(ECAssembly *obj);

/******************************************************************************
 * Icon routines for handling camera images
 ******************************************************************************/

DV_EXPORT ECTextureImage *ECIcon_GetTextureImage(ECIcon *i);
DV_EXPORT char *ECIcon_GetTextureName(ECIcon *i);
DV_EXPORT char *ECIcon_GetTextureFileName(ECIcon *i);
DV_EXPORT int32 ECIcon_SetTextureFromSnap(ECIcon *icon, VCBody *bod, int wid, int hgt);
DV_EXPORT int32 ECIcon_SetTextureFromFile(ECIcon *icon, char *filename);
DV_EXPORT int32 ECIcon_Delete(ECIcon *c);
DV_EXPORT int32 ECIcon_ToFile(ECIcon *c);

#ifdef __cplusplus
}
#endif

#endif /* _CAMERA.H__ */
