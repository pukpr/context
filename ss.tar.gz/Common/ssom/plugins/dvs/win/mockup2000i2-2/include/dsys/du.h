/*
 *    PROJECT:      DVS
 *    SUBSYSTEM:    du
 *    MODULE:       du.h
 *
 *    File:         $RCSfile: du.h,v $
 *    Revision:     $Revision: 1.28 $
 *    Date:         $Date: 2003/09/24 14:22:54 $
 *    Author:       $Author: jeff $
 *    RCS Ident:    $Id: du.h,v 1.28 2003/09/24 14:22:54 jeff Exp $
 *
 *    FUNCTION:
 *    external declarations of functions in the du library.
 *
 *
 * Copyright (c) 1994, 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _DU_H
#define _DU_H

#include <stdio.h>
#include <string.h>

#ifndef DU_EXPORT
#if defined(_WIN32) && !defined(_WINDU_SOURCE) && !defined(__EPP__) && !defined(BUILD_STATIC)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `extern'
 */
#ifdef  _LIB_DIVU
#define DU_EXPORT __declspec(dllexport) extern
#else
#define DU_EXPORT __declspec(dllimport) extern
#endif
#else
#define DU_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ndef DU_EXPORT */


#ifdef __cplusplus
extern "C" {
#endif

/*
 * strcasecmp functions
 *
 */

DU_EXPORT int duStrcasecmp(const char *s1, const char *s2);
DU_EXPORT int duStrncasecmp(const char *s1, const char *s2, size_t n);

DU_EXPORT void duVersion(FILE *fp);

/*
 * Functions for efficient allocation of many identically sized blocks.
 */

/*
 * many small chunks are allocated at once. One of these
 * structures manages that.
 */
typedef struct duBlkAllocChunk duBlkAllocChunk;

/*
 * the block header. Contains house keeping info for the block allocator.
 */
typedef struct duBlkCtrl {
    duBlkAllocChunk *freeChunks;  /* Ptr to linked list of free blocks */
    void              *freeList;  /* Pointer to the free list          */
    unsigned long    totalItems;  /* Total number of block items       */
    unsigned long     freeItems;  /* Total number of free items        */
    unsigned long     chunkSize;  /* Number of items to alloc at once  */
    unsigned long     itemAlign;  /* Alignment of units in bytes.      */
    unsigned long      itemSize;  /* Size of items in bytes            */
} duBlkCtrl;
DU_EXPORT void duBlkAllocConstruct(duBlkCtrl *ctrlBlock,
                                unsigned long is,
                                unsigned long cs,
                                unsigned long align);
typedef void* (*duAllocFunc)(unsigned long);
typedef void   (*duFreeFunc)(void*);

DU_EXPORT void  duBlkAllocDestruct(duBlkCtrl *ctrlBlock,
                                   duFreeFunc ffunc);
DU_EXPORT void         *duBlkAlloc(duBlkCtrl *ctrlBlock,
                                   duAllocFunc afunc);
DU_EXPORT void           duBlkFree(duBlkCtrl *ctrlBlock, void *item);

/*
 * Functions to manipulate hash tables.
 */
typedef long (*duHfunc)(void *key, long size);
typedef int (*duCfunc)(void *a, void *b);
typedef struct duHashElem duHashElem;
typedef struct duHashTab duHashTab;

/*
 * the following is used if iterating over all the elements in a hash
 * table. It keeps track of where in the table you are for use with the
 * iteration functions.
 */
typedef struct duHashIterator {
    duHashTab  *h;
    long      bucket;
    duHashElem *item;
    duHashElem *prev;
} duHashIterator;

DU_EXPORT void           *duHashLookup  (duHashTab *t, void *key);
DU_EXPORT void           duHashInstall  (duHashTab *t, void *key, void *datum);

#define duHashRemove(t, key)    duHashRemoveK((t), (key), NULL)
#define duHashRemoveK(t, key, old)    duHashRemoveKDatum ((t), (key), NULL, (old) )

DU_EXPORT void           *duHashRemoveKDatum (duHashTab *t, void *key, void *d, void **old_key);
DU_EXPORT duHashTab      *duNewHashTab  (long Size, duHfunc hashfun,
                                     duCfunc cmpfun);
DU_EXPORT void           duDeleteHashTab  (duHashTab *t);

typedef int (*duIfunc)(void *key, void *user_data, void **inst_key, void ** inst_datum);
typedef void (*duDfunc)(void *key, void *datum);

DU_EXPORT void  *duHashLookupInstall    (duHashTab *t, void *key, duIfunc instfun, void *user_data, int *found);
DU_EXPORT void  duIterateDestroyHashTab (duHashTab *t, duDfunc destroyfun);

#define duHashIterateInit(iter, t) \
    duHashIterateInitK(iter, t, NULL)

#define duHashIterate(iter) \
    duHashIterateK(iter, NULL)

DU_EXPORT void      *duHashIterateInitK (duHashIterator *iter, duHashTab *t,
                                      void **key);
DU_EXPORT void          *duHashIterateK (duHashIterator *iter, void **key);

#define duHashIterateRm(i) \
    duHashIterateRmK((i), NULL)

DU_EXPORT void          *duHashIterateRmK(duHashIterator *iter, void **key);

#define DU_VERBOSE_ALLWAYS 	0x80000000
#define DU_DEBUG_ALLWAYS 	0x80000000

DU_EXPORT void 	         __duVerboseStart		(int module, int level);
DU_EXPORT void 	         __duDebugStart			(int module, int level, char *file, int line);
DU_EXPORT void           __duVerboseMessage		(char *format, ...);
DU_EXPORT unsigned long  duVerbose_ModuleSetLevel	(unsigned int module, unsigned long level);
DU_EXPORT unsigned long  duVerbose_ModuleGetLevel	(unsigned int module) ;
DU_EXPORT unsigned long	 duDebug_ModuleSetLevel		(unsigned int module, unsigned long level);
DU_EXPORT unsigned long	 duDebug_ModuleGetLevel		(unsigned int module);
DU_EXPORT FILE	     	*duDebug_SetLogFile		(FILE *, int mode);
DU_EXPORT char	        *duDebug_SetName		(char *, int mode);
DU_EXPORT void	         duDebug_Quiet			(void);
DU_EXPORT void	         duDebug_VeryQuiet		(void);
DU_EXPORT void	         duDebug_Noisy			(void);
DU_EXPORT void 	         duWarn				(char *format, ...);
DU_EXPORT void   	 duError			(char *format, ...);
DU_EXPORT void 	         duFatal			(char *format, ...);
DU_EXPORT int		 duVerbose_GetModuleHandle	(char *moduleName);
DU_EXPORT int		 duDebug_GetModuleHandle	(char *moduleName);
DU_EXPORT int		 duDebug_AddModuleHelp(int module, char *help);
DU_EXPORT char 		*duDebug_GetModuleHelp(int module);
DU_EXPORT int		 duVerbose_AddModuleHelp(int module, char *help);
DU_EXPORT char 		*duVerbose_GetModuleHelp(int module);
DU_EXPORT int		 duVerbose_GetModuleName(int module, char **name);
DU_EXPORT int		 duDebug_GetModuleName(int module, char **name);
DU_EXPORT void           duMessageServerMode(const int mode, const int socket);

typedef struct {
    unsigned long	 level;
    char		*moduleName;
    char		*help;
} duVerboseInfo;


DU_EXPORT duVerboseInfo		*__duVerboseLevels;
DU_EXPORT duVerboseInfo		*__duDebugLevels;

#define DU_DEBUG_DONT_OVERRIDE	0
#define DU_DEBUG_OVERRIDE	1

#define duVerbose(x,y)  do {                                        \
                            if (__duVerboseLevels[1].level & (x))   \
                            {                                       \
                                __duVerboseStart(1,x);		    \
                                __duVerboseMessage y;               \
                            }                                       \
                        } while (0)

#define duVerbose_Module(x,m,y)  do {                               \
                            if (__duVerboseLevels[m].level & (x))   \
                            {                                       \
                                __duVerboseStart(m,x);		    \
                                __duVerboseMessage y;               \
                            }                                       \
                        } while (0)

#ifdef NDEBUG
#undef duDebug
#define duDebug(x,y) 		((void)0)
#define duDebug_Module(x,m,y) 	((void)0)
#else
#undef duDebug
#define duDebug(x,y)  do {                                        	\
                            if (__duDebugLevels[1].level & (x))       	\
                            {                                       	\
                                __duDebugStart(1, x, __FILE__, __LINE__);	\
                                __duVerboseMessage y;               	\
                            }                                       	\
                        } while (0)
#undef duDebug_Module
#define duDebug_Module(x,m,y)  do {                                        	\
                            if (__duDebugLevels[m].level & (x))       	\
                            {                                       	\
                                __duDebugStart(m, x, __FILE__, __LINE__);	\
                                __duVerboseMessage y;               	\
                            }                                       	\
                        } while (0)
#endif

#define duVerbose_SetLevel(l) duVerbose_ModuleSetLevel(1,l)
#define duVerbose_GetLevel()  duVerbose_ModuleGetLevel(1)
#define duDebug_SetLevel(l)   duDebug_ModuleSetLevel(1,l)
#define duDebug_GetLevel()    duDebug_ModuleGetLevel(1)


typedef void (*duNameCb)(const char* const name);
typedef void (*duModuleCb)(const char* const name, const int id);

typedef void (*duVerboseCb)(const int module, const int level, const char* const msg);
typedef void (*duDebugCb)(const int module, const int level,
                          const char* file, const int line,
                          const char* const msg);
typedef void (*duWarnCb)(const char* const msg);
typedef void (*duErrorCb)(const char* const msg);
typedef void (*duFatalCb)(const char* const msg);

DU_EXPORT duNameCb duNameSetCb(duNameCb);
DU_EXPORT duModuleCb duDebugModuleSetCb(duModuleCb);
DU_EXPORT duModuleCb duVerboseModuleSetCb(duModuleCb);
DU_EXPORT duWarnCb duWarnSetCb(duWarnCb);
DU_EXPORT duErrorCb duErrorSetCb(duErrorCb);
DU_EXPORT duFatalCb duFatalSetCb(duFatalCb);
DU_EXPORT duDebugCb duDebugSetCb(duDebugCb);
DU_EXPORT duVerboseCb duVerboseSetCb(duVerboseCb);
DU_EXPORT void duPullMessageConfig(void);


#define DU_SYSTEM_ERROR (-1)
DU_EXPORT int duErrno;
DU_EXPORT int duErrType;
DU_EXPORT int         duRegisterErrors(int errorCount, const char **errorStrings);
DU_EXPORT const char       *duStrError(int errnum, int errtype);
DU_EXPORT void                duPerror(const char *mesg);

DU_EXPORT int duGetKeycode(char *string, unsigned int *keyCode);

/* Keycodes */
/*
 * define the modifier values
 */
#define VC_INPUT_RELEASE 	0x00010000
#define VC_INPUT_PRESS		0x00020000
#define VC_MODIFIER_0   	0x00100000
#define VC_MODIFIER_1   	0x00200000
#define VC_MODIFIER_2   	0x00400000
#define VC_MODIFIER_3   	0x00800000
#define VC_MODIFIER_4   	0x01000000
#define VC_MODIFIER_5   	0x02000000
#define VC_MODIFIER_6   	0x04000000
#define VC_MODIFIER_7   	0x08000000
#define VC_INPUT_TOGGLE         0x10000000
#define VC_INPUT_ALL_MODIFIERS	0x20000000

#define VC_MODIFIER_SHIFT	VC_MODIFIER_0
#define VC_MODIFIER_CTRL	VC_MODIFIER_1
#define VC_MODIFIER_ALT		VC_MODIFIER_2
#define VC_MODIFIER_ESC		VC_MODIFIER_3
#define VC_MODIFIER_AUTO_RPT	VC_MODIFIER_4	/* Key caused by an auto-rpt */

#define VC_INPUT_CODE_MASK	0x0000ffff
#define VC_INPUT_TYPE		0x000f0000
#define VC_INPUT_MODIFIER_MASK	0x0ff00000
#define VC_INPUT_ALL_KEYS	0x0000ffff
#define VC_INPUT_SINGLE_KEY	0x00000000

#define VC_BackSpace		0xFF08   /* XK_BackSpace */
#define VC_Tab			0xFF09   /* XK_Tab */
#define VC_Linefeed		0xFF0A   /* XK_Linefeed */
#define VC_Clear		0xFF0B   /* XK_Clear */
#define VC_Return		0xFF0D   /* XK_Return */
#define VC_Pause		0xFF13   /* XK_Pause */
#define VC_Scroll_Lock		0xFF14   /* XK_Scroll */
#define VC_Sys_Req              0xFF15   /* XK_Sys */
#define VC_Escape		0xFF1B   /* XK_Escape */


#define VC_Home			0xFF50  /* XK_Home */
#define VC_Left			0xFF51	/* Move left, left arrow */  /* XK_Left */
#define VC_Up			0xFF52	/* Move up, up arrow, XK_Up */
#define VC_Right		0xFF53	/* Move right, right arrow, XK_Right */
#define VC_Down			0xFF54	/* Move down, down arrow, XK_Down */
#define VC_Prior		0xFF55	/* Prior, previous, XK_Prior */
#define VC_Page_Up		0xFF55  /* XK_Page_Up */
#define VC_Next			0xFF56	/* Next, XK_Next */
#define VC_Page_Down		0xFF56  /* XK_Page_Down */
#define VC_End			0xFF57	/* EOL, XK_End */
#define VC_Begin		0xFF58	/* BOL, XK_Begin */


/* Misc Functions */

#define VC_Select		0xFF60	/* Select, mark, XK_Select */
#define VC_Print		0xFF61  /* XK_Print */
#define VC_Execute		0xFF62	/* Execute, run, do, XK_Execute */
#define VC_Insert		0xFF63	/* Insert, insert here, XK_Insert */
#define VC_Undo			0xFF65	/* Undo, oops, XK_Undo */
#define VC_Redo			0xFF66	/* redo, again, XK_Redo */
#define VC_Menu			0xFF67  /* XK_Menu */
#define VC_Find			0xFF68	/* Find, search, XK_Find */
#define VC_Cancel		0xFF69	/* Cancel, stop, abort, exit, XK_Cancel */
#define VC_Help			0xFF6A	/* Help, ?, XK_Help */
#define VC_Break		0xFF6B  /* XK_Break */
#define VC_Mode_switch		0xFF7E	/* Character set switch, XK_Mode_switch */
#define VC_script_switch        0xFF7E  /* Alias for mode_switch, XK_script_switch */
#define VC_Num_Lock		0xFF7F  /* XK_Num_Lock */

/* Keypad Functions, keypad numbers cleverly chosen to map to ascii */

#define VC_KP_Space		0xFF80	/* space, XK_KP_Space */
#define VC_KP_Tab		0xFF89  /* XK_KP_Tab */
#define VC_KP_Enter		0xFF8D	/* enter, XK_KP_Enter */
#define VC_KP_F1		0xFF91	/* PF1, KP_A, ..., XK_KP_F1 */
#define VC_KP_F2		0xFF92  /* XK_KP_F2 */
#define VC_KP_F3		0xFF93  /* XK_KP_F3 */
#define VC_KP_F4		0xFF94  /* XK_KP_F4 */
#define VC_KP_Home		0xFF95  /* XK_KP_Home */
#define VC_KP_Left		0xFF96  /* XK_KP_Left */
#define VC_KP_Up		0xFF97  /* XK_KP_Up */
#define VC_KP_Right		0xFF98  /* XK_KP_Right */
#define VC_KP_Down		0xFF99  /* XK_KP_Down */
#define VC_KP_Prior		0xFF9A  /* XK_KP_Prior */
#define VC_KP_Page_Up		0xFF9A  /* XK_KP_Page_Up */
#define VC_KP_Next		0xFF9B  /* XK_KP_Next */
#define VC_KP_Page_Down		0xFF9B  /* XK_KP_Page_Down */
#define VC_KP_End		0xFF9C  /* XK_KP_End */
#define VC_KP_Begin		0xFF9D  /* XK_KP_Begin */
#define VC_KP_Insert		0xFF9E  /* XK_KP_Insert */
#define VC_KP_Delete		0xFF9F  /* XK_KP_Delete */
#define VC_KP_Equal		0xFFBD	/* equals, XK_KP_Equal */

#define VC_KP_Multiply		0xFFAA  /* XK_KP_Multiply */
#define VC_KP_Add		0xFFAB  /* XK_KP_Add */
#define VC_KP_Separator		0xFFAC	/* separator, often comma, XK_KP_Separator */
#define VC_KP_Subtract		0xFFAD  /* XK_KP_Subtract */
#define VC_KP_Decimal		0xFFAE  /* XK_KP_Decimal */
#define VC_KP_Divide		0xFFAF  /* XK_KP_Divide */

#define VC_KP_0			0xFFB0  /* XK_KP_0 */
#define VC_KP_1			0xFFB1  /* XK_KP_1 */
#define VC_KP_2			0xFFB2  /* XK_KP_2 */
#define VC_KP_3			0xFFB3  /* XK_KP_3 */
#define VC_KP_4			0xFFB4  /* XK_KP_4 */
#define VC_KP_5			0xFFB5  /* XK_KP_5 */
#define VC_KP_6			0xFFB6  /* XK_KP_6 */
#define VC_KP_7			0xFFB7  /* XK_KP_7 */
#define VC_KP_8			0xFFB8  /* XK_KP_8 */
#define VC_KP_9			0xFFB9  /* XK_KP_9 */

#define VC_F1			0xFFBE  /* XK_F1 */
#define VC_F2			0xFFBF  /* XK_F2 */
#define VC_F3			0xFFC0  /* XK_F3 */
#define VC_F4			0xFFC1  /* XK_F4 */
#define VC_F5			0xFFC2  /* XK_F5 */
#define VC_F6			0xFFC3  /* XK_F6 */
#define VC_F7			0xFFC4  /* XK_F7 */
#define VC_F8			0xFFC5  /* XK_F8 */
#define VC_F9			0xFFC6  /* XK_F9 */
#define VC_F10			0xFFC7  /* XK_F10 */
#define VC_F11			0xFFC8  /* XK_F11 */
#define VC_F12			0xFFC9  /* XK_F12 */
#define VC_F13			0xFFCA  /* XK_F13 */
#define VC_F14			0xFFCB  /* XK_F14 */
#define VC_F15			0xFFCC  /* XK_F15 */
#define VC_F16			0xFFCD  /* XK_F16 */
#define VC_F17			0xFFCE  /* XK_F17 */
#define VC_F18			0xFFCF  /* XK_F18 */
#define VC_F19			0xFFD0  /* XK_F19 */
#define VC_F20			0xFFD1  /* XK_F20 */
#define VC_F21			0xFFD2  /* XK_F21 */
#define VC_F22			0xFFD3  /* XK_F22 */
#define VC_F23			0xFFD4  /* XK_F23 */
#define VC_F24			0xFFD5  /* XK_F24 */
#define VC_F25			0xFFD6  /* XK_F25 */
#define VC_F26			0xFFD7  /* XK_F26 */
#define VC_F27			0xFFD8  /* XK_F27 */
#define VC_F28			0xFFD9  /* XK_F28 */
#define VC_F29			0xFFDA  /* XK_F29 */
#define VC_F30			0xFFDB  /* XK_F30 */
#define VC_F31			0xFFDC  /* XK_F31 */
#define VC_F32			0xFFDD  /* XK_F32 */
#define VC_F33			0xFFDE  /* XK_F33 */
#define VC_F34			0xFFDF  /* XK_F34 */
#define VC_F35			0xFFE0  /* XK_F35 */
#define VC_SHIFT_L		0xFFE1
#define VC_SHIFT		VC_SHIFT_L
#define VC_SHIFT_R		0xFFE2
#define VC_CTRL_L		0xFFE3
#define VC_CTRL			VC_CTRL_L
#define VC_CTRL_R		0xFFE4

#define VC_META_L		0xFFE7
#define VC_META_R		0xFFE8
#define VC_ALT_L		0xFFE9
#define VC_ALT_R		0xFFEA
#define VC_ALT			VC_META_L



#define VC_BUTTON_0		0x0080
#define VC_BUTTON_1		0x0081
#define VC_BUTTON_2		0x0082
#define VC_BUTTON_3		0x0083
#define VC_BUTTON_4		0x0084
#define VC_BUTTON_5		0x0085
#define VC_BUTTON_6		0x0086
#define VC_BUTTON_7		0x0087
#define VC_BUTTON_8		0x0088
#define VC_BUTTON_9		0x0089
#define VC_BUTTON_10		0x008a
#define VC_BUTTON_11		0x008b
#define VC_BUTTON_12		0x008c
#define VC_BUTTON_13		0x008d
#define VC_BUTTON_14		0x008e
#define VC_BUTTON_15		0x008f

#ifdef __cplusplus
}
#endif
#endif /*_DU_H */
