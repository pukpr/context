#ifndef _ECSYNCTIMER_H
#define _ECSYNCTIMER_H

#include "ectypes.h"
#include "ecsmartptr.h"
#include "eciteminfo.h"
class DV_EXPORT _ECSyncTimer;

class _ECSyncTimer;
typedef ECSmartPtr<_ECSyncTimer> ECSyncTimerPtr;

class DV_EXPORT _ECSyncTimer: public _ECBaseItem
{
public:
    typedef enum { FORWARDS, BACKWARDS } timerDirection;

    _ECSyncTimer();
    ~_ECSyncTimer();

    int getId(void) const;
    char *getIdString(void) const;
    static ECCallbackIterator attachGlobalCreateCallback(ecGlobalCallbackFunc func, void *data)
    {
        return _ECBaseItem::attachGlobalCreateCallback(getMyId(), func, data);
    }
    static ECCallbackIterator attachGlobalUpdateCallback(ecGlobalCallbackFunc func, void *data)
    {
        return _ECBaseItem::attachGlobalUpdateCallback(getMyId(), func, data);
    }
    static ECCallbackIterator attachGlobalDeleteCallback(ecGlobalCallbackFunc func, void *data)
    {
        return _ECBaseItem::attachGlobalDeleteCallback(getMyId(),func, data);
    }

    static void detachGlobalCreateCallback(ECCallbackIterator iter)
    {
        _ECBaseItem::detachGlobalCreateCallback(getMyId(), iter);
    }
    static void detachGlobalUpdateCallback(ECCallbackIterator iter)
    {
        _ECBaseItem::detachGlobalUpdateCallback(getMyId(), iter);
    }
    static void detachGlobalDeleteCallback(ECCallbackIterator iter)
    {
        _ECBaseItem::detachGlobalDeleteCallback(getMyId(),iter);
    }
    static int getMyId();

    static _ECSyncTimer *create()
    {
        _ECSyncTimer *newAssembly = new _ECSyncTimer;
        newAssembly->_create(0);
        return newAssembly;
    };
    _ECBaseItem *clone(void) const
    {
        _ECSyncTimer *newAssembly = new _ECSyncTimer(*this);
        newAssembly->_create(0);
        return newAssembly;
    };
    void	GotSync(double time);
    double	GetTime(void) const { return m_time;};
    void	SetTime(double time);
    void	SetDirection(timerDirection direction);
    void	SetWakeupTime(double time);
	void	Pause();
	void	Continue(bool fromPauseTime);
    bool	IsPaused(void) const;

private:
    double	m_time;
    double	m_lastWakeupTime;
    double	m_wakeupTime;
	uint32	m_state;
    double	m_lastForwardTime;
    double	m_lastPauseTime;
};

DV_TEMPLATE_EXPORT template class DV_EXPORT ECSmartPtr<_ECSyncTimer>;

#endif
