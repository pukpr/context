/*
-- ----------------------------------------------------------------------------
--
--  		     Copyright 1996, 1997 Division Limited.
--			      All Rights Reserved
--
--
--  System       : dVS
--  Module       : Registry library
--  Object Name  : $RCSfile: dreg.h,v $
--  Revision     : $Revision: 1.15 $
--  Date         : $Date: 1999/03/22 11:23:49 $
--  Author       : $Author: jeff $
--
--  Description	
--	Defines the interface to the Division registry library.
-- 
--  Notes
--
--  History
--	
--
-- ----------------------------------------------------------------------------
*/

#ifndef __DREG_H__
#define __DREG_H__

#ifdef __cplusplus
extern "C" {
#endif

/*
 * ------------------------------------------------------------
 *
 * Windows NT needs us to define the symbols we are exporting
 * and importing from a DLL.
 *
 * Under unix we can just use extern.
 *
 * ------------------------------------------------------------
 */
    
#ifndef DREG_EXPORT
#    if defined(_WIN32) && !defined(_WINDU_SOURCE) && !defined(__EPP__) && !defined (BUILD_STATIC)
#        ifdef  _LIB_DIVU
#            define DREG_EXPORT __declspec(dllexport) extern 
#        else
#            define DREG_EXPORT __declspec(dllimport) extern 
#        endif 
#    else
#        define DREG_EXPORT  extern
#    endif /* ! _WIN32 */
#endif /* not def DREG_EXPORT */

/*
 * ------------------------------------------------------------
 *
 * Registry node status values.
 *
 * ------------------------------------------------------------
 */
 
    
#define REGISTRY_STATUS_CONDITION 0x0001  /* This is a conditional node */
#define REGISTRY_STATUS_HEAD      0x0002  /* This is a header node */
#define REGISTRY_STATUS_LITERAL   0x0004  /* This is a literal node */
#define REGISTRY_STATUS_AUTO      0x0008  /* This is an automatic node */
#define REGISTRY_STATUS_NOEVAL    0x0010  /* Tag the tree as evaluate disable */
#define REGISTRY_STATUS_ENV       0x0020  /* Tag the tree as an environment variable */
#define REGISTRY_STATUS_REG       0x0040  /* Tag the tree as a registry variable */
#define REGISTRY_STATUS_EVALUATED 0x0080  /* Node has been evaluated. */

/*
 * ------------------------------------------------------------
 *
 * Registry verbosity flags
 *
 * ------------------------------------------------------------
 */
 
#define DREG_VRBSE_CREATE    0x00000001 /* Node create */
#define DREG_VRBSE_DELETE    0x00000002 /* Node delete */
#define DREG_VRBSE_EXPORT    0x00000004 /* Node export */
#define DREG_VRBSE_CLONE     0x00000008 /* Node clone */
#define DREG_VRBSE_CONNECT   0x00000010 /* Registry connect */
#define DREG_VRBSE_LINE1     0x00000020 /* Input echo - level 1 */
#define DREG_VRBSE_LINE2     0x00000040 /* Input echo - level 2 */
#define DREG_VRBSE_COND1     0x00000080 /* Conditional processing - level 1 */
#define DREG_VRBSE_COND2     0x00000100 /* Conditional processing - level 2 */
#define DREG_VRBSE_ENV       0x00000200 /* Environment processing */
#define DREG_VRBSE_GET       0x00000400 /* Node get */
#define DREG_VRBSE_SET       0x00000800 /* Node set */
#define DREG_VRBSE_TREE      0x00001000 /* Print tree after loading */

DREG_EXPORT int dreg_verbose;   /* verbose mask */

/*
 * ------------------------------------------------------------
 *
 * Registry debugging flags
 *
 * Setting the 'dreg_debug' variable changes these immediatly.
 *
 * ------------------------------------------------------------
 */

#define DREG_DEBUG_DECOMPOSE 0x00010000 /* Name decomposition debugging */
#define DREG_DEBUG_CONSTRUCT 0x00020000 /* Node construction debugging */
#define DREG_DEBUG_DESTRUCT  0x00040000 /* Node construction debugging */
#define DREG_DEBUG_LINK      0x00080000 /* Node linkage debugging */
#define DREG_DEBUG_UNLINK    0x00100000 /* Node linkage debugging */
#define DREG_DEBUG_FIND      0x00200000 /* Node searching debugging */
#define DREG_DEBUG_COND      0x00400000 /* Conditional debugging. */
#define DREG_DEBUG_ENV       0x00800000 /* Environment debugging */

DREG_EXPORT int dreg_debug;     /* Debug mask */

/*
 * ------------------------------------------------------------
 *
 * The registry data structures.  Registry provides an opaque
 * handle to the underlying registry nodes.
 *
 * The TraverseInfo structure maintains state during traversal.
 * Library users will typically declare these on the stack
 * so the internal structure has been exposed.
 *
 * ------------------------------------------------------------
 */
 
typedef struct Registry Registry;

typedef struct dreg_TraverseInfo
{
    Registry *r;
    struct RegistryValue *v;
    struct RegistryValue *c;
} dreg_TraverseInfo;

/*
 * ------------------------------------------------------------
 *
 * dVS support functions
 *
 * These functions are used by the actors to ensure
 * that they open the same set of registry files when
 * accessing configuration information.
 *
 * ------------------------------------------------------------
 */

DREG_EXPORT Registry *dreg_OpenDvsRegistry(void);
DREG_EXPORT Registry **dreg_OpenDvsRegistryParts(char ***regNameList);

/*
 * ------------------------------------------------------------
 *
 * Registry library interface functions.
 *
 * ------------------------------------------------------------
 */

        /*
          -- dreg_Open
          --
          -- Open a registry file and merge it with the registry
          -- pointed to by r.
          -- If r is NULL then a new registry is created and the
          -- contents of the file loaded into it.
          -- If both r and fileName are NULL then a new empty registry
          -- is created.
          --
          -- A pointer to the registry is returned on success and
          -- NULL on failure.
        */
                   
DREG_EXPORT Registry *dreg_Open(Registry *r, const char * const fileName);

        /*
          -- dreg_Close
          --
          -- Deletes the contents of the registry pointed to by
          -- r and frees the heap space used by it.
        */
    
DREG_EXPORT int dreg_Close(Registry *r);

        /*
          -- dreg_Copy
          --
          -- Copies the contents of the registry pointed to by from
          -- to the registry pointed to by to.
          */
    
DREG_EXPORT int dreg_Copy(Registry *to, Registry *from);

        /*
          -- dreg_Export
          --
          -- Writes the contents of the the registry pointed to by r
          -- to the file named in fileName.
          -- The file is written in a form readable by the dreg_Open
          -- function.
          */
    
DREG_EXPORT int dreg_Export(Registry *r, const char * const fileName);

        /*
          -- dreg_DiffExport
          --
          -- Writes the differences between the contents of registry r with diff
          -- to the file named in fileName.
          -- The file is written in a form readable by the dreg_Open
          -- function.
          */
    
DREG_EXPORT int dreg_DiffExport(Registry *r, const char * const fileName, Registry *diff);

        /*
          -- dreg_Info
          --
          -- Provide information about the registry node pointed to by
          -- r.  Any of the remaining arguments may be NULL, if they are
          -- non-NULL then they will contain the following at function
          -- return:
          -- 
          -- name - the node's name
          -- path - the full path to this node
          -- numChildren - the number of child nodes this node has
          -- numValues - then number of values this nodes contains
          -- level - the depth of this node from the root.
        */
          
DREG_EXPORT int dreg_Info(Registry *r, char **name, char **pathName,
                          int *numChildren, int *numValues, int *level);

        /* 
           -- dreg_Status
           --
           -- Sets and clears bits in a registry node's status field.
           --
           -- The bits set in the set_status will be set in the status field.
           -- The bits set in the clear_status will be unset in the status field.
           --
           -- The new status is returned from the function.  The current status
           -- may be obtained by passing set_status and clear_status paremters set
           -- to zero.
        */
    
DREG_EXPORT int dreg_Status(Registry *r, const int set_status, const int clear_status);

        /*
          -- dreg_CreateNode
          --
          -- Create a node with the name given by 'node' as a child of
          -- the registry node pointed to by r. If name may be a path
          -- name, in which case a hierarchy is created.
          -- A pointer to the last node created is returned, or NULL
          -- if an error occured.
        */
           
DREG_EXPORT Registry *dreg_CreateNode(Registry *r, const char * const node);

        /*
          -- dreg_DeleteNode
          --
          -- Deletes the node named in node relative to the registry
          -- node given by r.  node may contain a pathname in which case
          -- the deepest node in the path is deleted.
          --
          -- All child nodes will be recursively deleted and all values
          -- will be deleted within the deleted nodes.
          --
          */
    
DREG_EXPORT int dreg_DeleteNode(Registry *r, const char * const node);

        /*
          -- dreg_RenameNode
          --
          -- Renames the node named in node relative to regsitry r to be the name
          -- contained within newName.  The node may contain a path, in which
          -- case the last element will be renamed, for example, if node
          -- contained a/b/c and newName contained fred then the new path
          -- would become a/b/fred.
          --
        */
    
DREG_EXPORT int dreg_RenameNode(Registry *r, const char * const node, const char * const newName);

        /*
          -- dreg_LinkNode
          --
          -- Link the regsitry node referred to by node to be a child of
          -- the node given by parent.  If the node is curently linked to another
          -- node it will be unlinked from that node before being linked to
          -- its new parent.
          --
        */
    
DREG_EXPORT int dreg_LinkNode(Registry *node, Registry *parent);

        /*
          -- dreg_UnlinkNode
          --
          -- Unlink the node given by node from its parent.
          --
        */
          
DREG_EXPORT int dreg_UnlinkNode(Registry *node);

        /*
          -- dreg_FindNode
          --
          -- Find the registry node given by node relative to the registry
          -- node pointed to by r.  Node may contain a path.
          --
          -- A pointer to the found registry node will be returned, or NULL
          -- if an error occured.
        */
    
DREG_EXPORT Registry *dreg_FindNode(Registry *r, const char * const node);

        /*
          -- dreg_FirstChild
          --
          -- Return the registry pointer corresponding to the first child of the
          -- registry node pointed to by r.  If the name parameter is non-null
          -- then name of the child will be returned in it.  The traverse pointer
          -- must point to a dreg_TraversInfo variable.
          -- If the node does not have any children or an error occurs then
          -- NULL is returned.
        */
    
DREG_EXPORT Registry *dreg_FirstChild(Registry *r, char **name, dreg_TraverseInfo *traverse);

        /*
          -- dreg_NextChild
          --
          -- Return the registry pointer corresponding to the next child of the
          -- registry node pointed to by r.  If the name parameter is non-null
          -- then name of the child will be returned in it.  The traverse pointer
          -- must point to the same dreg_TraverseInfo variable as given to the
          -- dreg_FirstChild function.
          -- If the node has another child then a pointer to it is returned,
          -- otherwise NULL is returned.
          --
          -- Typical code might be:
          --
          --  dreg_TraverseInfo trav;
          --
          --  for (child = dreg_FirstChild(r, NULL, &trav);
          --       child != NULL;
          --       child = dreg_NextChild(r, NULL, &trav))
          --  {
          --      operate on child node ...
          --  }
        */
    
DREG_EXPORT Registry *dreg_NextChild(Registry *r, char **name, dreg_TraverseInfo *traverse);

        /*
          -- dreg_ParentNode
          --
          -- Return the parent of the registry node
        */
          
DREG_EXPORT Registry *dreg_ParentNode(Registry *r);

        /*
          -- dreg_RootNode
          --
          -- Return the node corresponding to the root of
          -- the registry tree.
        */
    
DREG_EXPORT Registry *dreg_RootNode(Registry *r);


        /*
          -- dreg_Traverse
          --
          -- Perform an in order traversal of the given registry
          -- tree. For each node in the tree the registry function
          -- is called.
          */

typedef int (*RegistryFunc)(Registry *r,
                            const int level,
                            const char * const name,
                            void *data);
DREG_EXPORT int dreg_Traverse(Registry *r, RegistryFunc func, void *data);

        /*
          -- dreg_FindValue
          --
          -- Find the value named by name which is connected
          -- to the registry node given by node relative to registry
          -- r (node my be null).  If the value is found then then
          -- containing registry is returned, otherwise NULL.
          -- If the parameter conditional is non-NULL, then it will be
          -- set to 1 if the value is conditional and 0 otherwise.
          --
          -- Note: unless the registry has been set up with
          -- evaluation turned off a registry loaded from a file
          -- will have no conditional values as they will have
          -- been evaluated at load time.  So most program
          -- can ignore the conditional parameter. 
        */
    
DREG_EXPORT Registry *dreg_FindValue(Registry *r,
                                     const char * const node,
                                     const char * const name,
                                     int *conditional); 

        /* 
           -- dreg_ValueStatus
           --
           -- Sets and clears bits in a values's status field.
           --
           -- The bits set in the set_status will be set in the status field.
           -- The bits set in the clear_status will be unset in the status field.
           --
           -- The new status is returned from the function.  The current status
           -- may be obtained by passing set_status and clear_status paremters set
           -- to zero.
        */

DREG_EXPORT int dreg_ValueStatus(Registry *r,
                                 const char * const name,
                                 const int set_status,
                                 const int clear_status);

        /*
          -- dreg_FirstValue
          --
          -- Return the first value associated with the registry node given
          -- by r.  The traverse parameter must point at a dreg_TraverseInfo variable.
          -- If the remaining fields are non-NULL then they will be returned as
          -- follows:
          --
          -- name - name of the value
          -- value - value of the value
          -- conditional - 1 if conditional or 0 if not.
        */
    
DREG_EXPORT int dreg_FirstValue(Registry *r, char **name, char **value, int *conditional,
                                dreg_TraverseInfo *traverse);

        /*
          -- dreg_NextValue
          --
          -- Return the next value associated with the registry node given
          -- by r.  The traverse parameter must point at a dreg_TraverseInfo variable.
          -- If the remaining fields are non-NULL then they will be returned as
          -- follows:
          --
          -- name - name of the value
          -- value - value of the value
          -- conditional - 1 if conditional or 0 if not.
        */
    
DREG_EXPORT int dreg_NextValue(Registry *r, char **name, char **value, int *conditional,
                               dreg_TraverseInfo *traverse);

        /*
          -- dreg_FirstValueConditional
          --
          -- Return the first condition associated with the named value.
          -- The traverse parameter must point at a dreg_TraverseInfo variable.
          -- If the remaining fields are non-NULL then they will be returned as
          -- follows:
          --
          -- condition - the text of the condition
          -- value - value of the value
        */

DREG_EXPORT int dreg_FirstValueCondition(Registry *r,
                                         const char * const name,
                                         char **condition,
                                         char **value, dreg_TraverseInfo *traverse);

        /*
          -- dreg_NextValueCondition
          --
          -- Return the next condition associated with the named value.
          -- The traverse parameter must point at a dreg_TraverseInfo variable.
          -- If the remaining fields are non-NULL then they will be returned as
          -- follows:
          --
          -- condition - the text of the condition
          -- value - value of the value
        */

DREG_EXPORT int dreg_NextValueCondition(Registry *r,
                                        const  char * const name, 
                                        char **condition,
                                        char **value, dreg_TraverseInfo *traverse);

        /*
          -- dreg_CreateValue
          --
          -- Create a value attached to the node given by node and r.
          -- The name is givne by name and the value by value.
        */
    
DREG_EXPORT Registry *dreg_CreateValue(Registry *r,
                                       const char *const node,
                                       const char *const name,
                                       const char *const value);

        /*
          -- dreg_CreateValueCondition
          --
          -- Create a value condition attached to the node given by node and r. 
          -- The name is given by name and the value by value. The text
          -- of the condition is given in condition.
        */
    
DREG_EXPORT Registry *dreg_CreateValueCondition(Registry *r,
                                                const char * const node,
                                                const char * const name,
                                                const char * const condition,
                                                const char * const value);


        /*
          -- dreg_GetValue
          --
          -- Get the value of the named value, that is connected
          -- to the node given by node and r.
          -- The value is returned in the value parameter, the value
          -- will have any value references within it expanded.
          -- If the conditional parameter is non-null then it is
          -- set to 1 if the value is conditional and 0 if not.
        */
    
DREG_EXPORT Registry *dreg_GetValue(Registry *r,
                                    const char * const node,
                                    const char * const name,
                                    char **value,
                                    int *conditional);
        /*
          -- dreg_GetValueLiteral
          --
          -- The same as dreg_GetValue except that value
          -- references in the value are not expanded.
          --
          */
    
DREG_EXPORT Registry *dreg_GetValueLiteral(Registry *r,
                                           const char * const node,
                                           const char * const name,
                                           char **value,
                                           int *conditional);

        /*
          -- dreg_GetValueCondition
          --
          -- The same as dreg_GetValue except that it does it for
          -- a named condition for a conditional value.
        */
    
DREG_EXPORT Registry *dreg_GetValueCondition(Registry *r,
                                             const char * const node,
                                             const char * const name,
                                             const char * const condition,
                                             char **value);
 
        /*
          -- dreg_GetValueConditionLiteral
          --
          -- The same as dreg_GetValueLiteral except that it does it for
          -- a named condition for a conditional value.
        */
    
DREG_EXPORT Registry *dreg_GetValueConditionLiteral(Registry *r,
                                                    const char * const node,
                                                    const char * const name,
                                                    const char * const condition,
                                                    char **value);

        /*
          -- dreg_SetValue
          --
          -- Set (or create) a value named by name and whose value
          -- is given by value, attached to the node given by node
          -- and r.
        */

DREG_EXPORT Registry *dreg_SetValue(Registry *r,
                                    const char * const node,
                                    const char * const name,
                                    const char * const value);

        /*
          -- dreg_SetValueCondition
          --
          -- Set (or create) a conditonal value named by name and whose
          -- value is given by value.  The condition is given by
          -- condition.  The value is attached to the node given by node 
          -- and r.
        */

DREG_EXPORT Registry *dreg_SetValueCondition(Registry *r,
                                             const char * const node,
                                             const char * const name,
                                             const char * const condition,
                                             const char * const value);

        /*
          -- dreg_DeleteValue
          --
          -- Delete the named value, and if the value
          -- is conditional all the attached conditional
          -- values.
        */
          
DREG_EXPORT int dreg_DeleteValue(Registry *r,
                                 const char * const node,
                                 const char * const name);

        /*
          -- dreg_DeleteValueCondition
          --
          -- Delete the named conditional value from the
          -- given value.
          */
    
DREG_EXPORT int dreg_DeleteValueCondition(Registry *r,
                                          const char * const node,
                                          const char * const name,
                                          const char * const condition);


#ifdef __cplusplus
}
#endif

        /*
          -- dreg_GetValueCondition
          --
          -- The same as dreg_GetValue except that it does it for
          -- a named condition for a conditional value.
        */
 
#endif /* __DREG_H__ */
