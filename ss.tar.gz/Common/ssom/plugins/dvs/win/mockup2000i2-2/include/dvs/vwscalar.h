/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: vwscalar.h,v $
 *    Revision:     $Revision: 1.3 $
 *    Date:         $Date: 1997/04/22 12:34:07 $
 *    Author:       $Author: simon $
 *    RCS Ident:    $Id: vwscalar.h,v 1.3 1997/04/22 12:34:07 simon Exp $
 *
 *    FUNCTION: Sclar public function prototypes.
 * 
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _Scalar_H
#define _Scalar_H
#ifdef __cplusplus
extern "C" {
#endif

/* INCLUDE FILES ========================================== */
#include "vwvalue.h"

/* PUBLIC TYPES =========================================== */

typedef enum _VWtScalarAspect {
  VWcSCALAR_HORIZONTAL = 1, 
  VWcSCALAR_VERTICAL
} VWtScalarAspect;

enum VWtScalarResourceTokens {
  VWrScalarAspect = VW_RESOURCES_SCALAR, 

  VWrIncrementVisual, 
  VWrIncrementHighlightVisual, 
  VWrIncrementMaterial, 
  VWrIncrementHighlightMaterial,
  VWrIncrementIconVisual, 
  VWrIncrementIconMaterial, 
  
  VWrDecrementVisual, 
  VWrDecrementHighlightVisual, 
  VWrDecrementMaterial, 
  VWrDecrementHighlightMaterial, 
  VWrDecrementIconVisual, 
  VWrDecrementIconMaterial, 
  
  VWrComponentSizeRatio,

  VWrPuckSize,
  VWrPuckVisual,
  VWrPuckHighlightVisual,
  VWrPuckMaterial,
  VWrPuckHighlightMaterial,

  VWrBarWidthRatio,
  VWrBarVisual, 
  VWrBarMaterial
};

/* PUBLIC FUNCTIONS ======================================*/
VW_EXPORT VWidget *VWScalar_CreateManaged(VWidget *, char *, VWArg [], int);
VW_EXPORT VWidget *VWScalar_Create(VWidget *, char *, VWArg [], int);

VW_EXPORT float32 VWScalar_GetValue(VWidget *ScalarWig);
VW_EXPORT void VWScalar_SetValue(VWidget *ScalarWig, float32 newValue, int trigger);

VW_EXPORT void VWScalar_SetMaximumValue(VWidget *ScalarWig, float32 max);
VW_EXPORT float32 VWScalar_GetMaximumValue(VWidget *ScalarWig);
VW_EXPORT void VWScalar_SetMinimumValue(VWidget *ScalarWig, float32 min);
VW_EXPORT float32 VWScalar_GetMinimumValue(VWidget *ScalarWig);

VW_EXPORT void VWScalar_SetIncrement(VWidget *ScalarWig, float32 inc);
VW_EXPORT float32 VWScalar_GetIncrement(VWidget *ScalarWig, float32 inc);

VW_EXPORT void VWScalar_SetPower(VWidget *ScalarWig, float32 power);
VW_EXPORT float32 VWScalar_GetPower(VWidget *ScalarWig);

VW_EXPORT void VWScalar_SetSnap(VWidget *ScalarWig, float32 snap);
VW_EXPORT float32 VWScalar_GetSnap(VWidget *ScalarWig);

VW_EXPORT void VWScalar_AddDragCallback(VWidget *ScalarWig, VWCallback *callback, void *calldata);
VW_EXPORT void VWScalar_RemoveDragCallback(VWidget *ScalarWig, VWCallback *callback);
VW_EXPORT void VWScalar_RemoveAllDragCallbacks(VWidget *ScalarWig);
VW_EXPORT void VWScalar_AddValueChangedCallback(VWidget *ScalarWig, VWCallback *callback, void *calldata);
VW_EXPORT void VWScalar_RemoveValueChangedCallback(VWidget *ScalarWig, VWCallback *callback);
VW_EXPORT void VWScalar_RemoveAllValueChangedCallbacks(VWidget *ScalarWig);


#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /*_Scalar_H */
