/*
 *
 *    PROJECT:      dVS
 *    SUBSYSTEM:    dp
 *    MODULE:       dp.h
 *
 *
 *    File:         $RCSfile: dp.h,v $
 *    Revision:     $Revision: 1.38 $
 *    Date:         $Date: 1999/06/29 15:20:59 $
 *    Author:       $Author: rajini $
 *    RCS Ident:    $Id: dp.h,v 1.38 1999/06/29 15:20:59 rajini Exp $
 *
 *    FUNCTION:
 *
 *
 * Copyright (c) 1994, 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole  or in part, be copied, photocopied,
 * reproduced, translated,  or  reduced  to  any  electronic  medium or
 * machine readable  form without  prior written  consent from Division
 * Ltd.
 */

#ifndef _DP_H 
#define _DP_H      1

#ifdef __cplusplus
extern "C" {
#endif

#ifndef DP_EXPORT
#if defined(_WIN32) && !defined(_WINDU_SOURCE) && !defined(__EPP__) && !defined (BUILD_STATIC)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `extern'
 */
#ifdef  _LIB_DIVU
#define DP_EXPORT __declspec(dllexport) extern
#else
#define DP_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define DP_EXPORT  extern
#endif /* ! _WIN32 */
/* #define DP_EXPORT  extern  */
#endif /* ndef DP_EXPORT */

#include <stdio.h>

/* PATH_MAX was defined all over the show - to different values as well! */
/* So HoPpY put it here in a bid to fix this problem up! */
#include <limits.h>
#if ! defined PATH_MAX
#define PATH_MAX 1024
#endif

#include <dsys/divtypes.h>

#if defined (_UNIX)
#include <sys/types.h>
#if !defined(_DP_UNX)
#include <dsys/dp.unx>
#endif
#elif defined (_WIN32)
#if !defined(_DP_WIN32)
#include <dsys/dp.w32>
#endif
#else
#error "Unknown processor type "
#endif

/*
 * Error Reporting utility
 */
#define RPT_MESSAGE     0               /* Report message */
#define RPT_WARN        1               /* Report warning */
#define RPT_ERROR       2               /* Report error */
#define RPT_FATAL       3               /* Report fatal error */
DP_EXPORT void               dpReport(int level, char *string, ...);

/* start up anything needed */
DP_EXPORT void                 dpInit(void);

/* get the version */
DP_EXPORT void              dpVersion(FILE *fp);

DP_EXPORT int             dpIpcCreate(dpIpcCtl *ctrl_block,
                                      int       key,
                                      long      memsize,
                                      void     *memaddr,
                                      int       num_processes,
                                      int       permissions);

DP_EXPORT int            dpIpcDestroy(dpIpcCtl *ctrl_block);

DP_EXPORT int             dpIpcAttach(dpIpcCtl *ctrl_block,
                                      int       key,
                                      long      memsize,
                                      void     *memaddr,
                                      int       num_processes,
                                      int       permissions);
DP_EXPORT void            dpIpcDetach(dpIpcCtl *ctrl_block);

DP_EXPORT void              dpIpcSave(FILE     *fp,
                                      dpIpcCtl *ctrl_block);

DP_EXPORT void              dpIpcRestore(FILE     *fp,
                                      dpIpcCtl *ctrl_block);

DP_EXPORT void              dpIpcDestroyFromFile(FILE *fp);
DP_EXPORT int               dpIpcExcludeRange( unsigned long startAddr, 
                                               unsigned long endAddr );

DP_EXPORT void              dpProtectSharedMemory(dpIpcCtl *ctrl_block);

DP_EXPORT void              dpUnProtectSharedMemory(dpIpcCtl *ctrl_block);

DP_EXPORT int               dpUnlockSem(dpIpcCtl *ctrl_block, int semid);

DP_EXPORT int               dpSemPoll(dpIpcCtl *ctrl, int semid);
DP_EXPORT int               dpSemPendI( dpIpcCtl *ctrl, int semid);
DP_EXPORT int               dpSemPend( dpIpcCtl *ctrl, int semid);
DP_EXPORT int               dpSemPendPairI(dpIpcCtl *ctrl_block, int sem1, int sem2);

DP_EXPORT uint32            dpGetTime(void);

DP_EXPORT void (dpGetVirtualTime)(dpVtime *x);
DP_EXPORT void dpAttachSegvHandler( int (*mapFunction)(void *) );

/*
 * set up skew and a 'last time' field.
 * 'x' should point to array of three
 * dpVtimes in space shared by
 * all accessing procs.
 */
DP_EXPORT void      dpSetVirtualTimeSkew(dpVtime * x);

DP_EXPORT void      dpSetSkewForLocalTime(dpVtime *skew);

/* adding, subing comparing times */
DP_EXPORT void          dpSubVtimes(dpVtime *r,dpVtime *a,dpVtime *b);
DP_EXPORT void          dpAddVtimes(dpVtime *r,dpVtime *a,dpVtime *b);
DP_EXPORT void          dpFreqFromVtimes (float * f, dpVtime * a, dpVtime *b, unsigned int samples);
#define dpVtimeAfter(a,b) (  ((a)->secs > (b)->secs)       \
                           ||(  ((a)->secs == (b)->secs)   \
                              &&((a)->uSecs > (b)->uSecs)))
#define dpVtimeEqual(a,b) (  ((a)->secs == (b)->secs)   \
                           &&((a)->uSecs == (b)->uSecs))

/*
 * setting alarms...
 */
DP_EXPORT void          dpSetAlarm(dpVtime *t, int repeat, void (*func)());
DP_EXPORT void       (dpHoldAlarm)(void);
DP_EXPORT void    (dpReleaseAlarm)(void);

/*
 * sleeping.....
 */
DP_EXPORT void  (dpSleep)(unsigned long secs);
DP_EXPORT void  (dpUsleep)(unsigned long usecs);
DP_EXPORT void  (dpFsleep)(float waitForSecs);
DP_EXPORT float (dpGiveTime)(DP_FTIME_PTR thisTime);
DP_EXPORT void  (dpResetFtime)(DP_FTIME_PTR thisTime);
DP_EXPORT int   (dpFtimeReady)(DP_FTIME_PTR thisTime, const float nextTime);
DP_EXPORT float (dpWorkOutRemainingDelay)(DP_FTIME_PTR thisTime, const float delay);
DP_EXPORT void  (dpSwitchLastTime)(DP_FTIME_PTR thisTime);

/*
 * Windows Handle things (mapped out safely on UNIX).
 */
DP_EXPORT int    (dpAddSystemHandle)(dpHandle newHandle);
DP_EXPORT int (dpRemoveSystemHandle)(dpHandle handle);
DP_EXPORT dpHandle   (dpGetLastHandle)(void);
DP_EXPORT uint32   (dpAddWindowsMessage)(uint32 mask);
DP_EXPORT uint32   (dpRemoveWindowsMessage)(uint32 mask);

/*
 * to be called at the end of interupt (signal) handler
 */
DP_EXPORT void     (dpHandlerDone)(void);

/*
 * environment putting and getting
 */

/*
 * process spawning
 */

#if defined(_WIN32) && !defined(_WINDU_SOURCE)
typedef DWORD dpPid;
#else
typedef pid_t dpPid;
#endif /* !_WIN32 */

#define DP_PROCESS_CANT_EXEC (42)

#define DP_PROCESS_NO_WAIT (1)


DP_EXPORT dpPid dpCreateProcess(char *program,
                                char **progArgs,
                                const int32 priority,
                                const int32 processor);

#ifdef _WIN32
DP_EXPORT dpPid dpCreateProcessEx(char *program,
				  char **progArgs,
				  const int32 priority,
				  const int32 processor, 
				  int flags);
#endif

DP_EXPORT char *dpGetUserName(void);
DP_EXPORT char *dpGetHomeDirectory(void);

typedef struct 
{
    char 	 machine[DP_PLATFORM_MACHINE_LEN];
    char	 os[DP_PLATFORM_OS_LEN];
    char	 osVersion[DP_PLATFORM_OSVERSION_LEN];
    char 	 platform[DP_PLATFORM_PLATFORM_LEN];
    char	 miscInfo[DP_PLATFORM_MISCINFO_LEN];
}dpMachineInfo;

DP_EXPORT int dpGetMachineInfo(dpMachineInfo *info);
DP_EXPORT int dpGetShortHostName(char *hostname, int size);
DP_EXPORT int dpGetFullHostName(char *hostname, int size);

/*
 * dpWait interfaces
 */

#define DPWAIT_READ           0
#define DPWAIT_WRITE          1
#define DPWAIT_EXCEPTION      2
#define DPWAIT_TIMEOUT        3
#define DPWAIT_ERROR          4
#define DPWAIT_WINDOWSMESSAGE 5
#define DPWAIT_INTERRUPT      6

DP_EXPORT int dpWait_addRead(dpHandle fd);
DP_EXPORT int dpWait_addWrite(dpHandle fd);
DP_EXPORT int dpWait_addException(dpHandle fd);
DP_EXPORT int dpWait_removeRead(dpHandle fd);
DP_EXPORT int dpWait_removeWrite(dpHandle fd);
DP_EXPORT int dpWait_removeException(dpHandle fd);
DP_EXPORT dpHandle dpWait_getFirst(int *ioType);
DP_EXPORT dpHandle dpWait_checkFirst(int *ioType);
DP_EXPORT dpHandle dpWait_getNext (int *ioType);
DP_EXPORT void dpWait_Interruptible(int32 flag);
#ifdef _WIN32
DP_EXPORT dpHandle dpCreateWindow(char *winName);
DP_EXPORT dpHandle dpOpenWindow(char *winName);
#endif



#ifdef MAXPATHLEN
#define DP_FIND_MAX_PATH		MAXPATHLEN
#else
#ifdef MAX_PATH
#define DP_FIND_MAX_PATH		MAX_PATH
#else
#define DP_FIND_MAX_PATH		255
#endif
#endif

typedef struct dpFindHandle {
	char *dirName;
	char *fileName;
	void *handle;
    int  dirNameLen;
}dpFindHandle;

typedef struct dpFileInfo {
	char fileName[DP_FIND_MAX_PATH];
}dpFileInfo;

DP_EXPORT char 		*dpGetTmpDirName(void);
DP_EXPORT dpFindHandle 	*dpFindFirstFile( char *fileName, dpFileInfo *fileInfo );
DP_EXPORT int dpFindNextFile( dpFindHandle *fileHandle, dpFileInfo *fileInfo );
DP_EXPORT void dpFindClose( dpFindHandle *fileHandle );

#ifdef __cplusplus
}
#endif

#endif   /* _DP_H */
