/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: dcitools.h,v $
 *    Revision:     $Revision: 1.64 $
 *    Date:         $Date: 2000/03/09 13:13:09 $
 *    Author:       $Author: jeff $
 *    RCS Ident:    $Id: dcitools.h,v 1.64 2000/03/09 13:13:09 jeff Exp $
 *
 *    FUNCTION:
 *
 * Copyright (c) 1992 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _DCITOOLS_H
#define _DCITOOLS_H
#ifdef __cplusplus
extern "C" {
#endif

#include <dvise/ectools.h>
#include "dcitypes.h"
#include "dci_parse.h"
#include <dvise/queryparser.h>

#ifdef _LIB_DCI
#include <dsys/parser.h>
#include "_dcifunc.h"
#endif

/* PUBLIC DEFINES =======================================*/


/* PUBLIC TYPES =========================================*/


/* PUBLIC VARIABLES ======================================*/


/* PUBLIC FUNCTIONS ======================================*/

/*
 * Version Control
 */

DV_EXPORT void dciVersion(FILE *);

/* ******** Application login stream initialisation function ******** */
DV_EXPORT int DCILoginStreamInitialise(char *applicationName, char *agentName);

/* Create the pipe used for dci connection requests. 
 * Sets up a callback to handle messages on this pipe and
 * returns the fd of the login pipe (-1 on failure).
 */

DV_EXPORT void DCIApplicationCloseClientConnections(void);
/* Send close signals to all clients */



/* ******** Client connection request function ******** */
DV_EXPORT DCICommsInfo *DCIRequestConnection(char *clientName, 
                                             char *agentName, int bufferSize);
/* Open a pipe and the login pipe for the given application then
 * make a DCI link request, wait for response.  If successful, open the
 * server pipe and return pipe info, otherwise NULL.
 */

DV_EXPORT void DCIClientCloseConnection(DCICommsInfo *info);
DV_EXPORT void DCIMainLoop(DCICommsInfo *info);

/* For the client end.  Close pipes and clean up. */


DV_EXPORT void DCIRemoveClient(DCICommsInfo *info);
DV_EXPORT ECAction *DCI_RegisterInterest(DCICommsInfo *info, int eId, char *focusName, 
                                         ECItemType focusType, char *exp, DCIClientCallbackFunc cb,
                                         void *thisP, void *ud);
DV_EXPORT int32 DCI_DeregisterInterest(DCICommsInfo *info, int eId, char *focusName, 
                                       ECItemType focusType, ECAction *cb);
DV_EXPORT int DCI_RegisterReceiptFunc(DCICommsInfo *, int, char *,
                                      DCIClientCallbackFunc, void *, void *);
DV_EXPORT int DCI_DeregisterReceiptFunc(DCICommsInfo *, int, char *,
                                        DCIClientCallbackFunc, void *);

/* ******** Server functions ********* */
DV_EXPORT DCICommsInfo *DCIServerGetClientList(void);

/* ******** Get body function ******** */
DV_EXPORT VCBody *DCI_getClientBody(DCICommsInfo *info, char *name);

/* ******** Low level internal communication functions ******** */
DV_EXPORT void DCIWrite(DCICommsInfo *info, DCIString *message);
/* General purpose (both ends) write command */

DV_EXPORT int DCIWriteAllClients(void);
/* For each registered DCI client, look for pending writes and attempt
 * to send messages. Returns 1 if any of the clients are blocked.
 */
DV_EXPORT void DCIWriteMessageAllClients(DCIString *message);
/* For each registered DCI client, append the same message to the clients
 * pipe 
 */
DV_EXPORT int DCIWriteClient(DCICommsInfo *info);
/* As DCIWriteAllClients, but for a single specified client.
 * Returns 1 if the write was blocked. */

DV_EXPORT int DCIPipeReader(DCICommsInfo *);
/* Read a message from dvise through the pipe */

DV_EXPORT void DCIServerReader(VCFile_CallbackData *fileData, void *data);
/* Read a message from the client through the pipe.  This is the procedure
 * called back by VC. */

DV_EXPORT int DCIParse(DCICommsInfo *);
/* General (both ends) message reader.  
 * Returns 1 for reading a normal message, 0 for no message and -1 for
 * an exit message.
 */
DV_EXPORT int DCIParseVDI(void);
/* Internal use only.  
 * Reads an item using the dci version of the vdi parser. */

DV_EXPORT void DCIServerWrite(DCICommsInfo *info, DCIString *);

DV_EXPORT void DCI_SchedulePipeWrite(DCICommsInfo *info, DCIString *message);

DV_EXPORT int DCI_EventAction(ECEvent *event, ECEventData *data, ECAction *action);
DV_EXPORT int DCIInputDescriptor(DCICommsInfo *dciInfo);
DV_EXPORT int DCIClientId(DCICommsInfo *dciInfo);


/* ******** Message construction functions ******** */
/* these functions are actually defined in vdiwrite.c in libec */

DV_EXPORT void DCIMessageCreate(DCIString *);
DV_EXPORT void DCIAssemblyMessageCreate(DCIString *, ECAssembly *object);
DV_EXPORT void DCIAssemblyItemsMessageCreate(DCIString *, ECAssembly *object, 
                                             ECItem *itemList);
DV_EXPORT void DCIPartialAssemblyMessageCreate(DCIString *, ECAssembly *object, ...);
DV_EXPORT void DCIAssemblyLinkageMessageCreate(DCIString *, ECAssembly *object);
DV_EXPORT void DCIZoneAssemblysMessageCreate(DCIString *, ECZone *object);

DV_EXPORT void DCIZoneMessageCreate(DCIString *, ECZone *zone);
DV_EXPORT void DCIZoneLinkageMessageCreate(DCIString *, ECZone *zone);
DV_EXPORT void DCIZoneItemsMessageCreate(DCIString *, ECZone *zone, 
                                         ECItem *itemList);
DV_EXPORT void DCIPartialZoneMessageCreate(DCIString *, ECZone *zone, ...);
DV_EXPORT void DCIZoneAssemblysMessageCreate(DCIString *, ECZone *zone);

DV_EXPORT void DCILibraryMessageCreate(DCIString *, ECLibrary *library);
DV_EXPORT void DCILibraryCreateWrite(char *, char *, char *);
DV_EXPORT void DCILibraryItemsMessageCreate(DCIString *, ECLibrary *library, 
                                            ECItem *itemList);
DV_EXPORT void DCIPartialLibraryMessageCreate(DCIString *, ECLibrary *library, 
                                              ...);
DV_EXPORT void DCILibraryLinkageMessageCreate(DCIString *, ECLibrary *library);
DV_EXPORT void DCIFileLibrariesMessageCreate(DCIString *);
DV_EXPORT void DCIFileMessageCreate(DCIString *, ECFile *file);
DV_EXPORT void DCIFileItemsMessageCreate(DCIString *, ECFile *file, ECItem *itemList);
DV_EXPORT void DCIItemMessageCreate(DCIString *, ECItem *item);
DV_EXPORT void DCIActionWrite(ECAction *a);
DV_EXPORT void DCIEventDataWrite(EC_DCI_EventData *eD);
DV_EXPORT void DCIFocusWrite(ECItem *focus);


/* ***************** send functions ******************** */

DV_EXPORT void DCISendZoneAssemblysQuery(DCICommsInfo *info, void *userData, 
                                         char *zoneName);
DV_EXPORT void DCISend_AssembliesQuery(DCICommsInfo *info, void *userData, 
                                       char *rootName);
DV_EXPORT void DCISendZoneAssemblysInform(DCICommsInfo *info, void *userData, 
                                          ECZone *zone);
DV_EXPORT void DCISend_AssembliesInform(DCICommsInfo *info, void *userData, 
                                        ECAssembly *root);
DV_EXPORT void DCISendZoneAssemblyAttributesQuery(DCICommsInfo *info, void *userData, 
                                                  char *zonename, char *objectName, ...);
DV_EXPORT void DCISend_AssemblyAttributesQuery(DCICommsInfo *info, void *userData, 
                                               char *objectName, ...);
/* vararg list is of type ECItemType and terminated by ECItemTypeNull */
DV_EXPORT void DCISend_AssemblyAttributesInform(DCICommsInfo *info, void *userData, 
                                                ECAssembly *object, ECItem *itemList);
DV_EXPORT void DCISendZoneAssemblyAttributesInform(DCICommsInfo *info, void *userData, 
                                                   char *zoneName, ECAssembly *object, ECItem *itemList);
/* Write an inform message containing the attributes of types given in the
 * itemList from the passed object.  If itemList is NULL all attributes
 * are written. 
 */
DV_EXPORT void DCISend_AssemblyLinkageInform(DCICommsInfo *info, void *userData, 
                                             ECAssembly *object);
DV_EXPORT void DCISendZoneAssemblyLinkageInform(DCICommsInfo *info, void *userData, 
                                                char *zoneName, ECAssembly *object);
DV_EXPORT void DCISend_AssemblyAttributeListInform(DCICommsInfo *info, void *userData, 
                                                   char *obj, ECItem *item, int index);
DV_EXPORT void DCISendZoneAssemblyAttributeListInform(DCICommsInfo *info, void *userData, 
                                                      char *zone, char *obj, ECItem *item, int index);
DV_EXPORT void DCISend_AssemblyAddAttributeListInform(DCICommsInfo *info, void *userData,
                                                      char *obj, ECItem *item, int index);
DV_EXPORT void DCISendZoneAssemblyAddAttributeListInform(DCICommsInfo *info, void *userData,
                                                         char *zone, char *obj, ECItem *item, int index);
DV_EXPORT void DCISend_AssemblyRemoveAttributeListInform(DCICommsInfo *info, 
                                                         void *userData,
                                                         char *obj, char *itemName, 
                                                         int index);
DV_EXPORT void DCISendZoneAssemblyRemoveAttributeListInform(DCICommsInfo *info, 
                                                            void *userData,
                                                            char *zone, char *obj, 
                                                            char *itemName, int index);
DV_EXPORT void DCISend_AssemblyRenameInform(DCICommsInfo *, void *userData,
                                            char *oldName, char *newName);
DV_EXPORT void DCISendZoneAssemblyRenameInform(DCICommsInfo *, void *userData,
                                               char *zoneName, char *oldName, char *newName);
DV_EXPORT void DCISend_AssemblyLinkInform(DCICommsInfo *info, void *userData, 
                                          char *objectName, char *parentName);
DV_EXPORT void DCISendZoneAssemblyLinkInform(DCICommsInfo *info, void *userData, 
                                             char *zoneName, char *objectName, char *parentName);
DV_EXPORT void DCISend_AssemblyUnlinkInform(DCICommsInfo *info, void *userData, 
                                            char *objectName);
DV_EXPORT void DCISend_MultipleLinkInform(DCICommsInfo *info, void *userData, 
                                          ECItem *assList, ECAssembly *parentAssembly);
DV_EXPORT void DCISend_MultipleInstCheckLinkInform(DCICommsInfo *info, void *userData, ECItem *childPathList,
                                                   ECAssembly *parentAssembly, int checkInstances);
DV_EXPORT void DCISendZoneAssemblyUnlinkInform(DCICommsInfo *info, void *userData, 
                                               char *zoneName, char *objectName);
DV_EXPORT void DCISend_MultipleUnlinkInform(DCICommsInfo *info, void *userData, 
                                            ECItem *assList);
DV_EXPORT void DCISend_MultipleInstCheckUnlinkInform(DCICommsInfo *info, void *userData, ECItem *assPathList,
                                                     int checkInstances);
DV_EXPORT void DCISend_AssemblyInstanceInform(DCICommsInfo *info, void *userData, 
                                              char *libraryName, char *definitionName);
DV_EXPORT void DCISendZoneAssemblyInstanceInform(DCICommsInfo *info, void *userData, 
                                                 char *zoneName, char *libraryName, char *definitionName);
DV_EXPORT void DCISend_AssemblyDestroyInform(DCICommsInfo *info, void *userData, 
                                             char *pathName);
DV_EXPORT void DCISendZoneAssemblyDestroyInform(DCICommsInfo *info, void *userData, 
				       char *zoneName, ECItem *assPathList);
DV_EXPORT void DCISendZoneAssemblyInstCheckDestroyInform(DCICommsInfo *info, void *userData, 
                                 char *zoneName, ECItem *assPathList, int checkInstances);
DV_EXPORT void DCISendZoneAssemblyLoadOnlyInform(DCICommsInfo *info, void *userData, 
                                                 char *zoneName, ECItem *assPathList);
DV_EXPORT void DCISendZoneAssemblyEnableOnlyInform(DCICommsInfo *info, void *userData, 
                                                   char *zoneName, ECItem *assPathList);
DV_EXPORT void DCISend_SaveInfoInform(DCICommsInfo *info, void *userData, 
                                      char *fileName, uint32 flags);
DV_EXPORT void DCISend_SaveInfoQuery(DCICommsInfo *info, void *userData);
DV_EXPORT void DCISend_SaveAttributesInform(DCICommsInfo *info, void *userData, 
                                            char *fileName, char *rootName, int dNms);
DV_EXPORT void DCISend_SaveAttributesQuery(DCICommsInfo *info, void *ud, char *rNam);
DV_EXPORT void DCISend_FlyToAllInform(DCICommsInfo *info, void *userData);
DV_EXPORT void DCISend_BodyNavigatorInform(DCICommsInfo *info, void *userData);
DV_EXPORT void DCISend_AssemblyCreateInform(DCICommsInfo *info, void *userData, 
                                            ECAssembly *object, char *parentName);
DV_EXPORT void DCISend_AttributeCreateInform(DCICommsInfo *info, void *userData, 
                                             char *parentName, ECItemType attrType);
DV_EXPORT void DCISendZoneAssemblyCreateInform(DCICommsInfo *info, void *userData, 
                                               char *zoneName, ECAssembly *object, char *parentName);
DV_EXPORT void DCISend_AssemblyNewInform(DCICommsInfo *info, void *userData, 
                                         char *objectName, char *parentName);
DV_EXPORT void DCISendZoneAssemblyNewInform(DCICommsInfo *info, void *userData, 
                                            char *zoneName, char *objectName, char *parentName);
DV_EXPORT void DCISend_AssemblyMakeNonInstanceInform(DCICommsInfo *info, void *userData, 
                                             char *pathname);

DV_EXPORT void DCISend_RegisterInterestInform(DCICommsInfo *info, void *userData,
                                              int eId, ECItem *focus, char *exp);
DV_EXPORT void DCISend_DeregisterInterestInform(DCICommsInfo *info, void *userData,
                                                int eventId, ECItem *focus);
DV_EXPORT void DCISend_EventInform(DCICommsInfo *inf, void *ud, int eId, EC_DCI_EventData *data);
DV_EXPORT void DCISend_EventForEntityInform(DCICommsInfo *info, void *userData, 
                                            int eventId, void *entity, 
                                            void *otherEntity, ECUserData *uData);
DV_EXPORT void DCISend_EventForEntityQuery(DCICommsInfo *info, void *userData, 
                                            int eventId, void *entity, 
                                            void *otherEntity, ECUserData *uData);
DV_EXPORT void DCISend_LandmarkDataInform(DCICommsInfo *info, void *userData,
                                          char *path, char *target);
DV_EXPORT void DCISend_LandmarkDeleteInform(DCICommsInfo *info, void *userData, char *path);
DV_EXPORT void DCISend_LandmarkDataQuery(DCICommsInfo *info, void *userData, char *path);
DV_EXPORT void DCISend_LandmarkCreateInform(DCICommsInfo *info, void *userData,
                                            char *lp, char *ln, char *cp, char *cn);
DV_EXPORT void DCISend_FlightPathCreateInform(DCICommsInfo *info, void *userData,
                                              char *p, char *m);
DV_EXPORT void DCISend_SectionCreateInform(DCICommsInfo *info, void *userData,
                                           char *p, char *s);
DV_EXPORT void DCISend_AnnotateCreateInform(DCICommsInfo *info, void *userData,
                                           char *p, ECAssembly *note);
DV_EXPORT void DCISend_BodyPartSelectListInform(DCICommsInfo *info, void *userData, 
                                                ECEventData *data);
DV_EXPORT void DCISend_BodyPartSelectListQuery(DCICommsInfo *info, void *userData, 
                                               char *bodyName, char *bodyPartName);
DV_EXPORT void DCISend_Exit(DCICommsInfo *info, void *userData, int flag);
DV_EXPORT void DCISendExit(DCICommsInfo *info, void *userData, int flag);
DV_EXPORT void DCISend_AssemblyAttributeInform(DCICommsInfo *info, void *userData, 
                                               char *libraryName, ECItem *item);
DV_EXPORT void DCISendAssemblyAttributeInform(DCICommsInfo *info, void *userData, 
                                              char *libraryName, ECItem *item);
DV_EXPORT void DCISend_AssemblyAddAttributeInform(DCICommsInfo *info, void *userData,
                                                  char *libraryName, ECItem *item);
DV_EXPORT void DCISendAssemblyAddAttributeInform(DCICommsInfo *info, void *userData,
                                                 char *libraryName, ECItem *item);
DV_EXPORT void DCISend_AssemblyRemoveAttributeInform(DCICommsInfo *info, void *userData,
                                                     char *libraryName, char *itemName);
DV_EXPORT void DCISendAssemblyRemoveAttributeInform(DCICommsInfo *info, void *userData,
                                                    char *libraryName, char *itemName);
DV_EXPORT void DCISend_FileLibrariesQuery(DCICommsInfo *info, void *userData);
DV_EXPORT void DCISendFileLibrariesQuery(DCICommsInfo *info, void *userData);
DV_EXPORT void DCISend_FileLibrariesInform(DCICommsInfo *info, void *userData);
DV_EXPORT void DCISendFileLibrariesInform(DCICommsInfo *info, void *userData);
DV_EXPORT void DCISendLibraryCreateInform(DCICommsInfo *info, void *userData, 
                                          ECLibrary *object);
DV_EXPORT void DCISendLibraryOpenInform(DCICommsInfo *info, void *userData, 
                                        char *pathName, DCILibraryType type);
DV_EXPORT void DCISendLibraryImportInform(DCICommsInfo *info, void *userData, 
                                          ECLibrary *library);
DV_EXPORT void DCISendLibraryExportInform(DCICommsInfo *info, void *userData, 
                                          ECLibrary *library, char *shortPath,
                                          char *longPath);
DV_EXPORT void DCISend_FileAttributesQuery(DCICommsInfo *info, void *userData, 
                                           ...);
/* vararg list is of type ECItemType and terminated by ECItemTypeNull */
DV_EXPORT void DCISendFileAttributesQuery(DCICommsInfo *info, void *userData, 
                                          ...);
/* vararg list is of type ECItemType and terminated by ECItemTypeNull */
DV_EXPORT void DCISend_FileAttributesInform(DCICommsInfo *info, void *userData,
                                            ECFile *file, ECItem *itemList);
DV_EXPORT void DCISendFileAttributesInform(DCICommsInfo *info, void *userData,
                                           ECFile *file, ECItem *itemList);
DV_EXPORT void DCISend_ActionFunctionsQuery(DCICommsInfo *info, void *userData);
DV_EXPORT void DCISendActionFunctionsQuery(DCICommsInfo *info, void *userData);
DV_EXPORT void DCISend_ActionFunctionsInform(DCICommsInfo *info, void *userData);
DV_EXPORT void DCISendActionFunctionsInform(DCICommsInfo *info, void *userData);
DV_EXPORT void DCISend_EventNamesQuery(DCICommsInfo *info, void *userData);
DV_EXPORT void DCISendEventNamesQuery(DCICommsInfo *info, void *userData);
DV_EXPORT void DCISend_EventNamesInform(DCICommsInfo *info, void *userData, char *name);
DV_EXPORT void DCISendEventNamesInform(DCICommsInfo *info, void *userData, char *name);
DV_EXPORT void DCISend_FileNameQuery(DCICommsInfo *info, void *userData);
DV_EXPORT void DCISendFileNameQuery(DCICommsInfo *info, void *userData);
DV_EXPORT void DCISend_PluginNameQuery(DCICommsInfo *info, void *userData);
DV_EXPORT void DCISendPluginNameQuery(DCICommsInfo *info, void *userData);
DV_EXPORT void DCISend_SaveInform(DCICommsInfo *info, void *userData, 
                                  char *fileName, char *path);
DV_EXPORT void DCISendSaveInform(DCICommsInfo *info, void *userData, 
                                 char *fileName, char *path);
DV_EXPORT void DCISend_ImageSaveInform(DCICommsInfo *info, void *userData,
                                       char *imageName);
DV_EXPORT void DCISendImageSaveInform(DCICommsInfo *info, void *userData,
                                      char *imageName);
DV_EXPORT void DCISend_ToggleBranchInform(DCICommsInfo *info, void *userData,
                                          char *assembly);
DV_EXPORT void DCISendToggleBranchInform(DCICommsInfo *info, void *userData,
                                         char *assembly);
DV_EXPORT void DCISendListToggleBranchInform(DCICommsInfo *info, void *userData, ECItem *assList);
DV_EXPORT void DCISend_TogglePickingQuery(DCICommsInfo *info, void *userData);
DV_EXPORT void DCISendTogglePickingInform(DCICommsInfo *info, void *userData, int32 flags);
DV_EXPORT void DCISend_ToggleHighlightModeQuery(DCICommsInfo *info, void *userData);
DV_EXPORT void DCISendToggleHighlightModeInform(DCICommsInfo *info, void *userData, int32 flags);
DV_EXPORT void DCISend_FileNameInform(DCICommsInfo *info, void *userData, 
                                      char *fileName, char *attrFile);
DV_EXPORT void DCISendFileNameInform(DCICommsInfo *info, void *userData, 
				  char *fileName, char *attrFile);
DV_EXPORT void DCISend_PluginNameInform(DCICommsInfo *info, void *userData, 
                                        char **pluginName);
DV_EXPORT void DCISendPluginNameInform(DCICommsInfo *info, void *userData, 
                                       char **pluginName);
DV_EXPORT void DCISend_ClipAssemblyCopyInform(DCICommsInfo *info, void *userData,
                                              char *lib, char *zone, char **objects);
DV_EXPORT void DCISendClipAssemblyCopyInform(DCICommsInfo *info, void *userData,
                                             char *lib, char *zone, char **objects);
DV_EXPORT void DCISend_ClipAssemblyPasteInform(DCICommsInfo *info, void *userData,
                                               char *lib, char *zone, char *parent);
DV_EXPORT void DCISendClipAssemblyPasteInform(DCICommsInfo *info, void *userData,
                                              char *lib, char *zone, char *parent);
DV_EXPORT void DCISend_ClipAttributeCopyInform(DCICommsInfo *info, void *userData,
                                             char **objects);
DV_EXPORT void DCISendClipAttributeCopyInform(DCICommsInfo *info, void *userData,
                                             char **objects);
DV_EXPORT void DCISend_ClipAttributePasteInform(DCICommsInfo *info, void *userData,
                                             char *parent);
DV_EXPORT void DCISendClipAttributePasteInform(DCICommsInfo *info, void *userData,
                                             char *parent);
/* name may be NULL */
DV_EXPORT void DCISend_MessageInform(DCICommsInfo *info, void *userData, 
                                     char *message);
DV_EXPORT void DCISendMessageInform(DCICommsInfo *info, void *userData, 
                                    char *message);
DV_EXPORT void DCISend_ErrorInform(DCICommsInfo *info, void *userData, 
                                   char *error);
DV_EXPORT void DCISendErrorInform(DCICommsInfo *info, void *userData, 
                                  char *error);
DV_EXPORT void DCISendUserDCIMessage(DCICommsInfo *info, DCIMessageType type,
                           char *DCICommand, char *message);
DV_EXPORT void DCISendQuotedUserDCIMessage(DCICommsInfo *info, DCIMessageType type,
                           char *DCICommand, char *message);
DV_EXPORT void DCISend_InstanceInfoInform(DCICommsInfo *info, void *userData, ECItem *instanceList);
DV_EXPORT void DCISend_InstanceInfoQuery(DCICommsInfo *info, void *userData, ECItem *instanceList,
                               int searchChildren, int displayChildren);
DV_EXPORT void DCISend_FailedDeleteInform(DCICommsInfo *info, void *userData, ECItem *instanceList,
                                          ECItem *clipList);
DV_EXPORT void DCISend_QueryAssembliesQuery(DCICommsInfo *info, void *userData, Query *query, 
                                           ECItem *assList, int checkChildren, int caseSensitive);
DV_EXPORT void DCISend_QueryAssembliesInform(DCICommsInfo *info, void *userData, ECItem *assList);
DV_EXPORT void DCISend_QueryListQuery(DCICommsInfo *info, void *userData);
DV_EXPORT void DCISend_QueryListInform(DCICommsInfo *info, void *userData, ECItem *queries);
DV_EXPORT void DCISend_QueryDeleteInform(DCICommsInfo *info, void *userData, ECItem *queries);
DV_EXPORT void DCISend_QueryCreateInform(DCICommsInfo *info, void *userData, Query *query);
DV_EXPORT void DCISend_QueryUpdateInform(DCICommsInfo *info, void *userData, Query *query, char *originalName);
DV_EXPORT void DCISend_InstanceAlterationInform(DCICommsInfo *info, void *userData, ECItem *instanceList, 
                                      DCIParseTokens type, char *linkParentName);
DV_EXPORT void DCISend_IncludeNodeQuery(DCICommsInfo *info, void *userData, char *qNode,
                                        char *fileName);
DV_EXPORT void DCISend_IncludeNodeInform(DCICommsInfo *info, void *userData, char *qNode,
                                         char *includeNode, char *fileName);
DV_EXPORT void DCISend_IncludePathQuery(DCICommsInfo *info, void *userData, char *path);
DV_EXPORT void DCISend_IncludePathInform(DCICommsInfo *info, void *userData, char *path);
DV_EXPORT void DCISend_AllIncludeNodesQuery(DCICommsInfo *info, void *userData, char *rootName);
DV_EXPORT void DCISend_AllIncludeNodesInform(DCICommsInfo *info, void *udata, ECAssembly *root);
DV_EXPORT void DCISend_RendOptsInform(DCICommsInfo *i, void *d, ECUserData *options);
DV_EXPORT void DCISend_RendOptsQuery(DCICommsInfo *i, void *d, ECUserData *qryOpts);


/* ************* Receipt function functions ************* */

DV_EXPORT void DCIRegisterReceiptFunction(DCIMessageType ioq, int dciToken, 
                                          DCIReceiptFunc func);
DV_EXPORT void DCIRegisterReceiptFunctionWithData(DCIMessageType ioq, int dciToken, 
                                                  DCIReceiptFunc func, void *data);
/* simon 20/6/97 - a recept function with call data */
DV_EXPORT void DCIRegisterMultipleReceiptFunctions(DCIMessageType ioq, 
                                                   int dciToken, 
                                                   DCIReceiptFunc func, ...);
/* Just like multiple calls to DCIRegisterReceiptFunction */

void DCIRegisterMultipleInformFunctions(int dciToken, 
                                        DCIReceiptFunc func, ...);
/* Just like multiple calls to DCIRegisterReceiptFunction each with message
 * type DCIInform */

void DCIRegisterMultipleQueryFunctions(int dciToken, 
                                       DCIReceiptFunc func, ...);
/* Just like multiple calls to DCIRegisterReceiptFunction each with message
 * type DCIQuery */

DV_EXPORT DCIReceiptFunc DCIReceiptFunctionFind(DCIMessageType ioq, int dciToken);
DV_EXPORT DCIReceiptFunc DCIReceiptFunctionAndDataFind(DCIMessageType ioq, int dciToken, 
                                                       void **data);
/* simon 20/6/97 returns a reciept function and some (void *) calldata for that function */
DV_EXPORT int DCIRegisterUserCommand(char *);


/* ************************* Misc functions **************************** */

DV_EXPORT ECAssembly *DCIAssemblyFind(DCICommsInfo *info, char *objectName);
/* Find an object from the zone stored in the info structure.
 * If no zone has been set, then the topelevel zone is searched.
 */
DV_EXPORT ECAssembly *DCIAssemblyFindFromTemplate(DCICommsInfo *info, 
                                                  ECAssembly *dcitemplate);
/* The template object may have a libraryName
 */

DV_EXPORT void DCIUserEventsUpdate(ECStringset *ss);
/* To be used after receiving a inform event names.
 * Registers any functions listed that aren't in the default set. 
 */

DV_EXPORT void DCIActionFuncsUpdate(ECActionFunc *af);
/* To be used after receiving a inform action functions.
 * Registers any functions listed that aren't already defined. 
 */

DV_EXPORT void DCIMessageToClient(DCICommsInfo *info, char *string);
DV_EXPORT void DCI_ForceMessages(void);

/* ************************* Error messages **************************** */
DV_EXPORT void DCIWarning(char *string);
DV_EXPORT void DCIError(char *string);
DV_EXPORT void DCIErrorToClient(DCICommsInfo *info, char *string);

/*********************** WMan - User Role DCI Functions *****************/
DV_EXPORT void DCISend_UsersQuery(DCICommsInfo *info, void *data);
DV_EXPORT void DCISend_UsersInform(DCICommsInfo *info, void *data, char *dviseData);
DV_EXPORT void DCISend_RolesQuery(DCICommsInfo *info, void *data);
DV_EXPORT void DCISend_RolesInform(DCICommsInfo *info, void *data, char *dviseData);
DV_EXPORT void DCISend_SetBodyInform(DCICommsInfo *info, void *data, char *bod);
DV_EXPORT void DCISend_SetBodyRoleInform(DCICommsInfo *info, void *data, char *bod, char *role);
DV_EXPORT void DCISend_BodyUnitsInform(DCICommsInfo *info, void *userData, 
                                       dmDistanceUnit units);
DV_EXPORT void DCISend_BodyUnitsQuery(DCICommsInfo *info, void *userData);
DV_EXPORT void DCISend_SetBodyPositionInform(DCICommsInfo *info, void *userData, 
                                             char *bodyName, int mode, int axis, float32 val);

/************** Messages to load/unload enable/disable optionally on a tree ***************/
DV_EXPORT void DCISend_EnableAllInform(DCICommsInfo *info, void *ud, char *objName, int tree);
DV_EXPORT void DCISend_DisableAllInform(DCICommsInfo *info, void *ud, char *objName, int tree);
DV_EXPORT void DCISend_LoadAllInform(DCICommsInfo *info, void *userData, 
                                       char *objName, int doTree);
DV_EXPORT void DCISend_UnloadAllInform(DCICommsInfo *info, void *userData, 
                                       char *objName, int doTree);


DV_EXPORT void DCISend_ResetVisualInform(DCICommsInfo *info, void *ud, char *objName, int tree);
DV_EXPORT void DCISend_DeselectAllInform(DCICommsInfo *info, void *ud);
DV_EXPORT void DCISend_MatrlOverrideInform(DCICommsInfo *info, void *ud, char *objName, int tree,
                                           char *frontMat, char *backMat);

/*
 * Annotation Service
 */

DV_EXPORT void DCISend_ASInitInform(DCICommsInfo *info, void *userData);
DV_EXPORT void DCISend_ASSetContextInform(DCICommsInfo *info, void *userData, char* vdifile, char* db);
DV_EXPORT void DCISend_ASViewAnnotationInform(DCICommsInfo *info, void *userData, char* annotation);
    
/* *************** Functions provided by the client ************** */
/* DCIReceiptFunctions provided by the client are registered using
 * DCIRegisterReceiptFunction (prototype above).  The prototypes
 * of the functions (i.e. the parameters passed to whatever function
 * is assigned) are given below, indexed by message type and token value
 *
 * In each case the first parameter is the comms info structure and
 * the second parameter is a userData field passed within the message.
 * Further parameters vary according to the message type and tag.
 *=========================================================================

 **** Inform Messages ****
  
 DCIInform tAssemblyAttributes
 DCICommsInfo *, void *, char *, ECAssembly *)
  
 DCIInform tAssemblyLinkage
 DCICommsInfo *, void *, char *, ECAssembly *)
  
 DCIInform tAssemblyRename
 DCICommsInfo *, void *, char *, char *, char *)
 
 DCIInform tAssemblies
 DCICommsInfo *, void *, ECAssembly *)
  
 DCIInform tAssemblyAttributeList
 DCICommsInfo *, void *, char *, char *, ECItem *, int)
  
 DCIInform tAssemblyAddAttributeList
 DCICommsInfo *, void *, char *, char *, ECItem *, int)
  
 DCIInform tAssemblyRemoveAttributeList
 DCICommsInfo *, void *, char *, char *, char *, int)
  
 DCIInform tFileLibraries
 DCICommsInfo *, void *, ECAssembly *)
  
 DCIInform tFileAttributes
 DCICommsInfo *, void *, ECFile *)
  
 DCIInform tAssemblyLink
 DCICommsInfo *, void *, char *, char *, char *)
  
 DCIInform tAssemblyUnlink
 DCICommsInfo *, void *, char *, char *)
  
 DCIInform tAssemblyCreate
 DCICommsInfo *, void *, char *, char *, ECAssembly *)

 DCIInform tAssemblyMakeNonInstance
 DCICommsInfo *, void *, char *)

 DCIInform tAttributeCreate
 DCICommsInfo *, void *, char *, int)

 DCIInform tLibraryCreate
 DCICommsInfo *, void *, ECAssembly *)

 DCIInform tLibraryCreate
 DCICommsInfo *, void *, char *, int)

 DCIInform tLandmarkCreate
 DCICommsInfo *, void *, char *, char *, char *, char *)
  
 DCIInform tFlightPathCreate
 DCICommsInfo *, void *, char *, char *)
  
 DCIInform tSectionCreate
 DCICommsInfo *, void *, char *, char *)

 DCIInform tAnnotateCreate
 DCICommsInfo *, void *, char *, ECAssembly *)

 DCIInform tAssemblyInstance
 DCICommsInfo *, void *, char *, char *, char *)
  
 DCIInform tAssemblyInstance
 DCICommsInfo *, void *, char *, char *, char *)
  
 DCIInform tAssemblyDestroy
 DCICommsInfo *, void *, char *, char *)
  
 DCIInform tAssemblyAttribute
 DCICommsInfo *, void *, char *, ECItem *)
  
 DCIInform tAssemblyAddAttribute
 DCICommsInfo *, void *, char *, ECItem *)
  
 DCIInform tAssemblyRemoveAttribute
 DCICommsInfo *, void *, char *, char *)
  
 DCIInform tActionFunctions
 DCICommsInfo *, void *, ECActionFunc *)
  
 DCIInform tRegisterInterest
 DCICommsInfo *, void *, int, ECItem *, char *)
  
 DCIInform tDeregisterInterest
 DCICommsInfo *, void *, int, ECItem *)
  
 DCIInform tdciEvent
 DCICommsInfo *, void *, int, ECEventData *)
  
 DCIInform tEventNames
 DCICommsInfo *, void *, ECStringset *, int)
  
 DCIInform tImageSave
 DCICommsInfo *, void *, char *)
 
 DCIInform tToggleBranch
 DCICommsInfo *, void *, char *)
  
 DCIInform tSaveInfo
 DCICommsInfo *, void *, char *, int)

 DCIInform tToggleHighlightMode
 DCICommsInfo *, void *, int)
  
 DCIInform tTogglePicking
 DCICommsInfo *, void *, int)

 DCIInform tFileName
 DCICommsInfo *, void *, char *, char *)
  
 DCIInform tPluginName
 DCICommsInfo *, void *, char **)

 DCIInform tSave
 DCICommsInfo *, void *, char *, int, int)
 
 DCIInform tSaveMaterials
 DCICommsInfo *, void *, char *)

 DCIInform tRoles
 DCICommsInfo *, void *, char *)
  
 DCIInform tUsers
 DCICommsInfo *, void *, char *)
  
 DCIInform tSetBody
 DCICommsInfo *, void *, char *)
 
 DCIInform tSetBodyPosition
 DCICommsInfo *, void *, char *, int, char, float32)
  
 DCIInform tBodyPartSelectList
 DCICommsInfo *, void *, EC_DCI_EventData *)
  
 DCIInform tExit
 DCICommsInfo *, void *, int)
  
 DCIInform tError
 DCICommsInfo *, void *, char *)
  
 DCIInform tMessage
 DCICommsInfo *, void *, char *)
  
 DCIInform tLoadAll
 DCICommsInfo *, void *, char *, int)

 DCIInform tUnloadAll
 DCICommsInfo *, void *, char *, int)

 DCIInform tEnableAll
 DCICommsInfo *, void *, char *, int)
  
 DCIInform tDisableAll
 DCICommsInfo *, void *, char *, int)
  
 DCIInform tResetVisual
 DCICommsInfo *, void *, char *, int)
  
 DCIInform tDeselectAll
 DCICommsInfo *, void *)
  
 DCIInform tFlyToAll
 DCICommsInfo *, void *)
  
 DCIInform tClipAssemblyCopy
 DCICommsInfo *, void *, char *, char *, char **)
  
 DCIInform tClipAssemblyPaste
 DCICommsInfo *, void *, char *, char *, char *)
 
 DCIInform tClipAttributeCopy
 DCICommsInfo *, void *, char **)
  
 DCIInform tClipAttributePaste
 DCICommsInfo *, void *, char *)
 
 DCIInform tBodyNavigator
 DCICommsInfo *, void *)
 **** Query Messages ****
  
 DCIQuery tAssemblyAttributes
 DCICommsInfo *, void *, char *, ECAssembly *)
  
 DCIQuery tAssemblyLinkage
 DCICommsInfo *, void *, char *, ECAssembly *)
  
 DCIQuery tAssemblies
 DCICommsInfo *, void *, char *)
  
 DCIQuery tActionFunctions
 DCICommsInfo *, void *)
  
 DCIQuery tEventNames
 DCICommsInfo *, void *, char *)
  
 DCIQuery tFileName
 DCICommsInfo *, void *)
  
 DCIQuery tSaveInfo
 DCICommsInfo *, void *)

 DCIQuery tTogglePicking
 DCICommsInfo *, void *)

 DCIQuery tToggleHighlightMode
 DCICommsInfo *, void *)

 DCIQuery tRoles
 DCICommsInfo *, void *)
  
 DCIQuery tUsers
 DCICommsInfo *, void *)
  
 DCIQuery tPluginName
 DCICommsInfo *, void *)

 DCIQuery tBodyPartSelectList
 DCICommsInfo *, void *, char *, char *)
 */


#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /*_DCITOOLS_H */
