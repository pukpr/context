
static char *sockCommands[] = {
    "LOAD_PLUGIN",
    "UNLOAD_PLUGIN",
    "FILEOPEN",
    "ACK",
    NULL
};

#define LOAD_PLUGIN      0
#define UNLOAD_PLUGIN    1
#define FILE_OPEN        2
#define ACK_MESSAGE      3
#define NUM_COMMANDS     4

