/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    FUNCTION:
 *
 * Copyright (c) 1994 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */

#ifndef _ECCPPATTR_H
#define _ECCPPATTR_H

#ifndef DV_EXPORT
#include "dvexport.h"
#endif

#ifndef _ECTYPES_H
#include "ectypes.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct ECCppItem {
    ECItemType          type;
    struct ECAssembly  *owner;
    char               *name;
    char               *pathName;
    void               *clientData;
    struct ECCppItem   *definition;
    ECItem             *instanceList;
} ECCppItem;

DV_EXPORT ECCppItem *ECCppItem_Allocate(void);
DV_EXPORT ECCppItem *ECCppItem_Create(void *item);
DV_EXPORT void ECCppItem_Destroy(ECCppItem *cppItem);
DV_EXPORT ECItemType ECCppItem_GetType(ECCppItem *cppItem);
DV_EXPORT int ECCppItem_GetClientDataKey();
DV_EXPORT char *ECCppItem_GetName(ECCppItem *cppItem);
DV_EXPORT void ECCppItem_SetOwner(ECCppItem *cppItem, void *newOwner);
DV_EXPORT void *ECCppItem_GetClientData(ECCppItem *cppItem);
ECCppItem * ECCppItem_Copy(ECCppItem *item);
void 		 ECCppItem_SetDefn(ECCppItem *def, ECCppItem *newItem);
    

#ifdef __cplusplus
}
#endif /* _cplusplus */

#endif /* _ECCPPATTR_H */
