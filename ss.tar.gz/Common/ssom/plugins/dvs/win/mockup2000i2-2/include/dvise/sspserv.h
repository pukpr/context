/******************************************************************************/
/*									      */
/*	######    ###   #     #   ###    #####    ###   ####### #     #	      */
/*	#     #    #    #     #    #    #     #    #    #     # ##    #	      */
/*	#     #    #    #     #    #    #          #    #     # # #   #	      */
/*	#     #    #    #     #    #     #####     #    #     # #  #  #	      */
/*	#     #    #     #   #     #          #    #    #     # #   # #	      */
/*	#     #    #      # #      #    #     #    #    #     # #    ##	      */
/*	######    ###      #      ###    #####    ###   ####### #     #	      */
/*									      */
/*									      */
/*			#####    ###     ###     ###			      */
/*			     #  #   #   #   #   #   #			      */
/*			     # #     # #     # #     #			      */
/*			#####  #     # #     # #     #			      */
/*			#      #     # #     # #     #			      */
/*			#       #   #   #   #   #   #			      */
/*			######   ###     ###     ###			      */
/*									      */
/* 		Copyright (c) Division Limited. All rights reserved	      */
/*									      */
/* This Document may not, in whole or in part, be copied, photocopied,	      */
/* reproduced, translated, or reduced to any electronic medium or machine     */
/* readable form without prior written consent from Division Ltd.	      */
/*									      */
/******************************************************************************/

#if !defined _SSPSERV_H_
#define _SSPSERV_H_

#include <dsys/dp.h>
#include <dvise/ss.h>

extern int ssp_servHandleMessage (SS_HANDLE ss, uint16 command);

#endif /* _SSPSERV_H */
