#ifndef _MANINVKIN_HH
#define _MANINVKIN_HH


#ifndef _swapi_h
#define SWAPI_IKBEHLIM 000001
#define SWAPI_IKBEHPREF 000002 
#define SWAPI_IKBEHLOC 004000
#define SWAPI_IKBEHPOS 002000
#endif


class DV_EXPORT _ECSwManIKSpecsInfo: public _ECItemInfo
{
public:
    _ECSwManIKSpecsInfo(char *keyword) : _ECItemInfo(keyword) {};
    _ECBaseItem * createItem(void) ;
    int parseFileStream(dParseFilePtr, _ECBaseItem *, hierarchy *);
};
typedef ECSmartPtr<_ECSwManIKSpecsInfo> ECSwManIKSpecsInfoPtr;

extern _ECSwManIKSpecsInfo ManIKSpecsParser;

// Parser tokens
#define DEF_TOKEN(a, b, c) a,
typedef enum{
    tSwManIKSpecsStartToken = 256,
#include "man_invkin_def.hh"
    tSwManIKSpecsEndToken
}SwManIKSpecsToken;
#undef DEF_TOKEN 


typedef enum
{
dvSwIKSolveScopeGlobal = 0,
dvSwIKSolveScopeLocal = SWAPI_IKBEHLOC
} dvSwIKSolveScope;

typedef enum
{
    dvSwIKSolveBoundsNULL = 0,
    dvSwIKSolveBoundsLim = SWAPI_IKBEHLIM,
    dvSwIKSolveBoundsPref = SWAPI_IKBEHPREF
} dvSwIKSolveBounds;

typedef enum
{
dvSwIKRootMovementFree = 0,
dvSwIKRootMovementFix = SWAPI_IKBEHPOS
} dvSwIKRootMovement;

class DV_EXPORT _ECSwManRegister;
typedef ECSmartPtr<_ECSwManRegister> ECSwManRegisterPtr;


// This class holds the IK specs for the whole manikin
class DV_EXPORT _ECSwManIKSpecs : public _ECBaseItem
{

public:
    _ECSwManIKSpecs();
    _ECSwManIKSpecs(char *RootName);
    _ECSwManIKSpecs(char *RootName,
		    dvSwIKSolveScope sc, 
		    dvSwIKSolveBounds bo, 
		    dvSwIKRootMovement mo);
    ~_ECSwManIKSpecs();
 
    // Generic query and set methods
    static int getMyId(void);
    int getId(void) const;
    char *getIdString(void) const; // %WAR: Abstract virtual from _ECBaseItem
    char *GetName() const {return _attributeName;};
    ECError SetName(char *newName);
    ECError SetNameNoCopy(char *newName);

    // Specific query and set methods
    static _ECSwManIKSpecs *getFromAssembly(ECAssembly *ass); 
    _ECAssembly *getThisAssembly() {return(getManikinRootAssembly());};
    _ECAssembly *getManikinRootAssembly() ;
    char *getObjectHandle() {return(_objectHandle);};
    char *getManikinHandle() {return(_objectHandle);};

    dvSwIKSolveScope getSolveScope() {return _solveScope;};
    dvSwIKSolveBounds getSolveBounds(){return _solveBounds;};
    dvSwIKRootMovement getIKRootMovement(){return _rootMovement;};

    dvSwRetType setSolveScope(dvSwIKSolveScope sc){
	if(_setall (sc, getSolveBounds(), getIKRootMovement()) == dvSwSuccess)
	{
	    _solveScope=sc;
	    _update(0);
	    return(dvSwSuccess);
	}
	return(dvSwFailure);
    };
    dvSwRetType setSolveBounds(dvSwIKSolveBounds bo){
	if(_setall (getSolveScope(), bo, getIKRootMovement()) == dvSwSuccess)
	{
	    _solveBounds = bo;
	    _update(0);
	    return(dvSwSuccess);
	}
	return(dvSwFailure);
    };
    dvSwRetType setIKRootMovement(dvSwIKRootMovement mo){
	if(_setall (getSolveScope(), getSolveBounds(), mo) == dvSwSuccess)
	{
	    _rootMovement = mo;
	    _update(0);   
	    return(dvSwSuccess);
	}
	return(dvSwFailure);
    };

    // Interface methods
    dvSwRetType solveOnJointLimits() {
	return(setSolveBounds(dvSwIKSolveBoundsLim));
    };
    dvSwRetType solveOnPrefAngles() {
	return(setSolveBounds(dvSwIKSolveBoundsPref));
    };
    dvSwRetType solveOnLocalSystems() {
	return(setSolveScope(dvSwIKSolveScopeLocal));
    };
    dvSwRetType solveOnGlobalSystems() {
	return(setSolveScope(dvSwIKSolveScopeGlobal));
    }
    dvSwRetType lockGlobalSystem() {
	return(setIKRootMovement(dvSwIKRootMovementFix));
    };
    dvSwRetType unlockGlobalSystem() {
	return(setIKRootMovement(dvSwIKRootMovementFree));
    };
					// Snap all 'follow manikin' cns back
					// to the manikin.
    dvSwRetType reinitAllCons();
					// Snap all 'follow manikin' cns back
					// to the manikin and store their
					// positions for future restoring.
    dvSwRetType reinitAndStoreAllCons();

    dvSwRetType solveIK();
    dvSwRetType Inspect();

 
    // I/O methods
    int writeVdiFile(); // %NOTE: The write method is member...
    // .. But the read method is a friend (member of the class defined above)
    friend int _ECSwManIKSpecsInfo::parseFileStream(dParseFilePtr IS, 
					       _ECBaseItem *thisAttribute,
					       hierarchy *pH);
   
private:
    dvSwRetType _setall(dvSwIKSolveScope sc, 
			dvSwIKSolveBounds bo,
			dvSwIKRootMovement mo);

    dvSwRetType _getall();

    dvSwIKSolveScope _solveScope;
    dvSwIKSolveBounds _solveBounds;
    dvSwIKRootMovement _rootMovement;

    char * _objectHandle; // Safework name of THIS instance
    char * _attributeName; // Name of this attribute

     // pointer to the assembly and register entry
    //ECSwManRegisterPtr thisRegister;

};

typedef ECSmartPtr<_ECSwManIKSpecs> ECSwManIKSpecsPtr;

#endif
