/****************************************************************************
 *
 *  			Copyright 1995 Division Limited.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *
 *
 ****************************************************************************
 *
 *  Copyright (c) 1995 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 *  This Document may not, in whole or in part, be copied,
 *  photocopied, reproduced, translated, or reduced to any
 *  electronic medium or machine readable form without prior
 *  written consent from Division Ltd.
 ****************************************************************************/

#ifndef __TBSHELL_H__
#define __TBSHELL_H__
#ifdef __cplusplus
extern "C" {
#endif

#include "vwform.h"
/* VWShell_CreateManaged / VWShell_Create - return a pointer to a newly created
 * VWShell widget. */
VW_EXPORT VWidget *VWShell_CreateManaged(VWidget *Parent, char *name, VWArg args[], int argc);
VW_EXPORT VWidget *VWShell_Create(VWidget *Parent, char *name, VWArg args[], int argc);
/* VWShell_AddQuitCallback - Adds a user defined VWCallback to the shell widget.
 * This is invoked when the quit button is pressed. The Shell widget is automatically
 * unmanaged before this callback is executed */
VW_EXPORT void VWShell_AddQuitCallback(VWidget *thisWig, VWCallback *cb, void *cd);
VW_EXPORT void VWShell_AddLockCallback(VWidget *thisWig, VWCallback *cb, void *cd);
VW_EXPORT void VWShell_AddUnlockCallback(VWidget *thisWig, VWCallback *cb, void *cd);
VW_EXPORT void VWShell_SetLockIconLocked(VWidget *ShellWig);
VW_EXPORT void VWShell_SetLockIconUnlocked(VWidget *ShellWig);
VW_EXPORT void VWShell_SetTitleVisual(VWidget *ShellWig, char *titleVisual);
VW_EXPORT void VWShell_AddResizeUpdateCallback(VWidget *widget, VWCallback *cb, void *cd);
VW_EXPORT void VWShell_RemoveResizeUpdateCallback(VWidget *widget, VWCallback *cb, void *cd);
VW_EXPORT void VWShell_AddRelocateUpdateCallback(VWidget *widget, VWCallback *cb, void *cd);
VW_EXPORT void VWShell_RemoveRelocateUpdateCallback(VWidget *widget, VWCallback *cb, void *cd);
VW_EXPORT void VWShell_AddIconiseCallback(VWidget *thisWig, VWCallback *cb, void *cd);
VW_EXPORT void VWShell_AddUniconiseCallback(VWidget *thisWig, VWCallback *cb, void *cd);

VW_EXPORT void VWShell_SetLockIconLocked(VWidget *ShellWig);
VW_EXPORT void VWShell_SetLockIconUnlocked(VWidget *ShellWig);
VW_EXPORT void VWShell_AddLockPullDownMenu(VWidget *ShellWig, VWidget *menu, int numParts);
VW_EXPORT void VWShell_Uniconise(VWidget *ShellWig);

VW_EXPORT void VWShell_Iconise(VWidget *ShellWig);
VW_EXPORT void VWShell_ResetIconise(VWidget *ShellWig);

enum {
    VWrTitleVisual = VW_RESOURCES_SHELL,
    VWrUnactivateQuit,
    VWrUnactivateIconise,
    VWrUnactivateLock,
    VWrOverrideIconise
};

#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /* __TBSHELL_H__ */
