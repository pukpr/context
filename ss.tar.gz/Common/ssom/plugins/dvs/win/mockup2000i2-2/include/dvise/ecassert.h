
/* -*- C -*- ****************************************************************
 *
 *  			Copyright 2000 division.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: ecassert.h,v $
 *  Revision      : $Revision: 1.6 $
 *  Date          : $Date: 2000/05/22 16:27:52 $
 *  Author        : $Author: jeff $
 *  Created By    : <unknown>
 *  Created       : Wed May 17 17:23:49 2000
 *  Last Modified : <:00517.1724>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 *  $Log: ecassert.h,v $
 *  Revision 1.6  2000/05/22 16:27:52  jeff
 *  sequencer fixes, (more) assert updates
 *

 *  Revision 1.5  2000/05/22 15:23:06  simon
 *  New version that works on windows.
 *
 *  Revision 1.4  2000/05/22 15:20:35  simon
 *  Fixed optimized version.
 *
 *  Revision 1.3  2000/05/22 15:18:28  simon
 *  Fixed #define.
 *
 *  Revision 1.2  2000/05/22 15:06:13  jeff
 *  fixes for unix
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: ecassert.h,v $
 *  Revision      : $Revision: 1.
 *  Revision 1.1  2000/05/22 11:03:30  simon
 *  Added ecassert.  Replaced all references to assert.  Fixed numerious bugs.
 *
 *
 ****************************************************************************
 *
 *  Copyright (c) 2000 division.
 * 
 *  All Rights Reserved.
 * 
 * This  document  may  not, in  whole  or in  part, be  copied,  photocopied,
 * reproduced,  translated,  or  reduced to any  electronic  medium or machine
 * readable form without prior written consent from division.
 *
 ****************************************************************************/

#ifndef _ECASSERT_H
#define _ECASSERT_H

#ifndef DV_EXPORT
#include "dvexport.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif
    
#undef ECAssert

#if ( defined (_WIN32)  && ! defined(_WINDU_SOURCE) && ! defined (__EPP__) && ! defined(_DEBUG) )|| defined(NDEBUG)

#define ECAssert(val) ((void)0)

#else

#define _STR(x) _VAL(x)
#define _VAL(x) #x
DV_EXPORT void _ECAssert(char *);
#define ECAssert(EXP) ((EXP)?((void)0):_ECAssert(__FILE__ ":" _STR(__LINE__) " " #EXP ))
#endif


#ifdef __cplusplus
}
#endif /* _cplusplus */

#endif /* _ECASSERT_H */
