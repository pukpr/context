#ifndef _MANHANDLE_HH
#define _MANHANDLE_HH

/*****************************************************************************/

class DV_EXPORT _ECSwManHandleInfo: public _ECItemInfo
{
public:
    _ECSwManHandleInfo(char *keyword) : _ECItemInfo(keyword) {};
    _ECBaseItem * createItem(void) ;
    int parseFileStream(dParseFilePtr, _ECBaseItem *, hierarchy *);

};

typedef ECSmartPtr<_ECSwManHandleInfo> ECSwManHandleInfoPtr;
extern _ECSwManHandleInfo ManHandleParser;

// Parser tokens
#define DEF_TOKEN(a, b, c) a,
typedef enum{
    tSwManHandleStartToken = 256,
#include "man_handle_def.hh"
    tSwManHandleEndToken
}SwManHandleToken;
#undef DEF_TOKEN 

// Type of manikin entity 
typedef enum {
    dvSwUnknown = 0,
    dvSwManRoot = 1, 
    dvSwManSeg = 2,
    dvSwManIKCons = 3 
    /*, 
      dvSwMotionSensor ??
      */
} dvSwObjectType;

/*
 * This class holds the handles (which correspond to 
 * instance names under Safework) necessary to 
 * reconstruct and identify all the manikin parts under  * dvsafework.
 * 
 *
 */

class DV_EXPORT _ECSwManHandle : public _ECBaseItem
{ 
    // implemented in man_handle.cc

public:
    _ECSwManHandle();
    _ECSwManHandle(ECAssemblyPtr ass, 
		   dvSwObjectType objtype, 
		   char *ObjectName, 
		   char *RootName = NULL,
		   int segIndex = -1);
    ~_ECSwManHandle(void);

     // Generic query and set methods
    int getId(void) const;
    static int getMyId(void);
    char *getIdString(void) const; // %WAR: Abstract virtual from _ECBaseItem
    char *GetName() const {return _attributeName;};
    ECError SetName(char *newName);
    ECError SetNameNoCopy(char *newName);

    // Specific query and set methods
    static _ECSwManHandle *getFromAssembly(ECAssembly *ass); 
    char *getManikinHandle() {return _manikinHandle;};
    char *getObjectHandle() {return _objectHandle;};
    _ECAssembly *getThisAssembly() {return(thisAssembly.operator->());};
    _ECAssembly *getManikinRootAssembly() ;
    dvSwRetType loadAssembly();
    dvSwRetType unloadAssembly();
    void setSegIndex(int index) {_segId = index;};

    int getSegmentIndex() {return(_objectType == dvSwManSeg ? _segId : -1);};

    bool isManRoot() {return(_objectType == dvSwManRoot); };
    bool isManSeg() {return(_objectType == dvSwManSeg); };
    bool isIKCons() {return(_objectType == dvSwManIKCons); };

    // I/O methods
    int writeVdiFile(); // %NOTE: The write method is member...
    // .. But the read method is a friend (member of the class defined above)
    friend int _ECSwManHandleInfo::parseFileStream(dParseFilePtr IS, 
						   _ECBaseItem *thisAttribute,
						   hierarchy *pH);


private: 
    dvSwObjectType _objectType;
    char * _objectHandle; // Safework name of THIS instance
    char * _manikinHandle; // name of the manikin's root under Safework

    char * _attributeName; // Name of this attribute
    int _segId;  // Segment index in case this is a segment

    // pointers to the assembly and register entry
    ECAssemblyPtr thisAssembly;
};

typedef ECSmartPtr<_ECSwManHandle> ECSwManHandlePtr;

#endif
