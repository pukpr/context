/*
 *      PROJECT:
 *      SUBSYSTEM:
 *      MODULE:
 *
 *      FILE:           $RCSfile: haptic.h,v $
 *      REVISION:       $Revision: 1.4 $
 *      Date:           $Date: 1997/05/29 11:52:49 $
 *      Author:         $Author: fuzzy $
 *      RCS Ident:      $Id: haptic.h,v 1.4 1997/05/29 11:52:49 fuzzy Exp $
 *
 *      FUNCTION:
 *
 * Copyright (c) 1992 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine reable form without prior
 * written consent from Division Ltd.
 */

#ifndef _HAPTIC_H_
#define _HAPTIC_H_

#include <stdio.h>
#include <stddef.h>
#include <errno.h>
#include <dvs/vc.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef HAPTIC_EXPORT
#if defined (_WIN32) && ! defined (__EPP__)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `extern'
 */

#ifdef  _LIB_HAPTIC
#define HAPTIC_EXPORT __declspec(dllexport) extern
#else
#define HAPTIC_EXPORT __declspec(dllimport) extern
#endif /* IN_A_DIVISION_LIB */
#else
#define HAPTIC_EXPORT  extern
#endif /* ! _WIN32 */
#endif /* ifndef VC_EXPORT */

#ifdef _LIB_HAPTIC

#include <hapticeltype.h>

#if !defined ( __EPP__)  && !defined (_HAPTICELEMEN_C)
#include <hapticelem.h>		/* VC Element definitions */
#endif

#include <hapticstruct.h>
#include <hapticfunc.h>

#else

#include <dvs/hapticeltype.h>

#if !defined ( __EPP__)  && !defined (_HAPTICELEMEN_C)
#include <dvs/hapticelem.h>		/* VC Element definitions */
#endif

#include <dvs/hapticstruct.h>
#include <dvs/hapticfunc.h>
#endif

#ifdef __cplusplus
}
# endif

#endif


