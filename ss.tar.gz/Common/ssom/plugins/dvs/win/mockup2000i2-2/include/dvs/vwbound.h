/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: vwbound.h,v $
 *    Revision:     $Revision: 1.3 $
 *    Date:         $Date: 1997/04/22 12:33:48 $
 *    Author:       $Author: simon $
 *    RCS Ident:    $Id: vwbound.h,v 1.3 1997/04/22 12:33:48 simon Exp $
 *
 *    FUNCTION: Sclar public function prototypes.
 * 
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _VWBound_H
#define _VWBound_H
#ifdef __cplusplus
extern "C" {
#endif
/* PUBLIC TYPES =============================================*/

enum VWBounderArgTypes {
    VWrBoundAnchorVisual = VW_RESOURCES_BOUND, 
    VWrBoundAnchorHighlightVisual, 
    VWrBoundAnchorMaterial, 
    VWrBoundAnchorHighlightMaterial, 
    VWrBoundAnchorScale, 
    VWrBoundConstrainedPuckVisual, 
    VWrBoundConstrainedPuckHighlightVisual, 
    VWrBoundPuckMaterial, 
    VWrBoundPuckHighlightMaterial, 
    VWrBoundPuckScale, 
    VWrBoundFreePuckVisual, 
    VWrBoundFreePuckHighlightVisual, 
    VWrBoundFreePuckHighlightMaterial, 
    VWrBoundFreePuckMaterial, 
    VWrBoundBarVisual, 
    VWrBoundBarMaterial, 
    VWrBoundBarWidth, 
    VWrBoundDefaultValue, 
    VWrBoundDragCallback, 
    VWrBoundDragCalldata, 
    VWrBoundDropCallback, 
    VWrBoundDropCalldata, 
    VWrBoundAnchorDropCalldata, 
    VWrBoundAnchorDropCallback
};

typedef enum {
    VWcPosX = 0, 
    VWcPosY, 
    VWcPosZ, 
    VWcNegX, 
    VWcNegY, 
    VWcNegZ
} VWtBoundAxis;


typedef enum {
    VWcAxisLocked = 0, 
    VWcAxisUnlocked, 
    VWcAxisFree, 
    VWcAxisNotSet
} VWtBoundLock;



/* PUBLIC FUNCTIONS ======================================*/

VW_EXPORT VWidget *VWBounder_CreateManaged(VWidget *, char *, VWArg [], int);
VW_EXPORT VWidget *VWBounder_Create(VWidget *, char *, VWArg [], int);

VW_EXPORT void VWBounder_Reset(VWidget *);
VW_EXPORT void VWBounder_SetAxisLimit(VWidget *, VWtBoundAxis, VWtBoundLock, float32);
VW_EXPORT float32 VWBounder_GetAxisLimit(VWidget *, VWtBoundAxis, VWtBoundLock *);
VW_EXPORT VWtBoundAxis VWBounder_GetLastMovedAxis(VWidget *);





#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /*_vwBound_H */
