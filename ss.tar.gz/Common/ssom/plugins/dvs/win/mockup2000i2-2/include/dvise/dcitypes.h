/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: dcitypes.h,v $
 *    Revision:     $Revision: 1.12 $
 *    Date:         $Date: 1999/05/19 14:46:25 $
 *    Author:       $Author: rajini $
 *    RCS Ident:    $Id: dcitypes.h,v 1.12 1999/05/19 14:46:25 rajini Exp $
 *
 *    FUNCTION:
 *
 *
 *    $Log: dcitypes.h,v $
 *    Revision 1.12  1999/05/19 14:46:25  rajini
 *    Save the id returned by VC_AttachFile and pass it to VC_DetachFile.
 *
 *    Revision 1.11  1998/05/20 11:37:04  rajini
 *    Added support for multiple material libraries.
 *
 *    Revision 1.10  1997/09/25 14:47:32  john
 *    general tidying up to try to reduce compiler warnings
 *    removed unused variables
 *    stopped dciParseMessage mallocing memory that is unused
 *    removed functions that just pass on paramaters to another function.
 *
 *    Revision 1.9  1997/08/26 11:16:09  simon
 *    *** empty log message ***
 *
 *    Revision 1.8  1997/08/01 12:14:47  rajini
 *    *** empty log message ***
 *
 *    Revision 1.7  1997/03/11 11:23:32  clives
 *    *** empty log message ***
 *
 *    Revision 1.6  1996/12/19 18:14:05  clives
 *    *** empty log message ***
 *
 *    Revision 1.5  1996/10/24 14:38:58  clives
 *    *** empty log message ***
 *
 *    Revision 1.4  1996/10/03 15:57:12  clives
 *    *** empty log message ***
 *
 *    Revision 1.3  1996/10/01 16:35:42  clives
 *    *** empty log message ***
 *
 *    Revision 1.2  1996/09/18 14:50:59  clives
 *    *** empty log message ***
 *
 *    Revision 1.1.1.1  1996/07/25 16:06:30  alex
 *    Initial import of dVISE
 *
 *    Revision 1.1.1.1  1996/07/24 17:30:14  alex
 *    Initial version of dVISE
 *
 *    Revision 1.1  1995/11/03 17:03:23  alex
 *    Quick_RCS_Check
 *
 * Revision 1.3  1995/04/26  11:40:12  alex
 * *** empty log message ***
 *
 * Revision 1.2  95/03/03  16:24:12  alex
 * *** empty log message ***
 * 
 * Revision 1.1  1995/03/01  13:15:41  alex
 * Initial revision
 *
 * Revision 1.1  1995/03/01  13:11:05  alex
 * Initial revision
 *
 *
 * Copyright (c) 1992 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _DCITYPES_H
#define _DCITYPES_H

/* PUBLIC DEFINES =======================================*/
#define DCI_DEFAULT_STREAM_SIZE 8192
#define DCI_LOGIN_STREAM_SIZE 1024
#define DCI_BLOCKED_WRITE_RETRY_DELAY_SECS 2
#define DCI_BLOCKED_WRITE_RETRY_DELAY_USECS 1

#define DCI_BODY_TRANSLATE 0
#define DCI_BODY_ROTATE 1

#define DCI_DBG 0x1000

/* PUBLIC TYPES =========================================*/

typedef enum {
  DCIClient, DCIServer, DCIDefunct
} DCIEnd;

typedef enum DCILibraryType {
  DCIVdl, DCIPlugin, DCIMaterial
} DCILibraryType;

typedef enum {
  DCIQuery=0, DCIInform=1
} DCIMessageType;


/* The structure DCICommsInfo is used by both ends of the DCI link and
 * so certain structures are filled only at one end.
 * The field streamEnd tells you which end of the connection this structure
 * is being used at.
 */
typedef struct DCICommsInfo {
  /* Common fields */
  DCIEnd       end;
  int          rfd;
  int          wfd;
  char        *rbuf;
  int          rbufsize;
  int          rIndex;
  void        *rCallbackHandle;	/* reader callback for this comms info */
  void        *wCallbackHandle;	/* writer callback for this comms info */
  int          rFileCallbackId; /* Id returned by VC_AttachFile */
  int          wFileCallbackId; /* Id returned by VC_AttachFile */

  char        *clientName;

  /* The following fields are used at the application end only */
  DCIString    buffer;          /* buffer for pending write */
  int          interest;        /* bit mask of update interest for the client */
  ECZone      *ecZone;          /* a pointer to the real zone */
  ECZone      *clip;	        /* a pointer to the clipboard for this client */
  ECZone      *attrClip;        /* a pointer to the attribute clipboard for this client */
  ECEventList *eventList;       /* list of events in which interest has been registered */
  char        *bodyName;        /* name of body associated with client */
  int          clientPid;       /* process id of the client */
  struct DCICommsInfo *next;
  int          bufIndex;
} DCICommsInfo;

typedef void (*DCIReceiptFunc)();
typedef void (*DCIClientCallbackFunc)(void *, ECEventData *, void *);

typedef struct DCIBodyRole {
  int bodyNum;
  char *roleName;
  struct DCIBodyRole *next;
} DCIBodyRole;

typedef void (*DCI_CallbackFunc) (char *, EC_DCI_EventData *, ECAction *);

/* PUBLIC VARIABLES ======================================*/


/* PUBLIC FUNCTIONS ======================================*/


#endif /*_DCITYPES_H */
