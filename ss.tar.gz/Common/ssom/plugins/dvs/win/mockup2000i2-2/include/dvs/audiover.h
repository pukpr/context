/*
-- ----------------------------------------------------------------------------
--
--                      Copyright 1996 Division Limited.
--                            All Rights Reserved
--
--
--  System       : dVS
--  Module       : Audio support library
--  Object Name  : $RCSfile: audiover.h,v $
--  Revision     : $Revision: 1.3 $
--  Date         : $Date: 1997/09/29 12:30:40 $
--  Author       : $Author: mark $
--
--  Description 
--      Defines the major and minor version numbers for the audio actor.
--
--  Notes
--
--  History
--      
--
-- ----------------------------------------------------------------------------
*/

#ifndef __AUDIOVER_H__
#define __AUDIOVER_H__

#define AUDIO_VERSION_MAJOR 5           /* protocol version major number */
#define AUDIO_VERSION_MINOR 0           /* protocol version minor number */
#define AUDIO_VERSION_PROTOCOL "AUDIO"  /* protocol name */

#endif /* __AUDIOVER_H__ */
