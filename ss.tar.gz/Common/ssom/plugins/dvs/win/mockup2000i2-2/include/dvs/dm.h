/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: dm.h,v $
 *    Revision:     $Revision: 1.1 $
 *    Date:         $Date: 1996/04/09 14:10:50 $
 *    Author:       $Author: john $
 *    RCS Ident:    $Id: dm.h,v 1.1 1996/04/09 14:10:50 john Exp $
 *
 *    FUNCTION:
 *
 *
 *
 * Copyright (c) 1995 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _DVS_DM_H
#define _DVS_DM_H
#include <dsys/dm.h>
#include <dvs/dmelem.h>
#endif /*_DVS_DM_H */
