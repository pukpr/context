#ifndef _DVSAFEWORKDEBUG_HH
#define _DVSAFEWORKDEBUG_HH

#include <dsys/dmd.h>
#include <dvise/ecassert.h>

/******************************************************************************

  This header file describes some function prototypes used to display debug
  information on the screen.

******************************************************************************/

/* These enumerated types are the bit masks used by the verbose and debug
   system debugging protocols for controling output in this module (refered to
   as dvSw from the command line).

   Nb. there are levels of debug and 32 levels of verbose which are expressed
       as constants in the range 0x1 to Ox80000000. */

typedef enum
{
    dvSwVInit		= 0x00000001, /* obsolete */
    dvSwVCreation	= 0x00000002,
    dvSwVBuild		= 0x00000004,
    dvSwVHierarchy	= 0x00000008,

    dvSwVGeom		= 0x00000010,
    dvSwVExit		= 0x00000020, /* obsolete */
    dvSwVPoll		= 0x00000040,
    dvSwVConstraints	= 0x00000080,

    dvSwVSelect		= 0x00000100,
    dvSwVVision		= 0x00000200,
    dvSwVRoot		= 0x00000400,
    dvSwVAnthro		= 0x00000800,

    dvSwVPosture	= 0x00001000,
    dvSwVToolbox	= 0x00002000, /* obsolete */
    dvSwVControl	= 0x00004000, /* Init, exit, file new, load, save*/ 
    dvSwVRegister	= 0x00008000,

    dvSwVVisionGeom	= 0x00010000,
    dvSwVComm		= 0x00020000, 
    dvSwVCallbacks	= 0x00040000,
    dvSwVTexture 	= 0x00080000,

    dvSwVGroups		= 0x00100000,
    dvSwVLibraries	= 0x00200000,
    dvSwVLoadUnload	= 0x00400000,	// Segment Load/unload behaviour.
    dvSwVCnsPickUnpick	= 0x00800000	// Constraint pick/unpick.

} dvSwVerboseLevels;


typedef enum
{
    dvSwDInit		= 0x00000001, /* obsolete */
    dvSwDCreation	= 0x00000002,
    dvSwDBuild		= 0x00000004,
    dvSwDHierarchy	= 0x00000008,

    dvSwDGeom		= 0x00000010,
    dvSwDExit		= 0x00000020, /* obsolete */
    dvSwDPoll		= 0x00000040,
    dvSwDConstraints	= 0x00000080,

    dvSwDSelect		= 0x00000100,
    dvSwDVision		= 0x00000200,
    dvSwDRoot		= 0x00000400,
    dvSwDAnthro		= 0x00000800,

    dvSwDPosture	= 0x00001000,
    dvSwDToolbox	= 0x00002000, /* obsolete */
    dvSwDControl	= 0x00004000, /* Init, exit, file new, load, save*/ 
    dvSwDRegister	= 0x00008000,

    dvSwDVisionGeom	= 0x00010000,
    dvSwDComm		= 0x00020000,
    dvSwDCallbacks	= 0x00040000,
    dvSwDTexture        = 0x00080000,
    
    dvSwDGroups		= 0x00100000,
    dvSwDLibraries	= 0x00200000
    /*
    dvSwD		= 0x00400000,
    dvSwD		= 0x00800000,
    */

} dvSwDebugLevels;


/* Abbreviations for module debug. */

#define dvSwVerbose(verbose_level, printf_body)			\
	duVerbose_Module(verbose_level, dvSwVerboseModuleHandle, printf_body)

#define dvSwDebug(debug_level, printf_body)			\
	duDebug_Module(debug_level, dvSwDebugModuleHandle, printf_body)

/*****************************************************************************/

					/* Single precision (dm) debug
                                           functions. */
void
pmatrix(/*const*/ dmMatrix, const char *);

void
point(const dmPoint, const char *);

void
pquat(const dmQuaternion, const char *);

void
psplit(/*const*/ dmMatrix, const char *);

void
prot(const dmPoint, const char *);


					/* Double precision (dmd) debug
                                           functions. */
void
dpmatrix(/*const*/ dmdMatrix, const char *);

void
dpoint(const dmdPoint, const char *);

void
dpquat(const dmdQuaternion, const char *);

void
dpsplit(/*const*/ dmdMatrix, const char *);

void
dprot(const dmdPoint, const char *);


void
dvSwDebugDmSplit_ModuleFunc(dvSwDebugLevels, unsigned int, dmMatrix);

void
dvSwVerboseDmSplit_ModuleFunc(dvSwVerboseLevels, unsigned int, dmMatrix);


void
dvSwDebugDmdSplit_ModuleFunc(dvSwDebugLevels, unsigned int, dmdMatrix);

void
dvSwVerboseDmdSplit_ModuleFunc(dvSwVerboseLevels, unsigned int, dmdMatrix);


/******************************************************************************
  High level macros for debugging dm (single precision) types eg. matrices,
  vectors, points, quaternions etc.
******************************************************************************/

					/* If compiling with debug... */
					/* ...then define the high level
					   debugging macros... */
#ifndef NDEBUG
#define dvSwDebugDmTriple_Module(debug_level, module, triple)		\
	duDebug_Module(debug_level, module, ("%.6f %.6f %.6f\n",	\
				triple[DM_X], triple[DM_Y], triple[DM_Z]))

#define dvSwDebugDmEuler_Module(debug_level, module, euler)		\
			duDebug_Module(debug_level, module,		\
				("%.6f %.6f %.6f\n",			\
					dmRadToDeg(euler[DM_PITCH]),	\
					dmRadToDeg(euler[DM_YAW]),	\
					dmRadToDeg(euler[DM_ROLL])))

#define dvSwDebugDmQuat_Module(debug_level, module, quat)		\
	duDebug_Module(debug_level, module, ("%.6f %.6f %.6f %.6f\n",	\
			quat[DM_X], quat[DM_Y], quat[DM_Z], quat[DM_W]))

#define dvSwDebugDmMatrix_Module(debug_level, module, matrix)		\
	duDebug_Module(debug_level, module, ("%.6f %.6f %.6f\n",	\
		matrix[DM_X][DM_X],					\
		matrix[DM_X][DM_Y],					\
		matrix[DM_X][DM_Z],					\
		matrix[DM_X][DM_W]));					\
	duDebug_Module(debug_level, module, ("%.6f %.6f %.6f %.6f\n",	\
		matrix[DM_Y][DM_X],					\
		matrix[DM_Y][DM_Y],					\
		matrix[DM_Y][DM_Z],					\
		matrix[DM_Y][DM_W]));					\
	duDebug_Module(debug_level, module, ("%.6f %.6f %.6f %.6f\n",	\
		matrix[DM_Z][DM_X],					\
		matrix[DM_Z][DM_Y],					\
		matrix[DM_Z][DM_Z],					\
		matrix[DM_Z][DM_W]));					\
	duDebug_Module(debug_level, module, ("%.6f %.6f %.6f %.6f\n",	\
		matrix[DM_W][DM_X],					\
		matrix[DM_W][DM_Y],					\
		matrix[DM_W][DM_Z],					\
		matrix[DM_W][DM_W]))

#define dvSwDebugDmSplit_Module(debug_level, module, matrix)		\
    if (duDebug_ModuleGetLevel(module) && debug_level != 0)		\
    {									\
	dvSwDebugDmSplit_ModuleFunc(debug_level, module, matrix);	\
    }
					/* ...else if compiling without debug,
					   the cause the high level debug
					   macros to be omitted. */
#else
#define dvSwDebugDmTriple_Module(debug_level, module, triple)	((void)0)
#define dvSwDebugDmEuler_Module(debug_level, module, euler)	((void)0)
#define dvSwDebugDmQuat_Module(debug_level, module, quat)	((void)0)
#define dvSwDebugDmMatrix_Module(debug_level, module, matrix)	((void)0)
#define dvSwDebugDmSplit_Module(debug_level, module, matrix)	((void)0)

#endif
     /* High level verbose macros*/


#define dvSwVerboseDmTriple_Module(verbose_level, module, triple)	\
	duVerbose_Module(verbose_level, module, ("%.6f %.6f %.6f\n",	\
				triple[DM_X], triple[DM_Y], triple[DM_Z]))



#define dvSwVerboseDmEuler_Module(verbose_level, module, euler)		\
			duVerbose_Module(verbose_level, module,		\
				("%.6f %.6f %.6f\n",			\
					dmRadToDeg(euler[DM_PITCH]),	\
					dmRadToDeg(euler[DM_YAW]),	\
					dmRadToDeg(euler[DM_ROLL])))



#define dvSwVerboseDmQuat_Module(verbose_level, module, quat)		\
	duVerbose_Module(verbose_level, module, ("%.6f %.6f %.6f %.6f\n",\
			quat[DM_X], quat[DM_Y], quat[DM_Z], quat[DM_W]))




#define dvSwVerboseDmMatrix_Module(verbose_level, module, matrix)	\
	duVerbose_Module(verbose_level, module, ("%.6f %.6f %.6f %.6f\n",\
		matrix[DM_X][DM_X],					\
		matrix[DM_X][DM_Y],					\
		matrix[DM_X][DM_Z],					\
		matrix[DM_X][DM_W]));					\
	duVerbose_Module(verbose_level, module, ("%.6f %.6f %.6f %.6f\n",\
		matrix[DM_Y][DM_X],					\
		matrix[DM_Y][DM_Y],					\
		matrix[DM_Y][DM_Z],					\
		matrix[DM_Y][DM_W]));					\
	duVerbose_Module(verbose_level, module, ("%.6f %.6f %.6f %.6f\n",\
		matrix[DM_Z][DM_X],					\
		matrix[DM_Z][DM_Y],					\
		matrix[DM_Z][DM_Z],					\
		matrix[DM_Z][DM_W]));					\
	duVerbose_Module(verbose_level, module, ("%.6f %.6f %.6f %.6f\n",\
		matrix[DM_W][DM_X],					\
		matrix[DM_W][DM_Y],					\
		matrix[DM_W][DM_Z],					\
		matrix[DM_W][DM_W]))


#define dvSwVerboseDmSplit_Module(verbose_level, module, matrix)	\
    if (duVerbose_ModuleGetLevel(module) && verbose_level != 0)		\
    {									\
	dvSwVerboseDmSplit_ModuleFunc(verbose_level, module, matrix);	\
    }


/******************************************************************************
  High level macros for debugging dmd (double precision) types eg. matrices,
  vectors, points, quaternions etc.
******************************************************************************/

					/* If compiling with debug... */
					/* ...then define the high level
					   debugging macros... */
#ifndef NDEBUG
#define dvSwDebugDmdTriple_Module(debug_level, module, triple)		\
	duDebug_Module(debug_level, module, ("%.6f %.6f %.6f\n",	\
				triple[DMD_X], triple[DMD_Y], triple[DMD_Z]))

#define dvSwDebugDmdEuler_Module(debug_level, module, euler)		\
			duDebug_Module(debug_level, module,		\
				("%.6f %.6f %.6f\n",			\
					dmdRadToDeg(euler[DMD_PITCH]),	\
					dmdRadToDeg(euler[DMD_YAW]),	\
					dmdRadToDeg(euler[DMD_ROLL])))

#define dvSwDebugDmdQuat_Module(debug_level, module, quat)		\
	duDebug_Module(debug_level, module, ("%.6f %.6f %.6f %.6f\n",	\
			quat[DMD_X], quat[DMD_Y], quat[DMD_Z], quat[DMD_W]))

#define dvSwDebugDmdMatrix_Module(debug_level, module, matrix)		\
	duDebug_Module(debug_level, module, ("%.6f %.6f %.6f\n",	\
		matrix[DMD_X][DMD_X],					\
		matrix[DMD_X][DMD_Y],					\
		matrix[DMD_X][DMD_Z],					\
		matrix[DMD_X][DMD_W]));					\
	duDebug_Module(debug_level, module, ("%.6f %.6f %.6f %.6f\n",	\
		matrix[DMD_Y][DMD_X],					\
		matrix[DMD_Y][DMD_Y],					\
		matrix[DMD_Y][DMD_Z],					\
		matrix[DMD_Y][DMD_W]));					\
	duDebug_Module(debug_level, module, ("%.6f %.6f %.6f %.6f\n",	\
		matrix[DMD_Z][DMD_X],					\
		matrix[DMD_Z][DMD_Y],					\
		matrix[DMD_Z][DMD_Z],					\
		matrix[DMD_Z][DMD_W]));					\
	duDebug_Module(debug_level, module, ("%.6f %.6f %.6f %.6f\n",	\
		matrix[DMD_W][DMD_X],					\
		matrix[DMD_W][DMD_Y],					\
		matrix[DMD_W][DMD_Z],					\
		matrix[DMD_W][DMD_W]))

#define dvSwDebugDmdSplit_Module(debug_level, module, matrix)		\
    if (duDebug_ModuleGetLevel(module) && debug_level != 0)		\
    {									\
	dvSwDebugDmdSplit_ModuleFunc(debug_level, module, matrix);	\
    }
					/* ...else if compiling without debug,
					   the cause the high level debug
					   macros to be omitted. */
#else
#define dvSwDebugDmdTriple_Module(debug_level, module, triple)	((void)0)
#define dvSwDebugDmdEuler_Module(debug_level, module, euler)	((void)0)
#define dvSwDebugDmdQuat_Module(debug_level, module, quat)	((void)0)
#define dvSwDebugDmdMatrix_Module(debug_level, module, matrix)	((void)0)
#define dvSwDebugDmdSplit_Module(debug_level, module, matrix)	((void)0)
#endif

     /* High level verbose macros*/


#define dvSwVerboseDmdTriple_Module(verbose_level, module, triple)	\
	duVerbose_Module(verbose_level, module, ("%.6f %.6f %.6f\n",	\
				triple[DMD_X], triple[DMD_Y], triple[DMD_Z]))



#define dvSwVerboseDmdEuler_Module(verbose_level, module, euler)	\
			duVerbose_Module(verbose_level, module,		\
				("%.6f %.6f %.6f\n",			\
					dmdRadToDeg(euler[DMD_PITCH]),	\
					dmdRadToDeg(euler[DMD_YAW]),	\
					dmdRadToDeg(euler[DMD_ROLL])))



#define dvSwVerboseDmdQuat_Module(verbose_level, module, quat)		\
	duVerbose_Module(verbose_level, module, ("%.6f %.6f %.6f %.6f\n",\
			quat[DMD_X], quat[DMD_Y], quat[DMD_Z], quat[DMD_W]))




#define dvSwVerboseDmdMatrix_Module(verbose_level, module, matrix)	\
	duVerbose_Module(verbose_level, module, ("%.6f %.6f %.6f %.6f\n",\
		matrix[DMD_X][DMD_X],					\
		matrix[DMD_X][DMD_Y],					\
		matrix[DMD_X][DMD_Z],					\
		matrix[DMD_X][DMD_W]));					\
	duVerbose_Module(verbose_level, module, ("%.6f %.6f %.6f %.6f\n",\
		matrix[DMD_Y][DMD_X],					\
		matrix[DMD_Y][DMD_Y],					\
		matrix[DMD_Y][DMD_Z],					\
		matrix[DMD_Y][DMD_W]));					\
	duVerbose_Module(verbose_level, module, ("%.6f %.6f %.6f %.6f\n",\
		matrix[DMD_Z][DMD_X],					\
		matrix[DMD_Z][DMD_Y],					\
		matrix[DMD_Z][DMD_Z],					\
		matrix[DMD_Z][DMD_W]));					\
	duVerbose_Module(verbose_level, module, ("%.6f %.6f %.6f %.6f\n",\
		matrix[DMD_W][DMD_X],					\
		matrix[DMD_W][DMD_Y],					\
		matrix[DMD_W][DMD_Z],					\
		matrix[DMD_W][DMD_W]))


#define dvSwVerboseDmdSplit_Module(verbose_level, module, matrix)	\
    if (duVerbose_ModuleGetLevel(module) && verbose_level != 0)		\
    {									\
	dvSwVerboseDmdSplit_ModuleFunc(verbose_level, module, matrix);	\
    }


/******************************************************************************
	Global variables used by the inverse kinematic functions.
******************************************************************************/

					/* Handles on the inverse kinematics
					   module to help du decide if
					   verbose/debug output has been
					   selected on the command line for
					   this module. */

extern	unsigned int	dvSwVerboseModuleHandle;
extern	unsigned int	dvSwDebugModuleHandle;

/*****************************************************************************/
#endif // define _DEBUG_HH
