/****************************************************************************
 *
 *  			Copyright 1995 Division Limited.
 *			      All Rights Reserved
 *
 *
 *  System        : 
 *  Module        : 
 *  Object Name   : $RCSfile: dvconver.h,v $
 *  Revision      : $Revision: 1.3 $
 *  Date          : $Date: 1999/06/23 12:50:05 $
 *  Author        : $Author: bill $
 *  Last Modified : <990617.1513>
 *
 *  Description	
 *
 *  Notes
 *
 *  History
 *	
 ****************************************************************************
 *
 *  Copyright (c) 1995 Division Ltd.
 * 
 *  All Rights Reserved.
 * 
 *  This Document may not, in whole or in part, be copied,
 *  photocopied, reproduced, translated, or reduced to any
 *  electronic medium or machine readable form without prior
 *  written consent from Division Ltd.
 ****************************************************************************/

#ifndef __DVCONVER_H__
#define __DVCONVER_H__

#ifndef DVCON_EXPORT
#if defined(_WIN32) && !defined(_WINDU_SOURCE) && !defined(__EPP__) && !defined(BUILD_STATIC)
/* only  Windoze needs this baroque construct.
 * On sensible systems simply use `extern'
 */
#if defined _LIB_DIVU
#define DVCON_EXPORT __declspec(dllexport) extern 
#else
#define DVCON_EXPORT __declspec(dllimport) extern 
#endif 
#else
#define DVCON_EXPORT extern
#endif
#endif

#include <dsys/divtypes.h>
#include <dsys/buildno.h>

#ifdef __cplusplus
extern "C" {
#endif

DVCON_EXPORT void
dvconVersionPrint(char *name, char *version, int32 initYear) ;

#ifdef dvconDEPEND_DVF
#define __dvfVersion(fp) dvfVersion(fp)
#else
#define __dvfVersion(fp)
#endif

#ifdef dvconDEPEND_DGL
#define __dglVersion(fp) dglVersion(fp)
#else
#define __dglVersion(fp)
#endif

#ifdef dvconDEPEND_DNRB
#define __dnrbVersion(fp) dnrbVersion(fp)
#else
#define __dnrbVersion(fp)
#endif

#ifdef dvconDEPEND_DRCP
#define __drcpVersion(fp) drcpVersion(fp)
#else
#define __drcpVersion(fp)
#endif

#ifdef dvconDEPEND_DO
#define __doVersion(fp) doVersion(fp)
#else
#define __doVersion(fp)
#endif

#ifdef dvconDEPEND_DMAP
#define __dmapVersion(fp) dmapVersion(fp)
#else
#define __dmapVersion(fp)
#endif

#ifdef dvconDEPEND_DPT
#define __dptVersion(fp) dptVersion(fp)
#else
#define __dptVersion(fp)
#endif

#ifdef dvconDEPEND_DPI
#define __dpiVersion(fp) dpiVersion(fp)
#else
#define __dpiVersion(fp)
#endif

#ifdef dvconDEPEND_DPF
#define __dpfVersion(fp) dpfVersion(fp)
#else
#define __dpfVersion(fp)
#endif

#define dvconIdentity(name,version,initYear)                                 \
do {                                                                         \
    dvconVersionPrint(name,version,initYear) ;                               \
    fprintf(stdout,"Division dVS. %s. Version %s%s. %s\n",                   \
            name,BUILD_VERSION_NO,version,__DATE__) ;                        \
    __dvfVersion(NULL) ;                                                     \
    __drcpVersion(NULL) ;                                                    \
    __dglVersion(NULL) ;                                                     \
    __dnrbVersion(NULL) ;                                                    \
    __dmapVersion(NULL) ;                                                    \
    __dptVersion(NULL) ;                                                     \
    __dpiVersion(NULL) ;                                                     \
    __dpfVersion(NULL) ;                                                     \
    exit(0) ;                                                                \
} while(0)
              
#ifdef __cplusplus
}
#endif
              

#endif /* __DVSTOOL_H__ */
