/******************************************************************************/
/*									      */
/*	######    ###   #     #   ###    #####    ###   ####### #     #	      */
/*	#     #    #    #     #    #    #     #    #    #     # ##    #	      */
/*	#     #    #    #     #    #    #          #    #     # # #   #	      */
/*	#     #    #    #     #    #     #####     #    #     # #  #  #	      */
/*	#     #    #     #   #     #          #    #    #     # #   # #	      */
/*	#     #    #      # #      #    #     #    #    #     # #    ##	      */
/*	######    ###      #      ###    #####    ###   ####### #     #	      */
/*									      */
/*			   #     #####   #####   #####			      */
/*			  ##    #     # #     # #     #			      */
/*			 # #    #     # #     # #			      */
/*			   #     ######  ###### ######			      */
/*			   #          #       # #     #			      */
/*			   #    #     # #     # #     #			      */
/*			 #####   #####   #####   #####			      */
/*									      */
/* 		Copyright (c) Division Limited. All rights reserved	      */
/*									      */
/* This Document may not, in whole or in part, be copied, photocopied,	      */
/* reproduced, translated, or reduced to any electronic medium or machine     */
/* readable form without prior written consent from Division Ltd.	      */
/*									      */
/******************************************************************************/

#if !defined _INPDEV_H_
#define _INPDEV_H_


#if defined __cplusplus
extern "C" {
#endif 


#if defined _WIN32 && !defined(_WINDU_SOURCE) && !defined __EPP__ && !defined(BUILD_STATIC)
/*
 * only  Windoze needs this baroque construct.
 * On sensible systems simply use `extern'
 */
#if defined _LIB_DIVU
#define INPDEV_EXPORT __declspec(dllexport) extern
#else
#define INPDEV_EXPORT __declspec(dllimport) extern
#endif /* _LIB_DIVU */
#else
#define INPDEV_EXPORT extern
#endif /* WIN32 */


/******************************************************************************/
/*									      */
/*	Include files.							      */
/*									      */
/******************************************************************************/
#include <dsys/dm.h>
#include <dsys/dp.h>
#include <dsys/du.h>
#include <dsys/dfile.h>
#include <dsys/dload.h>

/******************************************************************************/
/*									      */
/*	Defines etc.							      */
/*									      */
/******************************************************************************/

/* Device Driver String for input */
#define VCINPUT_DRIVER_STRING "Input Device Driver"

/* Generic device driver verbose numbers */
#define VCINPUT_VERBOSE_ALLOC		0x00001
#define VCINPUT_VERBOSE_OPEN		0x00002
#define VCINPUT_VERBOSE_SERVICE		0x00004
#define VCINPUT_VERBOSE_READ		0x00008
#define VCINPUT_VERBOSE_POSITIONS	0x00010
#define VCINPUT_VERBOSE_BUTTONS		0x00020
#define VCINPUT_VERBOSE_CONFIG		0x00040
#define VCINPUT_VERBOSE_VC		0x00080
#define VCINPUT_VERBOSE_DEVICE		0x00100
#define VCINPUT_VERBOSE_ENABLE		0x00200
#define VCINPUT_VERBOSE_PAIRS		0x00400
#define VCINPUT_VERBOSE_PARSE		0x00800
#define VCINPUT_VERBOSE_PRINT		0x01000
#define VCINPUT_VERBOSE_RESET		0x02000
#define VCINPUT_VERBOSE_SAMPLE		0x04000
#define VCINPUT_VERBOSE_VC_DATA		0x08000
#define VCINPUT_VERBOSE_FILTER		0x10000

/* Buffer sizes */
#define VCINPUT_KEY_BUFFER_SIZE		32
#define VCINPUT_DEVNAME_SIZE		256
#define VCINPUT_SLNAME_SIZE		256
#define VCINPUT_OPTION_SIZE		256
#define VCINPUT_COMPARE_SIZE            256
#define VCINPUT_HASHKEY_SIZE		1024

#define VCINPUT_ST_SIZE			10

/* Function Binding Codes */
/* 0 to 15 are reserved for internal functions */
/* 16 to 31 are reserved for user defined uses */
#define VCINPUT_FUNC_CODE_NONE			0
#define VCINPUT_FUNC_CODE_RESET_POS		(1 << 0)
#define VCINPUT_FUNC_CODE_DEC_SENS		(1 << 1)
#define VCINPUT_FUNC_CODE_INC_SENS		(1 << 2)
#define VCINPUT_FUNC_CODE_RESET_SENS		(1 << 3)
#define VCINPUT_FUNC_CODE_TOGGLE_TRANS		(1 << 4)
#define VCINPUT_FUNC_CODE_TOGGLE_ROTS		(1 << 5)
#define VCINPUT_FUNC_CODE_TOGGLE_DOM		(1 << 6)
#define VCINPUT_FUNC_CODE_REZERO		(1 << 7)

#define VCINPUT_FUNC_CODE_MIN			0
#define VCINPUT_FUNC_CODE_MAX			31
#define VCINPUT_FUNC_DO_ALL			0xFFFFFFFF

/* Licensing services */
#define VCINPUT_LIC_NONE			0
#define VCINPUT_LIC_IMMERSIVE			(1 << 0)

/* Structure sizes */
#define VCINPUT_TIME_SIZE	(sizeof(VCINPUT_TIME))
#define VCINPUT_PRE_FILTER_SIZE (sizeof(VCINPUT_PRE_FILTER))
#define VCINPUT_FILTER_SIZE	(sizeof(VCINPUT_FILTER))
#define VCINPUT_SENSOR_SIZE	(sizeof(VCINPUT_SENSOR))
#define VCINPUT_VKB_SIZE	(sizeof(VCINPUT_VKB))
#define VCINPUT_CONTROL_SIZE	(sizeof(VCINPUT_CONTROL))
#define VCINPUT_DEVICE_SIZE	(sizeof(VCINPUT_DEVICE))

/* Filter function names */
#define VCINPUT_FILTER_TYPE_FUNC_NAME	"vcinputFilterTypeFunction"
#define VCINPUT_FILTER_TYPE_NAME	"INPUT FILTER FUNCTION"
#define VCINPUT_FILTER_ALLOC_FUNC_NAME	"vcinputFilterAllocFunction"
#define VCINPUT_FILTER_FUNC_NAME	"vcinputFilterFunction"

/* Call back types */
#define VCINPUT_CALLBACK_TYPE_NONE	0
#define VCINPUT_CALLBACK_TYPE_XWIN	1

#define VCINPUT_TEST_DOMAIN		"TESTINPUT"

#if defined _WINDOWS
#define VCINPUT_SYSTEM_PATH		"etc/input;system/input"
#else
#define VCINPUT_SYSTEM_PATH		"etc/input:system/input"
#endif

/******************************************************************************/
/*									      */
/*	Typedefs and structures etc.					      */
/*									      */
/******************************************************************************/
/* Structure pointer types need to be defined here */
typedef struct VCINPUT_FILTER      VCINPUT_FILTER,	* VCINPUT_FILTER_PTR;
typedef struct VCINPUT_PRE_FILTER  VCINPUT_PRE_FILTER,  * VCINPUT_PRE_FILTER_PTR;
typedef struct VCINPUT_TIME        VCINPUT_TIME,	* VCINPUT_TIME_PTR;
typedef struct VCINPUT_SENSOR      VCINPUT_SENSOR,      * VCINPUT_SENSOR_PTR;
typedef struct VCINPUT_VKB         VCINPUT_VKB,         * VCINPUT_VKB_PTR;
typedef struct VCINPUT_FUNCTIONS   VCINPUT_FUNCTIONS,   * VCINPUT_FUNCTIONS_PTR;
typedef struct VCINPUT_CONTROL	   VCINPUT_CONTROL,	* VCINPUT_CONTROL_PTR;
typedef struct VCINPUT_DEVICE      VCINPUT_DEVICE,      * VCINPUT_DEVICE_PTR;
typedef struct VCINPUT_DEVICE_LIST VCINPUT_DEVICE_LIST, * VCINPUT_DEVICE_LIST_PTR;

/* Function pointer types */
typedef char * (*VCINPUT_STRING_FUNC)	(void);
typedef int    (*VCINPUT_DEV_FUNC)	(VCINPUT_DEVICE_PTR device);
typedef void   (*VCINPUT_TIME_FUNC)	(dpVtime *          thisTime);
typedef int    (*VCINPUT_X_FUNC)	(VCINPUT_DEVICE_PTR device, uint32 windowId, char * serverName, char * actorName);
typedef int    (*VCINPUT_FILTER_FUNC)	(VCINPUT_SENSOR_PTR sensor, void * data);

/* Filters can be applied to a sensor */
struct VCINPUT_FILTER
{
  void * data;					/* Data that enables the filter to execute */
  DLOAD_HANDLE		dloadHandle;		/* dload handle for functions etc. */
  VCINPUT_FILTER_FUNC	filterFunc;		/* Function that implements the filter */
  VCINPUT_FILTER_PTR	next;			/* Next filter in chain to execute - NULL if EOL */

  char			filterLabel [VCINPUT_DEVNAME_SIZE];	/* Helps with debugging etc. */
};

/* Pre filters that can be applied to a sensor */
struct VCINPUT_PRE_FILTER
{
  dmPoint posScale;
  dmEuler angScale;
  dmPoint posOffset;
  dmEuler angOffset;
};

/* A timings structure that hangs off a device. */

struct VCINPUT_TIME
{
  dpVtime  times [VCINPUT_ST_SIZE];		/* Last n sample times */
  float    sampleHz;					/* Sample rate of last n samples */
  float    accHz;				/* Accumulated Hz sample rate */
  unsigned int count;
};

/* A sensor contains the positional information */
struct VCINPUT_SENSOR
{
  dmMatrix position;				/* position and orientation */
  int      sensorEnabled;			/* Is this sensor enabled? */
  int      sensorPresent;			/* Is this sensor present? */
  int      newPosition;				/* Is there a new position to report? */
  int      mapped;				/* Has this position been mapped? */
  int      relative;				/* Is this device reporting relative positions? */
  int      threeD;				/* 3D or 2D positions to be pushed out? */
  char     resourceName [VCINPUT_DEVNAME_SIZE];	/* The name of the sensor in the registry */

  dmMatrix lockMin;				/* Minimum constraints */
  dmMatrix lockMax;				/* Maximum constraints */
  dmMatrix prePos;				/* Pre position mapping */
  dmMatrix postPos;				/* Post position mapping */
  int      lockMinValid;			/* Is the lockMin matrix valid */
  int      lockMaxValid;			/* Is the lockMax matrix valid */
  int      prePosValid;				/* Is the pre position matrix valid */
  int      postPosValid;			/* Is the post position matrix valid */

  VCINPUT_PRE_FILTER preFilter;			/* Pre filtering positions */
  VCINPUT_FILTER_PTR filterList;		/* List of filters to execute */
};

/* A virtual keyboard contains the key presses */
struct VCINPUT_VKB
{
  uint32 keyboardBuffer [VCINPUT_KEY_BUFFER_SIZE];		/* A keyboard buffer */
  int	 keyboardEnabled;					/* Is this VKB enabled? */
  int    keyboardPresent;					/* Is this keyboard present? */
  int    keysInBuffer;						/* The number of keys in the VKB buffer */
  int    newKeys;						/* If there are new keys waiting? */
  char   resourceName [VCINPUT_DEVNAME_SIZE];        		/* The name of the VKB in the registry */

  duHashTab * mappings;						/* Pointer to keyboard mappings */
  duHashTab * bindings;						/* Pointer to keyboard bindings */
};

/* The functions table contains the pointers of the functions that */
/* need to be called for the device to operate */
struct VCINPUT_FUNCTIONS
{
  VCINPUT_DEV_FUNC  open;		/* Open the device */
  VCINPUT_DEV_FUNC  close;		/* Close the device */
  VCINPUT_DEV_FUNC  service;		/* Service routine for things that need doing all the time */
  VCINPUT_DEV_FUNC  read;		/* Read the device */
  VCINPUT_DEV_FUNC  release;		/* Release resources for the device */
  VCINPUT_TIME_FUNC timeFunction;	/* Time function */

};

struct VCINPUT_CONTROL
{
  uint32		functionBits;			/* Function bindings to call */

  float			tSens;				/* Translational sensitivity */
  float                 rSens;				/* Rotational sensitivity */
  float			tStartSens;			/* Start Translational Sensitivity */
  float			rStartSens;			/* Start Rotational sensitivity */
  float			tUpFactor;			/* Translational Multiply up factor */
  float			tDnFactor;			/* Translational Multiply down factor */
  float			rUpFactor;			/* Rotational Multiply up factor */
  float			rDnFactor;			/* Rotational Multiply down factor */
  float			tUpLimit;			/* Translational upper sens limit */
  float			tDnLimit;			/* Translational lower sens limit */
  float			rUpLimit;			/* Rotational upper sens limit */
  float			rDnLimit;			/* Rotational lower sens limit */

  int                   giveTrans;			/* Show translations */
  int			giveRots;			/* Show rotations */
  int			dominantMode;			/* Where we only give dominant movements */
  float                 domFactor;			/* Factor used in comparing trans to rots */
};

/* Sensors and virtual keyboards are found in each device */
struct VCINPUT_DEVICE
{
  int			numSensors;			/* Sensors available. NOT the maximum possible */
  int			numVKB;				/* Number of keyboards available. NOT the max */
  int                   baudRate;			/* Baud rate if appropriate */
  VCINPUT_SENSOR_PTR	sensors;			/* Pointer to an array of sensors */
  VCINPUT_VKB_PTR	VKB;				/* Pointer to an array of virtual keyboards */
  VCINPUT_FUNCTIONS	functions;			/* Table of function pointers */
  void *		deviceState;			/* Device specific state */
  DLOAD_HANDLE		dloadHandle;			/* dload handle for functions etc. */
  char			addrName [VCINPUT_DEVNAME_SIZE];/* The name of the device we are accessing */
  char			slName [VCINPUT_SLNAME_SIZE];	/* The name of the device SL we are accessing */
  char			options [VCINPUT_OPTION_SIZE];	/* Device specific options */
  int			ready;				/* Device ready for action? */
  unsigned int		samples;			/* Times we've sampled on this device */
  unsigned int		sampleSensor;			/* Times we've sampled sensors OK */
  unsigned int		sampleKeyboard;			/* Times we've sampled keyboards OK */
  unsigned int          gotSensorSample;		/* Got a Sensor Sample */
  unsigned int          gotVKBSample;			/* Got a VKB Sample */

  unsigned int		licReqd;			/* License services reqd */

  VCINPUT_TIME	time;					/* Time and sample data */

  int                   callbackType;			/* The type of callback */
  void                * callbackFunction;		/* The callback function */
  void                * callbackHandle;			/* Callback handle for VC */

  VCINPUT_CONTROL       control;			/* Function control etc. */
};

struct VCINPUT_DEVICE_LIST
{
  int numDevices;
  VCINPUT_DEVICE_PTR deviceList;	/* Array of device pointers */

};

/******************************************************************************/
/*									      */
/*	Function Prototypes						      */
/*									      */
/******************************************************************************/

/* Initialise the function pointers for a device with the given pointers */
INPDEV_EXPORT void inpdev_funcInit (VCINPUT_DEVICE_PTR device,
                             VCINPUT_DEV_FUNC          open,
                             VCINPUT_DEV_FUNC          close,
			     VCINPUT_DEV_FUNC          service,
 	                     VCINPUT_DEV_FUNC          read,
 	                     VCINPUT_DEV_FUNC          release,
			     VCINPUT_TIME_FUNC         timeFunction);

/* Allocate the necessary resources and attach to a given device */
INPDEV_EXPORT int inpdev_allocResources (VCINPUT_DEVICE_PTR device, int numSensors, int numVKB, int deviceStateSize);

/* Free off any resources attached to a device */
INPDEV_EXPORT void inpdev_freeResources (VCINPUT_DEVICE_PTR device);

/* Reset device state at start of open! */
INPDEV_EXPORT void inpdev_newOpen (VCINPUT_DEVICE_PTR device);

/* Update the sample stats for a device on completion of sampling */
INPDEV_EXPORT void inpdev_sampleComplete (VCINPUT_DEVICE_PTR device);

/* Mark all sensors as relative or absolute */
INPDEV_EXPORT void inpdev_sensorsAbsolute (VCINPUT_DEVICE_PTR device);
INPDEV_EXPORT void inpdev_sensorsRelative (VCINPUT_DEVICE_PTR device);

/* Does the device push out 2D or 3D type positions? */
INPDEV_EXPORT void inpdev_sensors2D (VCINPUT_DEVICE_PTR device);
INPDEV_EXPORT void inpdev_sensors3D (VCINPUT_DEVICE_PTR device);

/* Mark a device ready or not  */
INPDEV_EXPORT void inpdev_deviceReady (VCINPUT_DEVICE_PTR device);
INPDEV_EXPORT void inpdev_deviceNotReady (VCINPUT_DEVICE_PTR device);

/* Sensor and VKB present functions */
INPDEV_EXPORT void inpdev_sensorPresent (VCINPUT_DEVICE_PTR device, int numSensor);
INPDEV_EXPORT void inpdev_vkbPresent (VCINPUT_DEVICE_PTR device, int numVKB);
INPDEV_EXPORT void inpdev_allSensorsPresent (VCINPUT_DEVICE_PTR device);
INPDEV_EXPORT void inpdev_allKeyboardsPresent (VCINPUT_DEVICE_PTR device);

/* Add a key to a VKBs buffer */
INPDEV_EXPORT int inpdev_addKey (VCINPUT_DEVICE_PTR device, int numVKB, uint32 key);

/* Set a new position to a sensor */
INPDEV_EXPORT int inpdev_setNewPosition (VCINPUT_DEVICE_PTR device, int numSensor, dmMatrix matrix);

/* Set state at start of read */
INPDEV_EXPORT void inpdev_newRead (VCINPUT_DEVICE_PTR device);

/* Are any sensors/VKBs enabled */
INPDEV_EXPORT int inpdev_anySensorEnabled (VCINPUT_DEVICE_PTR device);
INPDEV_EXPORT int inpdev_anyVKBEnabled    (VCINPUT_DEVICE_PTR device);

/* Return values from option strings */
INPDEV_EXPORT int inpdev_intFromOptions    (char * options, char * token, int * value);
INPDEV_EXPORT int inpdev_floatFromOptions  (char * options, char * token, float * value);
INPDEV_EXPORT int inpdev_stringFromOptions (char * options, char * token, char ** start, char ** end);

/* Open Callbacks */
INPDEV_EXPORT void inpdev_addXOpenCallback (VCINPUT_DEVICE_PTR device, VCINPUT_X_FUNC function);

/* Run from an actor or testinput */
INPDEV_EXPORT void   inpdev_setDomainTestMode (char * domain);
INPDEV_EXPORT int    inpdev_isTest (void);
INPDEV_EXPORT char * inpdev_domainExtName (void);

/* Build an addr name from local/x etc. etc. */
INPDEV_EXPORT int inpdev_realAddrName (char * s, size_t nob);

/* Position/Angle manipulations */
INPDEV_EXPORT int  inpdev_getSensorPreFilter   (VCINPUT_DEVICE_PTR device, int sensorNum, VCINPUT_PRE_FILTER_PTR * filterPtr);
INPDEV_EXPORT void inpdev_applySensorPreFilter (dmPoint thisPoint, dmEuler thisEuler, VCINPUT_PRE_FILTER_PTR filter);

/* Macros */
#define INPDEV_SENSOR_ENABLED(a,b)	(a->sensors[b].sensorEnabled)
#define INPDEV_VKB_ENABLED(a,b)		(a->VKB[b].keyboardEnabled)
#define INPDEV_NUM_SENSORS(a)		(a->numSensors)
#define INPDEV_NUM_VKB(a)		(a->numVKB)

/* Key mapping stuff */
INPDEV_EXPORT int inpdev_addMapping		(VCINPUT_VKB_PTR vkb, uint32 keyFrom, uint32 keyTo);
INPDEV_EXPORT int inpdev_addBinding		(VCINPUT_VKB_PTR vkb, uint32 key, uint32 functionCode);
INPDEV_EXPORT int inpdev_addFilter		(VCINPUT_SENSOR_PTR sp, char * filterPath, char * filterParms, char * filterLabel);
INPDEV_EXPORT uint32 inpdev_mapKey		(VCINPUT_VKB_PTR vkb, uint32 inKey);
INPDEV_EXPORT uint32 inpdev_functionCode	(VCINPUT_VKB_PTR vkb, uint32 inKey);

/* Finding input system files */
INPDEV_EXPORT int  inpdev_findSystemFile (char * filename, char * fullPath, int maxPathSize);

/* Function bindings */
#define INPDEV_CLR_FUNC_BITS(d)		(d->control.functionBits = 0)
#define INPDEV_FUNC_BITS_SET(d)		(d->control.functionBits)
#define INPDEV_SET_FUNC_BIT(d,f)	(d->control.functionBits |= f)
#define INPDEV_FUNC_BIT_SET(d,f)	(d->control.functionBits & f)
#define INPDEV_CLR_FUNC_BIT(d,f)	(d->control.functionBits &= ~f)

INPDEV_EXPORT void inpdev_processGenericFunctions (VCINPUT_DEVICE_PTR device, uint32 doThese);
INPDEV_EXPORT void inpdev_resetAllPositions (VCINPUT_DEVICE_PTR device);
INPDEV_EXPORT void inpdev_applyDominant (dmPoint thisPosition, dmEuler thisEuler, float factor);

#if defined __cplusplus
}
#endif /* __cplusplus */
#endif /* INPDEV_H */
