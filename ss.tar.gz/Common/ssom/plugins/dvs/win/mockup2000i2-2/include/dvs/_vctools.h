#ifndef __VCTOOLS_H
#define __VCTOOLS_H

/*
 *      PROJECT:
 *      SUBSYSTEM:
 *      MODULE:
 *
 *      FILE:           $RCSfile: _vctools.h,v $
 *      REVISION:       $Revision: 1.13 $
 *      Date:           $Date: 1999/01/25 15:52:01 $
 *      Author:         $Author: jeff $
 *      RCS Ident:      $Id: _vctools.h,v 1.13 1999/01/25 15:52:01 jeff Exp $
 *
 *      FUNCTION:
 *
 * Copyright (c) 1994 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */

int	 _VCModulesInit(void);
int	 _VCCollisionInit(void);
int	 _VCVisual_Init(void);

void	 _VCDropObject(VCAttribute *attribute, _VCBodyPickInfo *pickInfo, uint32 mode);
void	 _VCObjectPositionUpdateHandler (VLInstanceEvent *instData, void *data);
void	 _VCObjectVCPositionUpdateHandler (VLInstanceEvent *instData, void *data);
int 	 _VCObjectInit (void);
int	 _VCAttribute_AttachQueryFunc(ElementHandle element, VCCallback_QueryFunc func);
void	 _VCAttributeCallbackHandler (VLInstanceEvent *instData, void *data);

void	 _VCBodyAttributeHandler(VLInstanceEvent *instData, void *data);
void	 _VCBodyInputHandler(VCInput_UpdateCallbackData *callbackData, void *data);
void	 _VCBodyCollisionHandler(VCCollision_CallbackData *callbackData, void *data);
void	 _VCBodyScreenIntersectionHandler(VCIntersection_CallbackData *callbackData, void *data);
void	 _VCExitHandler(void);
void 	*_VCList_AllocateCallback(VC_CallbackFunc function, void *data, void *systemData);
void   	*_VCList_AttachCallbackInfo(VCCallbackFunctions **functionList,VCCallbackFunctions *callbackInfo);
void   	*_VCList_AttachCallback(VCCallbackFunctions **functionList,VC_CallbackFunc function, void *data, void *systemData);
int	 _VCList_ProcessCallbacks(VCCallbackFunctions **functionList, void *callbackData,
                                  VCCallback_QueryFunc func, void *data);
int	 _VCList_DetachCallback(VCCallbackFunctions **functionList, void *callbackHandle,
                                void **systemData);
int	 _VCList_DetachAllCallbacks (VCCallbackFunctions **functionList);

void   _VCList_MoveCallbacks(VCCallbackFunctions **functionList, VCCallbackFunctions **newFunctionList);


int	 	 _VCParseCommandLine ( int *argc, char **argv, VCCommandLineOptions *options, int actor,
                                      VC_VersionFunc versionFunc);
int		 _VC_initVl(VCCommandLineOptions *options);
void		 _VC_initVcVerbose(VCCommandLineOptions *options);
VCBody  	*_VC_GetBodyFromActorId(uint32 actorId);
_VCBodyPartList *_VCGetBodyPartListFromBodyPart (VCBody *body, VCAttribute *bodyPart);
int		 _VCEntity_GetFirstAttributeIndex (VCEntity *entity, ElementHandle elem);
int		 _VCEntity_GetNextAttributeIndex (VCEntity *entity, ElementHandle elem, int index);
VCCollision 	*_VC_GetCollision (InstanceNo collisionInst);
VCTracker	*_VC_GetTracker(InstanceNo ino);
/* VCInput		*_VC_GetInput(InstanceNo ino); */
VCPosition	*_VC_GetPosition(InstanceNo ino);
VCIntersection	*_VC_GetIntersection(InstanceNo ino);
VCVisualViewResource *_VC_GetVisualView (InstanceNo inst);
VCVisualSourceResource *_VC_GetVisualSource(InstanceNo inst);
VCSync *_VC_GetSync (InstanceNo inst);
VCLod 		*_VCLod_Alloc(InstanceNo ino, char *name, uint32 status);
VCGeogroup 	*_VCGeogroup_Alloc(InstanceNo ino, uint32 status);
VCGeometry 	*_VCGeometry_Alloc(InstanceNo ino, uint32 status);

VC_EXPORT VCLod		*_VC_GetLod(InstanceNo ino);
VC_EXPORT VCGeogroup	*_VC_GetGeogroup(InstanceNo ino);
VC_EXPORT VCGeometry	*_VC_GetGeometry(InstanceNo ino);
VC_EXPORT int 		 VC_Get_VertexSize(VCVertex_Type format);



_VCObjectFunctions	*_VC_GetAttributeCallbackFuncs(ElementHandle element, InstanceNo inst, int *offset);
void			 _VC_AttachAttributeInterestToEntity(VCEntity *entity, uint32 mode,
                                                             _VCObjectFunctions *functions,
                                                             int attributeOffset);
int			 _VC_AttachCallbackElement(ElementHandle element, _VCAttributeCallbackList *callbackList);
int			 _VC_FindCallbackElement(ElementHandle element, _VCAttributeCallbackList *callbackList);
VCAttribute 		*VC_GetAttribute (InstanceNo inst);
void			 _VC_HandleAttributeChange(VCEntity *entity);
int32			 _VCAttributeFree (VCAttribute *attribute);

extern void		 _VC_MergeBoundBox(VCGeometry_BoundBox *thisBox, VCGeometry_BoundBox *thatBox);
extern void		 _VC_SetBoundBoxCenter(VCGeometry_BoundBox *thisBox);
VCDynamicVisual 	*_VC_GetDynamicVisual (InstanceNo inst);
int			 _VCCallbackModeQueryFunc(void *callbackSystemData, void *systemData, void *callbackData);
VCEntity 		*vcGetEntity(InstanceNo inst);


extern uint32	 _VCAttributeCacheMode;
extern uint32	 _VCId;
extern uint32	 _VCBodyPickId;
/* Hoppy, 12/07/98 */
extern uint32	 _VCBodySelectId;
VC_EXPORT int	 _VCDoneWaitEvent;
extern int	 _vcObjectRelocateMode;
extern int	 _VCReportAllEntities;
extern int 	 _VCApplication ; /* This is set to one when we call VCApplication init and left at 0
                                    * if we call VCActorInit
                                    */
extern int		 _VCInitialised;
extern duHashTab	*_VCAttributeHashTable;
extern _VCAttributeCallbackList	 _VCAttributeCallbacks;
extern VCCallbackFunctions	*_vcBodyInputFuncList;
extern VCCallbackFunctions	*_vcBodyCollisionFuncList;
extern VCCallbackFunctions	*_vcBodyScreenIntersectFuncList;
extern VCCallbackFunctions 	*_vcBodyAttributeFuncList;
extern char		       **_vcBodyNameList;
extern int	 		 _vcBodyNameListSize;
extern int	 		 _vcBodyInitialised;


/*
 * Binary geometry and material file reading/writing functions
 *
 */

extern int _vcBgfWriteInt8(_vcBgfFile *fl, int8 i);
extern int _vcBgfWriteUint8(_vcBgfFile *fl, uint8 i);
extern int _vcBgfWriteInt16(_vcBgfFile *fl, int16 i);
extern int _vcBgfWriteUint16(_vcBgfFile *fl, uint16 i);
extern int _vcBgfWriteInt32(_vcBgfFile *fl, int32 i);
extern int _vcBgfWriteFloat32(_vcBgfFile *fl, float32 f);
extern int _vcBgfWriteFloat64(_vcBgfFile *fl, float64 f);
extern int _vcBgfWriteStr(_vcBgfFile *fl, void *source, int32 size);
extern int _vcBgfWriteBlock(_vcBgfFile *fl, void *source, int32 size);
extern int _vcBgfWriteFloat32Block(_vcBgfFile *fl, float32 *source, int32 size);
extern int _vcBgfWriteInt32Block(_vcBgfFile *fl, int32 *source, int32 size);

extern void _vcBgfFillReadBuffer(_vcBgfFile *bf);
extern int32 _vcBgfSkipBytes(_vcBgfFile *bf, uint32 len);
extern int32 _vcBgfSetPos(_vcBgfFile *bf, uint32 pos);
extern int8 _vcBgfReadInt8(_vcBgfFile *bf);
extern int16 _vcBgfReadInt16(_vcBgfFile *bf);
extern float32 _vcBgfReadFloat32(_vcBgfFile *bf);
extern int32 _vcBgfReadInt32(_vcBgfFile *bf);
extern int32 _vcBgfReadInt32Block(_vcBgfFile *bf, int32 *buf, uint32 n);
extern int32 _vcBgfReadString(_vcBgfFile *bf, char8 *s, uint32 n);
extern int32 _vcBgfReadName(_vcBgfFile *bf, char8 **name, int32 *name_len, int32 len);
extern _vcBgfFile *_vcBgfOpenFile(char8 *file, int mode, uint32 buffer_size,
                                  char8 *buffer, int32 endian);
extern void _vcBgfCloseFile(_vcBgfFile *bf);
extern int32 _vcBgfPos(_vcBgfFile *bf);
extern void _vcBgfSeek(_vcBgfFile *bf, int32 offset);


void VCVisualBoundingBox_SetCacheMode(VCVisualBoundingBox *item, uint32 newCacheMode);
uint32 VCVisualBoundingBox_GetCacheMode(VCVisualBoundingBox *item);
VCVisualBoundingBox *_VC_GetVisualBoundingBox (InstanceNo inst);
void *VCVisualBoundingBox_AttachCreateCallback(VCVisualBoundingBox *item, VCVisualBoundingBox_Func func, void *data);
void *VCVisualBoundingBox_AttachUpdateCallback(VCVisualBoundingBox *item, VCVisualBoundingBox_Func func, void *data);
void *VCVisualBoundingBox_AttachDeleteCallback(VCVisualBoundingBox *item, VCVisualBoundingBox_Func func, void *data);
int VCVisualBoundingBox_DetachCreateCallback(VCVisualBoundingBox *item, void *callbackHandle);
int VCVisualBoundingBox_DetachUpdateCallback(VCVisualBoundingBox *item, void *callbackHandle);
int VCVisualBoundingBox_DetachDeleteCallback(VCVisualBoundingBox *item, void *callbackHandle);
VCVisualBoundingBox *VCVisualBoundingBox_CreateData(VCVisualBoundingBoxData *bboxData);
int VCVisualBoundingBox_GetData(VCVisualBoundingBox *item, VCVisualBoundingBoxData *boundingBoxData);
int VCVisualBoundingBox_SetData (VCVisualBoundingBox *item,VCVisualBoundingBoxData *boundingBoxData);
int VCVisualBoundingBox_Delete(VCVisualBoundingBox *item);

void VCSectionBounds_SetCacheMode(VCSectionBounds *item, uint32 newCacheMode);
uint32 VCSectionBounds_GetCacheMode(VCSectionBounds *item);
VCSectionBounds *_VC_GetSectionBounds (InstanceNo inst);
void *VCSectionBounds_AttachCreateCallback(VCSectionBounds *item, VCSectionBounds_Func func, void *data);
void *VCSectionBounds_AttachUpdateCallback(VCSectionBounds *item, VCSectionBounds_Func func, void *data);
void *VCSectionBounds_AttachDeleteCallback(VCSectionBounds *item, VCSectionBounds_Func func, void *data);
int VCSectionBounds_DetachCreateCallback(VCSectionBounds *item, void *callbackHandle);
int VCSectionBounds_DetachUpdateCallback(VCSectionBounds *item, void *callbackHandle);
int VCSectionBounds_DetachDeleteCallback(VCSectionBounds *item, void *callbackHandle);
VCSectionBounds *VCSectionBounds_CreateData(VCSectionBoundsData *bboxData);
int VCSectionBounds_GetData(VCSectionBounds *item, VCSectionBoundsData *boundingBoxData);
int VCSectionBounds_SetData (VCSectionBounds *item,VCSectionBoundsData *boundingBoxData);
int VCSectionBounds_Delete(VCSectionBounds *item);

#define _vcBgfReadFloat32Block(bf, buf, n) \
    _vcBgfReadInt32Block(bf, (int32 *) buf, n)

#define _vcBgfReadInt8Block(bf, buf, n) \
    _vcBgfReadString(bf, (char8 *) buf, n)

void	_VCSearchPathCreateHandler(VCSearchPath_CallbackData *callbackData, void *data);
void	_VCSearchPathUpdateHandler(VCSearchPath_CallbackData *callbackData, void *data);
void	_VCSearchPathDeleteHandler(VCSearchPath_CallbackData *callbackData, void *data);

VC_EXPORT dpVtime *_VCUpdateTime;
extern dpVtime *_VCExtractTime;
VC_EXPORT int _VCVerboseModule;
VC_EXPORT int _VCDebugModule;

void    _VCInitVerboseHelp(void);
#define _VCVerbose(l,s) duVerbose_Module(l,_vcVerboseModule,s)
#define _VCDebug(l,s) duDebug_Module(l,_vcDebugModule,s)
#endif
