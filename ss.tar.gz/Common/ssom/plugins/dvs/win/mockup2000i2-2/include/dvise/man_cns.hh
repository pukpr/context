#ifndef _MANCNS_HH
#define _MANCNS_HH

					// For SWAPI_CNS... (would be nicer to
					// map these within the man_cns.cc file
					// to save the dependency... one
					// day...)
#ifndef _swapi_h
#define SWAPI_CNSPOS 000010  /* Position constraint */
#define SWAPI_CNSROT 000020  /* Orientation constr. */
#define SWAPI_CNSFRA 000030  /* Frame constraint (position and orientation) */
#define SWAPI_CNSPOI 000100  /* Point constr. */
#define SWAPI_CNSLIN 000200  /* Line constr. */
#define SWAPI_CNSPLA 000400  /* Plane constr */
#define SWAPI_CNSHSP 001000  /* Halfspace constr. */
#define SWAPI_CNSACTIVE 01  
#define SWAPI_CNSINACTIVE 00  
#endif

class DV_EXPORT _ECSwManCnsInfo: public _ECItemInfo
{
public:
    _ECSwManCnsInfo(char *keyword) : _ECItemInfo(keyword) {};
    _ECBaseItem * createItem(void) ;
    int parseFileStream(dParseFilePtr IS, 
			_ECBaseItem *thisAttribute,
			hierarchy *pH);
};

typedef ECSmartPtr<_ECSwManCnsInfo> ECSwManCnsInfoPtr;

extern _ECSwManCnsInfo ManCnsParser;

// Update flags for the manikin constraint!!

#define manCONSTRAINT_UPDATE_REINITSAF  0x000100
#define manCONSTRAINT_UPDATE_MOVE	0x001000
#define manCONSTRAINT_UPDATE_REINIT	0x002000
#define manCONSTRAINT_UPDATE_STATE 	0x004000
#define manCONSTRAINT_UPDATE_MOVEMENT	0x008000
#define manCONSTRAINT_UPDATE_TYPE  	0x010000
#define manCONSTRAINT_UPDATE_WEIGHT	0x020000
#define manCONSTRAINT_UPDATE_PICK	0x040000

// Parser tokens
#define DEF_TOKEN(a, b, c) a,
typedef enum{
    tSwManCnsStartToken = 256,
#include "man_cns_def.hh"
    tSwManCnsEndToken
}SwManCnsToken;
#undef DEF_TOKEN 

					/* State of a constraint active or
					   inactive. */
typedef enum
{
    dvSwCnsStateNULL = 5,
    dvSwCnsActive = SWAPI_CNSACTIVE,
    dvSwCnsInactive = SWAPI_CNSINACTIVE

} dvSwCnsState;


                               //Type of constraint 
typedef enum 
{
    dvSwManCnsUnknown = 0,
    dvSwManCnsPos =  SWAPI_CNSPOS, // Position constraint.
    dvSwManCnsRot =  SWAPI_CNSROT, // Orientation constraint.
    dvSwManCnsFra =  SWAPI_CNSFRA, // Frame constraint (position+orientation).
    dvSwManCnsPoi =  SWAPI_CNSPOI, // Point constraint.
    dvSwManCnsLin =  SWAPI_CNSLIN, // Line constraint.
    dvSwManCnsPla =  SWAPI_CNSPLA, // Plane constraint.
    dvSwManCnsHsp =  SWAPI_CNSHSP  // Halfspace constraint.

} dvSwCnsType;

					/* Type of movement of constraint
					   (follows manikin like default
					   constraints, or follows world like
					   added constraints). */
typedef enum
{
    dvSwCnsMovementNULL = 0,
    dvSwCnsFollowsManikin = 1,
    dvSwCnsFollowsWorld = 2

} dvSwCnsMovement;

	
					/* Whether a constraint is being picked
					   or not. */
typedef enum
{
    dvSwCnsPicked,
    dvSwCnsUnpicked

} dvSwCnsPick;

// Whether a constraint has to be
// reinited from Safework or not

typedef enum
{
    dvSwCnsReinitFromSafeworkLock 	= 0, // Always ask swapi (vision cns)
    dvSwCnsReinitFromSafework 		= 1, // Ask swapi and store matrix 
    dvSwCnsReinitFromMatrix		= 2  // derive from matrix  

} dvSwCnsReinitType;

/*
 * This class holds the handles (which correspond to 
 * instance names under Safework) necessary to 
 * reconstruct and identify all the manikin parts under  * dvsafework.
 * 
 *
 */
class DV_EXPORT _ECSwManCns : public _ECBaseItem
{ 
    // implemented in man_cns.cc

    // %WAR:  The "Show Geometry" map is not implemented yet!!!


public:
    _ECSwManCns();
    _ECSwManCns(char *ObjectName, 
		char *RootName);
    _ECSwManCns(char *ObjectName, 
		char *RootName,
		dvSwCnsState st, 
		dvSwCnsType ty, 
		dvSwCnsMovement mo);
    ~_ECSwManCns();

    // Generic query and set methods
    int getId(void) const;
    static int getMyId(void);
    char *getIdString(void) const; // %WAR: Abstract virtual from _ECBaseItem
    char *GetName() const {return _attributeName;};
    ECError SetName(char *newName);
    ECError SetNameNoCopy(char *newName);

    dvSwRetType _updateSafework();
    
    // Constraint Interface methods
    dvSwRetType Activate() {
	if(_setstate(dvSwCnsActive) == dvSwSuccess)
	{
	    _state = dvSwCnsActive;
	    _update(manCONSTRAINT_UPDATE_STATE);
	    return(dvSwSuccess);   
	}
	return (dvSwFailure);
    };

    dvSwRetType Deactivate() {
	if(_setstate(dvSwCnsInactive) == dvSwSuccess)
	{
	    _state = dvSwCnsInactive;
	    _update(manCONSTRAINT_UPDATE_STATE);
	    return(dvSwSuccess);   

	}
	return (dvSwFailure);
 
    };

    dvSwRetType Reinit();
    dvSwRetType storeForUndo();
    dvSwRetType Move();

    // Specific query and set
    static _ECSwManCns *getFromAssembly(ECAssembly *ass); 
    _ECAssembly *getThisAssembly();
    _ECAssembly *getManikinRootAssembly();
    _ECAssembly *getManikinSegmentAssembly();
    char *getObjectHandle() {return(_objectHandle);};
    char *getManikinHandle() {return(_manikinHandle);};
    dvSwCnsPick getPickFlag() { return _pick_flag; };
    dvSwCnsType getType() { return _type;};
    dvSwCnsMovement getMovement(){ return _movement;};
    dvSwCnsMovement getStoredMovement(){ return _stored_movement;};
    dvSwCnsState getState(){ return _state;};
    dvSwCnsState getStoredState(){ return _stored_state;};
    float32 getWeight() {return _weight;};
    int32 getLinkIndex() {return _link;};

    dvSwRetType setPickFlag(dvSwCnsPick pick_flag) { 
	
	_pick_flag = pick_flag;
	_update(manCONSTRAINT_UPDATE_PICK);
	return(dvSwSuccess);   
    };
    dvSwRetType setType(dvSwCnsType type) {
	if(_settype(type) == dvSwSuccess)
	{
	    _type = type;
	    _update(manCONSTRAINT_UPDATE_TYPE);
	    return(dvSwSuccess);
	}
	return(dvSwFailure);
    };
    dvSwRetType setMovement(dvSwCnsMovement movement);
    dvSwRetType setStoredMovement(dvSwCnsMovement stored_movement) {
	_stored_movement = stored_movement;
	_update(0);
 	return(dvSwSuccess);   
    };
    dvSwRetType setState(dvSwCnsState state) {
	if(_setstate(state) == dvSwSuccess)
	{
	    _state = state;
	    _update(manCONSTRAINT_UPDATE_STATE);
	    return(dvSwSuccess);
	}
	return(dvSwFailure);
    };
    dvSwRetType setStoredState(dvSwCnsState stored_state) {
	_stored_state = stored_state;
 	_update(0);
	return(dvSwSuccess);   
    };
    friend void 
    _ECSwManCnsCreateAssociationsCallback(ECCallbackInfo *info, void *data);

    // I/O methods
    int writeVdiFile(); // %NOTE: The write method is member...
    // .. But the read method is a friend (member of the class defined above)
    friend int _ECSwManCnsInfo::parseFileStream(dParseFilePtr IS, 
						_ECBaseItem *thisAttribute,
						hierarchy *pH);

private: 
    dvSwRetType _settype(dvSwCnsType ty) {
	return(_setall(ty, _state, _weight ));
    };
    dvSwRetType _setstate(dvSwCnsState st);    
    dvSwRetType _getall();
    dvSwRetType _setall(dvSwCnsType ty, dvSwCnsState st, float32 weight);
    // Indicates whether the Cns is being picked
    dvSwCnsPick			_pick_flag; 

    // Type of Cns
    dvSwCnsType			_type;
    dvSwCnsState		_state;

    // Weight
    float32 			_weight;

    // Index of segment the cosntraint is attached to
    int 			_link;

    // Local offset WRT the segment's matrix
    dmMatrix			_offset_matrix;

    // Whether the Cns follows the manikin or the world
    // and stored version of the previous
    dvSwCnsMovement		_movement;
    dvSwCnsMovement		_stored_movement;
    dvSwCnsState		_stored_state;

    // How the constraint has to be reinited;
    dvSwCnsReinitType		_reinit_type;
    dvSwCnsReinitType 		getReinitType() {return (_reinit_type);};
    void			setReinitType(dvSwCnsReinitType t) { 
	_reinit_type = t;
    };
    // The vision needs to change the type of reinit for the vision constraint
    friend void 
    _ECSwReachAndVisionCreateAssociationsCallback(ECCallbackInfo *info, 
						  void *data);
    // The register imposes a reinit when the anthropometry has changed
    friend class _ECSwManRegister;

    dvSwRetType 		reinitFromSafework();    
    dvSwRetType 		reinitFromMatrix();
    dvSwRetType 		setOffsetMatrix();
    
    char * _objectHandle; // Safework name of THIS instance
    char * _manikinHandle; // name of the manikin's root under Safework

    char * _attributeName; // Name of this attribute
    
    // pointer to the register entry
    //ECSwManRegisterPtr thisRegister;

};

typedef ECSmartPtr<_ECSwManCns> ECSwManCnsPtr;

#endif
