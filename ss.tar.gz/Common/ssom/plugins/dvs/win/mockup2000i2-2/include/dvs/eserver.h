#ifndef __ESERVER_H__
#define __ESERVER_H__

#include "esexport.h"

ES_EXPORT void EServer_Initialise(const char* const logFileName);
ES_EXPORT void EServer_PostAttachInit();
ES_EXPORT void EServer_Exit();


#endif
