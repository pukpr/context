#ifndef _DVSW_PANELS_HH
#define _DVSW_PANELS_HH

#include "dvise/dvexport.h"

DV_EXPORT void
dvSwPanelOpenLibrary(void);

DV_EXPORT void
dvSwPanelOpenPostureAnalysis(void);

DV_EXPORT void
dvSwPanelOpenAnthropometry(void);


DV_EXPORT void
dvSwPanelOpenPushPull(void);

DV_EXPORT void
dvSwPanelOpenLiftLower(void);

DV_EXPORT void
dvSwPanelOpenCarry(void);

#endif
