/*
 *    PROJECT:      
 *    SUBSYSTEM:    
 *    MODULE:       
 *
 *    File:         $RCSfile: vwtext.h,v $
 *    Revision:     $Revision: 1.4 $
 *    Date:         $Date: 1997/05/22 16:20:12 $
 *    Author:       $Author: simon $
 *    RCS Ident:    $Id: vwtext.h,v 1.4 1997/05/22 16:20:12 simon Exp $
 *
 *    FUNCTION: Frame public function prototypes.
 * 
 * Copyright (c) 1996 Division Ltd.
 *
 * All Rights Reserved.
 *
 * This Document may not, in whole or in part, be copied,
 * photocopied, reproduced, translated, or reduced to any
 * electronic medium or machine readable form without prior
 * written consent from Division Ltd.
 */
#ifndef _VWText_H
#define _VWText_H
#ifdef __cplusplus
extern "C" {
#endif
#ifdef _dummyBrace_
}
#endif
/* INCLUDES ============================================== */
#include "vwidgets.h"
#include "vwborder.h"
/* PUBLIC FUNCTIONS ====================================== */

enum {
    VWrNumLines = VW_RESOURCES_TEXT,
    VWrLineLength,
    VWrStartingText,
    VWrSetScrolling,
    VWrSetAvailableChars,
    VWrUseScrollBar,
    VWrDontUseBorder,
    VWrTextType,
    VWrUseFlatButtons,
    VWrBackgroundFlatWhite,
    VWrFormatText,
    VWrTextSelectionCallBack,
    VWrTextSelectionCallBackData
};

typedef enum VWText_Type {
    VWText_Label, 
    VWText_Button, 
    VWText_Toggle
} VWText_Type;


VW_EXPORT VWidget *VWText_CreateManaged(VWidget *Parent, char *name, VWArg args[], int argc);
VW_EXPORT VWidget *VWText_Create(VWidget *Parent, char *name, VWArg args[], int argc);
VW_EXPORT void VWText_SetText(VWidget *thisWig, char *text);
VW_EXPORT void VWText_AppendText(VWidget *thisWig, char *text);
VW_EXPORT void VWText_InsertText(VWidget *thisWig, char *text, int position);
VW_EXPORT void VWText_ClearText(VWidget *thisWig);
VW_EXPORT void VWText_DeleteText(VWidget *thisWig, int startPos, int finishPos);
VW_EXPORT char *VWText_GetAllText(VWidget *thisWig);
VW_EXPORT void VWText_GetSpecifiedText(VWidget *thisWig, char *text, int startPos, int finishPos);
VW_EXPORT char VWText_GetSelectedChar(VWidget *thisWig, int *position);
VW_EXPORT void VWText_StartScrolling(VWidget *thisWig);
VW_EXPORT void VWText_StopScrolling(VWidget *thisWig);
VW_EXPORT int VWText_IsItScrolling(VWidget *thisWig);
VW_EXPORT void VWText_AddSelectionCallback(VWidget *thisWig, VWCallback *cb, void *cd);
VW_EXPORT void VWText_AddDeselectionCallback(VWidget *thisWig, VWCallback *cb, void *cd);



#ifdef _dummyBrace_
{
#endif
#ifdef __cplusplus
}
#endif /* _cplusplus */
#endif /*_VWText_H */
