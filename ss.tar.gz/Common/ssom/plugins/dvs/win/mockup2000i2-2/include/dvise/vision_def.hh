/* Nb. since all these entries are PARSER_ANY_CASE, this has been removed from
   this file and is hard coded in the DEF_TOKEN macro as necessary to make it
   more legible. */

DEF_TOKEN( tSwReachAndVisionVisionShow,			"visionshow")
DEF_TOKEN( tSwReachAndVisionVisionShowOn,		"visionon")
DEF_TOKEN( tSwReachAndVisionVisionShowOff,		"visionoff")

DEF_TOKEN( tSwReachAndVisionVisionModel,		"model")
DEF_TOKEN( tSwReachAndVisionVisionBinocular,		"binocular")
DEF_TOKEN( tSwReachAndVisionVisionAmbinocular,		"ambinocular")
DEF_TOKEN( tSwReachAndVisionVisionMonocularLeft,	"monocularleft")
DEF_TOKEN( tSwReachAndVisionVisionMonocularRight,	"monocularright")

DEF_TOKEN( tSwReachAndVisionVisionLineOfSight,		"lineofsight")
DEF_TOKEN( tSwReachAndVisionVisionLineOfSightOn,	"lineofsighton")
DEF_TOKEN( tSwReachAndVisionVisionLineOfSightOff,	"lineofsightoff")

DEF_TOKEN( tSwReachAndVisionVisionCentral,		"central")
DEF_TOKEN( tSwReachAndVisionVisionCentralOn,		"centralon")
DEF_TOKEN( tSwReachAndVisionVisionCentralOff,		"centraloff")

DEF_TOKEN( tSwReachAndVisionVisionPeripheral,		"peripheral")
DEF_TOKEN( tSwReachAndVisionVisionPeripheralOn,		"peripheralon")
DEF_TOKEN( tSwReachAndVisionVisionPeripheralOff,	"peripheraloff")

DEF_TOKEN( tSwReachAndVisionVisionBlind,		"blind")
DEF_TOKEN( tSwReachAndVisionVisionBlindOn,		"blindon")
DEF_TOKEN( tSwReachAndVisionVisionBlindOff,		"blindoff")

DEF_TOKEN( tSwReachAndVisionVisionParamsVerticalTop,		"verticaltop")
DEF_TOKEN( tSwReachAndVisionVisionParamsVerticalBottom,		"verticalbottom")
DEF_TOKEN( tSwReachAndVisionVisionParamsCentralAngle,		"centralangle")
DEF_TOKEN( tSwReachAndVisionVisionParamsHorizontalMonocular,	"horizontalmonocular")
DEF_TOKEN( tSwReachAndVisionVisionParamsHorizontalAmbinocular,	"horizontalambinocular")

DEF_TOKEN( tSwReachAndVisionVisionParamsPonctumProximum,	"ponctumproximum")
DEF_TOKEN( tSwReachAndVisionVisionParamsFocalDistance,		"focaldistance")
DEF_TOKEN( tSwReachAndVisionVisionParamsPonctumRemotum,		"ponctumremotum")


DEF_TOKEN( tSwReachAndVisionReachShow,			"reachshow")
DEF_TOKEN( tSwReachAndVisionReachShowOn,		"reachon")
DEF_TOKEN( tSwReachAndVisionReachShowOff,		"reachoff")

DEF_TOKEN( tSwReachAndVisionReachLeft,			"reachleft")
DEF_TOKEN( tSwReachAndVisionReachLeftOn,		"reachlefton")
DEF_TOKEN( tSwReachAndVisionReachLeftOff,		"reachleftoff")

DEF_TOKEN( tSwReachAndVisionReachRight,			"reachright")
DEF_TOKEN( tSwReachAndVisionReachRightOn,		"reachrighton")
DEF_TOKEN( tSwReachAndVisionReachRightOff,		"reachrightoff")
