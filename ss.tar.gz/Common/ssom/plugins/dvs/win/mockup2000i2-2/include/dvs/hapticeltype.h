#define InstanceNo uint32	/* Define InstanceNo as a basic type !! */



typedef struct 
{
    uint32		 mode;
    float32		 mass;
    char8		 geometry[1];
} _VCHaptic;

typedef struct 
{
    uint32		 mode;
    char8		 name[1];
} _VCHapticResource;




#undef InstanceNo

#define el_VCHaptic		el__VCHaptic
#define el_VCHapticResource	el__VCHapticResource








