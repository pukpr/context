#ifndef _DVSOCK_H_
#define _DVSOCK_H_

#define _BSD_SIGNALS
#define _DVS_DVSOCK
/*
#define DEBUG 1
*/
#include <stdio.h>
#include <stdlib.h>
#include <dsys/du.h>
#include <dsys/dp.h>
#include <dsys/dtcp.h>

#include "dvsocktypes.h"
#include "dvsockdefs.h"

DP_EXPORT struct connections *connectionList;
DP_EXPORT int numConnections;


DP_EXPORT int dvsockFindOrAddConnectionInfo(int32 addr, unsigned short port);
DP_EXPORT struct connections * dvsockFindConnectionInfo(int sock, int *connectionPtr);
DP_EXPORT int dvsockDoNewConnection(struct sockaddr_in *addr, int thisEndian, int dataBaseId);
DP_EXPORT int dvsockAddNewConnection(int32 sock, int32 addr, unsigned short port,
                                     void (*messageFunc)(int connection, char *message, int messageLen, void *userData));
DP_EXPORT void dvsockEndianConvertHeader(AgentMessage *messageHeader);
DP_EXPORT int  dvsockDeleteConnectionInfo(int offset);


DP_EXPORT int dvsockGetPorts(char *name, int32 *startPort, int32 *numPorts);
DP_EXPORT int dvsockInitConnection(dvsockInfo *info, dvsockFunctionTable *funcTable, void *applicationData);
DP_EXPORT void dvsockConnectToServer(void);
DP_EXPORT void dvsockWrite(struct connections *thisConnection, int offset);
DP_EXPORT int32 dvsockReadHandler(int sock);
DP_EXPORT int dvsockWriteHandler(int sock);
DP_EXPORT int dvsockSendMessage(int32 sock, char *message);
DP_EXPORT void dvsockSetDataBaseId(int32 dbaseId);
DP_EXPORT char * dvsockGetDefaultDomain(void);

#endif
