main() {
  int major, minor;

  dloadVersionFunction (&major, &minor);

  EC_PluginEntryPoint (&major);


}


