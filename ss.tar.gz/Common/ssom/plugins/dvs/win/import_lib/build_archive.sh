 dlltool --input-def libdvise.def --dllname libdvise.dll --output-lib libdvise.a
 dlltool --input-def libdivvc.def --dllname libdivvc.dll --output-lib libdivvc.a
