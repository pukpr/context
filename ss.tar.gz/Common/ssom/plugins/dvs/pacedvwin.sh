cd  `dirname $0`
env GNU_ENV_DISPLAY=0 \
    PACE=`pwd`/../../ \
    PACE_DEBUG_DISPLAY=0 \
    PACE_DEBUG_LEVEL=0 \
    PACE_DISPLAY=0 \
    PACE_INIT=1 \
    PACE_NODE=12 \
    PACE_SIM=0 \
    DIVISIONROOT="C:\ptc\mockup2000i2" \
    FLEXLM_BATCH=1 \
    HOMEDRIVE=M: \
    HOMEPATH=\ProE \
    LM_LICENSE_FILE="7788@sifweblnx;7788@sifweblnx" \
    MAPROOTOFF=ON \
    MC=i486_nt \
    MOCKUP_FEATURE_NAME="MOCKUP_1258589 MOCKUP_3594879" \
    PROCESSOR_ARCHITECTURE=x86 \
    PROCESSOR_IDENTIFIER="x86 Family 15 Model 4 Stepping 1, GenuineIntel" \
    PROCESSOR_LEVEL=15 \
    PROCESSOR_REVISION=0401 \
    PRODIR="C:\ptc\mockup2000i2" \
    PRO_DIRECTORY="C:\ptc\mockup2000i2" \
    PRO_MACHINE_TYPE=i486_nt \
    PTCPATH=true \
    PTCTestEnv="Text String" \
    PTC_HOSTNAME=`uname -n` \
/C/ptc/mockup2000i2/i486_nt/obj/dvs -n dvmockup $1
