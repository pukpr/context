#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <dvise/dvise.h>
#include <dvs/vc.h>

#include "dvise_plugin.h"

static int Debug_Output = 1;
static int Display_Output = 1;
static int DVS_LINK_RESET = 1;

/* static FILE *stderr_file;
*/
#define stderr_file stderr


ECAssembly* Get_Assembly(char *name, char *entity)
{
   ECAssembly *assembly;
   int strict_mode = 0;  /* ??? should be enumerated */

   /* if entity is empty string then search from the top zone,
      otherwise find the entity assembly and search within entity */
   if (strcmp(entity, "") == 0) {
     assembly = ECAssembly_FindNamedAssembly (EC_GetTopZone(), name, strict_mode);
   } else {
     ECAssembly *parent_assembly = ECAssembly_FindNamedAssembly (EC_GetTopZone(), entity, strict_mode);
     if (parent_assembly) {
       assembly = ECAssembly_FindNamedAssembly (parent_assembly, name, strict_mode);
     } else {
       /* if parent_assembly is not found search from the top */
       assembly = ECAssembly_FindNamedAssembly (EC_GetTopZone(), name, strict_mode);
     }
   }
   return(assembly);
}

ECAssembly* Find_Assembly(dvs_msg *msg)
{
  ECAssembly *assembly;
  if (msg->assembly == NULL) {
    assembly = Get_Assembly(msg->object, msg->entity);
  } else {
    assembly = msg->assembly;
  }
  return assembly;
}

void MsgSendEvent (dvs_msg *msg)
{
   ECAssembly *assembly = Find_Assembly(msg);
   uint32 eventId = 0;

   if (Display_Output) {
      fprintf(stderr_file, "%s %s \n",msg->object, msg->event);  /* confirm to stdout. */
   }

   eventId = ECEvent_GetIdFromName(msg->event); /* generate an event ID */

   if (assembly){
      if (eventId)  /* if object and event are valid, send event to object. */
         ECEvent_GenerateForAssemblyTree(eventId, assembly, NULL, NULL, 0, 0);
      else
         fprintf(stderr_file, "!!! eventId is 0 @ %s\n", msg->event);
   } else {
      fprintf(stderr_file, "!!! assembly pointer null @ %s\n", msg->object);
   }
}


void create_textured_material (char *material_name) {
    VCMaterialData mat;

    memset(&mat, 0, sizeof(VCMaterialData));
    mat.diffuse[VC_RED] = mat.diffuse[VC_GREEN] = mat.diffuse[VC_BLUE] = 1.0f; /* 0.8f; */
    mat.ambient[VC_RED] = mat.ambient[VC_GREEN] = mat.ambient[VC_BLUE] = 1.0f; /* 0.3f; */
    mat.specular[VC_RED] = mat.specular[VC_GREEN] = mat.specular[VC_BLUE]= 0.0f; /* 0.9f; */
    mat.specular[3] = 2.0f;
    mat.opacity[VC_RED] = mat.opacity[VC_GREEN] = mat.opacity[VC_BLUE] = 1.0f;
    mat.mode = VC_MATERIAL_ENABLE;
    mat.name = mat.textureName = material_name;
    if (!VCMaterial_CreateData(&mat)) {
        printf("failed to create material.\n");
    }
}

extern uint8 image_data_1d[];

void MsgSendTexture1D (dvs_msg *msg)
{
   VCTextureImageData tex_image;
   VCTextureData      tex_data;

   if (Display_Output) {
      fprintf(stderr_file, "%s %s \n",msg->object, msg->event);  /* confirm to stdout. */
   }

   /* Create a material. */
   create_textured_material (msg->object);

   /* Create a texture image. */
   memset(&tex_image, 0, sizeof(VCTextureImageData));
   tex_image.mode = VC_TEXTUREIMAGE_ENABLE;
   tex_image.width = (int) msg->pos.x; /* 16 */
   tex_image.height = 1;
   tex_image.numComponents = 4;
   tex_image.image = image_data_1d;

   /* Create a texture data. */
   memset(&tex_data, 0, sizeof(VCTextureData));
   tex_data.mode = VC_TEXTURE_ENABLE;
   tex_data.name = msg->object;

   tex_data.textureImage = VCTextureImage_CreateData(&tex_image);

   if (!VCTexture_CreateData(&tex_data)) printf("failed to create 1D texture.\n");

}

extern uint8 image_data_2d[];

void MsgSendTexture2D (dvs_msg *msg)
{
   VCTextureImageData tex_image;
   VCTextureData      tex_data;

   if (Display_Output) {
      fprintf(stderr_file, "%s %s \n",msg->object, msg->event);  /* confirm to stdout. */
   }

   /* Create a material. */
   create_textured_material (msg->object);

   /* Create a texture image. */
   memset(&tex_image, 0, sizeof(VCTextureImageData));
   tex_image.mode = VC_TEXTUREIMAGE_ENABLE;
   tex_image.width = (int) msg->pos.x;  /* 64 max */
   tex_image.height = (int) msg->pos.y; /* 64 max */
   tex_image.numComponents = 4;
   tex_image.image = image_data_2d;

   /* Create a texture data. */
   memset(&tex_data, 0, sizeof(VCTextureData));
   tex_data.mode = VC_TEXTURE_ENABLE;
   tex_data.name = msg->object;

   tex_data.textureImage = VCTextureImage_CreateData(&tex_image);

   if (!VCTexture_CreateData(&tex_data)) printf("failed to create 2D texture.\n");

}


void MsgSendVariable (dvs_msg *msg)
{
   if (Display_Output) {
     fprintf(stderr_file, "Sending 'Variable' to add geometry: %s <- %s \n", msg->object, msg->event);
   }
    
   VCEntity      *eptr;
   ECAssembly    *asmb, *asmb2;

   asmb = Get_Assembly (msg->object, "");
   //asmb2 = ECAssembly_PSCreate(msg->object);
   if (asmb){
      //ECAssembly_CopyDefined(asmb, asmb2);
      //fprintf(stderr_file, "NAMED: %s\n", ECAssembly_GetName(asmb2));
      //asmb2 = ECAssembly_Copy (asmb);
      //ECAssembly_SetName(asmb2, msg->object);
   } else {
      fprintf(stderr_file, "Assembly not found: %s \n",msg->object);
      return;
   }

   eptr = ECAssembly_GetVCEntity(asmb);

   VCEntity_AddVisualGeometry (eptr, msg->event);
   VCEntity_AddBoundaryGeometry (eptr, msg->event);

//   ECAssembly_Enable (asmb);
   ECAssembly_SendPositionToVC(asmb);

//   dmPoint        p;
//   dmEuler        o;
//   dmScale        s;
//   VCPositionData pos; 

//   dmPointSet  (p, 0.0, 0.0, 0.0);
//   dmEulerSetD (o, 0.0, 0.0, 0.0);
//   dmScaleSet  (s, 1.0, 1.0, 1.0);
//   VCPosition_MakePointEulerScale (&pos, o, o, s);
//   eptr = VCEntity_Create(&pos, 0);

//   theItem = ECAssembly_GetItemList(EC_GetTopZone());
//   ECItem_SetType(theItem, theItemType);
//   ECSetVariable(msg->object, msg->event, theItem);

}


void MsgSendCoordinate (dvs_msg *msg)
{
    ECAssembly *assembly = Find_Assembly(msg);
    dmPoint p;
    dmEuler e;

    if(Debug_Output){
      fprintf(stderr_file, "MOVE: %s (entity is %s) (%g,%g,%g) (%g,%g,%g)\n", msg->object, msg->entity,
              msg->pos.x, msg->pos.y, msg->pos.z,
              msg->rot.a, msg->rot.b, msg->rot.c);
    }

    if(assembly == NULL){
    	fprintf(stderr_file, "%s object not found in database\n", msg->object);
    	return;
    }

    switch (msg->msg_type){
       case ROTATION:
          dmEulerSet(e, msg->rot.a, msg->rot.b, msg->rot.c);
          ECAssembly_SetPosOrScale(assembly, NULL, e, NULL);
          break;
       case POSITION:
          dmPointSet(p, msg->pos.x, msg->pos.y, msg->pos.z);
          ECAssembly_SetPosOrScale(assembly, p, NULL, NULL);
          break;
       case COORDINATE:
          dmEulerSet(e, msg->rot.a, msg->rot.b, msg->rot.c);
          dmPointSet(p, msg->pos.x, msg->pos.y, msg->pos.z);
          ECAssembly_SetPosOrScale(assembly, p, e, NULL);
          break;
    }

    ECAssembly_SendPositionToVC(assembly);
}


void MsgGetCoordinate (dvs_msg *msg, position *scale)
{
    ECAssembly *assembly = Find_Assembly(msg);
    dmPoint p;
    dmEuler e;
    dmScale s;

    if(assembly == NULL){
    	fprintf(stderr_file, "%s object not found in database\n", msg->object);
    	return;
    }

    ECAssembly_GetPosOrScale(assembly, p, e, s);
    msg->pos.x = p[0];
    msg->pos.y = p[1];
    msg->pos.z = p[2];
    msg->rot.a = e[0];
    msg->rot.b = e[1];
    msg->rot.c = e[2];
    scale->x = s[0];
    scale->y = s[1];
    scale->z = s[2];
}

void MsgSendScale (dvs_msg *msg)
{
    ECAssembly *assembly = Find_Assembly(msg);
    dmScale s;

    if(Debug_Output){
      fprintf(stderr_file, "SCALE: %s (%g,%g,%g)\n", msg->object,
              msg->pos.x, msg->pos.y, msg->pos.z);
    }

    if(assembly == NULL){
    	fprintf(stderr_file, "%s object not found in database\n", msg->object);
    	return;
    }
    dmScaleSet(s, msg->pos.x, msg->pos.y, msg->pos.z);
    ECAssembly_SetPosOrScale(assembly, NULL, NULL, s);
    ECAssembly_SendPositionToVC(assembly);
}

void MsgSendSpin (dvs_msg *msg)
{
    ECAssembly *assembly = Find_Assembly(msg);
    VCEntity *entity;

    if(Debug_Output){
      fprintf(stderr_file, "SPIN: %s (%g,%g,%g)\n", msg->object,
              msg->rot.a, msg->rot.b, msg->rot.c);
    }

    if(assembly == NULL){
    	fprintf(stderr_file, "%s object not found in database\n", msg->object);
    	return;
    }
    entity = ECAssembly_GetVCEntity (assembly);
    VCEntity_SpinX (entity, msg->rot.a);
    VCEntity_SpinY (entity, msg->rot.b);
    VCEntity_SpinZ (entity, msg->rot.c);
}

void MsgSendLink (dvs_msg *msg)
{
   ECAssembly *parent = Find_Assembly(msg);
   ECAssembly *child = Get_Assembly(msg->event, msg->entity);

   dmEuler e;
   dmEulerSet(e, 0.0, 0.0, 0.0);
   dmPoint p;
   dmPointSet(p, 0.0, 0.0, 0.0);

   if (strcmp(msg->object, "") == 0) {
      EC_PrintMessage("** ERROR: Trying to link empty string msg->object");
      return;
   }
   if (strcmp(msg->event, "") == 0) {
      EC_PrintMessage("** ERROR: Trying to link empty string msg->event");
      return;
   }
   
   if (parent){
      if (child)  /* if parent and child are valid, link child to parent. */
         /* ECAssembly_LinkChild (parent, child); */
         VCEntity_Link(ECAssembly_GetVCEntity(parent),
	                    ECAssembly_GetVCEntity(child),
                       VC_LINK_ADJUST_POSITION);
         if (DVS_LINK_RESET) {
            ECAssembly_SetPosOrScale(child, p, e, NULL);
            ECAssembly_SendPositionToVC(child);
         }
      else
         fprintf(stderr_file, "!!! child pointer is null %s\n", msg->event);
   } else {
      fprintf(stderr_file, "!!! parent pointer null @ %s\n", msg->object);
   }
}


void MsgSendUnLink (dvs_msg *msg)
{
   ECAssembly *assembly = Find_Assembly(msg);
   if (Display_Output) {
     fprintf(stderr_file, "!!!!!UnLink %s\n",msg->object);
   }
   if (assembly){
     VCEntity_Unlink(ECAssembly_GetVCEntity(assembly), VC_UNLINK_ADJUST_POSITION);
   } else {
     fprintf(stderr_file, "!!! unlink assembly pointer null @ %s\n", msg->object);
   }
}

float MsgGetVariable (char *var_name_str)
{
   fprintf(stderr_file, "!! get variable NOT IMPLEMENTED, see previous version\n");
   return (0.0);
}


static
void syncDelete( VCSync_CallbackData *callbackData, void *data)
{
    fprintf(stderr_file, "dVISE sync deleted\n");
}

static
void syncUpdate( VCSync_CallbackData *callbackData, void *data)
{
    VCSync *sync = callbackData -> sync;

    if (sync){
        pace_synch(1);
    }
}


static
void CleanUp()
{
    pace_synch(0);
    fprintf(stderr_file, "dVISE disconnected, PACE messaging removed\n");
}

void
processCollisions(VCCollision_CallbackData *cd, void *data)
{
    EC_PrintMessage ("EC clang####################################################\n");
    fprintf (stderr_file, "fprintf clang####################################################\n");
    fflush(stderr);
}

void
processCollideCallback(VCCollideMonitor_CallbackData *cd, void *data)
{
    EC_PrintMessage ("EC collide clang####################################################\n");
    fprintf (stderr_file, "fprintf collide clang####################################################\n");
    fflush(stderr);
}

/*
** STUB function for BAE Systems to insert their own functionality
**
** This function is called automatically at the instant of a pair of assemblies being reported in collision
**
*/
static
void va_BAESystems_gotInterference( ECAssembly *assembly1, ECAssembly *assembly2, float distance, int type)
{
    EC_PrintMessage("** Collision Reported:" );
    if (assembly1 != NULL && assembly2 != NULL) {
      //EC_PrintMessage("  Got assembly [%s]", ECAssembly_GetPathName(assembly1));
      //EC_PrintMessage("  Got assembly [%s]", ECAssembly_GetPathName(assembly2));
        EC_PrintMessage("  Got assembly [%s]", ECAssembly_GetName(assembly1));
        EC_PrintMessage("  Got assembly [%s]", ECAssembly_GetName(assembly2));
        AddCollision(ECAssembly_GetName(assembly1), ECAssembly_GetName(assembly2));
        if (type == 4) {
            EC_PrintMessage("  The collision was hard");
        }
        else if (type == 3) {
      	    EC_PrintMessage("  The collision was a touch");
	}
        else if (type == 1) {
      	    EC_PrintMessage("  The collision was a non-contact tolerance match");
        }
    } else {
        EC_PrintMessage("** ERROR: va_BAESystems_gotInterference: Could not identify both assemblies");
    }
}

/*
** CALLBACK function
**
** This is called on the creation of all VCCollisionRequestReport Attributes, once per colliding report line
**
*/
static
void va_reportCollisionPair (VCCollisionRequestReport_CallbackData *attributeData, void *data)
{
	//
	// References:
	//

	//struct VCCollisionRequestReport_CallbackData
	//{
	//	VCCollisionRequestReport	*collisionRequestReport;
	//};

	//struct VCCollisionRequestReport
	//{
	//	InstanceNo		 ino;
	//	uint32		 status;
	//	uint32		 cacheMode;
	//	void		*instanceData;
	//	uint32		 instanceDataSize;
	//	uint32		 instanceDataCount;
	//	VCUserDataList	*userDataList;
	//	VCCallbackFunctions	*createFunctionList;
	//	VCCallbackFunctions	*deleteFunctionList;
	//	VCCallbackFunctions	*updateFunctionList;
	//	void		*createCallbackHandle;
	//	void		*updateCallbackHandle;
	//	void		*deleteCallbackHandle;
	//	struct VCCollisionRequestReport *next;
	//	float32             *polylines;
	//	int32                polylineSize;
	//};

	//EC_PrintMessage("va_reportCollisionPair: called");


	if (attributeData == NULL || attributeData->collisionRequestReport == NULL) {
		EC_PrintMessage("** ERROR: va_reportCollisionPair: Null attribute data in callback");
		return;
	}

	VCAttribute *boundary1=NULL;
	VCAttribute *boundary2=NULL;
	dmMatrix     position1;
	dmMatrix     position2;
	float        distance;
	float*		 polys;
	int32		 type;


	// Reference:
	// VC_EXPORT int VCCollisionRequestReport_Get( VCCollisionRequestReport *item, VCAttribute **boundary1, VCAttribute **boundary2,
	// dmMatrix position1, dmMatrix position2, float32 *distance, float32 **polylines, int32* type);
	//
	int result = VCCollisionRequestReport_Get (attributeData->collisionRequestReport, &boundary1, &boundary2, position1, position2, &distance, &polys, &type);
	if (result != VC_OK) {
		EC_PrintMessage("** ERROR: va_reportCollisionPair: Failed to extract the collision report");
		return;
	}

	if (boundary1 != NULL && boundary2 != NULL) {
		// Got both boundaries OK
		VC_Traverse trav1, trav2;
		VCEntity *e1 = VCAttribute_GetFirstEntity (boundary1, &trav1);
		VCEntity *e2 = VCAttribute_GetFirstEntity (boundary2, &trav2);
		if (e1 != NULL && e2 != NULL) {
			// Got both entities OK
			ECAssembly *assembly1 = ECAssembly_GetFromVCEntity (e1);
			ECAssembly *assembly2 = ECAssembly_GetFromVCEntity (e2);
			va_BAESystems_gotInterference (assembly1, assembly2, distance, type);
		}
		else {
                     EC_PrintMessage("** ERROR: va_reportCollisionPair: Failed to extract both entities");
		}
	}
        else {
             EC_PrintMessage("** ERROR: va_reportCollisionPair: Failed to extract both collision boundaries");
	}
}

extern int gnat_argc;
extern char **gnat_argv;

/* This is the standard entry point */
 void EC_PluginEntryPoint (ECPlugin *plg, char *string) { // (void) {
   char * dvs_debug;
   char *name[] = {"dvise_plugin"};
   char * disable_pace;

/*   stderr_file = fopen ("dvs_debug.log", "w");
*/
   gnat_argc = 0; /* argc; */
   gnat_argv = name;

   EC_PrintMessage("Plugin:PACE");
   fprintf(stderr_file, "Plugin:PACE\n");
   adainit(); /* elaborate_PACE(); */
   EC_PrintMessage("elaborated");
   fprintf(stderr_file, "elaborated\n");

   start_pace_messaging();
   dvs_debug = getenv("DVS_DEBUG");
   if (dvs_debug == 0) {  // if env var not specified 
     dvs_debug = "1";  // default to 1
   }
   if (getenv("DVS_LINK_RESET") == 0) {  // if env var not specified 
     DVS_LINK_RESET = 0;
   }

   if (strcmp(dvs_debug, "0") == 0) {   // if = 0
     Display_Output = 0;
     Debug_Output = 0;       
     fprintf(stderr_file, "Debugging output set to OFF\n");
   } else if (strcmp(dvs_debug, "1") == 0) {  // if = 1
     Display_Output = 1;
     Debug_Output = 0;       
     fprintf(stderr_file, "Debugging output set to PARTIAL\n");
   } else {
     Display_Output = 1;
     Debug_Output = 1;       
     fprintf(stderr_file, "Debugging output set to FULL\n");
   }

   disable_pace = getenv("DISABLE_PACE");
   if (disable_pace == 0) {     /* PACE exists, proceed with application */
      EC_PrintMessage("dVISE connected to PACE");
      fprintf(stderr_file, "dVISE 6.0 connected to PACE\n");
      VC_AttachSyncCallbacks("local", "visual", syncUpdate, syncDelete, NULL);
      VC_AttachExitCallback((VC_ExitFunc)CleanUp,NULL);

      // Add the callback for creation of all VCCollisionRequestReport Attributes
      // This is called for every interference event
      VCCollisionRequestReport_AttachCreateCallback	(NULL, va_reportCollisionPair, NULL);
      //VCCollision_AttachUpdateCallback(NULL, processCollisions, NULL);
      //VCCollideMonitor_AttachUpdateCallback(NULL, processCollideCallback, NULL);
      //VCBody_AttachCollisionCallback(NULL, NULL, NULL, NULL);

      EC_PrintMessage("EC registered collision callback!!####################################################\n");
      fprintf (stderr_file, " fprintf registered collision callback!!####################################################\n");
   } else {
      fprintf(stderr_file, "dVISE NOT connecting to PACE as requested by the existence of DISABLE_PACE\n");
   }
 }

// this has got to be exactly 46 characters long:  see g-comver.ads
char __gnat_version[46] = "GNAT Version: (6.2.1 from dvise_plugin.c)    \0";

 /* Identify the version of dVISE that is required */
 void dloadVersionFunction (int * major, int * minor) {
    EC_PrintMessage("Plugin:VERSION");
    EC_PrintMessage(__gnat_version);
    *major = 5;
    *minor = 0;
 }


