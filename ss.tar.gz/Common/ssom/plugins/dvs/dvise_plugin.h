typedef enum {  EVENT = 1,
 		VARIABLE = 2,
		COORDINATE = 3,
		SCALE = 4,
		POSITION = 5,
		ROTATION = 6,
		LINK = 7,
		UNLINK = 8,
                /* the rest are experimental */
		TEXTURE1D = 9,
		SPIN = 10,
                TEXTURE2D = 11
      } MsgType;

typedef struct position_st {
    float x, y, z;
} position;

typedef struct rotation_st {
    float a, b, c;
} rotation;

typedef struct dvs_msg_st {
    MsgType msg_type;
    char object[32];
    char event[32];
    position pos;
    rotation rot;
    char entity[32];
    ECAssembly * assembly;
} dvs_msg;

/* functions */
extern void MsgSendEvent (dvs_msg *msg);
extern void MsgSendVariable (dvs_msg *msg);
extern void MsgSendCoordinate (dvs_msg *msg);
//extern void MsgSendLink	(dvs_msg *parent_msg, dvs_msg *child_msg);
extern void MsgSendLink	(dvs_msg *msg);
extern void MsgSendUnLink (dvs_msg *msg);
extern void MsgSendTexture1D (dvs_msg *msg);
extern void MsgSendScale (dvs_msg *msg);
extern void MsgSendSpin (dvs_msg *msg);
extern void MsgSendTexture2D (dvs_msg *msg);

extern void MsgGetCoordinate (dvs_msg *msg, position *scale);

extern float MsgGetVariable (char *var_name_str);
/* extern int dviseMessageMain(int argc, char **argv); */

extern void AddCollision (char *assembly1, char *assembly2);

//extern void FindAssembly (char name[32], char entity[32], ECAssembly *assembly);
extern ECAssembly* Get_Assembly(char *name, char *entity);
