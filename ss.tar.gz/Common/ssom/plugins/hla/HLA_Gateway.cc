#include <iostream>
#include <stdlib.h>
#include <string>
#include <cstring>
//#include "windows.h"

#include "NullFederateAmbassador.hh"
using namespace std;

#define BUFFER_SIZE 100000
#define NAMING_SIZE 200
#define FED_TAG getenv("FED_TAG")
#define HLA_NAME getenv("HLA_NAME")
#define HLA_FAILED "!!!"

// "MATREX_FOMV0.5"
#define MAX_CLASSES 100000

extern "C" {
  // callback for receiving parameters/attributes of message
  // reentrant-safe only if 1 receiver thread invoked
  //REMOVED void Callback_Message (const char *Msg,
  //                       const char *Attr,
  //                       const char *Data,
  //                       const RTI::ULong Length,
  //                       const long Time);
  // callback for sending parameters/attributes of message
  // requires a lock if multiple threaded senders invoked
  //REMOVED  void Get_Tuple (char *Param, char Data[], int *Length);

  // KBASE accessors
  //REMOVED  char *get_hla_int_name (int Group, int ID);
  //REMOVED  char *get_hla_obj_name (int Group, int ID);
  //REMOVED  int   get_hla_obj_atts (int Group, int ID);
  //REMOVED  char *get_hla_att_name (int Group, int ID, int Index);
  //REMOVED  int   get_hla_int_mode (int Group, int ID);
  //REMOVED  int   get_hla_obj_mode (int Group, int ID);
}

int FH; // FederateHandle
char Phase_Name[100];   // Contains the name of the phase we have synchronized
int Synch_Achieved;     // Whether synchronization phase achieved
char Phase_Time[100];   // Contains the time
long Receive_Interaction_Counter = 0;
char Initial_Name[BUFFER_SIZE];
typedef void *(CB) (const char *Msg,
                    const char *Attr,
                    const char *Data,
                    const RTI::ULong Length,
                    const long Time);


class HLA_Gateway : public NullFederateAmbassador
{
private:
   RTI::RTIambassador _rtiAmbassador;  // libRTI provided
   int group;
   std::string Federation_Name;
   CB *Callback_Message;
public:
   void Register (CB Call_Back) {
      this->Callback_Message = Call_Back;
   }
   virtual ~HLA_Gateway() throw (RTI::FederateInternalError) { }

   void tick ()
   {
     _rtiAmbassador.tick();
   }

  void start(char *fed_path,
             char *federate_name,
             char *federation_name,
             int Group,
             char *(get_hla_int_name) (int Group, int ID),
             char *(get_hla_obj_name) (int Group, int ID),
             int   (get_hla_obj_atts) (int Group, int ID),
             char *(get_hla_att_name) (int Group, int ID, int Index),
             int   (get_hla_int_mode) (int Group, int ID),
             int   (get_hla_obj_mode) (int Group, int ID)
            )
   {
      // std::ios::sync_with_stdio();
      group = Group;
      Federation_Name = std::string(federation_name);
      if (HLA_NAME == NULL) {
         cout << "HLA_NAME must be set as an environment variable, exiting." << endl;
         exit(0);
      }
      //_rtiAmbassador = new RTI::RTIambassador();
      sprintf(Initial_Name, HLA_NAME);
      sprintf(Phase_Name, "Unknown");
      sprintf(Phase_Time, "0");
      Synch_Achieved = 0;

      try {
         // if (Group == 0) {
         try {
             cout << "Federation:" << federation_name << " " << fed_path << endl;
            _rtiAmbassador.createFederationExecution(federation_name,
                                                     fed_path  // "../ssom/rti/MATREX_FOMV0.5.fed"
             );
         } catch (RTI::FederationExecutionAlreadyExists) {
             // cout << "Federation Execution Already Exists." << endl;
         } catch (RTI::Exception& e) {
             cout << "THE CONNECTION TO THE RTI NEVER CREATED" << endl;
             cout << &e << endl;
         }

         FH = (int) _rtiAmbassador.joinFederationExecution(federate_name,
                                                           federation_name,
                                                           (RTI::FederateAmbassadorPtr) this);
         // }

         // Register Interaction messages from the KBASE
         for (int I=1; I<MAX_CLASSES; I++) {
            char* Name = get_hla_int_name (Group, I);
            if (strlen(Name) == 0) break;
            cout << Name << " registered." << endl;
            RTI::InteractionClassHandle ICH = _rtiAmbassador.getInteractionClassHandle(Name);
            int Mode = get_hla_int_mode (Group, I);
            if (Mode >= 0) {
              _rtiAmbassador.publishInteractionClass(ICH);
            }
            if (Mode <= 0) {
              _rtiAmbassador.subscribeInteractionClass(ICH);
            }
            //_rtiAmbassador.subscribeInteractionClass(ICH);
            //_rtiAmbassador.publishInteractionClass(ICH);
         }
         cout << "interactions registered" << endl;

         // Register Objects and Attributes from the KBASE
         char IName[BUFFER_SIZE];
         for (int I=1; I<MAX_CLASSES; I++) {
            char* Name = get_hla_obj_name (Group, I); // + InstanceName?
            if (strlen(Name) == 0) break;
            cout << Name << " registered." << endl;
            RTI::ObjectClassHandle OCH = _rtiAmbassador.getObjectClassHandle(Name);
            int Num = get_hla_obj_atts (Group, I);
            RTI::AttributeHandleSet* ahs = RTI::AttributeHandleSetFactory::create(Num);
            for (int J=1; J<=Num; J++) {
               char *Att = get_hla_att_name (group, I, J);
               // cout << Att << ":attribute" << endl;
               ahs->add(_rtiAmbassador.getAttributeHandle(Att, OCH));
            }
            int Mode = get_hla_obj_mode (Group, I);
            if (Mode >= 0) {
              _rtiAmbassador.publishObjectClass(OCH, *ahs);
              if (Group==0) {
                  sprintf(IName, "%s", HLA_NAME);
              } else {
                  sprintf(IName, "%d%s%s", Group, HLA_NAME, Name);
              }
              RTI::ObjectClassHandle OI = _rtiAmbassador.registerObjectInstance(OCH, IName);

            }
            if (Mode <= 0) {
              _rtiAmbassador.subscribeObjectClassAttributes(OCH, *ahs);
              _rtiAmbassador.requestClassAttributeValueUpdate (OCH, *ahs);
            }
            // _rtiAmbassador.publishObjectClass(OCH, *ahs);
            // Note that IName is used for update below
         }

      } catch (RTI::NameNotFound) {
         cout << "NAME NOT FOUND" << endl;
         return;
      } catch (RTI::FederateNotExecutionMember) {
         cout << "NOT MEMBER" << endl;
         return;
      } catch (RTI::ConcurrentAccessAttempted) {
         cout << "CONCURRENT ACCESS" << endl;
         return;
      } catch (RTI::RTIinternalError) {
         cout << "RTI INTERNAL ERROR" << endl;
         return;
      } catch (RTI::Exception& e) {
         cout << "THE CONNECTION TO THE RTI NEVER COMPLETED" << endl;
         cout << &e  << endl;
         sprintf(Phase_Name, HLA_FAILED);
         return;
      }
      sprintf(Phase_Name, "Standby");
   }
   void update(const char *Name,
               const int N,
               void *(Get_Tuple)(char *Param, char Data[], int *Length)
               ) // add an instance name here?
   {
      char Attribute[BUFFER_SIZE], Value[BUFFER_SIZE];
      int Length;
      RTI::ObjectClassHandle OCH;
      char IName[BUFFER_SIZE];

      OCH = _rtiAmbassador.getObjectClassHandle(Name);


      if (HLA_NAME && (group==0)) {
         if (strcmp (HLA_NAME, Initial_Name)) {
            try {
               RTI::ObjectClassHandle OI = _rtiAmbassador.registerObjectInstance(OCH, HLA_NAME);
               sprintf(Initial_Name, HLA_NAME);
            } catch (RTI::ObjectAlreadyRegistered) {
    	       cout << HLA_NAME << " already registered HLA Instance." << endl;

            }
         }
         sprintf(IName, "%s", HLA_NAME);
      } else {
         sprintf(IName, "%d%s%s", group, HLA_NAME, Name);
      }

		// Note that IName is used from register above
//	sprintf(IName, "%d%s%s", group, Name, EntityStateDecoration);
      RTI::ObjectHandle OID = _rtiAmbassador.getObjectInstanceHandle(IName);

      try {

         RTI::AttributeHandleValuePairSet* attributes = RTI::AttributeSetFactory::create(N);

         for (int I=0; I<N; I++) {
           // Get parameter handles & values (i.e. Tag/Value in XML parlance)
           Get_Tuple(Attribute, Value, &Length);
			  RTI::AttributeHandle ATTR_HDL = _rtiAmbassador.getAttributeHandle(Attribute, OCH);

			  // Check for ownership before update
			  if (_rtiAmbassador.isAttributeOwnedByFederate(OID, ATTR_HDL)){
              attributes->add(ATTR_HDL, Value, Length);
			  } else {
				  cout << Attribute << " not owned. No update performed for that attribute."<< endl;
			  }
         }

         _rtiAmbassador.updateAttributeValues(OID, *attributes, FED_TAG);
         delete attributes;

      } catch (RTI::Exception& e) {
         cout << &e  << endl;
      }

   }

   void send(const char *Name, 
             const int N,
             void *(Get_Tuple)(char *Param, char Data[], int *Length))
   {
      char Param[BUFFER_SIZE], Value[BUFFER_SIZE];
      int Length;
      RTI::InteractionClassHandle ICH = _rtiAmbassador.getInteractionClassHandle(Name);

      try {
         RTI::ParameterHandleValuePairSet* parameters = RTI::ParameterSetFactory::create(N);

         for (int I=0; I<N; I++) {
           // Get parameter handles & values (i.e. Tag/Value in XML parlance)
           Get_Tuple(Param, Value, &Length);

           parameters->add(_rtiAmbassador.getParameterHandle(Param, ICH), Value, Length);
         }

         _rtiAmbassador.sendInteraction(ICH, *parameters, FED_TAG);
         delete parameters;
      } catch (RTI::Exception& e) {
         cout << &e  << endl;
      }


   }

   void quit()
   {
     // Group is not used unless we need to know the name of the Fed
     //if (Group == 0) {

      cout << "quitting HLA gateway:" << group << endl;
      try {
         _rtiAmbassador.resignFederationExecution(
            RTI::DELETE_OBJECTS_AND_RELEASE_ATTRIBUTES );
         try {
            _rtiAmbassador.destroyFederationExecution(Federation_Name.c_str());
         } catch (RTI::FederatesCurrentlyJoined) {
         }
      } catch (RTI::Exception& e) {
         cout << &e << endl;
      }
    //}
   }

   void receiveInteraction (
           RTI::InteractionClassHandle       theInteraction,
     const RTI::ParameterHandleValuePairSet& theParameters,
     const char                             *theTag)
   throw (
     RTI::InteractionClassNotKnown,
     RTI::InteractionParameterNotKnown,
     RTI::FederateInternalError)
   {
      //float Time = 9.99; // May not need to use this
      Receive_Interaction_Counter += 1;
      const char *Object = _rtiAmbassador.getInteractionClassName(theInteraction);

      cout << "Received: " << Object << "::" << theTag << endl;
      for (unsigned int i = 0; i < theParameters.size(); ++i) {

        try {
           char Buffer[BUFFER_SIZE];
           RTI::ULong Length = theParameters.getValueLength(i);

           theParameters.getValue(i, Buffer, Length);
           char *PN = _rtiAmbassador.getParameterName(theParameters.getHandle(i),
                                                      theInteraction);
           Callback_Message (Object, PN, Buffer, Length, Receive_Interaction_Counter);

        }
        catch (RTI::ArrayIndexOutOfBounds& e) {
           cout << &e  << endl;
        }
     }
   }

   void receiveInteraction (
           RTI::InteractionClassHandle       theInteraction,
     const RTI::ParameterHandleValuePairSet& theParameters,
     const RTI::FedTime&                     theTime,
     const char                              *theTag,
           RTI::EventRetractionHandle        theHandle)
   throw (
     RTI::InteractionClassNotKnown,
     RTI::InteractionParameterNotKnown,
     RTI::InvalidFederationTime,
     RTI::FederateInternalError)
   {
     cout << "receiveInteraction#2" << endl;
     receiveInteraction(theInteraction, theParameters, theTag);
   }

   virtual void discoverObjectInstance (
           RTI::ObjectHandle          theObject,
           RTI::ObjectClassHandle     theObjectClass,
     const char *                     theObjectName)
   throw (
     RTI::CouldNotDiscover,
     RTI::ObjectClassNotKnown,
     RTI::FederateInternalError)
   {
     cout << "discoverObjectInstance " << theObjectName << endl;
   }

   virtual void reflectAttributeValues (
           RTI::ObjectHandle                 theObject,
     const RTI::AttributeHandleValuePairSet& theAttributes,
     const char                              *theTag)
   throw (
     RTI::ObjectNotKnown,
     RTI::AttributeNotKnown,
     RTI::FederateOwnsAttributes,
     RTI::FederateInternalError)
   {
     // float Time = 1.11; // May not need to use this
     Receive_Interaction_Counter += 1;
     cout << "reflectAttributeValues " << theTag << endl;
     const RTI::ObjectClassHandle OCH = _rtiAmbassador.getObjectClass(theObject);
     const char *Object = _rtiAmbassador.getObjectClassName(OCH); // theObject);
     cout << "reflectAttributeValues " << Object << endl;
     for (unsigned int i = 0; i < theAttributes.size(); ++i) {
        try {
           char Buffer[BUFFER_SIZE];
           RTI::ULong Length = theAttributes.getValueLength(i);

           theAttributes.getValue(i, Buffer, Length);
           char *ON = _rtiAmbassador.getAttributeName(theAttributes.getHandle(i),
                                                      OCH);
           Callback_Message (Object, ON, Buffer, Length, Receive_Interaction_Counter);
        }
        catch (RTI::ArrayIndexOutOfBounds& e) {
           cout << &e  << endl;
        }
     }
   }


   int getFedHandle () {
     return FH;
   }

   void announceSynchronizationPoint (const char *label, const char *tag)
   throw (RTI::FederateInternalError)
   {
     try {
         sprintf(Phase_Name, label);
         sprintf(Phase_Time, tag);
         Synch_Achieved = 1;
         cout << "#############################################" << endl;
         cout << "####### SYNCH POINT " << label << " @ " << tag << endl;
         cout << "#############################################" << endl;
     }
     catch (RTI::FederateInternalError& e) {
        cout << &e  << endl;
     }
   }

   void federationSynchronized (const char *label)
   throw (RTI::FederateInternalError)
   {
     try {
         cout << "####################################" << endl;
         cout << "####### FEDERATION SYNCHED " << label << endl;
         cout << "####################################" << endl;
     }
     catch (RTI::FederateInternalError& e) {
        cout << &e  << endl;
     }
   }

   void achieved (const char *Phase_Name) {
      _rtiAmbassador.synchronizationPointAchieved(Phase_Name);
   }

};

HLA_Gateway* hlaGateway;
int OK = 0;


   // For every vehicle application, there will be a primary Federate "gateway"
   // This is given a static handle for convenient access.
   // Any secondary gateways added need to be handled remotely, by passing in
   // an extra parameter, default set to NULL.


   // X
extern "C" {

  HLA_Gateway* Startup_Gateway(
             char *fed_path,
             char *federate_name,
             char *federation_name,
             int  Group,
             char *(get_hla_int_name) (int Group, int ID),
             char *(get_hla_obj_name) (int Group, int ID),
             int   (get_hla_obj_atts) (int Group, int ID),
             char *(get_hla_att_name) (int Group, int ID, int Index),
             int   (get_hla_int_mode) (int Group, int ID),
             int   (get_hla_obj_mode) (int Group, int ID)
             )
   {
      if (hlaGateway) {
         cout << "SECONDARY Gateway" << endl;
         // Primary already set
         HLA_Gateway* HG = new HLA_Gateway();
         HG->start(fed_path, federate_name, federation_name, Group,
                   get_hla_int_name, get_hla_obj_name, get_hla_obj_atts,
                   get_hla_att_name, get_hla_int_mode, get_hla_obj_mode);
         return HG;
      } else {
         // Set_Unique_Name ();
         cout << "PRIMARY Gateway" << endl;
         OK = 1;
         // Create primary
         hlaGateway = new HLA_Gateway();
         hlaGateway->start(fed_path, federate_name, federation_name, Group,
                   get_hla_int_name, get_hla_obj_name, get_hla_obj_atts,
                   get_hla_att_name, get_hla_int_mode, get_hla_obj_mode);
         if (!strcmp(Phase_Name, HLA_FAILED))
            return (0);
         else
            return (hlaGateway);
      }
   }

   // X
   void Receive_Message (HLA_Gateway* HG,
                         CB Call_Back)
   {
      if (OK) {
         if (HG) {
            HG->Register(Call_Back);
            HG->tick();
         } else {
            hlaGateway->Register(Call_Back);
            hlaGateway->tick();
         }
      }
   }

   // X
   void Send_Message (const char *Name, const int N,
                      HLA_Gateway* HG,
                      void *(Get_Tuple)(char *Param, char Data[], int *Length)) {
      if (OK) {
         if (HG) {
            HG->send(Name, N, Get_Tuple);
         } else {
            hlaGateway->send(Name, N, Get_Tuple);
         }
      }
   }

   // X
   void Update_Attributes (const char *Name,
                           const int N,
                           HLA_Gateway* HG,
                           void *(Get_Tuple)(char *Param, char Data[], int *Length)) {
      if (OK) {
         if (HG) {
            HG->update(Name, N, Get_Tuple);
         } else {
            hlaGateway->update(Name, N, Get_Tuple);
         }
      }
   }

   // *
   void Exit_Gateway(HLA_Gateway* HG) {
      if (HG) {
         HG->quit();
//         delete HG;
      } else {
         OK = 0;
         hlaGateway->quit();
//         delete hlaGateway;
      }
   }

   int Get_Federate_Handle (HLA_Gateway* HG) {
      if (OK) {
         if (HG) {
            return HG->getFedHandle();
         } else {
            return hlaGateway->getFedHandle();
         }
      } else {
         return 0;
      }
   }

   char * Get_Phase () {
      if (OK) {
         if (Synch_Achieved == 1) {
            cout << "####################################" << endl;
            cout << "####### SYNC ACHIEVED " << Phase_Name << endl;
            cout << "####################################" << endl;
            hlaGateway->achieved(Phase_Name);
//            _rtiAmbassador.synchronizationPointAchieved(Phase_Name);
            Synch_Achieved = 0;
            // return "";
         }
      }
      return Phase_Name;
   }

   char * Get_Phase_Time () {
      return Phase_Time;
   }
}


//#include <windows.h>
//BOOL APIENTRY DllMain(HANDLE hModule,
//                      DWORD  ul_reason_for_call,
//                      LPVOID lpReserved)
//{
//    return TRUE;
//}
