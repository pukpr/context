#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>

char __gnat_version[46] = "GNAT Version: (6.2.1 from sumit_plugin.c)    \0";

typedef enum {  EVENT = 1,
 		VARIABLE = 2,
		COORDINATE = 3,
		SCALE = 4,
		POSITION = 5,
		ROTATION = 6,
		LINK = 7,
		UNLINK = 8,          /* the rest are experimental */
		TEXTURE1D = 9,
		SPIN = 10,
      TEXTURE2D = 11
      } MsgType;

typedef struct position_st {
    float x, y, z;
} position;

typedef struct rotation_st {
    float a, b, c;
} rotation;

typedef struct dvs_msg_st {
    MsgType msg_type;
    char object[32];
    char event[32];
    position pos;
    rotation rot;
    char entity[32];
    char * assembly;
} dvs_msg;

// need to store a one-time queue handle here
void MsgSendEvent(dvs_msg *msg) {
   fprintf (stderr, "%s %s\n", "PLUGIN--SendEvent--", msg->object);
};
void MsgSendVariable(dvs_msg *msg)  {
   fprintf (stderr, "%s\n", "PLUGIN--SendVar--");
};
void MsgSendCoordinate(dvs_msg *msg) {
   fprintf (stderr, "%s %s\n", "PLUGIN--SendCoord--", msg->object);
};
void MsgSendLink(dvs_msg *msg) {
   fprintf (stderr, "%s\n", "PLUGIN--SendLink--");
};
void MsgSendUnLink(dvs_msg *msg) {
   fprintf (stderr, "%s\n", "PLUGIN--SendUnlink--");
};
void MsgSendTexture1D(dvs_msg *msg) {
   fprintf (stderr, "%s\n", "PLUGIN--SendTexture1D--");
};
void MsgSendScale(dvs_msg *msg) {
   fprintf (stderr, "%s\n", "PLUGIN--SendScale--");
};
void MsgSendSpin(dvs_msg *msg) {
   fprintf (stderr, "%s\n", "PLUGIN--SendSpin--");
};
void MsgSendTexture2D(dvs_msg *msg) {
   fprintf (stderr, "%s\n", "PLUGIN--SendTexture2D--");
};
void MsgGetCoordinate(dvs_msg *msg, position *scale) {
   fprintf (stderr, "%s\n", "PLUGIN--GetCoord--");
};
void *Get_Assembly(char *name, char *entity) {
   fprintf (stderr, "%s\n", "PLUGIN--Get_Assembly--");
};

void Load_Plugin (int argc, char *argv[]) {
   void *handle;
   char *error;
   void (*pace_synch)(int);
   char *Plugin_Path = getenv ("SUMIT_PLUGIN_PATH");
  
   if (!Plugin_Path) {
      fprintf (stderr, "SUMIT_PLUGIN_PATH not defined\n");
      return;
   }
   // Load the PLUGIN shared library
   //
   handle = dlopen(Plugin_Path, RTLD_LAZY);
   if (!handle) {
      fprintf (stderr, "Loading SUMIT_PLUGIN_PATH: %s\n", dlerror());
   } else {
      // Load the interface by finding the symbol
      // 
      pace_synch = dlsym(handle, "pace_synch");
      if ((error = dlerror()) != NULL)  {
          fprintf (stderr, "Starting Sumit Plugin: %s\n", error);
          return;
      }
      // The interface corresponding to the symbol is dereferenced
      //                  ... according to the signature defined
      (*pace_synch)(1); 

      // Keep the main alive
      while(1) {
        sleep (1);
      }
      dlclose(handle);
   }
}

int main (int argc, char *argv[]) {
   Load_Plugin (argc, argv);
   return 0;
}
