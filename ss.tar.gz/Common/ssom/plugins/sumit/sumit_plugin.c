#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern int gnat_argc;
extern char **gnat_argv;
char __gnat_version[46] = "GNAT Version: (6.2.1 from dvise_plugin.c)    \0";

/* This is the standard entry point */
 void SumitEntryPoint (void) {
   char *name[] = {"sumit_plugin"};
   gnat_argc = 0; /* argc; */
   gnat_argv = name;
 }

// this has got to be exactly 46 characters long:  see g-comver.ads
// char __gnat_version[46] = "GNAT Version: (6.2.1 from dvise_plugin.c)    \0";



