swig -python example.i
gcc -c example.c example_wrap.c -I/prog/shared/modsim/commontools/i686-pc-linux-gnu/python-2.4.3/include/python2.4/
ld -shared example.o example_wrap.o -o example.so
