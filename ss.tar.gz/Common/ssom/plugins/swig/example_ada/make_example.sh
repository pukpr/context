swig -python example.i
gcc -c example_wrap.c -I/prog/shared/modsim/commontools/i686-pc-linux-gnu/python-2.4.3/include/python2.4/
gnatmake example_main.adb -o example.so -largs -shared example_wrap.o 

