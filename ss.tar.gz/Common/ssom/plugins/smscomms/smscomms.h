extern "C" {
extern void smsRot (char *Name, float A, float B, float C);
extern void smsPos (char *Name, float X, float Y, float Z);
extern void smsCoord (char *Name, float X, float Y, float Z, float A, float B, float C);
extern void smsEvent (char *Name, char *Event);
extern void smsStart (int argc, char *argv[]);
extern void smsLink (char *Parent, char *Child);
extern void smsUnlink (char *Assembly);
extern void smsProjMagSet (float Value);
extern void smsPropMagSet (float Value);
}

/* requires -lthread          -- some type of threading library
            -lm               -- math library
            -lsocket -lnsl    -- socket library
            -lrt              -- real time clock library

$id: smscomms.h,v 1.1 11/04/2003 14:34:15 pukitepa Exp $ */
