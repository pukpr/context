/* gcc test.c ../../../lib/Linux/libsmscomms.a $ADASRC/../adalib/libgn*.a -lm -lpthread -ldl  */

#include <stdio.h>
#include "../../include/smscomms.h"

int main(int argc, char *argv[]) {

   smsStart(argc, argv);
   smsEvent ("assembly", "event");
   smsLink ("assembly", "link");
   smsUnlink ("assembly");
   smsRot ("assembly", 1.0, 1.0, 1.0);
   smsPos ("assembly", 1.0, 1.0, 1.0);
   smsCoord ("assembly", 1.0, 1.0, 1.0, 1.0, 1.0, 1.0);
    
}
