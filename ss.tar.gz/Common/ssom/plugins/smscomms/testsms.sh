g++ test.c ../../../lib/Linux/libsmscomms.a $ADASRC/../adalib/libgn*.a -lm -lpthread -ldl
env PACE_NODE=1 ./a.out
