
extern "C" {
  void create_udp_socket(char * hostname, char * port);
  void send_msg(void *buf, int len);
}
