
#include <iostream>

#include "udp_client.h"
#include "vputils/udp_socket.h"

using namespace std;

namespace {
  udp_socket socket;
  string my_host;
  string my_port;
}

void create_udp_socket(char * hostname, char * port) {
  my_host = hostname;
  my_port = port;
  if (!socket.connect(my_host, my_port)) {
    cerr << "connect_udp: could not create socket and connect to host " << my_host << " and port " << my_port << endl;
  } else {
    cout << "Got udp socket for host " << my_host << " and port " << my_port << endl;
  }
}

void send_msg(void *buf, int len) {
  socket.send_msg(buf, len);
}
