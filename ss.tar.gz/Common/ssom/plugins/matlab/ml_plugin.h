#include <windows.h>
#include <stdio.h>

#define GETPROC(name) \
   static int Started = 0;\
   static name##_fxn name##_dll;\
   if (!Started) {\
      Started = 1;\
      name##_dll=(name##_fxn)GetProcAddress(Get_Instance_Lib(), #name);\
      if (name##_dll == NULL) {\
         printf("ERROR: unable to find DLL function %s\n", #name);\
         exit(1);\
      }\
   }

extern void Set_Instance_Lib (HINSTANCE h);
extern HINSTANCE Get_Instance_Lib (void);
extern void startup_plugin (char *dll_name, char *ini_name);
