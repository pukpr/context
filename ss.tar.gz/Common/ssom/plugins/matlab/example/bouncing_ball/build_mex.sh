mex -I../../templates -I../.. timestwo.c ../../templates/startup_ada_plugin.c ../../ml_plugin.c
