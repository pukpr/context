//  This gets placed via option in RTW/Custom Code/Source files/
//  startup_ada_plugin.c

#include "ml_plugin.h"

void startup_ada_plugin () {
   startup_plugin ("ml_plugin.exe", "ada_initialize");
}

/////// Example of function of 2 parameters
double scaleNumbers (double a, double b) {
  typedef double (*ml_value_fxn)(double, double);
  GETPROC(ml_value);
  return ml_value_dll(a, b);
}

/////// Example of function of 1 parameter
void sendData (double v) {
  typedef void (*send_data_fxn)(double);
  GETPROC(send_data);
  send_data_dll(v);
}

void DispatchOutput (double PARAM, const double * const* uPtrs, 
                     int width, int Major, double Time, double *y) {
  typedef void (*dispatch_output_fxn)(double, double **, int, int, double, double *);
  GETPROC(dispatch_output);
  dispatch_output_dll (PARAM, uPtrs, width, Major, Time, y);
}

