#include <stdio.h>
#include "startup_ada_plugin.h"

int main(int argc, char **argv)
{
    double result;

    startup_ada_plugin ();
    // Call function.
    result = addNumbers(10, 2);

    // Unload DLL file
    // FreeLibrary(hinstLib);

    // Display result
    printf("The result was: %f\n", result);

    return 0;
}

