//  This gets placed via option in RTW/Custom Code/Header file/
//  #include "startup_ada_plugin.h"

// Called once via RTW/Custom Code/Initialize function/
extern void startup_ada_plugin ();

// Called from various S-functions
extern double scaleNumbers (double a, double b);
extern void sendData (double v);
extern void DispatchOutput (double PARAM, 
                            const double * const* uPtrs, int width,
                            int Major, double Time, double *y);
