//  This gets placed via option in RTW/Custom Code/Source files/
//  ml_plugin.c

#include <windows.h>
#include <stdio.h>

HINSTANCE hinstLib;
void Set_Instance_Lib (HINSTANCE h) {
   hinstLib = h;
}
HINSTANCE Get_Instance_Lib (void) {
   return hinstLib;
}

/////// Called once from user initializer function
void startup_plugin (char *dll_name,
                     char *ini_name) {
   static int Initialized = 0;
   if (!Initialized) {
      typedef void (*importInitFunction)();
      importInitFunction startUp;
      Initialized = 1;
      hinstLib = LoadLibrary(dll_name);
      if (hinstLib == NULL) {
         printf("ERROR: unable to load DLL = %s\n", dll_name);
         exit (1);
      }
      startUp = (importInitFunction)GetProcAddress(hinstLib, ini_name);
      if (startUp == NULL) {
         printf("ERROR: unable to start DLL function = %s\n", ini_name);
         FreeLibrary(hinstLib);
         exit (1);
      }
      startUp();
   }
}
