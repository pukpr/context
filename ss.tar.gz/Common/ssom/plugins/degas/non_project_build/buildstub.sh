OS=`uname -s`

touch junk.c

case $OS in
 SunOS) mkdir -p SunOS/stub; gcc junk.c -G -o SunOS/stub/libdegas.so;;
 IRIX*) mkdir -p IRIX/stub; gcc junk.c -shared -o IRIX/stub/libdegas.so;;
 Linux) mkdir -p Linux/stub; gcc junk.c -shared -o Linux/stub/libdegas.so;;
 *) echo "Build not configured for" $OS;;
esac

rm junk.c

