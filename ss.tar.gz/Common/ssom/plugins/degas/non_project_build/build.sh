OS=`uname -s`

case $OS in
 SunOS) mkdir -p SunOS; gcc degas.c -G -DSUNOS=1 -o SunOS/libdegas.so; r=$? ;;
 IRIX*) mkdir -p IRIX; gcc degas.c -shared -DIRIX=1  -o IRIX/libdegas.so; r=$? ;;
 Linux) mkdir -p Linux; gcc degas.c -shared -DLINUX=1 -o Linux/libdegas.so; r=$? ;;
 *) echo "Build not configured for" $OS; r=1;;
esac

if [ $r -eq 0 ]
then echo "Build complete for" $OS
else echo "Build failed for" $OS
fi

