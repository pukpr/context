## g++ -I/usr/include/gtk-1.2 -I/usr/include/glib-1.2 -I/usr/lib/glib/include -I/usr/X11R6/include -DMOZ_WIDGET_GTK TestGtkEmbed1.cpp -L/usr/lib -L/usr/X11R6/lib -lgtk -lgdk -rdynamic -lgmodule -lglib -ldl -lXi -lXext -lX11 -lm -lgtkembedmoz

g++ `gtk-config --cflags` -DMOZ_WIDGET_GTK -o TestGtkEmbed1 TestGtkEmbed1.cpp `gtk-config --libs` -lgtkembedmoz
