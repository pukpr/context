// The matrix from the ssom to
// Vega.  This matrix  is applied
// to incoming data.  Its inverse
// is applied to data going out.


double ssom2vega[4][4] =
{ 
  {1.0, 0.0, 0.0, 0.0},
  {0.0, 0.0, 1.0, 0.0},
  {0.0, 1.0, 0.0, 0.0},
  {0.0, 0.0, 0.0, 1.0}
};

/* For DVise based SMS, the transform should be:
double ssom2vega[4][4] =
{ 
  {-1.0, 0.0, 0.0, 0.0},
  {0.0, 0.0, 1.0, 0.0},
  {0.0, 1.0, 0.0, 0.0},
  {0.0, 0.0, 0.0, 1.0}
};

But for historical reasons, the automotives don't follow this convention.
so we do not negate x translations and rotations.
setenv SMS_COORD_SYSTEM 1 to turn on the SMS convention.
*/

/* This one (unity) is for the JACK PLAYER. */

/*double ssom2vega[4][4] =
{ 
  {1.0, 0.0, 0.0,  0.0},
  {0.0, 1.0, 0.0,  0.0},
  {0.0, 0.0, 1.0, 0.0},
  {0.0, 0.0, 0.0,  1.0}
};*/




typedef enum {  EVENT = 1,
 		VARIABLE = 2,
		COORDINATE = 3,
		SCALE = 4,
		POSITION = 5,
		ROTATION = 6,
		LINK = 7,
		UNLINK = 8,
		TEXTURE1D = 9,
		SPIN = 10,
                TEXTURE2D = 11} MsgType;

typedef struct position_st {
    float x, y, z;
} position;

typedef struct rotation_st {
    float a, b, c;
} rotation;

typedef struct dvs_msg_st {
    MsgType msg_type;
    char object[32];
    char event[32];
    position pos;
    rotation rot;
    char entity[32];
} dvs_msg;

/* functions */
extern "C"{
  void MsgSendEvent (dvs_msg *msg);
  void MsgSendVariable (dvs_msg *msg);
  void MsgSendCoordinate (dvs_msg *msg);
  void MsgSendLink	(dvs_msg *msg);
  void MsgSendUnLink (dvs_msg *msg);
  void SetRotOrder(char *entity, char *dof, char *ro);
  float MsgGetVariable (char *var_name_str);
  void GetTerrainHeight(float z, float x, int * data_good, float *h);
  void GetCoordinate(char * entity, char * assembly, int is_absolute, int * data_good, position *pos, rotation *ori);
  
  // 32 is max length of entity and geom_type due to Division restriction
  void CreateObject (char * entity, char * geom_type, position *pos, rotation *rot, int is_ground_clamp, int is_instance);
  
  // fx_type can be one of: "trail".
  void CreateEffect (char * entity, char * fx_type, position *pos, rotation *rot);
  
  // Init must be called before using this interface.
  void Init();
  
  // Set switch node states.
  void SetSwitch(char *entity, char *switch_node_name, int state);
  
  // Impact a munition.  This does the effects for the impact.
  void Impact(position *pos, char *munition);
  
  // Launch a munition.  This does the effects for the launch.
  void Launch(char *source, char *munition);
  
  // Start a plot of an object's motion.
  // Precondition: a plot has been added to the object.
  void StartPlot(char *entity);
  
  // Stop plotting an object's motion.
  void StopPlot(char *entity);
  
  void Player(char *filename);

  // Commit the queue of messages to the VE.
  void Commit();
}

