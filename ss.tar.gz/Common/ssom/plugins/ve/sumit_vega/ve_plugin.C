#include "damager.h"
#include "vputils/osutils.h"
#include "vputils/textutils.h"
#include "vp_matrix.h"
#include "ve_inet.h"
#include "playerThread.h"
#include "ve_plugin.h"

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <math.h>
#include <stdio.h>
#include <unistd.h>
#include <sstream>
#include <sys/resource.h>
#include <signal.h>
#include <iostream>
#include <map>
#include <vector>


using namespace std;
//using namespace vputils;

namespace{

  static vp_matrix s2v(4,4), v2s(4,4);

  int Debug_Output = 0;                                           
  int Display_Output = vputils::toint(vputils::getenv("SUMIT_VERBOSE","0"));
  const string default_veh = "nlos155_1";
  const double r2d = 180.0/M_PI;
  const double d2r = M_PI/180.0;
  
  
  
  // mapping of the original instance names to geometry types
  // pattern is for the instance name to be DUMMY_PREFIX_index .. ex. dummy_0
  // the value at each index is the corresponding geometry type
  const string DUMMY_PREFIX = "dummy_";
  const int NUM_TYPES = 6;
  string instance_types [NUM_TYPES];
  int num_dummies = 0;  // starts at 0 and increases to NUM_TYPES as addDummyInstance is called
  // Create an interface to the VE that queues messages and sends them 
  // only by calling commit() on the iface->
  ve_inet *iface;
  
  damager myDamager;
  
  typedef vector<playerThread*> playerThreadsType;
  playerThreadsType players;
}

static void sighandler(int sig)
{
    if (SIGINT == sig || SIGHUP == sig) {
        delete iface;
        exit(0);
    }
}
                                           
// returns the original instance name of a geometry type
// if found will return "dummy_index" 
// if not found will return ""
static string get_instance_name (string type)
{
    for (int i = 0; i < NUM_TYPES; i++) {
      if (instance_types [i] == type) {
	ostringstream s;
	s << DUMMY_PREFIX << i;
	return s.str();
      }   
    }
    return "";
}

static vp_matrix to_vega(float x,float y,float z, string assembly)
{
    vp_matrix vpos(1,4);
    
    double vect[4];
    vect[3] = 1.0;
    vect[0] = x;
    vect[1] = y;
    vect[2] = z;
    vpos.set(vect,4);
    vpos = vpos.multiply(&s2v);
    return vpos;
}

static vp_matrix to_ssom(float x,float y,float z, string assembly)
{
    vp_matrix vpos(1,4);
    double vect[4];
    vect[3] = 1.0;
    vect[0] = x;
    vect[1] = y;
    vect[2] = z;
    vpos.set(vect,4);
    vpos = vpos.multiply(&v2s);
    return vpos;
}

string composeTrail(string &name)
{
    ostringstream s;
    s << "<fx>"
      << "<missile_trail>"
      << "<name>" << name << "</name>"
      << "<data><![CDATA[<ve_fx>"
      << "<overall_color><r>0.25</r><g>0.25</g><b>0.5</b></overall_color>"
      << "<scale><x>3.0</x><y>3.0</y><z>3.0</z></scale>"
      << "<length>2000.0</length>"
      << "<fade_out>30.0</fade_out>"
      << "</ve_fx>]]></data>"
      << "</missile_trail>"
      << "</fx>";
    return s.str();      
}

string composeExplosion(string &name)
{
   ostringstream s;
   s << "<fx>"
     << "<explosion>"
     << "<name>" << name << "</name>"
     << "</explosion>"
     << "</fx>";
   return s.str();
}

string composeFire(string &name)
{
   ostringstream s;
   s << "<fx>"
     << "<fire>"
     << "<name>" << name << "</name>"
     << "</fire>"
     << "</fx>";
   return s.str();
}

string composeSmoke(string &name)
{
   ostringstream s;
   s << "<fx>"
     << "<smoke>"
     << "<name>" << name << "</name>"
     << "</smoke>"
     << "</fx>";
   return s.str();
}

void Impact(position *pos, char *munition)
{
    if(!pos){
        return;
    }
    
    vp_matrix loc;
    loc = to_vega(pos->x, pos->y, pos->z, "");
    
    ostringstream s;
    s << "<event>"
      << "<impact>"
      << "<e>" << loc.ge(1,1) << "</e>"
      << "<n>" << loc.ge(1,2) << "</n>"
      << "<height>" << loc.ge(1,3) << "</height>"
      << "</impact>"
      << "<munition>" << munition << "</munition>"
      << "</event>";
      
    myDamager.addCommand(s.str());
}

void Player(char *filename)
{
    playerThread *player = new playerThread;
    player->load(filename);
    player->start();
    players.push_back(player);
}

void Launch(char *source, char *munition)
{   
    ostringstream s;
    s << "<event>"
      << "<source>" << source << "</source>"
      << "<munition>" << munition << "</munition>"
      << "</event>";
      
    myDamager.addCommand(s.str());
}

void MsgSendEvent (dvs_msg *msg)
{
    if(!iface){
        return;
    }
    
    string event(msg->event);
    string entity_str(msg->entity);
    string assembly(msg->object);
    
    if (Display_Output) {
        cout << "event: " << event << ", " << entity_str << ":" << assembly <<  ":" << endl;
    }

    if (event == "on") {
        iface->setVisibility (entity_str, assembly, true);
    } else if (event == "off") {
        iface->setVisibility(entity_str, assembly, false);
    } else if (event == "start_effect"){
        iface->trigger_effect(entity_str);
    } else if (event == "stop_effect"){
        iface->stop_effect(entity_str);
    }
    
    //iface->commit();
}



void MsgSendVariable (dvs_msg *msg)
{
    
    if (Display_Output) {
        printf("VAR: %s %s \n",msg->object,msg->event);  /* confirm to stdout. */
    }
    
}


void MsgSendCoordinate (dvs_msg *msg)
{ 
    if(!iface){
        return;
    }
    
    if(Debug_Output){
      printf("MOVE: entity: %s , assembly: %s (%g,%g,%g) (%g,%g,%g)\n", 
             msg->entity,
             msg->object,
             msg->pos.x, msg->pos.y, msg->pos.z,
             msg->rot.a, msg->rot.b, msg->rot.c); 
    }
    
    //ostringstream s;
    //s << entity;
    //string vehicle(s.str());
    
    string assembly((const char*)(msg->object));
    
    vp_matrix vpos = to_vega(msg->pos.x,
                             msg->pos.y,
                             msg->pos.z, assembly);
    
    
    vp_matrix vrot = to_vega(r2d * (msg->rot.a),
                             r2d * (msg->rot.b),
                             r2d * (msg->rot.c), assembly);
			     
    //vp_matrix vrot(1,3);
    //vrot.set_element(1,1, -r2d * msg->rot.a); //p
    //vrot.set_element(1,3, r2d * msg->rot.b); //h
    //vrot.set_element(1,2, r2d * msg->rot.c); //r

    switch (msg->msg_type){
       case ROTATION:
          iface->rotate(msg->entity,assembly, vrot.get_element(1,1), vrot.get_element(1,2),
                       vrot.get_element(1,3));
          break;
       case POSITION:
          iface->translate(msg->entity,assembly, vpos.get_element(1,1), vpos.get_element(1,2),
                          vpos.get_element(1,3));
          break;
       case COORDINATE:
          iface->rotate(msg->entity,assembly,vrot.get_element(1,1), vrot.get_element(1,2),
                       vrot.get_element(1,3));
          iface->translate(msg->entity,assembly, vpos.get_element(1,1), vpos.get_element(1,2),
                          vpos.get_element(1,3));
          break;
       case SCALE:                    
          iface->scale(msg->entity,assembly,vpos.get_element(1,1), vpos.get_element(1,2),
               vpos.get_element(1,3));
          break;
    }
    
    //iface->commit();
}

void SetRotOrder(char *entity, char *dof, char *ro)
{
    if(!iface){
        return;
    }
    
    iface->set_rot_order(entity, dof, ro);
}

void MsgSendLink (dvs_msg *msg)
{
    if(!iface){
        return;
    }

    //vp_matrix vpos = to_vega(msg->pos.x,
    //                         msg->pos.y,
    //                         msg->pos.z, msg->object);
    
    //vp_matrix vrot = to_vega(r2d * msg->rot.a,
    //                        r2d * msg->rot.b,
    //                         r2d * msg->rot.c, msg->object);
    
    if (Display_Output) {
      cout << "linking: parent :" << msg->object << " and child :" << msg->event << endl;
    }
    iface->attach (msg->event, "", msg->object);

    //iface->commit();
    if (Display_Output) {
       printf("Link %s %s \n",msg->object, msg->event);  /* confirm to stdout. */
    }
    
}

void MsgSendUnLink (dvs_msg *msg)
{
   
    if(!iface){
        return;
    }
    
    iface->detach (msg->object);
    //iface->commit();

    if (Display_Output) {
        printf("!!!!!UnLink %s\n",msg->object);  
    }
   
}


float MsgGetVariable (char *var_name_str)
{
    printf("!! get variable NOT IMPLEMENTED, see previous version\n");
    return (0.0);
}




// adds a dummy instance and sets it to be invisible
// the number of times this is called must correspond to NUM_TYPES!!!!  (ie instance_types
// should be a vector instead of an array)
void addDummyInstance (std::string geom_path) 
{
    if(!iface){
        return;
    }
    
    ostringstream name;
    name << DUMMY_PREFIX << num_dummies;
    iface->create_model(name.str(), geom_path, false, false);
    iface->commit();
    instance_types [num_dummies++] = geom_path;
    //iface->setVisibility(name.str(), "", false);
}

void Init()
{
    cout << "ve_plugin:Init" << endl;
    
    bool is_sms = false;
    if (vputils::getenv("SMS_COORD_SYSTEM", "0") != "0") {
        is_sms = true;
    }
    
    signal(SIGINT, sighandler);
    signal(SIGHUP, sighandler);
    
    // Set up the ssom to ve matrix.
    double *p = &ssom2vega[0][0];
    s2v.set(p,16);
    if (is_sms > 0) {
        s2v.set_element(1, 1, -1.0);
    }
    // Set up the ve to ssom matrix.
    v2s = s2v.mp_inverse();

    string isQueued = vputils::getenv("VE_PROXY_QUEUING","");
    if(isQueued.empty()){
        // Make a non-queued interface.
        iface = new ve_inet();
    }else{
        // Make a queued interface.  Commit must be called!
        iface = new ve_inet(true);
    }
    
    if(!iface){
        cerr << "ve_plugin::Init: Could not allocate ve_inet interface!!!!!" << endl;
    }
    
    myDamager.start();
}

void GetTerrainHeight(float z, float x, int * data_good, float *h)
{
    if(!iface){
        return;
    }
    
    vp_matrix pos = to_vega(x,0.0,z,"");
    veEntityInfo info = iface->getInfo(pos.get_element(1,1),
                                      pos.get_element(1,2),
                                      pos.get_element(1,3));
    *data_good = (int)info.good;
    if(info.good){
        *h = info.hot;
    }else{
        cout << "GetTerrainHeight : bad return!" << endl;
    }
}

void GetCoordinate(char *entity, char *assembly, int is_absolute, int *data_good, position *pos, rotation *ori)
{
    if(!iface){
        return;
    }
    
    //cout << "called GetCoordinate " << entity << endl;

    bool is_abs = (bool) is_absolute;

    //cout << "getting info" << endl;
    veEntityInfo info = iface->getInfo(entity, assembly, (bool)is_absolute);
    
    *data_good = (int)info.good;
    if(info.good){
        //cout << "info.good: "  << info.good << endl;
        vp_matrix tmp_vec = to_ssom(info.rot[0], info.rot[1], info.rot[2], "");
	ori->a = float (d2r * tmp_vec.get_element(1,1));
	ori->b = float (d2r * tmp_vec.get_element(1,2));
	ori->c = float (d2r * tmp_vec.get_element(1,3));
        tmp_vec = to_ssom(info.pos[0], info.pos[1], info.pos[2], "");
	pos->x = float (tmp_vec.get_element(1,1));
	pos->y = float (tmp_vec.get_element(1,2));
	pos->z = float (tmp_vec.get_element(1,3));
    }else{
        cout << "GetCoordinate : bad return!" << endl;
    }
}


// Creates a new object in the scene with an absolute position and rotation 
// as given, with the name entity and a flight file corresponding to geom_type
void CreateObject (char * entity, char * geom_type, position *pos, rotation *rot, int is_ground_clamp, int is_instance)
{
    if(!iface){
        return;
    }
    
     // entity is a string like : PACE_NODE#subnode or just PACE_NODE
     cout << "called CreateObject " << entity << endl;

     string entity_name(entity);

     // Find the matching dummy instance name for geom_type
     // If geom_type is unrecognized, then do nothing
     string geom_id;
     if (is_instance) {
       geom_id = get_instance_name (geom_type); // name of existing dummy instance
     } else {
       geom_id = geom_type;  // flt file
     }

     if (geom_id == "") {
         cout << "geometry type " << geom_type << " is unrecognized\n";
     } else {
         iface->create_model(entity_name,geom_id,is_ground_clamp,is_instance);

         vp_matrix vpos = to_vega(pos->x,
			          pos->y,
			          pos->z,
			          "");     
         vp_matrix vrot = to_vega(r2d * rot->a,
			          r2d * rot->b,
			          r2d * rot->c, 
			          "");

         iface->translate(entity_name,"",vpos.get_element(1,1),
		         vpos.get_element(1,2),
		         vpos.get_element(1,3));

         iface->rotate(entity_name,"",vrot.get_element(1,1),
		      vrot.get_element(1,2),
		      vrot.get_element(1,3));

         iface->commit();
     }  
}


void CreateEffect (char * entity, char * fx_type, position *pos, rotation *rot)
{
    if(!iface){
        return;
    }

    string type(fx_type);
    string entity_name(entity);

    if("trail" == type){
        //is_instance implies munition at this time.
        iface->create_effect(composeTrail(entity_name));
    } else if ("explosion" == type) {
        iface->create_effect(composeExplosion(entity_name));
    } else if ("smoke" == type) {
        iface->create_effect(composeSmoke(entity_name));
    } else if ("fire" == type) {
        iface->create_effect(composeFire(entity_name));
    }

    vp_matrix vpos = to_vega(pos->x,
                             pos->y,
                             pos->z,
                             "");     
    vp_matrix vrot = to_vega(r2d * rot->a,
                             r2d * rot->b,
                             r2d * rot->c, 
                             "");

    cout << "positioning fx " << entity << endl;
    cout << vpos;
    cout << vrot;

    iface->translate(entity_name,"",vpos.get_element(1,1),
                    vpos.get_element(1,2),
                    vpos.get_element(1,3));

    iface->rotate(entity_name,"",vrot.get_element(1,1),
                 vrot.get_element(1,2),
                 vrot.get_element(1,3));

    //iface->commit();
}

// Set switch node states.
void SetSwitch(char *entity, char *switch_node_name, int state)
{
    
    if(!iface){
        return;
    }
    
    //string ent(entity);
    //string sw(switch_node_name);
    //string dof("");
    
    iface->setState(entity,"",switch_node_name,state);
}

// Enable the visual plotting of an object's path.
// Precondition: a plot was added to this object.
void StartPlot(char *entity)
{
    if(!iface){
        return;
    }
    
    iface->start_plot(entity);
}

void StopPlot(char *entity)
{
    if(!iface){
        return;
    }
    
    iface->stop_plot(entity);
}

void Commit()
{
    if(!iface){
        return;
    }
    
    iface->commit();
}


/* Necessary for the g++ linker, not in libgcc_eh.a */ 
extern "C" { 
void __gnat_install_locks (void (*lock) (void), void (*unlock) (void)) 
{
}
}  
