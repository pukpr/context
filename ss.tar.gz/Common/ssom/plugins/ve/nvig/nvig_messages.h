/*
$Marking$
*/

/*
$Copyright$
*/

#ifndef _NVIG_MESSAGES_H_
#define _NVIG_MESSAGES_H_

#include <iostream>
#include <string>
#include <iostream>


/***
 * TRICKY THING: 
 * Always use get_size() method on nvig messages instead of sizeof!
 * nvig messages contain strange C-like strings with variable length and a 
 * leading int for size.  Therefore sizeof gives you the wrong size when 
 * strings are present.
 *
 * USAGE:
 * Each nvig message below has a struct conforming to the nvig ICD (Rev New).
 * This struct is the actual data that must be sent over UDP to port 9101 
 * (default).  Each message struct is wrapped in a C++ class that has a 
 * "get_data()" and "get_size()" method.  Use the C++ classes rather than 
 * the raw structs to access the data.  "get_data()" returns the nvig 
 * structure pointer, "get_size()" returns the size of the thing pointed to 
 * by the pointer.
 *
 * Don't forget to call "swap()" on outgoing messages before sending them 
 * and on incoming messages before using them.
 *
 * Here is an outgoing udp example:
 *
 * msg.swap();
 * sock.send_msg(msg.get_data(), msg.get_size());
 *
 * where sock is a vputils/udp_socket that has been connected and msg is 
 * an nvig_msg.
 ***/

// Maybe this is the string length required???
const int NVIG_STRING_SIZE = 44;

namespace{

// Byte swapper.
void swap(char *buf, int len)
{
    if(len <= 0){
        return;
    }
    char tmp;
    int lmt = (int)(len/2);
    for(int i = 0; i < lmt; ++i){
        tmp = buf[i];
        buf[i] = buf[len - 1 - i];
        buf[len - 1 - i] = tmp;
    }
}

// Maybe this string type?
// a null terminated string of parametric length.
unsigned int var_string_size = 32;
struct var_string{
    char *buf;
    
    ~var_string()
    {
        delete [] buf;
    }
    
    void set(const std::string &s)
    {
        buf = new char[var_string_size];
        for(unsigned int i = 0; i < s.length(); ++i){
            if(i < var_string_size){
                if(i < s.length()){
                    buf[i] = s[i];
                }else{
                    buf[i] = 0;
                }
            }
        }
        buf[var_string_size - 1] = 0;
    }
};


}// end namespace.

// All nvig message classes conform to this interface.
class nvig_msg{
    friend std::ostream& operator<< (std::ostream &os,
                                     const nvig_msg &m)
    {
        os << m.id << std::endl;
	m.output(os);
	return os;
    }
private:
    std::string id;
public:
    nvig_msg(){}
    virtual ~nvig_msg(){}
    void set_id(const std::string &msg_type)
    {
        id = msg_type;
    }
    
    bool is(const std::string &msg_type)
    {
        if (id == msg_type) {
	    return true;
	}
	return false;
    }
    
    virtual void output(std::ostream &os) const = 0;
    virtual void* get_data() = 0;
    virtual int get_size() = 0;
    virtual void swap() = 0;    
};

// Wrangler for positionable messages.
class nvig_positional_msg : public nvig_msg{
private:
public:
    virtual ~nvig_positional_msg(){}
    virtual void set_pos(float p[3]) = 0;
    virtual void set_rot(float r[3]) = 0;
};

// Possible string implementation?  Works for hla anyhow.
struct hla_string{
    unsigned int len;
    char *str;
    
    hla_string()
    {
        len = 0;
        str = 0;
    }
    
    ~hla_string()
    {
        delete [] str;
    }
    
    void set(const std::string &s)
    {
        unsigned int overage = 4 - s.length() % 4;
        unsigned int str_len = s.length();
        if(overage != 4){
            str_len += overage;
        }
        std::cout << "string len: " << str_len << std::endl;
        std::cout << "[";
        str = new char[str_len];
        for(unsigned int i = 0; i < str_len; ++i){
            if(i < s.length()){
                str[i] = s[i];
                std::cout << str[i];
            }else{
                str[i] = 0;
                std::cout << ".";
            }
        }
        std::cout << "]" << std::endl;
        len = str_len;
    }
    
    int get_size()
    {
        return 4 + len;
    }
    
    void swap()
    {
        ::swap((char*)&len, sizeof(len));
    }
};

// OK, this is the string they are expecting.
struct nvig_string{
    friend std::ostream& operator<< (std::ostream &os,
                                const nvig_string &s)
    {
        for (int i = 0; i < s.len; i++) {
	    os << s.str[i];
	}
	os << std::endl;
	return os;
    }
    
    unsigned int len;
    char *str;
    
    nvig_string()
    {
        len = 0;
	str = 0;
    }
    
    ~nvig_string()
    {
        delete [] str;
    }
    
    void set(const std::string &s)
    {
        delete [] str;
        len = s.length();
	str = new char[len];
	for(unsigned int i = 0; i < len; ++i){
	    str[i] = s[i];
	}
    }
    
    int get_size()
    {
        return len + 4;
    }
    
    void swap()
    {
        ::swap((char*)&len, sizeof(len));
    }
};




///// HEADER

struct nvig_msg_header{
    unsigned int magic;
    unsigned short version;
    unsigned short mtype;
    unsigned short channel;
    unsigned short viewport;
    unsigned int msg_size;
    unsigned int timestamp;
    unsigned int sequence_number;  // timestamp and seq number are swapped
                                   // between versions.
    //unsigned int magic2;           // Is this a typo?
    unsigned int reserved1;
    unsigned int reserved2;
    
    nvig_msg_header()
    {
        magic = 0x78ac32ed;
        version = 1 << 8;
	channel = 0;
	viewport = 0;
	timestamp = 0;
	sequence_number = 0;
        reserved1 = 0;
        reserved2 = 0;
    }
    
    void swap()
    {
        ::swap((char*)&version, sizeof(unsigned short));
        ::swap((char*)&mtype, sizeof(unsigned short));
        ::swap((char*)&channel, sizeof(unsigned short));
        ::swap((char*)&viewport, sizeof(unsigned short));
        ::swap((char*)&msg_size, sizeof(unsigned int));
        ::swap((char*)&sequence_number, sizeof(unsigned int));
        ::swap((char*)&timestamp, sizeof(unsigned int));
    }
};


///// START_IG

struct nvig_start_ig_msg_st{
    nvig_msg_header header;
    unsigned short screen_width;
    unsigned short screen_height;
    unsigned int startup_flags;
    //char database_name[NVIG_STRING_SIZE];
    //char splash_screen[NVIG_STRING_SIZE];
    nvig_string database_name;
    nvig_string splash_screen;
    //std::string database_name;
    //std::string splash_screen;
    //var_string database_name;
    //var_string splash_screen;
    
    nvig_start_ig_msg_st()
    {
        header.mtype = 1;
        screen_width = 600;
	screen_height = 400;
	startup_flags = 0;
    }
    
    void swap()
    {
        header.swap();
        ::swap((char*)&screen_width, sizeof(unsigned short));
        ::swap((char*)&screen_height, sizeof(unsigned short));
        ::swap((char*)&startup_flags, sizeof(unsigned int));
	database_name.swap();
	splash_screen.swap();
    }
    
    void set_database_name(const std::string &dbname)
    {
        database_name.set(dbname);
    }
    
    void set_splash_screen(const std::string &ssname)
    {
        splash_screen.set(ssname);
    }
    
    int get_size()
    {  
        return 8 + database_name.get_size() + splash_screen.get_size();
    }
};

class nvig_start_ig_msg : public nvig_msg {
private:
    nvig_start_ig_msg_st msg;
public:
    nvig_start_ig_msg()
    {
        set_id("start_ig");
    }
    
    void set_db(const std::string &dbname)
    {
        msg.set_database_name(dbname);
    }
    
    virtual void output (std::ostream &os) const
    {
        os << "width  " << msg.screen_width << std::endl;
	    os << "height " << msg.screen_height << std::endl;
	    os << "flags  " << msg.startup_flags << std::endl;
	    os << "db     " << msg.database_name;
	    os << "splash " << msg.splash_screen;
    }
    
    virtual void* get_data()
    {
        return &msg;
    }
    
    virtual int get_size()
    {
        return msg.get_size() + sizeof(nvig_msg_header);
    }
    
    virtual void swap()
    {
        msg.swap();
    }
};


///// STATUS
struct nvig_status_msg_st{
    nvig_msg_header header;
    unsigned int status;
    
    nvig_status_msg_st()
    {
        header.mtype = 1000;
        status = 0;
    }
    
    void swap()
    {
        header.swap();
        ::swap((char*)&status, sizeof(unsigned int));
    }
    
    int get_size()
    {
        return sizeof(unsigned int);
    }
};

class nvig_status_msg : public nvig_msg {
private:
    nvig_status_msg_st *msg;
public:
    nvig_status_msg()
    {
        set_id("status");
        msg = 0;
    }
    
    virtual void output(std::ostream &os) const
    {
        if (msg) {
            os << "status: " << msg->status << std::endl;
        }
    }
    
    unsigned int get_status()
    {
        if (msg) {
            return msg->status;
        }
        return 0;
    }
    
    virtual void* get_data()
    {
        return msg;
    }
    
    void set_data(nvig_status_msg_st *m)
    {
        msg = m;
    }
    
    virtual int get_size()
    {
        if (msg) {
            return msg->get_size() + sizeof(nvig_msg_header);
        } else {
            return 0;
        }
    }
    
    virtual void swap()
    {
        if (msg) {
            msg->swap();
        }
    }
};


///// SYNC
struct nvig_sync_msg_st{
    nvig_msg_header header;
    
    nvig_sync_msg_st()
    {
        header.mtype = 105;
    }
    
    void swap()
    {
        header.swap();
    }
    
    int get_size()
    {
        return 0;
    }
};

class nvig_sync_msg : public nvig_msg {
private:
    nvig_sync_msg_st msg;
public:
    nvig_sync_msg()
    {
        set_id("sync");
    }
    
    virtual void output(std::ostream &os) const
    {
        
    }
    
    virtual void* get_data()
    {
        return &msg;
    }
    
    virtual int get_size()
    {
        return msg.get_size() + sizeof(nvig_msg_header);
    }
    
    virtual void swap()
    {
        msg.swap();
    }
};


///// STOP_IG
struct nvig_stop_ig_msg_st{
    nvig_msg_header header;
    unsigned short action;
    unsigned char blanking;
    unsigned char blanking_flags;
    unsigned int blank_color;
    nvig_string blank_image;
    
    nvig_stop_ig_msg_st()
    {
        header.mtype = 2;
        action = 0;
        blanking = 1;
        blanking_flags = 0;
        blank_color = 0;
    }
    
    void set_blank_screen(const std::string &image_name)
    {
        action = 1;
        blank_image.set(image_name);
    }
    
    void set_soft_shutdown()
    {
        action = 2;
    }
    
    void set_hard_shutdown()
    {
        action = 3;
    }
    
    void swap()
    {
        header.swap();
        ::swap((char*)&action, sizeof(unsigned short));
        ::swap((char*)&blank_color, sizeof(unsigned int));
        blank_image.swap();
    }
    
    int get_size()
    {
        return sizeof(unsigned short) + 2 + sizeof(unsigned int) +
               blank_image.get_size();
    }
};

class nvig_stop_ig_msg : public nvig_msg {
private:
    nvig_stop_ig_msg_st msg;
public:
    nvig_stop_ig_msg()
    {
        set_id("stop_ig");
    }
    
    virtual void output(std::ostream &os) const
    {
        os << "action         " << msg.action << std::endl
           << "blanking       " << msg.blanking << std::endl
           << "blanking_flags " << msg.blanking_flags << std::endl
           << "blank_color    " << msg.blank_color << std::endl
           << "blank_image    " << msg.blank_image;
           
    }
    
    virtual void set_blank_screen(const std::string &image_name)
    {
        msg.set_blank_screen(image_name);
    }
    
    virtual void set_soft_shutdown()
    {
        msg.set_soft_shutdown();
    }
    
    virtual void set_hard_shutdown()
    {
        msg.set_hard_shutdown();
    }
    
    virtual void* get_data()
    {
        return &msg;
    }
    
    virtual int get_size()
    {
        return msg.get_size() + sizeof(nvig_msg_header);
    }
    
    virtual void swap()
    {
        msg.swap();
    }
};



///// PLATFORM_UPDATE

struct nvig_platform_update_msg_st{
    nvig_msg_header header;
    float x, y, z;
    float h, p, r;
    unsigned int flags;
    
    nvig_platform_update_msg_st(float pos[3], float rot[3])
    {
	header.mtype = 100;
	x = pos[0]; y = pos[1]; z = pos[2];
	h = rot[0]; p = rot[1]; r = rot[2];
	flags = 0xffffffff;
    }
    
    void set_pos(float pos[3])
    {
        x = pos[0]; y = pos[1]; z = pos[2];
    }
    
    void set_rot(float rot[3])
    {
        h = rot[0]; p = rot[1]; r = rot[2];
    }
    
    void swap()
    {
        header.swap();
	::swap((char*)&x, sizeof(float));
	::swap((char*)&y, sizeof(float));
	::swap((char*)&z, sizeof(float));
	::swap((char*)&h, sizeof(float));
	::swap((char*)&p, sizeof(float));
	::swap((char*)&r, sizeof(float));
	::swap((char*)&flags, sizeof(int));
    }
    
    int get_size()
    {
        return 6 * sizeof(float) + sizeof(int);
    }
};

class nvig_platform_update_msg : public nvig_positional_msg{
private:
    nvig_platform_update_msg_st *msg;
public:
    nvig_platform_update_msg()
    {
        float p[3] = {0.0, 0.0, 0.0};
        float r[3] = {0.0, 0.0, 0.0};
        set_id("platform_update");
        msg = new nvig_platform_update_msg_st(p, r);
    }
    
    nvig_platform_update_msg(float pos[3], float rot[3])
    {
        set_id("platform_update");
	msg = new nvig_platform_update_msg_st(pos, rot);
    }
    
    ~nvig_platform_update_msg()
    {
        delete msg;
    }
    
    virtual void output(std::ostream &os) const
    {
        if (!msg) {
	    return;
	}
	os << "pos:  " << msg->x << " " << msg->y 
	   << " " << msg->z << std::endl;
	os << "rot:  " << msg->h << " " << msg->p 
	   << " " << msg->r << std::endl;
	os << "flags " << msg->flags << std::endl;
    }
    
    
    
    virtual void* get_data()
    {
        return msg;
    }
    
    virtual int get_size()
    {
        return msg->get_size() + sizeof(nvig_msg_header);
    }
    
    virtual void swap()
    {
        msg->swap();
    }
    
    virtual void set_pos(float p[3])
    {
        if(msg){
            msg->set_pos(p);
        }
    }
    
    virtual  void set_rot(float r[3])
    {
        if(msg){
            msg->set_rot(r);
        }
    }
};


///// UNPAUSE

struct nvig_unpause_ig_msg_st{
    nvig_msg_header header;
    int reserved;
    
    nvig_unpause_ig_msg_st()
    {
        header.mtype = 3;
	    reserved = 0;
    }
    
    int get_size()
    {
        return sizeof(int);
    }
    
    void swap()
    {
        header.swap();
    }
};

class nvig_unpause_ig_msg : public nvig_msg{
private:
    nvig_unpause_ig_msg_st msg;
public:
    nvig_unpause_ig_msg()
    {
        set_id("unpause");
    } 
    
    virtual void output(std::ostream& os) const
    {
    
    }
    
    virtual void* get_data()
    {
        return &msg;
    }
    
    virtual int get_size()
    {
        return msg.get_size() + sizeof(nvig_msg_header);
    }
    
    virtual void swap()
    {
        msg.swap();
    }  
};


///// SENSOR_VIEW

struct nvig_sensor_view_msg_st{
    nvig_msg_header header;
    float pos[3];
    float rot[3];
    float fov[4];
    unsigned int flags;
    
    nvig_sensor_view_msg_st(float p[3], float r[3])
    {
        header.mtype = 102;
	for (int i = 0; i < 3; ++i) {
	    pos[i] = p[i];
	    rot[i] = r[i];
	}
	fov[0] = 5; fov[1] = 5; 
	fov[2] = 5; fov[3] = 5;
	// flags seem to need binary 1s in
	// desired field positions. 
	// i.e.: 0111 = first 3 fields.
	flags = 0x00000003;
    }
    
    void set_pos(float p[3])
    {
        pos[0] = p[0]; pos[1] = p[1]; pos[2] = p[2];
    }
    
    void set_rot(float r[3])
    {
        rot[0] = r[0]; rot[1] = r[1]; rot[2] = r[2];
    }
    
    void set_fov(float w, float h, 
                 float n, float f)
    {
        fov[0] = w; fov[1] = h;
	fov[2] = n; fov[3] = f;
        // enable reading of the fov field.
        flags |= 0x04;
    }
    
    void swap()
    {
        header.swap();
	for (int i = 0; i < 3; ++i){
	    ::swap((char*)&pos[i], sizeof(float));
	    ::swap((char*)&rot[i], sizeof(float));
	    ::swap((char*)&fov[i], sizeof(float));
	}
	::swap((char*)&fov[3], sizeof(float));
	::swap((char*)&flags, sizeof(unsigned int));
    }
    
    int get_size()
    {
        return 10 * sizeof(float) + sizeof(unsigned int);
    }
};

class nvig_sensor_view_msg : public nvig_positional_msg{
private:
    nvig_sensor_view_msg_st *msg;
public:
    nvig_sensor_view_msg()
    {
        float p[3] = {0.0, 0.0, 0.0};
        float r[3] = {0.0, 0.0, 0.0};
        msg = new nvig_sensor_view_msg_st(p, r);
        set_id("sensor_view");
    }

    nvig_sensor_view_msg(float p[3], float r[3])
    {
        msg = new nvig_sensor_view_msg_st(p, r);
	set_id("sensor_view");
    }
    
    ~nvig_sensor_view_msg()
    {
        delete msg;
    }
    
    virtual void output(std::ostream& os) const
    {
        if(!msg){
	    return;
	}
	os << "pos:   " << msg->pos[0] << " "
	   << msg->pos[1] << " " << msg->pos[2] << std::endl;
	os << "rot:   " << msg->rot[0] << " "
	   << msg->rot[1] << " " << msg->rot[2] << std::endl;
	if (msg->flags & 0x04) {
            os << "fov:   " << msg->fov[0] << " "
	       << msg->fov[1] << " " << msg->fov[2] << " "
	       << msg->fov[3] << std::endl;
        }
	os << "flags: " << msg->flags << std::endl;
    }
    
    void set_rot(float r[3])
    {
        if(msg){
            msg->set_rot(r);
        }
    }
    
    void set_pos(float p[3])
    {
        if(msg){
            msg->set_pos(p);
        }
    }
    
    void set_fov(float w, float h, float n, float f)
    {
        if(msg){
            msg->set_fov(w, h, n, f);
        }
    }
    
    virtual void* get_data()
    {
        return msg;
    }
    
    virtual int get_size()
    {
        return msg->get_size() + sizeof(nvig_msg_header);
    }
    
    virtual void swap()
    {
        msg->swap();
    } 
};



///// ELEVATION STUFF

struct nvig_elevation_request {
    unsigned int request_id;
    float x;
    float y;
    
    nvig_elevation_request()
    {
        request_id = 0;
        x = 0.0;
        y = 0.0;
    }
    
    void swap()
    {
        ::swap((char*)&request_id, sizeof(unsigned int));
        ::swap((char*)&x, sizeof(float));
        ::swap((char*)&y, sizeof(float));
    }
};

struct nvig_elevation_response {
    unsigned int request_id;
    unsigned int success;
    float pos[3];
    float normal[3];
    
    nvig_elevation_response()
    {
        request_id = 0;
        success = 0;
        pos[0] = 0.0; pos[1] = 0.0; pos[2] = 0.0;
        normal[0] = 0.0; normal[1] = 0.0; normal[2] = 0.0;
    }
    
    void swap()
    {
        ::swap((char*)&request_id, sizeof(unsigned int));
        ::swap((char*)&success, sizeof(unsigned int));
        for (int i = 0; i < 3; ++i) {
            ::swap((char*)&pos[i], sizeof(float));
            ::swap((char*)&normal[i], sizeof(float));
        }
    }
};

struct nvig_terrain_elevation_msg{
    nvig_msg_header header;
    unsigned int num_requests;
    nvig_elevation_request *requests;
    
    nvig_terrain_elevation_msg()
    {
        header.mtype = 1400;
        num_requests = 0;
        requests = 0;
    }
    
    void swap()
    {
        header.swap();
        for (int i = 0; i < num_requests; ++i) {
            requests[i].swap();
        }
        ::swap((char*)&num_requests, sizeof(unsigned int));
    }
    
    int get_size()
    {
        return sizeof(unsigned int) + 
        num_requests * sizeof(nvig_elevation_request);
    }
};

struct nvig_terrain_elevation_response_msg{
    nvig_msg_header header;
    unsigned int num_responses;
    nvig_elevation_response *responses;
    
    nvig_terrain_elevation_response_msg()
    {
        header.mtype = 1401;
        num_responses = 0;
        responses = 0;
    }
    
    void swap()
    {
        header.swap();
        ::swap((char*)&num_responses, sizeof(unsigned int));
        for (int i = 0; i < num_responses; ++i) {
            responses[i].swap();
        }
    }
    
    int get_size()
    {
        return sizeof(unsigned int) + 
               num_responses * sizeof(nvig_elevation_response);
    }
};


///// VIDEO_PACKET

struct nvig_video_packet_msg_header{
    unsigned int frame_no;
    unsigned int sequence_no;
    unsigned int image_size;
    unsigned int packet_size;
    unsigned int channel_size;
    unsigned int bytes_per_pixel;
};



#endif /*_NVIG_MESSAGES_H_*/
