#ifndef _PLUG_CONFIG_H_
#define _PLUG_CONFIG_H_

#include "vp_matrix.h"
#include "threading/Lock.h"
#include "httpserver/DefaultContentHandler.h"

class plug_config : public DefaultContentHandler {
private:
    vp_matrix *myMatrix;
    vp_matrix *myInverseMatrix;
    Lock *myLock;
    bool unpauseMsg;
    double *vis_corner_e;
    double *vis_corner_n;
    std::string myHost;
    std::string myPort;
    void updateMatrices(const std::string &data);
    void updateVisCorner(const std::string &data);
    void unpause();
public:
    plug_config();
    const ExtensionList getExtensionList() const
    {
        ExtensionList mylist;
        mylist.push_back("xml");
        return mylist;
    }
    void handle (Connection *conn);
    const std::string getType() const {return "text/xml";}
    
    // set the matrix (m) and the inverse matrix (im) to be
    // updated by this handler.
    void setMatrices(vp_matrix *m, vp_matrix *im, Lock *l);
    
    // Set the addresses of the visual database offsets.
    void setVisCorner(double *e, double *n);
    
    // set the host (h) and port (p) that NVIG is listening on.
    void setHostPort(const std::string &h, const std::string &p);
};

#endif /*_PLUG_CONFIG_H_*/
