#include "plug_config.h"
#include "nvig_messages.h"
#include "vputils/udp_socket.h"
#include "vputils/textutils.h"
#include "xmltree.h"
#include "httpserver/Connection.h"

#include <iostream>
#include <sstream>

using namespace std;

plug_config::plug_config()
{
    myLock = 0;
    myMatrix = 0;
    myInverseMatrix = 0;
    unpauseMsg = false;
    myHost = "localhost";
    myPort = "9101";
    vis_corner_e = 0;
    vis_corner_n = 0;
}

void plug_config::updateMatrices(const string &data)
{
    if (myLock && myMatrix && myInverseMatrix) {
        cout << "updating matrix: " << endl;
        cout << data << endl;
        myLock->acquire();
        istringstream is(data);
        myMatrix->deserialize(is);
        cout << "updateMatrices: matrix is now: " << endl;
        cout << *myMatrix << endl << endl << endl;
        *myInverseMatrix = myMatrix->mp_inverse();
        myLock->release();
    }
}

void plug_config::updateVisCorner(const string &data)
{
    if (!vis_corner_e || !vis_corner_n) {
        return;
    }
    
    CXmlTree t;
    t.mReadData(data);
    CXmlNode *d = t.mGetRoot();
    if (!d) {
        return;
    }
    d = d->mGetFirstChild();
    if (!d) {
        return;
    }
    while(CXmlNode *n = d->mGetNextChild()){
        string tag = n->mGetTag();
	if ("easting" == tag || "e" == tag) {
	    *vis_corner_e = vputils::todouble(n->mGetData());
	} else if ("northing" == tag || "n" == tag) {
	    *vis_corner_n = vputils::todouble(n->mGetData());
	} else {
	    cerr << "plug_config::updateVisCorner: unknown tag "
	         << tag << endl;
	}
    }
}

void plug_config::unpause()
{
    udp_socket sock;
    if(!sock.connect(myHost, myPort)){
        cerr << "plug_config::unpause: could not create socket!" << endl;
        return;
    }
    cout << "unpause" << endl;
    nvig_unpause_ig_msg msg;
    msg.swap();
    sock.send_msg(msg.get_data(), msg.get_size());
}

void plug_config::handle(Connection *conn)
{
    Connection::response_type response_code = Connection::OK;
    
    switch (conn->getMethod()){
        case Connection::GET:
        {
            URI myURI = conn->getURI();
            const std::string data = myURI.getParam("xml");
            
            const string path = myURI.getPath();
            cout << "path: " << path << endl;
            
            if(!data.empty()){
                if ("/matrix.xml" == path) {
                    updateMatrices(data);
                } else if ("/unpause.xml" == path) {
                    unpause();
                } else if ("/vis_corner.xml" == path) {
		    updateVisCorner(data);
		}
            }
            
            const string resp = "<xml>OK</xml>";
            conn->setResponseCode(response_code);
            conn->send_header(getType(), resp.length());
            conn->send(resp);
        }
        break;
        case Connection::HEAD:
        case Connection::POST:
        {
            cout << "HEAD and POST not implemented" << endl;
            conn->setResponseCode(Connection::NOT_IMPLEMENTED);
            conn->send_header(getType(), 0);
        }
        break;
    }//end switch.
}

void plug_config::setMatrices(vp_matrix *m, vp_matrix *im, Lock *l)
{
    myLock = l;
    myMatrix = m;
    myInverseMatrix = im;
}

void plug_config::setVisCorner(double *e, double *n)
{
    vis_corner_e = e;
    vis_corner_n = n;
}

void plug_config::setHostPort(const string &h, const string &p)
{
    myHost = h;
    myPort = p;
}


