/*
$Marking$
*/

/*
$Copyright$
*/

// local.
#include "ve_plugin.h"
#include "plug_config.h"

// vplibs.
#include "vp_matrix.h"
#include "vputils/udp_socket.h"
#include "threading/Lock.h"
#include "vputils/osutils.h"
#include "vputils/textutils.h"
#include "httpserver/HttpServer.h"
#include "httpserver/StandardWebHandlers.h"

// nvig.
#include "nvig_messages.h"

// system.
#include <iostream>
#include <vector>
#include "math.h"

using namespace std;

namespace{

    // TODO: hmmm, az and el are separate.
    string ccas_name = "secondary_azimuth";
    string veh_id = "1";
    string myHost = "localhost";
    string myPort = "9101";
    
    bool debug = false;
    
    
    const double r2d = 180.0/M_PI;
    const double d2r = M_PI/180.0;
    
    double nvig_corner_e = 0.0;
    double nvig_corner_n = 0.0;
    
    Lock matrix_lock;
    // transforms to and from virtual env.
    vp_matrix s2v(4,4);
    vp_matrix v2s(4,4);
    
    HttpServer *myServer = 0;
    
    enum messageType {nvig_none, nvig_platform, nvig_ccas};
    
    // Driving camera message.
    nvig_sensor_view_msg      dummy_msg;
    
    // Secondary armament camera message.
    nvig_sensor_view_msg      ccas_camera_msg;
    
    // Vehicle message.
    nvig_platform_update_msg  platform_msg;
    
    vector<nvig_positional_msg*> nvig_messages;
    
    messageType whichMessage(const string &entity, const string &assembly)
    {
//        cout << "whichMessage: entity: " << entity << ", assembly: "
//	     << assembly << endl;
	    if (assembly == "") {
            if (veh_id == entity) {
                return nvig_platform;
            }
            return nvig_none;
        }
        
        if (ccas_name == assembly) {
            return nvig_ccas;
        } else {
            return nvig_none;
        }
    }
    
    
    nvig_positional_msg* makeMessage(const string &ent, const string &obj)
    {
        nvig_positional_msg *ret = 0;
	    if (obj == ""){
	        if (veh_id == ent) {
	            ret = new nvig_platform_update_msg;
		        return ret;
	        }
	    }
	
	    if(ccas_name == obj){
	        ret = new nvig_sensor_view_msg;
	        return ret;
	    }
	    return ret;
    }
    
    void init_env()
    {
        string dbg = vputils::getenv("NVIG_PLUGIN_DEBUG","0");
        if ("True" == dbg || "true" == dbg || "TRUE" == dbg || "1" == dbg) {
            debug = true;
        }
	string nv_e_off = vputils::getenv("NVIG_DB_E_CORNER_UTM", "213540");
	string nv_n_off = vputils::getenv("NVIG_DB_N_CORNER_UTM", "3433470");
	nvig_corner_e = vputils::todouble(nv_e_off);
	nvig_corner_n = vputils::todouble(nv_n_off);
    }

} //end namespace.

static vp_matrix to_ve(float x,float y,float z)
{
    vp_matrix vpos(1,4);
    
    double vect[4];
    vect[3] = 1.0;
    vect[0] = x;
    vect[1] = y;
    vect[2] = z;
    vpos.set(vect,4);
    
    matrix_lock.acquire();
    vpos = vpos.multiply(&s2v);
    matrix_lock.release();
    
    return vpos;
}

static vp_matrix to_ssom(float x,float y,float z)
{
    vp_matrix vpos(1,4);
    double vect[4];
    vect[3] = 1.0;
    vect[0] = x;
    vect[1] = y;
    vect[2] = z;
    vpos.set(vect,4);
    
    matrix_lock.acquire();
    vpos = vpos.multiply(&v2s);
    matrix_lock.release();
    
    return vpos;
}

void MsgSendEvent (dvs_msg *msg)
{
    ////delete msg;
}

void MsgSendVariable (dvs_msg *msg)
{
    ////delete msg;
}

void MsgSendCoordinate (dvs_msg *msg)
{
    //cout << "nvig_plugin.C: MsgSendCoordinate" << endl;
    
    if(!msg){
        return;
    }
    
    nvig_positional_msg *pmsg = makeMessage(msg->entity, msg->object);
    if (!pmsg) {
        return;
    }
    
    //cout << "nvig_plugin.C: send_coordinate" << endl;
    
    // The incoming values are in ssom coordinates.
    // Change them to nvig coordinates.
    string obj_str(msg->object);
    vp_matrix vpos;
    if ("" == obj_str) { // world.
        vpos = to_ve(msg->pos.x - nvig_corner_n,
                     msg->pos.y - nvig_corner_e,
                     msg->pos.z);
    } else { // local.
        vpos = to_ve(msg->pos.x,
                     msg->pos.y,
                     msg->pos.z);
    }
			   
//    cout << "plugin pos: " << vpos << endl;
    
    
    //vp_matrix vrot = to_ve(r2d * (msg->rot.a),
    //                       r2d * (msg->rot.b),
    //                       r2d * (msg->rot.c));
    
    // Rotations must also be transformed to nvig
    // coordinates.
    vp_matrix vrot(1,3);
    vrot.set_element(1,1, r2d * msg->rot.a); //p
    vrot.set_element(1,2, r2d * msg->rot.b); //h
    vrot.set_element(1,3, r2d * msg->rot.c); //r
    
    
    float rot[3] = {0.0, 0.0, 0.0};
    float pos[3] = {0.0, 0.0, 0.0};
    switch (msg->msg_type){
       case ROTATION:
          // hpr. heading is backward in nvig.
          rot[0] = -vrot.get_element(1,2); //h
          rot[1] = vrot.get_element(1,1); //p
          rot[2] = vrot.get_element(1,3); //r
          pmsg->set_rot(rot);
          break;
       case POSITION:
          pos[1] = vpos.get_element(1,1);
          pos[2] = vpos.get_element(1,2);
          pos[0] = vpos.get_element(1,3);
          pmsg->set_pos(pos);
          break;
       case COORDINATE:
          // hpr. heading is backward in nvig.
          rot[0] = -vrot.get_element(1,2); //h
          rot[1] = vrot.get_element(1,1); //p
          rot[2] = vrot.get_element(1,3); //r
          //rot[0] = vrot.get_element(1,2);
          //rot[1] = vrot.get_element(1,3);
          //rot[2] = vrot.get_element(1,1);
          pmsg->set_rot(rot);
          pos[1] = vpos.get_element(1,1);
          pos[2] = vpos.get_element(1,2);
          pos[0] = vpos.get_element(1,3);
          pmsg->set_pos(pos);
          break;
       case SCALE: 
          break;
    }
    
    // Finally, we can actually send the data.
    udp_socket sock;
    if (!sock.connect(myHost, myPort)) {
        cerr << "MsgSendCoordinate: could not create socket!" << endl;
        delete pmsg;
        return;
    }
    if (debug) {
        cout << "message: " << *pmsg << endl << endl;
    }
    pmsg->swap();
    sock.send_msg(pmsg->get_data(), pmsg->get_size());
    sock.close();
    delete pmsg;
    
    ////delete msg;
}

void MsgSendLink  (dvs_msg *msg)
{
    ////delete msg;
}


void MsgSendUnLink (dvs_msg *msg)
{
    //delete msg;
}

void SetRotOrder(char *entity, char *dof, char *ro)
{

}

float MsgGetVariable (char *var_name_str)
{

}

void GetTerrainHeight(float z, float x, int * data_good, float *h)
{
    *data_good = 1;
}

void GetCoordinate(char * entity, char * assembly, int is_absolute, int * data_good, position *pos, rotation *ori)
{
    *data_good = 1;
}

// 32 is max length of entity and geom_type due to Division restriction
void CreateObject (char * entity, char * geom_type, position *pos, rotation *rot, int is_ground_clamp, int is_instance)
{

}

// fx_type can be one of: "trail".
void CreateEffect (char * entity, char * fx_type, position *pos, rotation *rot)
{

}

// Init must be called before using this interface.
void Init()
{
    init_env();
    
    // Set up the ssom to nvig matrix.
    /*
    1 0 0 0
    0 0 1 0
    0 1 0 0
    0 0 0 1
    */
    
    s2v.identity();
    s2v.set_element(2, 2, 0.0);
    s2v.set_element(3, 2, 1.0);
    s2v.set_element(3, 3, 0.0);
    s2v.set_element(2, 3, 1.0);
    
    v2s = s2v.mp_inverse();
    
    const string web_root = vputils::getenv("NVIG_PLUGIN_WEBROOT","www-docs");
    const string web_port = vputils::getenv("NVIG_PLUGIN_SERVER_PORT","6801");
    myServer = new HttpServer(atoi(web_port.c_str()), 20, web_root);
    cout << "nvig_plugin server started on port " << web_port << endl;
    
    myHost = vputils::getenv("NVIG_PLUGIN_NVIG_HOST","localhost");
    myPort = vputils::getenv("NVIG_PLUGIN_NVIG_PORT","9101");
    
    // register regular web handlers.
    ContentHandlerList *handlers = createStandardHandlers();
    
    plug_config *myPlugConfig = new plug_config;
    myPlugConfig->setMatrices(&s2v, &v2s, &matrix_lock);
    myPlugConfig->setVisCorner(&nvig_corner_e, &nvig_corner_n);
    myPlugConfig->setHostPort(myHost, myPort);
    handlers->push_back(myPlugConfig);
    
    ContentHandlerList::const_iterator iter = handlers->begin();
    ContentHandlerList::const_iterator end = handlers->end();
    for (; iter != end; ++iter) {
        (*iter)->setDocumentRoot(web_root);
        myServer->register_handler(*iter);
    }
    delete handlers;
    
    myServer->start();
    cout << "Comms initialized" << endl;
    
    // "Unpause" the IG.
    udp_socket sock;
    if (!sock.connect(myHost, myPort)) {
        cerr << "Init: could not create socket for unpause ig message!" 
             << endl;
        return;
    }
    nvig_unpause_ig_msg msg;
    msg.swap();
    sock.send_msg(msg.get_data(), msg.get_size());
    sock.close();
    
    // Send initial "sensor" view message to get the view off the ground.
    if (!sock.connect(myHost, myPort)) {
        cerr << "Init: could not create socket for sensor view message!" 
             << endl;
        return;
    }
    nvig_sensor_view_msg *svmsg = new nvig_sensor_view_msg;
    if(!svmsg){
        cerr << "Init: could not create default sensor view message!" << endl;
        return;
    }
    float pos[3] = {0.0, 0.0, 2.0};
    svmsg->set_pos(pos);
    svmsg->swap();
    sock.send_msg(svmsg->get_data(), svmsg->get_size());
    sock.close();
    delete svmsg;
}

// Set switch node states.
void SetSwitch(char *entity, char *switch_node_name, int state)
{

}

// Impact a munition.  This does the effects for the impact.
void Impact(position *pos, char *munition)
{

}

// Launch a munition.  This does the effects for the launch.
void Launch(char *source, char *munition)
{

}

// Start a plot of an object's motion.
// Precondition: a plot has been added to the object.
void StartPlot(char *entity)
{

}

// Stop plotting an object's motion.
void StopPlot(char *entity)
{

}

void Player(char *filename)
{

}



// Commit the queue of messages to the VE.
void Commit()
{

}
