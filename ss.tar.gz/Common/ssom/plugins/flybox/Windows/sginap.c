long
sginap (long ticks)
{
	long retval = 0;
/*
        long secs = ticks * 1 / CLK_TCK;
	unsigned int remaining_secs = sleep (secs);
	if (remaining_secs != 0) {
		retval = remaining_secs * CLK_TCK;
	}
*/
	return retval;
}
