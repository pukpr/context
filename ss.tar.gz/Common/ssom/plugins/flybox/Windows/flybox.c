void setup_lv (void *v) {}
void get_lv_buffer (void *v) {}
