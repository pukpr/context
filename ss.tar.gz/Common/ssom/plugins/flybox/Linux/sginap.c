#if HAVE_CONFIG_H
#include <config.h>
#endif

#if HAVE_STDLIB_H
#include <stdlib.h>
#endif

#if TIME_WITH_SYS_TIME
# include <sys/time.h>
# include <time.h>
#else
# if HAVE_SYS_TIME_H
#  include <sys/time.h>
# else
#  include <time.h>
# endif
#endif

#if !HAVE_SGINAP
# ifdef __cplusplus
  extern "C" {
# endif
  extern long sginap (long ticks);
# ifdef __cplusplus
  }
# endif
#endif

#ifndef CLK_TCK
#define CLK_TCK (CLOCKS_PER_SEC / 1e4)
#endif

/**
     The sginap system call provides two functions.  With an argument of 0, it
     yields the processor to any higher or equal priority threads immediately,
     thus potentially allowing another thread to run.  Note that because
     normally the user has no direct control over the exact priority of a
     given thread, this does not guarantee that another thread will run.

     With an argument which is non-zero, sginap will suspend the thread for
     between ticks-1 and ticks clock ticks.  That is, it will suspend for at
     least ticks-1 clock ticks, but less than ticks clock ticks.  The length
     of a clock tick is defined by CLK_TCK in the include file <limits.h>.
     This is the same for all SGI systems.

     Note that if the calling thread is interrupted by a signal before the
     specified number of ticks has elapsed, sginap will return prematurely.
 */

long
sginap (long ticks)
{
	long retval = 0;
	long secs = ticks * 1 / CLK_TCK;
	unsigned int remaining_secs = sleep (secs);
	if (remaining_secs != 0) {
		retval = remaining_secs * CLK_TCK;
	}
	return retval;
}
