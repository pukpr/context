#include "../lv3.h"
#include <stdio.h>

main()
{
    bglv Buffer;

   setup_lv (); 
   printf ("Initialized flybox");
   while (1) {
      get_lv_buffer (&Buffer);
      printf ("Driver got %g \n", Buffer.ain[0] );
     
   };
}
