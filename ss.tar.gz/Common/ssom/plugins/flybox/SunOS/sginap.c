#if HAVE_CONFIG_H
#include <config.h>
#endif

#if HAVE_STDLIB_H
#include <stdlib.h>
#endif

#if TIME_WITH_SYS_TIME
# include <sys/time.h>
# include <time.h>
#else
# if HAVE_SYS_TIME_H
#  include <sys/time.h>
# else
#  include <time.h>
# endif
#endif

#if !HAVE_SGINAP
# ifdef __cplusplus
  extern "C" {
# endif
  extern long sginap (long ticks);
# ifdef __cplusplus
  }
# endif
#endif

long
sginap (long ticks)
{
	long retval = 0;
	long secs = ticks * 1 / CLK_TCK;
	unsigned int remaining_secs = sleep (secs);
	if (remaining_secs != 0) {
		retval = remaining_secs * CLK_TCK;
	}
	return retval;
}
