/*
 * flybox_test.c
 *
 * Main routine for v3.0 test for FlyBox
 */

#include <stdio.h>
#include <stdlib.h>

#include "lv3.h"

void setup_lv(void );
void get_lv_buffer (bglv *);

extern int open_lv(bglv *, char *, int );
extern int init_lv(bglv *);

extern int w_lv(int, char *);
extern int r_lv(bglv *);

extern int check_rev(bglv *);
extern int check_setup(bglv *);

static bglv bgdata;
static int debug = 0;

void get_lv_buffer (bglv *buffer) 
{
   int st;

   st = w_lv(bgdata.sp_fd, "o");
   st = r_lv(&bgdata);
                  
   if (st >= 0) {  
       bgdata.ain[1] = -bgdata.ain[1];
       *buffer = bgdata;
       if (debug) {
          printf("%4.2f %4.2f %4.2f %4.2f %4.2f\n", 
	   bgdata.ain[0], bgdata.ain[1], bgdata.ain[2], bgdata.ain[3],
	   bgdata.ain[4]);
       }
   } else {
       printf("error in lv\n"); 
   
   }
}


void setup_lv()
{
   int st;
   int i;
   
/*
 * Defaults to 5 analog, and 16 discretes
 */
 
   bgdata.analog_in = 0;
   bgdata.analog_in = AIC1 | AIC2 | AIC3 | AIC4 | AIC5;

   bgdata.dig_in = 0;
   bgdata.dig_in = DIC1 | DIC2;

/*
 *  Set the baud rate
 */
   bgdata.baud    = BAUD192;
 
/*
 *  Open the port & drivers
 *  Note that we don't hard code the "dev/ttyd2" string as in the
 *  Owner's Guide - it is a better habit to use the FBPORT environment
 *  variable.   You could:
              st = open_lv(&bgdata, "/dev/ttyd2", FB_NOBLOCK);
 *  but you are then stuck if you need to use a different port.
 */
   st = open_lv(&bgdata, "", FB_BLOCK);  /* Set BLOCKING for SPROCS */
   if (st < 0)
   {
      printf("Unable to open port\n");
      exit(-1);
   }
 
/*
 *  Send the init string
 */
   st = init_lv(&bgdata);
   if ( st < 0 )
   {
      check_setup(&bgdata);
      printf("Invalid setup requested.  Bye\n");
      exit(-1);
   }
}




