../../../test_tools/pacelib-sun -I.. sespp

g++ simple.c -L$PACE/plugins/sespp/SunOS -lsespp $PACE_LIBS -lpthread -lrt
