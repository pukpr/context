#include <unistd.h>

extern int gnat_argc;
extern char **gnat_argv; 

extern "C" {
void adainit();
void libsespp__init();
}

int main_value = 999;

int main(int argc, char *argv[])
{
  char *name[] = {"me"};
  
  gnat_argc = 0; /* argc; */
  gnat_argv = name;

  adainit();
  libsespp__init();
  sleep (1000000000);
  return (0);
}
