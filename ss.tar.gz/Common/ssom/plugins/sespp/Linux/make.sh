../../../test_tools/pacelib-x86 -I.. sespp

g++ simple.c $PACE/plugins/sespp/Linux/libsespp.a $PACE_LIBS -lpthread
