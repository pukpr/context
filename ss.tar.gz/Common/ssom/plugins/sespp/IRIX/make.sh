../../../test_tools/pacelib-sgi -I.. sespp

CC simple.c $PACE/plugins/sespp/IRIX/libsespp.a $PACE_LIBS -lexc -lpthread
