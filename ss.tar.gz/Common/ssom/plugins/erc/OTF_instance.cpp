#include <math.h>
#include "otf_terrain_interface.h"


otf_terrain_interface *OTF;

extern "C" {

   void Initialize_OTF () 
   {
      OTF = new otf_terrain_interface ("Fort_Hood_terrain_database", 
                                       "global_little_endian_spring.mdb");
   }



   void Extents_OTF(int coord,  //const std::string &coord_system,
                    double &x_min, double &x_max,
                    double &y_min, double &y_max)  
   {
      OTF->getExtents ((terrain_interface::coordSysType)coord, x_min, x_max, y_min, y_max);
/*
      switch (coord)
      {
         case 0: 
            OTF->getExtents ("utm", x_min, x_max, y_min, y_max);
            break;
         case 1: 
            OTF->getExtents ("latlon_degs", x_min, x_max, y_min, y_max);
            break;
         case 2: 
            OTF->getExtents ("latlon_rads", x_min, x_max, y_min, y_max);
            break;
         default:
            OTF->getExtents ("NotSet", x_min, x_max, y_min, y_max);
            break;
      }
*/      
   }



   double Get_Height_OTF (double E, double N, int Zone) 
   {
      return OTF->getHeight (E, N, Zone);
   }


   double Get_Roll_OTF (double E, double N, int Zone, double Az) 
   {
      double n[3];
      double Roll;
      
      // 90 deg to Heading = j*cos(az) - i*sin(az)
      // Normal = i*n[0] + j*n[1] + k*n[2]
      // Heading dot Normal = -n[0]*sin(az) + n[1]*cos(az) = cos(Pitch)

      OTF->getNormal (n, E, N, Zone);
      Roll = acos(-n[0]*sin(Az) + n[1]*cos(Az));
      return Roll;
   }


   double Get_Pitch_OTF (double E, double N, int Zone, double Az) 
   {
      double n[3];
      double Pitch;
      
      // Heading = i*cos(az) + j*sin(az)
      // Normal = i*n[0] + j*n[1] + k*n[2]
      // Heading dot Normal = n[0]*cos(az) + n[1]*sin(az) = cos(Pitch)
      
      OTF->getNormal (n, E, N, Zone);
      Pitch = acos(n[0]*cos(Az) + n[1]*sin(Az));
      return Pitch;
   }
    
}

