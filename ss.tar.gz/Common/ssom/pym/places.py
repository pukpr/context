
import sys

from hal import Position, Orientation
from XmlUtils import getTag, getTags, getText, parseFile, ParseError

class Place(object):
    def __init__(self, name, pos, ori):
        self.name = name
        self.pos = pos
        self.ori = ori

class PlaceManager(object):
    def __init__(self, filename):
        # a list of place names mapped to pos and ori
        # using a list (instead of dictionary) for iterating in order 
        self.places = []
        self.place_index = 0
        try:
            xml = parseFile(filename)
            for location in getTags(xml, 'location'):
                name = getText(getTag(location, 'name'), 'null')
                coordElt = getTag(location, 'coordinates')
                pos = Position(float(getText(getTag(coordElt, 'x'), '0.0')),
                               float(getText(getTag(coordElt, 'y'), '0.0')),
                               float(getText(getTag(coordElt, 'z'), '0.0')))
                orientElt = getTag(location, 'orientation')
                ori = Orientation(float(getText(getTag(orientElt, 'h'), '0.0')),
                                  float(getText(getTag(orientElt, 'p'), '0.0')),
                                  float(getText(getTag(orientElt, 'r'), '0.0')))
                self.places.append(Place(name, pos, ori))
        except ParseError, p:
            print "ParseError, invalid XML:", p


    def find_place(self, place_name):
        for i, place in enumerate(self.places):
            if place.name == place_name:
                self.place_index = i
                return place
        return None

    def get_current_place(self):
        if self.place_index >= 0 and self.place_index <= len(self.places):
            return self.places[self.place_index]
        else:
            return None

    def get_next_place(self):
        if self.place_index == len(self.places) - 1:
            self.place_index = 0
        else:
            self.place_index += 1
        return self.get_current_place()

    def get_prev_place(self):        
        if self.place_index == 0:
            self.place_index = len(self.places) - 1
        else:
            self.place_index -= 1
        return self.get_current_place()

    def get_place_pos(self, place_name):
        place = self.find_place(place_name)
        if place != None:
            return place.pos
        else:
            return None

    def get_place_names(self):
        place_names = []
        for place in self.places:
            place_names.append(place.name)
        return place_names


    

