from threading import Lock, Condition, Thread
import time
import sys

class Notify(object):

    def __init__(self):
        self.__cond = Condition(Lock())

    def notify_all(self):
        self.__cond.acquire()
        try:
            self.__cond.notifyAll()
        finally:
            self.__cond.release()

    def notify(self):
        self.__cond.acquire()
        try:
            self.__cond.notify()
        finally:
            self.__cond.release()

    def wait(self, timeout=None):
        self.__cond.acquire()
        try:
            self.__cond.wait(timeout)
        finally:
            self.__cond.release()
            
            
            
