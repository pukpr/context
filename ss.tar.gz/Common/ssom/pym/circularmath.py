import math

class CircularMath(object):
    """Copied from our Ada hal-fp_utilities.adb circular math generic package"""

    def __init__(self, min, max):
        """min must be less than max"""
        assert(min < max)
        self.min = min
        self.max = max
        self.zero_offset = self.max - self.min
        self.half_offset = self.zero_offset / 2.0
        self.delta_max = self.half_offset
        self.delta_min = -self.half_offset

    def normalize(self, value):
        return_value = value
        while return_value >= self.max:
            return_value = return_value - self.zero_offset
        while return_value < self.min:
            return_value = return_value + self.zero_offset
        return return_value

    def long_normalize(self, value):
        return self.normalize(value - self.zero_offset * math.floor (value / self.zero_offset))

    def difference(self, value1, value2):
        temp = self.normalize(value1 - value2)
        if temp >= self.delta_max:
            temp = temp - self.zero_offset
        elif temp < self.delta_min:
            temp = temp + self.zero_offset
        return temp

    def add(self, value1, value2):
        return self.normalize(value1 + value2)

    def subtract(self, value1, value2):
        return self.normalize(value1 - value2)

    def is_equal(self, left, right, epsilon = 0.1):
        return abs(self.difference(left, right)) <= epsilon

    def is_zero(self, value, epsilon = 0.1):
        return abs(self.difference(value, 0.0)) <= epsilon


                
