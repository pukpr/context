#!/usr/bin/env python

from http_utilities import http_query
from XmlUtils import item, parse, getText, getTag
import os
import _hal_lib

def triple_to_string(triple):
    if triple != None:
        return "%s, %s, %s" % (triple[0], triple[1], triple[2])
    else:
        return ""

class DvsCommand(object):
    """
    A division command that may include a translation, a rotation, or both.
    """

    def __init__(self, assembly='', trans=None, rot=None, entity=''):
        self.assembly = assembly
        self.trans = trans
        self.rot = rot
        self.entity = entity

    def to_string(self):
        return "(%s) (%s)" % (triple_to_string(self.trans), triple_to_string(self.rot))

class DvsControl(object):

    def __init__(self, dvsHost = os.getenv("DIVISION", ""), dvsPort = '5612'):
        self.dvsHost = dvsHost
        self.dvsPort = dvsPort
        self.debug = os.getenv("DVS_DEBUG", "0") != "0"
        self.do_coordinate_conversion = os.getenv("COORD_CONVERSION", "0") != "0"

    def pri(self, s):
        if self.debug:
            print s

    def dvs_query(self, xml, command='/hal.sms.proxy.put_command'):
        result = ''
        if self.dvsHost != "":
            result = http_query(self.dvsHost, self.dvsPort, command, 'set=%s' %(xml))
        return result

    def link(self, parent, child, entity=''):
        self.pri('Linking %s as child to %s as parent' %(child, parent))
        xml = item('dvs_record',
                   item('msg_type', '7') +
                   item('assembly', parent) +
                   item('event', child) +
                   item('entity', entity))
        self.dvs_query(xml)

    def event(self, assembly, name, entity=''):
        self.pri('Calling event %s on assembly %s.' %(assembly, name))
        xml = item('dvs_record',
                   item('msg_type', '1') +
                   item('assembly', assembly) +
                   item('event', name) +
                   item('entity', entity))
        self.dvs_query(xml)

    def coord_convert(self, (x, y, z)):
        if self.do_coordinate_conversion:
            return (x, z, y)
        else:
            return (x, y, z)

    def set_rot_order(self, entity, dof, rot_order):
        xml = item('set_rot_order',
        item('entity', entity) +
              item('dof', dof) +
              item('rot_order', rot_order))
        self.dvs_query(xml, '/hal.sms.proxy.put_rot_order')

    def rotate(self, assembly, a, b, c, entity='', inverse = False, euler_convert = ""):
        (a, b, c) = self.coord_convert((a, b, c))
        self.pri('Rotating assembly %s by (%s, %s, %s)' %(assembly, a, b, c))
        xml = ""
        if euler_convert != "":
            xml += item('euler_convert', euler_convert)
            xml += item('inverse', str(inverse))
        xml += item('dvs_record',
                    item('msg_type', '6') +
                    item('assembly', assembly) +
                    item('a', a) +
                    item('b', b) +
                    item('c', c) +
                    item('entity', entity))
        self.dvs_query(item('xml', xml))

    def scale(self, assembly, x, y, z, entity=''):
        (x, y, z) = self.coord_convert((x, y, z))
        self.pri('Scaling assembly %s by (%s, %s, %s)' %(assembly, x, y, z))
        xml = item('dvs_record',
                   item('msg_type', '4') +
                   item('assembly', assembly) +
                   item('x', x) +
                   item('y', y) +
                   item('z', z) +
                   item('entity', entity))
        self.dvs_query(xml)

    def translate(self, assembly, x, y, z, entity=''):
        (x, y, z) = self.coord_convert((x, y, z))
        self.pri('Translating assembly %s by (%s, %s, %s)' %(assembly, x, y, z))
        xml = item('dvs_record',
                   item('msg_type', '5') +
                   item('assembly', assembly) +
                   item('x', x) +
                   item('y', y) +
                   item('z', z) +
                   item('entity', entity))
        self.dvs_query(xml)

    def get_coordinate(self, assembly, entity=''):
    
        def make_triple(text):
            return (float(getText(getTag(text, 'x'))),
                    float(getText(getTag(text, 'y'))),
                    float(getText(getTag(text, 'z'))))
    
        xml_input = item('xml',
                         item('assembly', assembly) +
                         item('entity', entity))
        xml_output = parse(self.dvs_query(xml_input, './hal.sms.proxy.get_coord'))
        pos = self.coord_convert(make_triple(getTag(xml_output, 'pos')))
        ori = self.coord_convert(make_triple(getTag(xml_output, 'ori')))
        scale = self.coord_convert(make_triple(getTag(xml_output, 'scale')))
        return (pos, ori, scale)

    def send_command_http(self, cmd, inverse = False, euler_convert = ""):
        if cmd.trans != None:
            my_trans = self.coord_convert(cmd.trans)
            self.translate(cmd.assembly, my_trans[0], my_trans[1], my_trans[2], cmd.entity)
        if cmd.rot != None:
            my_rot = self.coord_convert(cmd.rot)
            self.rotate(cmd.assembly, my_rot[0], my_rot[1], my_rot[2], cmd.entity, inverse, euler_convert)

    def send_command(self, cmd):
        x = y = z = a = b = c = 0
        if cmd.trans != None:
            my_trans = self.coord_convert(cmd.trans)
            x = my_trans[0]
            y = my_trans[1]
            z = my_trans[2]
        if cmd.rot != None:
            my_rot = self.coord_convert(cmd.rot)
            a = my_rot[0]
            b = my_rot[1]
            c = my_rot[2]            
        _hal_lib.send_coord(str(cmd.assembly),
                            x, y, z,
                            a, b, c,
                            str(cmd.entity))

    def send_commands(self, commands):
        for cmd in commands:
            self.send_command(cmd) 

    def send_commands_http(self, commands, euler_convert = ""):
        xml = ""
        if euler_convert != "":
            xml += item("euler_convert", euler_convert)
        pos_def = item("pos",
                       item("x", "0.0") +
                       item("y", "0.0") +
                       item("z", "0.0"))
        rot_def = item("rot",
                       item("a", "0.0") +
                       item("b", "0.0") +
                       item("c", "0.0"))
        for cmd in commands:
            if cmd.trans != None:
                my_trans = self.coord_convert(cmd.trans)
                pos_xml = item("pos",
                               item("x", my_trans[0]) +
                               item("y", my_trans[1]) +
                               item("z", my_trans[2]))
            else:
                pos_xml = pos_def
            if cmd.rot != None:
                my_rot = self.coord_convert(cmd.rot)
                rot_xml = item("rot",
                               item("a", my_rot[0]) +
                               item("b", my_rot[1]) +
                               item("c", my_rot[2]))
            else:
                rot_xml = rot_def
            xml += item("coord", "%s\n%s\n%s\n%s" %(item("assembly", cmd.assembly),
                                                    item("entity", cmd.entity),
                                                    pos_xml,
                                                    rot_xml))
        self.dvs_query(item('coord_vector', xml), '/hal.sms.proxy.put_coord_vector')
                  
