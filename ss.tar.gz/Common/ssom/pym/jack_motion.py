
import sys
import time
import test_tools
from copy import deepcopy
import threading

from XmlUtils import parse, getTags, getText, getTag
from test_tools import sleep_until
from notify import Notify
from math import pi
    
class EventData(object):
    def __init__(self, assembly, event_name, entity, time):
        self.assembly = assembly
        self.event_name = event_name
        self.entity = entity
        self.time = time

    def play(self, dvs):
        print 'sending event %s for assembly %s and entity %s ' %(self.event_name,
                                                                  self.assembly,
                                                                  self.entity)
        dvs.event(self.assembly, self.event_name, self.entity)

    def cmp(left, right):
        return cmp(left.time, right.time)


class StepController(object):

    def __init__(self):
        self.step_signal = Notify()
        self.step_mode = False
        self.time_dict = {}

    def next_step(self):
	print "NEXT STEP"
        self.step_signal.notify_all()

    def wait_for_next_step(self):
	"WAITING"
        self.step_signal.wait()

    def set_time(self, motion_name, time):
        self.time_dict[motion_name] = time

        
class JackMotion(threading.Thread):
    def __init__(self, dvs, fig_file, chset_file, entity_name, key, event_list, time_warp, stepper):
        super(JackMotion, self).__init__()
        self.setDaemon(True)
        self.dvs = dvs
        self.fig_file = fig_file
        self.chset_file = chset_file
        self.entity_name = entity_name
        self.key = key
        # the original may have templates in it that need to be replaced before playing
        # can't overwrite the original since the template key needs to remain in place for multiple replacements
        self.original_event_list = event_list
        self.playable_event_list = deepcopy(event_list)
        self.time_warp = time_warp
        self.times = None
        self.frames = None
        self.trigger = threading.Event()
        self.motion_complete = threading.Event()
        self.current_time = 0.0
        self.stepper = stepper
        self.start()
    
    def set_times(self, times):
        self.times = times

    def set_frames(self, frames):
        self.frames = frames

    # templates can be applied to a motion's events (an events assembly, name or entity)
    # or to a jack_motion object entity tag (without a fig_file) which sets the assembly
    def apply_template(self, template_vars):
        self.playable_event_list = deepcopy(self.original_event_list)
        if template_vars != "":
            xml = parse(template_vars)
            vars = getTags(xml, 'var')
            for var in vars:
                template_key = getText(getTag(var, 'key'))
                template_value = getText(getTag(var, 'value'))
                # now search all the events in self.playable_event_list to match the key
                # key could be the assembly, event name, or entity name
                # when found, modify the event to use the template_value
                for event in self.playable_event_list:
                #for index, event in enumerate(self.playable_event_list):
                    if event.assembly == template_key:
                        print "Template Replacement on Assembly Name: %s -> %s" %(template_key, template_value)
                        event.assembly = template_value
                        #self.playable_event_list[index].assembly = template_value
                    elif event.event_name == template_key:
                        print "Template Replacement on Event Name: %s -> %s" %(template_key, template_value)
                        event.event_name = template_value
                        #self.playable_event_list[index].event_name = template_value
                    elif event.entity == template_key:
                        print "Template Replacement on Entity: %s -> %s" %(template_key, template_value)
                        event.entity = template_value
                        #self.playable_event_list[index].entity = template_value
                # now check the assembly
                #if self.dvs.assembly == template_key:
                #    self.dvs.assembly = template_value
                    
    def play_motion(self, synchronous = False, template_vars = ''):
        if not self.trigger.isSet():
            self.apply_template(template_vars)
            self.trigger.set()
            self.synchronous = synchronous
            if self.synchronous:
                self.motion_complete.wait()
                self.motion_complete.clear()
        else:
            print "Failed to play motion for %s since the motion is already playing." %(self.key)

    # events is a list of EventData objects
    def play_sequence(self, time_warp = 1.0):
        start = time.time()
        self.playable_event_list.sort(EventData.cmp)
        event_index = 0
        for i in range(0, len(self.times)):
            if self.stepper.step_mode:
                self.stepper.wait_for_next_step()
            if self.frames[i] != []:
                # check on whether or not an event falls in between self.frames and should be played
                while event_index < len(self.playable_event_list) and self.playable_event_list[event_index].time < self.times[i]:
                    test_tools.sleep_until(start + self.playable_event_list[event_index].time / time_warp)
                    self.playable_event_list[event_index].play(self.dvs)
                    event_index += 1
                test_tools.sleep_until(start + self.times[i] / time_warp)
                self.dvs.send_commands(self.frames[i])
            if self.stepper.step_mode:
                self.stepper.set_time(self.key, self.times[i])
        # play any remaining events
        while event_index < len(self.playable_event_list):
            test_tools.sleep_until(start + self.playable_event_list[event_index].time / time_warp)
            self.playable_event_list[event_index].play(self.dvs)
            event_index += 1

    def run(self):
        while True:
            self.trigger.wait()
            sys.stdout.flush()
            self.play_sequence(test_tools.warped_time(self.time_warp))
            self.trigger.clear()
            if self.synchronous:
                self.motion_complete.set()
                

class MotionItem(object):
    def __init__(self, motion, start_time):
        self.motion = motion
        self.start_time = start_time

class JackMotionSet(threading.Thread):

    def __init__(self, key):
        super(JackMotionSet, self).__init__()
        self.setDaemon(True)
        self.key = key
        self.motion_items = []
        self.trigger = threading.Event()
        self.motion_complete = threading.Event()
        self.start()

    def add_motion(self, motion, start_time):
        new_item = MotionItem(motion, start_time)
        insert_index = len(self.motion_items)
        for index, item in enumerate(self.motion_items):
            if new_item.start_time < item.start_time:
                insert_index = index
                break
        self.motion_items.insert(insert_index, new_item)

    def play_motion_set(self, synchronous = False, template_vars = ''):
        if not self.trigger.isSet():
            self.template_vars = template_vars
            self.trigger.set()
            self.synchronous = synchronous
            if self.synchronous:
                self.motion_complete.wait()
                self.motion_complete.clear()
        else:
            print "Failed to play motion_set for %s since the motion_set is already playing." %(self.key)

    def run(self):

        while True:
            self.trigger.wait()
            sys.stdout.flush()

            start = time.time()
            for motion_item in self.motion_items:
                test_tools.sleep_until(start + motion_item.start_time)
                motion_item.motion.play_motion(False, self.template_vars)
            
            self.trigger.clear()
            if self.synchronous:
                self.motion_complete.set()
                
