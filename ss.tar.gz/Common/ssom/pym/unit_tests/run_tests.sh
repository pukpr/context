env PYTHONPATH=../ python suite.py
