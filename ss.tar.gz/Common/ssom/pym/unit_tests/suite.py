import sys
from unittest import TestCase, TestSuite, TextTestRunner, makeSuite

from circularmathtest import CircularMathTest

def suite():
    suite = TestSuite((
        makeSuite(CircularMathTest)
        ))
    return suite

if __name__ == '__main__':
    runner = TextTestRunner()
    runner.run(suite())
    sys.exit(0)
