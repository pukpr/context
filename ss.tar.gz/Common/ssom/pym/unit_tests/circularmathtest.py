
import unittest

from circularmath import CircularMath

class CircularMathTest(unittest.TestCase):

    def setUp(self):
        self.cm = CircularMath(-180.0, 180.0)

    def testAdd(self):
        self.assertAlmostEquals(self.cm.add(179.0, 2.0), -179.0)
        self.assertAlmostEquals(self.cm.add(-150.0, -100.0), 110.0)
        self.assertAlmostEquals(self.cm.add(10.0, 20.0), 30.0)
        self.assertAlmostEquals(self.cm.add(-10.0, 20.0), 10.0)
        self.assertAlmostEquals(self.cm.add(10.0, -200.0), 170.0)
        self.assertAlmostEquals(self.cm.add(200.0, 0.0), -160.0)

    def testSubtract(self):
        self.assertAlmostEquals(self.cm.subtract(179.0, -2.0), -179.0)
        self.assertAlmostEquals(self.cm.subtract(-150.0, 100.0), 110.0)
        self.assertAlmostEquals(self.cm.subtract(10.0, -20.0), 30.0)
        self.assertAlmostEquals(self.cm.subtract(-10.0, -20.0), 10.0)
        self.assertAlmostEquals(self.cm.subtract(10.0, 200.0), 170.0)

    def testIsEqual(self):
        self.assertTrue(self.cm.is_equal(179.0, -181.0))
        self.assertTrue(self.cm.is_equal(180.0, -180.0))
        self.assertTrue(self.cm.is_equal(360.0, 0.0))
        self.assertTrue(self.cm.is_equal(0.0, 360.0))
        self.assertTrue(self.cm.is_equal(0.0, -360.0))
        self.assertTrue(self.cm.is_equal(720.0, 0.0))
        self.assertTrue(self.cm.is_equal(540.0, 180.0))

    def testMinGreaterThanMax(self):
        self.assertRaises(AssertionError, CircularMath, 180, -180)


def suite():
    suite = unittest.makeSuite(CircularMathTest)
    return unittest.TestSuite(suite)

if __name__ == '__main__':
    unittest.main()
        
