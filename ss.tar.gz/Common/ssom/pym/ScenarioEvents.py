
import sys
import os
import time
import threading
from math import floor

from http_utilities import http_query

sys.path.insert(0, os.environ["PACE_PYM"])
sys.path.insert(0, os.environ["PACE_PYM"] + '/../../../cannon/vcs/pym/lib/uio.zip')

from TemplateAction import TemplateAction

class RequiredToOverrideException(Exception):
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return repr(self.value)
    
class ScenarioEvent(object):
    def __init__(self, msg):
        self.msg = msg
    def play(self):
        raise RequiredToOverrideException('The play method must be overridden by classes that inherit from ScenarioEvent')

class MsgEvent(ScenarioEvent):
    def __init__(self, msg):
        super(MsgEvent, self).__init__(msg)
    def play(self):
        None

class FunctionEvent(ScenarioEvent):
    def __init__(self, func, msg, *args):
        super(FunctionEvent, self).__init__(msg)
        self.func = func
        self.args = args
    def play(self):
        func = self.func
        if self.args == ():
            func()
        else:
            func(*self.args)

class UrlEvent(ScenarioEvent):
    def __init__(self, host, port, url, cgi_params, msg):
        super(UrlEvent, self).__init__(msg)
        self.host = host
        self.port = port
        self.url = url
        self.cgi_params = cgi_params
    def play(self):
        http_query(self.host, self.port, self.url, self.cgi_params)

def to_time_string(seconds):
    total_seconds = int(seconds)
    minutes = int(floor(total_seconds / 60))
    secs = total_seconds - minutes * 60
    minutes_str = str(minutes)
    secs_str = str(secs)
    if len(minutes_str) == 1:
        minutes_str = "0%s" % minutes_str
    if len(secs_str) == 1:
        secs_str = "0%s" % secs_str
    return "%s:%s" % (minutes_str, secs_str)

class ConditionBasedEvent(object):
    def __init__(self, scenario_event, condition_description='', func=None, args=()):
        self.scenario_event = scenario_event
        self.condition_description = condition_description
        self.func = func
        self.args = args

class ConditionBasedEventRunner(threading.Thread):
    def __init__(self, condition_based_event_list):
        super(ConditionBasedEventRunner, self).__init__()
        self.setDaemon(True)
        self.list = condition_based_event_list
        self.index = -1
        self.executing = False

    def get_next_event(self):
        return self.list[self.index]

    def run(self):
        self.index = 0
        self.executing = True
        while self.index < len(self.list):
            next_event = self.get_next_event()
            time.sleep(0.1)
            if not next_event.func == None:
                if next_event.args == ():
                    while not next_event.func():
                        time.sleep(0.1)
                else:
                    while not next_event.func(*next_event.args):
                        time.sleep(0.1)
            print "Playing event: ", next_event.scenario_event.msg
            sys.stdout.flush()
            next_event.scenario_event.play()
            self.index += 1
        self.executing = False
    
class TimeOrderedEvent(object):
    def __init__(self, time, scenario_event):
        self.time = time
        self.time_string = to_time_string(time)
        self.scenario_event = scenario_event

class TimeOrderedEventRunner(threading.Thread):
    def __init__(self, time_ordered_event_list):
        super(TimeOrderedEventRunner, self).__init__()
        self.setDaemon(True)
        self.list = time_ordered_event_list
        self.index = -1
        self.start_time = 0
        self.pause_time = 0
        self.executing = False

    def get_next_event(self):
        return self.list[self.index]

    def get_current_time(self):
        return time.time() - self.start_time

    def run(self):
        self.index = 0
        self.start_time = time.time()
        self.executing = True

        while self.index < len(self.list):
            next_event = self.get_next_event()
            time.sleep(next_event.time - self.get_current_time())
            print "Playing event: ", next_event.scenario_event.msg
            sys.stdout.flush()
            next_event.scenario_event.play()
            self.index += 1
        self.executing = False

class TimeOrderedEventTemplate(TemplateAction):
    
    def __init__(self, time_ordered_event_runner):
        """
        time_ordered_event_list is expected to be a list of TimeOrderedEvent objects.
        The list should be ordered increasing by time
        """
        super(TimeOrderedEventTemplate, self).__init__('time_ordered_event.tmpl')
        self.runner = time_ordered_event_runner

    def Input(self):
        """
        The current state is always returned. Can also supply an 'action' cgi param
        with the possible values:
        ?action=start -> Start the time ordered event scenario
        """
        try:
            if 'action' in self.params:
                action = self.params['action']
            else:
                action = ''
            if action == 'start':
                self.runner.start()
                
            if self.runner.executing:
                self.tmpl.currently = 'Executing'
                self.tmpl.current_time = to_time_string(self.runner.get_current_time())
            else:
                self.tmpl.currently = 'Not Executing'
                self.tmpl.current_time = '0'
            self.tmpl.event_list = self.runner.list
            self.tmpl.next_event_index = self.runner.index
            self.send()
        except Exception, e:
            print "Unexpected error:", sys.exc_info()[0]
            print e
            sys.stdout.flush()
            raise

class ConditionBasedEventTemplate(TemplateAction):

    def __init__(self, condition_based_event_runner):
        super(ConditionBasedEventTemplate, self).__init__('condition_based_event.tmpl')
        self.runner = condition_based_event_runner

    def Input(self):
        try:
            if 'action' in self.params:
                action = self.params['action']
            else:
                action = ''
            if action == 'start':
                self.runner.start()
            if self.runner.executing:
                self.tmpl.currently = 'Executing'
            else:
                self.tmpl.currently = 'Not Executing'
            self.tmpl.event_list = self.runner.list
            self.tmpl.next_event_index = self.runner.index
            self.send()
        except Exception, e:
            print "Unexpected error:", sys.exc_info()[0]
            print e
            sys.stdout.flush()
            raise

class NextEventTemplate(TemplateAction):
    def __init__(self, event_list):
        super(NextEventTemplate, self).__init__('next_event.tmpl')
        self.event_list = event_list
        self.index = -1
        self.max_index = len(self.event_list) - 1

    def Input(self):
        try:
            print "Processing Next Event!"
            if 'index' in self.params:
                index = int(self.params['index'])
                if index >= 0 and index <= self.max_index:
                    self.index = index
            
            # the first time just display what the first event is
            self.tmpl.complete = False
            if self.index != -1:
                self.event_list[self.index].play()
            if self.index == (self.max_index):
                self.tmpl.complete = True
            else:
                self.index += 1
            self.tmpl.event_list = self.event_list
            self.tmpl.current_index = self.index
            self.send()
        except Exception, e:
            print "Unexpected error:", sys.exc_info()[0]
            print e
            sys.stdout.flush()
            raise

