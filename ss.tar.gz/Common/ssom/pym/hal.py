
class Position(object):
    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z

class Orientation(object):
    def __init__(self, h, p, r):
        self.h = h
        self.p = p
        self.r = r

class Place(object):
    def __init__(self, name, pos, ori):
        self.name = name
        self.pos = pos
        self.ori = ori
