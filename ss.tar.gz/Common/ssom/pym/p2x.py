#! /usr/bin/env python

from time import sleep

from http_utilities import *

bezel_buttons = [[55, 100],   #  0 (power)
                 [230, 135],  #  1 (top, left to right)
                 [350, 135],  #  2
                 [470, 135],  #  3
                 [590, 135],  #  4
                 [700, 135],  #  5
                 [815, 135],  #  6
                 [930, 135],  #  7
                 [1045, 135], #  8
                 [230, 895],  #  9 (bottom, left to right)
                 [350, 895],  # 10
                 [470, 895],  # 11
                 [590, 895],  # 12
                 [700, 895],  # 13
                 [815, 895],  # 14
                 [930, 895],  # 15
                 [1045, 895], # 16
                 [140, 230],  # 17 (left side, top to bottom)
                 [140, 370],  # 18
                 [140, 510],  # 19
                 [140, 650],  # 20
                 [140, 790],  # 21
                 [1140, 230], # 22 (right side, top to bottom)
                 [1140, 370], # 23
                 [1140, 510], # 24
                 [1140, 650], # 25
                 [1140, 790]] # 26

def push_button(button):
    """Pushes a bezel button on the crew screen through HTTP requests.

    The locations of the bezel buttons are hard-coded and assume that the crew screen is positioned at the absolute top-left of the screen at the default resolution."""
    global bezel_buttons
    params = "".join([str(bezel_buttons[button][0]), " ", str(bezel_buttons[button][1])])
    http_query("localhost", "5699", "ses.p2x.place", 'set=' + params)
    sleep(1)
    click()

def move_pointer(x, y):
    """Moves the mouse pointer to point (x, y) on the screen. Does not actuate a mouse click."""
    params = ''.join([str(x), ' ', str(y)])
    http_query('localhost', '5699', 'ses.p2x.place', 'set=' + params)

def relative_move_pointer(dx, dy):
    """Moves the mouse pointer relative to the current
    position by (dx, dy) on the screen. Does not actuate a mouse click."""
    params = ''.join([str(dx), ' ', str(dy)])
    http_query('localhost', '5699', 'ses.p2x.move', 'set=' + params)

def click():
    """Actuates a mouse click."""
    http_query('localhost', '5699', 'ses.p2x.push')

def press():
    """Actuates a mouse press."""
    http_query('localhost', '5699', 'ses.p2x.press')

def release():
    """Actuates a mouse release."""
    http_query('localhost', '5699', 'ses.p2x.release')

def push_login_enter():
    """Pushes the 'Enter' button on the FCS Login screen."""
    move_pointer(375, 710)
    sleep(1)
    click()

def push_combat_mode():
    """Pushes the 'Combat' button on the System Configuration screen."""
    move_pointer(550, 520)
    sleep(1)
    click()
