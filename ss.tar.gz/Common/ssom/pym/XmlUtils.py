#    This document contains trade secrets or other proprietary information.
#    It shall not be used, duplicated or disclosed in whole or in part 
#    without the express written permission of BAE Systems.
#    
#    This information is exempt from disclosure under Exemptions 3 and 4 
#    of the Freedom of Information Act. Any unauthorized disclosure by a 
#    Government employee is a violation of the Trade Secrets Act.
#    
#    The printed copy of the on-line document may not be 
#    current - verify current revision.

# $Id: XmlUtils.py,v 1.1 2006/05/30 16:56:01 ludwiglj Exp $

"Contains utilities useful for parsing XML."

from xml.dom import minidom

class Error(Exception):
    """Base class for exceptions in this module."""
    pass

class ParseError(Error):
    pass

def parse(source):
    try:
        xmldoc = minidom.parseString(source)
        return xmldoc
    except Exception, e:
        raise ParseError(str(e))

def parseFile(filename):
    try:
        f = open(filename, 'r')
        text = f.read()
        f.close()
        return parse(text)
    except IOError, e:
        print "IOError on file ", filename
        raise IOError

def getAttribute(node, attr, alt=None):
    """Returns the text value of an attribute.

    alt is an optional alternate text to return if node contains no data.
    """
    if node:
        return node.getAttribute(attr)
    else:
        return alt

def getTags(node, tag):
    "Returns a list of nodes that match tag."
    return node.getElementsByTagName(tag)

def getTag(node, tag):
    "Returns the first node to match tag."
    tags = getTags(node, tag)
    if tags:
        return tags[0]
    else:
        return None

def getText(node, alt=None):
    """Returns the text value of this node.

    alt is an optional alternate text to return if node contains no data.
    """
    try:
        for child in node.childNodes:
            if minidom.Node.TEXT_NODE == child.nodeType or minidom.Node.CDATA_SECTION_NODE == child.nodeType:
                return child.data
        return alt
    except:
        return alt

def getElement(doc):
    return doc.documentElement

def getFirstChild(node):
    return node._get_firstChild()

def item(tag, value):
    return '<%s>%s</%s>' %(tag, value, tag)

def item_attr(tag, attribute, attribute_value, tag_value):
    return '<%s %s="%s">%s</%s>' %(tag, attribute, attribute_value, tag_value, tag)

