
import sys
import os

sys.path.insert(0, os.environ["PACE_PYM"] + '/../../vcs/pym')

from uio.Action import Action
import uio.Constants
from Cheetah.Template import Template

class TemplateAction(Action):
    """
    Helper for processing Cheetah templates.  Use the Action
    pattern like normal, but set the name to 'example.tmpl',
    Set the template variables in the Input method and call send.
    """
    
    def __init__(self, name):
        super(TemplateAction, self).__init__(name)
        # currently the .tmpl files must be in the web root directory or
        # else the name must be the path to the .tmpl file
        # in future recursively search beneath web_root for .tmpl files
        self.tmpl = Template(file = '%s/%s' % (uio.Constants.web_root, name))

    def send(self, content_type = 'text/html'):
        data = str(self.tmpl)

        self.send_response(200)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', len(data))
        self.end_headers()
        self.write(data)
