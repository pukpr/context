
import os
import sys
import signal
from subprocess import Popen as _Popen, PIPE as _PIPE
from http_utilities import http_query, HttpConnectException
from time import sleep, time
import threading
from test_tools import check_python_version

PIPE_SERVER_NODE = 99
PIPE_SERVER_PORT = 5600 + PIPE_SERVER_NODE
NUM_LOG_FILES = 10

def _getoutput(cmd):
    """Executes cmd and returns its output."""
    return _Popen(str(cmd).split(), stdout=_PIPE).communicate()[0].strip()

def _system(cmd, env=None):
    """Executes cmd with environment _env_."""
    _Popen(str(cmd).split(), stdout=_PIPE, env=env).communicate()

class Automated(threading.Thread):
    def __init__(self):
        super(Automated, self).__init__()
        self.setDaemon(True)
    def get_logfile(self):
        # only keep one of these for now
        os.system('mkdir -p logs > /dev/null')
        os.system('rm -f logs/testout.log >& /dev/null')
        return 'logs/testout.log'

    def run(self):
        print('Running automated script: %s \n' % os.getenv('automated'))
        if 'prompt' in os.environ:
            prompt('Click to launch automated script')
        logname = self.get_logfile()

        _os = _getoutput('uname')

        if 'Sun OS' == _os:
            xterm_location = '/usr/local/bin/xterm'
        elif 'Linux' == _os:
            release = _getoutput('cat /etc/redhat-release')
            if '5' in release:
                xterm_location = '/usr/bin/xterm'
            else:
                xterm_location = '/usr/bin/X11/xterm'
        else:
            xterm_location = '/usr/bin/X11/xterm'

        env = dict(os.environ)
        env.pop('PKG_CONFIG_PATH', '')
        env.pop('_LMFILES_', '')
        env['PATH'] = '%s%s:%s' % (env['PYTHONHOME'], '/bin/', env['PATH'])
        env['LD_LIBRARY_PATH'] = '%s%s' % (env['PYTHONHOME'], '/lib/')
        env.pop('MANPATH', '')

        #_system(''.join((
        #    xterm_location,
        #    ' -e ',
        #    os.getenv('PROJECT_ROOT'),
        #    '/Common/ssom/test_tools/run_it.sh ',
        #    os.getenv('automated'),
        #    ' ',
        #    logname,
        #    ';'
        #)), env)

        _system(''.join((
            os.getenv('PROJECT_ROOT'),
            '/Common/ssom/test_tools/run_it.sh ',
            os.getenv('automated'),
            ' ',
            logname,
            ';'
            )), env)

class Launch_P4(threading.Thread):
    def __init__(self):
        super(Launch_P4, self).__init__()
        self.setDaemon(True)
        self.p4_complete = False

    # returns a logfile name and moves other logs over
    def get_logfile_name(self):
        os.system('mkdir -p logs > /dev/null')
        os.system('rm -f logs/%s.log >& /dev/null' %NUM_LOG_FILES)
        # it is okay if not all the logfiles exist yet
        i = NUM_LOG_FILES
        while i > 0:
            os.system('mv logs/%s.log logs/%s.log >& /dev/null' %(i-1, i))
            i = i-1
        return 'logs/1.log'

    def is_p4_complete(self):
        return self.p4_complete

    def run(self):
        logfile = self.get_logfile_name()  # logfile is hardcoded in p4.sh, but still need to call to move logs around
        new_env = os.environ
        new_env['PACE_NODE'] = str(PIPE_SERVER_NODE)
        os.spawnle(os.P_WAIT, '%s/p4.sh' %(os.environ['P4PATH']), new_env)
        self.p4_complete = True

def remove_file(file):
    "Removes file if present and if file does not exist fails quietly"
    try:
        os.remove(file)
    except OSError:
        None


# provides a large prompt window with control over what text
# appears in the window
def prompt(text):
    print('A prompt button has appeared above.')
    _os = _getoutput('uname')
    if 'Sun OS' == _os:
        bin = '/usr/local/bin/xmessage'
    elif 'Linux' == _os:
        release = _getoutput('cat /etc/redhat-release')
        if '5' in release:
            bin = '/usr/bin/xmessage'
        else:
            bin = '/usr/bin/X11/xmessage'
    else:
        bin = '/usr/bin/X11/xmessage'

    opts = '-buttons "Shutdown" -default "Shutdown" -title "Modsim VP"'
    cmd = '%s %s %s' % (bin, opts, text)
    os.system(cmd)

def print_bae():
    bae = """
    ____  ___    ______   _____            __
   / __ )/   |  / ____/  / ___/__  _______/ /____  ____ ___  _____
  / __  / /| | / __/     \__ \/ / / / ___/ __/ _ \/ __ `__ \/ ___/
 / /_/ / ___ |/ /___    ___/ / /_/ (__  ) /_/  __/ / / / / (__  )
/_____/_/  |_/_____/   /____/\__, /____/\__/\___/_/ /_/ /_/____/
                            /____/

    ____                        _      __
   / __ \_________  ____  _____(_)__  / /_____ ________  __
  / /_/ / ___/ __ \/ __ \/ ___/ / _ \/ __/ __ `/ ___/ / / /
 / ____/ /  / /_/ / /_/ / /  / /  __/ /_/ /_/ / /  / /_/ /
/_/   /_/   \____/ .___/_/  /_/\___/\__/\__,_/_/   \__, /
                /_/                               /____/

     """
    print(bae)


class Launcher(object):

    def __init__(self):
        self.max_wait_time = 60.0

    # kills off apps
    def kill_apps(self):
        http_query('localhost', PIPE_SERVER_PORT, 'ses.p2x.quit')
        http_query('localhost', PIPE_SERVER_PORT, 'pp', '-100')

    # should call this on a normal exit and it is called during a trapped exit
    def kill_children(self):
        # kills off all child processes
        os.system('kill -9 0')

    # called on a trapped exit
    def trapped_cleanup(self, sig_num, stack_frame):
        print("TRAPPED SIGNAL NUMBER %s" % sig_num)
        os.system('./%s' %os.getenv('CLEAN_FILE'))
        self.kill_children()

    # call this to register your launcher to look for the signal to call
    # the .clean_demo_HOST file
    def register_trap(self):
        host = _getoutput('uname -n')
        os.environ['CLEAN_FILE'] = '.clean_demo_%s' %host
        # trap the control-C's so we can call the .clean_demo script
        signal.signal(signal.SIGHUP, self.trapped_cleanup)
        signal.signal(signal.SIGINT, self.trapped_cleanup)

    # initialize launching environment
    def launching_environment(self, project_dir):
        check_python_version()

        release = _getoutput('cat /etc/redhat-release')
        if '5' in release:
            osversion = 'RHEL5'
        elif '3' in release:
            osversion = 'RHEL3'
        else:
            osversion = 'RHEL'

        os.environ['OS_VERSION'] = osversion

        os.environ['SYS'] = 'Linux'
        os.environ['_EXIT'] = '1'
        project_root = '%s/../' %project_dir
        os.environ['PROJECT_ROOT'] = project_root
        os.environ['PACE'] = ('%s/ssom/:%s/Common/ssom/' %
                              (project_dir, project_root))
        os.environ['PACE_PYM'] = '%s/Common/ssom/pym' % project_root
        os.environ['PROJECT_TEST'] = '%s/cannon/test/' % project_root
        os.environ['P4PATH'] = '%s/Common/ssom/test_tools' % project_root
        os.environ['P4BIN'] = ('%s/Common/bin/%s/p4_main' %
                               (project_root, os.getenv('SYS')))
        os.environ['P4NOENV'] = '-i'
         # LD_LIBRARY_PATH is not needed and its presence 
         # can make the launching of p4 much slower
        os.environ.pop('LD_LIBRARY_PATH', '')
        os.environ.pop('PKG_CONFIG_PATH', '')
        os.environ.pop('_LMFILES_', '')

        os.environ['PATH'] = ':'.join((
            '%s/Common/bin/%s/' % (project_dir, os.getenv('SYS')),
            '/usr/bin',
            '/bin',
            '/usr/bin/X11',
            '/usr/local/bin',
            '/usr/X11R6/bin'
        ))

        if os.getenv('P4DEBUG', '0') == '0':
            os.environ['grp_nostderr'] = '1'
        else:
            os.environ['grp_nostderr'] = '0'
        os.environ['PACE_DISPLAY'] = '0'

    # launches p4 and apps ... returns when p4 has finished launching and is ready
    def launch_apps(self):
        # if P4CHECK exists then run a P4 CHECK instead of a real run
        if 'P4CHECK' in os.environ:
            os.system('/bin/env PACE_NODE=%s %s CHECK' %
                      (PIPE_SERVER_NODE, os.getenv('P4BIN')))
            sys.exit(0)
        if 'P4CMDS' in os.environ:
            os.system('/bin/env PACE_NODE=%s %s CMDS' %
                      (PIPE_SERVER_NODE, os.getenv('P4BIN')))
            sys.exit(0)
        if 'CLEAN_FILE' in os.environ:
            # touch the clean file now and chmod it to avoid permission problems
            os.system('touch %s' % os.getenv('CLEAN_FILE'))
            os.system('chmod a+rwx %s' % os.getenv('CLEAN_FILE'))

        # have a separate thread run p4
        self.p4_thread = Launch_P4()
        self.p4_thread.start()

        # retry until the query goes through!
        connected = False
        while not connected:
            try:
                http_query('localhost', PIPE_SERVER_PORT,
                           'ses.pipe_server.wait_for_p4_is_ready')
                connected = True
            except HttpConnectException:
                print('\n\n waiting for p4 to finish launching. \n')
                sleep(1)

    def do_kill_prompt(self):
        return not ("NO_KILL_PROMPT" in os.environ)

    def shutdown(self):
        self.kill_apps()
        max_wait_until = time() + self.max_wait_time
        while not self.p4_thread.is_p4_complete() and time() < max_wait_until:
            sleep(0.25)
        if not self.p4_thread.is_p4_complete():
            os.system("./.clean_demo_%s" % os.getenv("HOST", "localhost"))

    # runs automated file if "automated" env variable is specified,
    # launches kill prompt unless "NO_KILL_PROMPT" env variable is specified
    def use_apps(self, prompt_text=''):
        if 'automated' in os.environ:
            auto = Automated()
            auto.start()
            if 'NO_KILL_PROMPT' in os.environ:
                auto.join()
                self.shutdown()
        # this pops up a dialog and waits for user to kill everything
        if self.do_kill_prompt():
            if not prompt_text:
                prompt_text = 'Shut down simulation'
            prompt(prompt_text)
            self.shutdown()
