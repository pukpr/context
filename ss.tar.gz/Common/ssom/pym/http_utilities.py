#! /usr/bin/env python

import urllib
import urlparse
from urlparse import (
    urlunsplit as _urlunsplit,
    urlsplit as _urlsplit
)
import os
import httplib
import mimetypes
import threading
import sys

from urllib2 import (
    urlopen as _urlopen,
    Request as _Request,
    URLError as _URLError,
    HTTPError as _HTTPError
)
from httplib import BadStatusLine as _BadStatusLine

from time import sleep as _sleep

_MAX_SEND_ATTEMPTS = 5

debug = False
if os.environ.has_key("TEST_DEBUG"):
    if os.environ["TEST_DEBUG"] == "1":
        debug = True

class HttpConnectException(Exception):
    pass

def _success_code(code):
    return (code >= 200) and (code < 300)

def http_query(host, port, url, cgi_params=''):
    """
    Performs HTTP query where 
    host, port, url, and cgi_params are strings.

    Returns result as a string.
    """
    attempts = 0
    while attempts < _MAX_SEND_ATTEMPTS:
        attempts += 1

        try:
            loc = '%s:%s' % (host, port)
            req = _urlunsplit(('http', loc, urllib.quote_plus(url), urllib.quote_plus(cgi_params, '=&'), ''))
            request = _Request(req, None)
            conn = _urlopen(request)
            ret_val = conn.read()
            conn.close()
            return ret_val
        except _HTTPError, e:
            ret_val = e.read()
            if _success_code(e.code):
                return ret_val
            raise
        except _BadStatusLine:
            msg = ''.join((
                'An error occurred while attempting ',
                'to establish a connection with ',
                '%s:%s.' % (host, port)
            ))
            print(msg)
        except _URLError, e:
            msg = ''.join((
                'An error occurred while attempting ',
                'to request %s. %s. Attempt #%s.' % (str(req), str(e), str(attempts))
            ))
            _sleep(0.1 * attempts)
            if attempts >= _MAX_SEND_ATTEMPTS:
                raise HttpConnectException(msg)
        except IOError, e:
            msg = ''.join((
                'An I/O error occurred while attempting ',
                'to establish a connection with ',
                '%s:%s. %s. Attempt #%s.' % (host, port, str(e), str(attempts))
            ))
            _sleep(0.1 * attempts)            
            if attempts >= _MAX_SEND_ATTEMPTS:            
                raise HttpConnectException(msg)

    req = 'http://%s:%s/%s' % (host, port, url)
    msg = 'Could not request %s.' % req
    print(msg)
    return ''

def http_post(host, port, url, data={}):
    "Performs HTTP POST with data being the POST data."
    encoded_url = _urlunsplit(
            ('http', '%s:%s' % (host, port), url, '', ''))
    encoded_data = urllib.urlencode(data)
    if debug:
        print('trying post on url %s with data %s' % (encoded_url, data))
    try:
        f = urllib.urlopen(encoded_url, encoded_data)
    except IOError:
        msg = 'In http_post, could not connect to %s:%s' % (host, port)
        raise HttpConnectException(msg)
    return f.read()

def http_get(host, port, url, cgi_params=''):
    """
    Performs HTTP GET where
    host, port, url, and cgi_params are strings.
    Returns result as a string.
    """
    encoded_url = _urlunsplit(
            ('http', '%s:%s' % (host, port), url,
                urllib.quote_plus(cgi_params, '=&'), ''))
    if debug:
        print('trying query on url %s' % encoded_url)
    try:
        f = urllib.urlopen(encoded_url)
    except IOError:
        msg = 'In http_get, could not connect to %s:%s' %(host,port)
        raise HttpConnectException(msg)
    return f.read()

def http_post_multipart (url, fields, files):
    urlparts = _urlsplit(url)
    return post_multipart(urlparts[1], urlparts[2], fields,files)

# taken from http://aspn.activestate.com/ASPN/Cookbook/Python/Recipe/146306
def post_multipart(host, selector, fields, files):
    """
    Post fields and files to an http host as multipart/form-data.
    fields is a sequence of (name, value) elements for regular form fields.
    files is a sequence of (name, filename, value) elements for data to be uploaded as files
    Return the server's response page.
    """
    content_type, body = encode_multipart_formdata(fields, files)
    h = httplib.HTTP(host)
    h.putrequest('POST', selector)
    h.putheader('content-type', content_type)
    h.putheader('content-length', str(len(body)))
    h.endheaders()
    h.send(body)
    errcode, errmsg, headers = h.getreply()
    return h.file.read()

# taken from http://aspn.activestate.com/ASPN/Cookbook/Python/Recipe/146360
def encode_multipart_formdata(fields, files):
    """
    fields is a sequence of (name, value) elements for regular form fields.
    files is a sequence of (name, filename, value) elements for data to be uploaded as files
    Return (content_type, body) ready for httplib.HTTP instance
    """
    BOUNDARY = '----------ThIs_Is_tHe_bouNdaRY_$'
    CRLF = '\r\n'
    L = []
    for (key, value) in fields:
        L.append('--' + BOUNDARY)
        L.append('Content-Disposition: form-data; name="%s"' % key)
        L.append('')
        L.append(value)
    for (key, filename, value) in files:
        L.append('--' + BOUNDARY)
        L.append('Content-Disposition: form-data; name="%s"; filename="%s"' % (key, filename))
        L.append('Content-Type: %s' % get_content_type(filename))
        L.append('')
        L.append(value)
    L.append('--' + BOUNDARY + '--')
    L.append('')
    body = CRLF.join(L)
    content_type = 'multipart/form-data; boundary=%s' % BOUNDARY
    return content_type, body

def get_content_type(filename):
    return mimetypes.guess_type(filename)[0] or 'application/octet-stream'

class p4thread ( threading.Thread ):
    def run ( self ):
        sys.stdout.write('P4 is ready\n')
        sys.stdout.flush()
        raw_input("Enter to exit:")
        os._exit(0)
