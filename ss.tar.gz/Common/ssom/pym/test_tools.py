import sys
import re
import os

import smtplib
import time

#from datetime import *

num_successes = 0
num_failed = 0

time_warp = float(os.getenv("TIME_WARP", "1.0"))

def warped_time(duration):
    return duration / time_warp
 
def sleep_until(wake_up_time):
    amount = wake_up_time - time.time()
    if amount > 0.0:
        time.sleep(amount)

def sleep(duration):
    time.sleep(duration/time_warp)

def send_mail(to_list, subject, body, from_str='python test tools'):
    'to_list should be an array of strings.'
    server = smtplib.SMTP('asdmngwia')
    msg = 'To: %s\r\nFrom: %s\r\nSubject:%s\r\n%s' %(', '.join(to_list), from_str, subject, body)
    server.sendmail(from_str, to_list, msg)
    server.quit()

def say(to_say):
    if os.environ.has_key('PACE_PYM'):
        say_exec = '/bin/env MB_FREQ=16000 %s/../audio/say' %(os.getenv('PACE_PYM'))
        os.system('%s "%s"' %(say_exec, to_say))
    else:
        print 'Should be saying :%s: but PACE_PYM is not set!' %(to_say)

def assert_true(bool_expr, error_msg, kill_if_failed=False):
    """Checks that bool_expr is true.  If not prints error_msg.  Kills test if kill_if_failed is true.  Tracks statistics."""

    if not bool_expr:
        global num_failed
        num_failed = num_failed + 1
        print "Assertion Failed: ", error_msg
        if kill_if_failed:
            print "Can't go on due to failure.  Dying now..."
            sys.exit(0)
            
    else:
        global num_successes
        num_successes = num_successes + 1

def assert_match(the_string, to_match, error_msg, kill_if_failed=False):
    """Checks that the_string contains matches the regular expression to_match.  If not prints error_msg.  Kills test if kill_if_failed is true.  Tracks statistics."""
    if re.compile(to_match).search(the_string) == None:
        assert_true(False, error_msg, kill_if_failed)
    else:
        assert_true(True, error_msg, kill_if_failed)

def match(the_string, to_match):
    """Returns true if the regular expression to_match is found within the_string"""
    if re.compile(to_match).search(the_string) == None:
        return False
    else:
        return True

def print_stats():
    print "Total number of successful assertions: ", num_successes
    print "Total number of failed assertions: ", num_failed

def clear_stats():
    global num_failed
    global num_successes
    num_successes = 0
    num_failed = 0

def check_python_version():
    (major, minor, super_minor, dummy, dummy) = sys.version_info
    if major < 3 and minor < 4:
        print "python version 2.4 or newer is required.  You are using python %s.%s.%s " %(major, minor, super_minor)
        print "You may need to set your PYTHONHOME environment variable and make sure the python available in your PATH environment variable is 2.4 or newer. "
        sys.exit(1)
