
import os
import sys

from hal import Position, Orientation
from places import Place, PlaceManager
from http_utilities import http_query
from xml.dom.minidom import parse
from XmlUtils import getTag, getTags, getText, item, item_attr, parseFile, ParseError

class VcsControl(object):

    def __init__(self, host, port, camera, placesFile = ''):
        self._host = host
        self._port = port
        self._camera = camera
        if placesFile == '':
            self.place_manager = None
        else:
            self.place_manager = PlaceManager(placesFile)

    def query(self, action, cgiParams):
        http_query(self._host, self._port, action, cgiParams)

    def translate(self, pos):
        xml = item('data',
                   '<translate x="%s" y="%s" z="%s" />' %(pos.x, pos.y, pos.z))
        cgiParams = 'action=modify&target=%s&data=%s' %(self._camera, xml)
        self.query('update', cgiParams)

    def rotate(self, ori):
        xml = item('data',
                   '<rotate x="%s" y="%s" z="%s" />' %(ori.p, ori.h, ori.r))
        cgiParams = 'action=modify&target=%s&data=%s' %(self._camera, xml)
        self.query('update', cgiParams)

    def move_camera(self, place_name):
        place = self.place_manager.find_place(place_name)
        if place == None:
            print 'no such place '
        else:
            self.translate(place.pos)
            self.rotate(place.ori)

        
