
import _hal_lib

# maps to the Euler_Conversion enumeration in hal-rotations.ads
XYZ_TO_YXZ = 1
XZY_TO_YXZ = 2
YXZ_TO_YXZ = 3
YZX_TO_YXZ = 4
ZXY_TO_YXZ = 5
ZYX_TO_YXZ = 6

# mapping from string order to the correct enumeration value
euler_order_map = {'xyz' : XYZ_TO_YXZ,
                   'xzy' : XZY_TO_YXZ,
                   'yzx' : YZX_TO_YXZ,
                   'zxy' : ZXY_TO_YXZ,
                   'zyx' : ZYX_TO_YXZ,
                   'xy' : XYZ_TO_YXZ,
                   'zx' : ZXY_TO_YXZ,
                   'zy' : ZYX_TO_YXZ,
                   # the rest do not need conversions
                   'yxz' : YXZ_TO_YXZ,
                   'xz' : YXZ_TO_YXZ, 
                   'yx' : YXZ_TO_YXZ,
                   'yz' : YXZ_TO_YXZ,
                   'x' : YXZ_TO_YXZ,
                   'y' : YXZ_TO_YXZ,
                   'z' : YXZ_TO_YXZ}
                   
def convert_euler(conv_type, rot, inverse = False):
    if conv_type == YXZ_TO_YXZ:
        return rot
    else:
        a = _hal_lib.new_floatp()
        b = _hal_lib.new_floatp()
        c = _hal_lib.new_floatp()
        _hal_lib.convert_euler(conv_type, rot[0], rot[1], rot[2], a, b, c, inverse)   
        return (_hal_lib.floatp_value(a), _hal_lib.floatp_value(b), _hal_lib.floatp_value(c))


def convert_vector_xyz_to_yxz(in_vec, in_rot):
    out_x = _hal_lib.new_floatp()
    out_y = _hal_lib.new_floatp()
    out_z = _hal_lib.new_floatp()
    _hal_lib.convert_vector_xyz_to_yxz(in_vec[0], in_vec[1], in_vec[2],
                                       in_rot[0], in_rot[1], in_rot[2],
                                       out_x, out_y, out_z)
    return (_hal_lib.floatp_value(out_x), _hal_lib.floatp_value(out_y), _hal_lib.floatp_value(out_z))


