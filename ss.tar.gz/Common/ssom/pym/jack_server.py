#!/usr/bin/env python

from optparse import OptionParser
import sys
import os
import time

sys.path.insert(0, os.environ["PACE_PYM"])
sys.path.insert(0, os.environ["PACE_PYM"] + '/../../vcs/pym')

from jack_to_dvs_setup import jack_setup, joint_mapping, assemble_frames, assemble_frames_for_object
from jack_motion import JackMotion, JackMotionSet, EventData, StepController
import dvscontrol
import test_tools
from XmlUtils import item, item_attr, parse, getTags, getText, getTag
from uio.Action import Action
import logging.config
from TemplateAction import TemplateAction

_P4_HEARTBEAT_HZ = 2

_log_file = 'logging.config'
if os.path.exists(_log_file):
    logging.config.fileConfig(_log_file)

def dirname(path):
    dir_index = path.rfind('/')
    dir_path = './'
    if dir_index != -1:
        dir_path = path[:dir_index] + '/'
    return dir_path

class NextStep(Action):
    def __init__(self, stepper):
        super(NextStep, self).__init__('next_step')
        self.stepper = stepper
    def Input(self):
	print "nextstepbutton"
        self.stepper.next_step()

        # sleep a bit to let the current time values get set
        time.sleep(0.5)

        self.send_response(200)
        self.send_header('Content-Type', 'text/xml')
        self.end_headers()

        output = ''
        for k,v in self.stepper.time_dict.iteritems():
            output += item('motion',
                           item('name', k) +
                           item('time', str(v)))
	print output
        self.write(item('xml', output))
#	self.write('output is output')
class ToggleStep(Action):
    def __init__(self, stepper):
        super(ToggleStep, self).__init__('toggle_step')
        self.stepper = stepper
    def Input(self):
        self.stepper.step_mode = not self.stepper.step_mode
        self.send_response(200)
        self.send_header('Content-Type', 'text/html')
        self.end_headers()
        self.write('step_mode is %s'  %(self.stepper.step_mode))

class DoSetup(Action):
    def __init__(self, dvs, motions):
        super(DoSetup, self).__init__('do_setup')
        self.dvs = dvs
        self.motions = motions
    def Input(self):
        # we don't want to set an entity up more than once, but there may be multiple
        # motions per entity
        setup_entities = {}
        for k, motion in self.motions.iteritems():
            if motion.fig_file != None and motion.entity_name not in setup_entities:
                jack_setup(self.dvs, motion.fig_file, motion.entity_name)
                setup_entities[motion.entity_name] = True

class Index(TemplateAction):
    def __init__(self, motions, motion_sets):
        super(Index, self).__init__('index.tmpl')
        self.tmpl.num_motions = len(motions)
        self.tmpl.motions = motions
        self.tmpl.motion_sets = motion_sets
        self.tmpl.num_sets = len(motion_sets)
    def Input(self):
        self.send()

class DoMotion(Action):
    def __init__(self, motions):
        super(DoMotion, self).__init__('do_motion')
        self.motions = motions
    def Input(self):
        success = True
        key = self.params.get('motion', 'NO_KEY')
        template_vars = self.params.get('template', '')
        synchronous = 'synch' in self.params
        success = False
        if key in self.motions:
            motion = self.motions[key]
            motion.play_motion(synchronous, template_vars)
            success = True
        self.send_response(200)
        self.send_header('Content-Type', 'text/xml')
        body = item('success', str(success))
        self.send_header('Content-Length', len(body))
        self.end_headers()
        self.write(body)

class DoMotionSet(Action):
    def __init__(self, motions, motion_sets):
        super(DoMotionSet, self).__init__('do_motion_set')
        self.motions = motions
        self.motion_sets = motion_sets
    def Input(self):
        success = True
        key = self.params.get('motion_set', 'NO_KEY')
        template_vars = self.params.get('template', '')
        synchronous = 'synch' in self.params
        success = False
        if key in self.motion_sets:
            motion_set = self.motion_sets[key]
            motion_set.play_motion_set(synchronous, template_vars)
            success = True
        self.send_response(200)
        self.send_header('Content-Type', 'text/xml')
        body = item('success', str(success))
        self.send_header('Content-Length', len(body))
        self.end_headers()
        self.write(body)

class JackServer(object):

    def __init__(self, initFile, veHost, vePort):
        self.dvs = dvscontrol.DvsControl(veHost, vePort)
        self.stepper = StepController()
        self.parse_init_file(initFile)  # sets self.motions and self.motion_sets
        self._Index = Index(self.motions, self.motion_sets)
        self._DoMotion = DoMotion(self.motions)
        self._DoMotionSet = DoMotionSet(self.motions, self.motion_sets)
        self._NextStep = NextStep(self.stepper)
        self._ToggleStep = ToggleStep(self.stepper)
        self._DoSetup = DoSetup(self.dvs, self.motions)

    def parse_init_file(self, initFile):
        dir_path = dirname(initFile)
        f = open(initFile, 'r')
        text = f.read()
        f.close()
        xml = parse(text)

        # handle jack motions
        jack_motions = getTags(xml, 'jack_motion')
        motion_list = []
        for jack_motion in jack_motions:
            fig_file_suffix = getText(getTag(jack_motion, 'fig_file'))
            # if fig_file does not exist then treat this jack motion as an object and don't do anything with the joints
            if fig_file_suffix != None:
                fig_file = '%s%s' %(dir_path, fig_file_suffix)
            else:
                fig_file = None
            chset_file = '%s%s' %(dir_path, getText(getTag(jack_motion, 'chset_file')))
            entity_name = getText(getTag(jack_motion, 'entity_name'))
            key = getText(getTag(jack_motion, 'key'))
            time_warp = 1.0
            time_warp_str = getText(getTag(jack_motion, 'time_warp'))
            try:
                time_warp = float(time_warp_str)
            except ValueError:
                time_warp = 1.0
            except TypeError:
                time_warp = 1.0
            event_list = []
            event_nodes = getTags(jack_motion, 'event')
            for event_node in event_nodes:
                assembly = getText(getTag(event_node, 'assembly'))
                event_name = getText(getTag(event_node, 'event_name'))
                event_entity_name = getText(getTag(event_node, 'event_entity'))
                time = float(getText(getTag(event_node, 'time')))
                event_list.append(EventData(assembly, event_name, event_entity_name, time))
            motion_list.append(JackMotion(self.dvs, fig_file, chset_file, entity_name, key, event_list, time_warp, self.stepper))

        # keep track of joint_dicts per figure file to avoid extra computation
        joint_dicts = {}
        # a dictionary of the possible motions this server can play
        self.motions = {}
        for motion in motion_list:
            if motion.fig_file != None:
                if motion.fig_file not in joint_dicts:
                    joint_dicts[motion.fig_file] = joint_mapping(motion.fig_file)
                (times, frames) = assemble_frames(joint_dicts[motion.fig_file], motion.chset_file, motion.entity_name)
            else:
                (times, frames) = assemble_frames_for_object(motion.chset_file, motion.entity_name)
            motion.set_times(times)
            motion.set_frames(frames)
            self.motions[motion.key] = motion

        # handle jack motion sets
        motion_sets_xml = getTags(xml, 'jack_motion_set')
        self.motion_sets = {}
        for motion_set_xml in motion_sets_xml:
            set_key = getText(getTag(motion_set_xml, 'set_key'))
            motion_set = JackMotionSet(set_key)
            items_xml = getTags(motion_set_xml, 'item')
            for item_xml in items_xml:
                item_key = getText(getTag(item_xml, 'key'))
                item_time = float(getText(getTag(item_xml, 'start_time')))
                if item_key in self.motions:
                    motion_set.add_motion(self.motions[item_key], item_time)
            self.motion_sets[set_key] = motion_set

    def run_web_server(self):
        import time
        import uio.Server
        import uio.p4

        server = uio.Server
        server.start()

        self._p4 = uio.p4.p4(server)

        time.sleep(0.1) # try to make p4 msg last

        p4session = self._p4
        p4session.setDaemon(1)
        p4session.start()

        timeout = 1.0 / _P4_HEARTBEAT_HZ
        while p4session.isAlive():
            time.sleep(timeout)

        server.stop()
        server.join()
        return 

def main():
    usage  = 'usage: %prog JACK_INIT_FILE.xml ve_host ve_node'
    parser = OptionParser(usage)
    (options, args) = parser.parse_args()
    if len(args) < 2 or len(args) > 3:
        parser.error('Incorrect number of arguments.  A jack initialization file must be supplied and a host for the virtual environment!  The virtual environment node defaults to 12.')

    initFile = args[0]
    veHost = args[1]
    veNode = '12'
    if len(args) == 3:
        veNode = args[2]
    vePort = str(int(veNode) + 5600)
    os.environ['VE_HOST'] = veHost
    os.environ['VE_NODE'] = veNode
    server = JackServer(initFile, veHost, vePort)
    server.run_web_server()
    
if __name__ == '__main__':
    main()

    
