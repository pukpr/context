
from optparse import OptionParser
import sys
import os
import re
from math import pi

import dvscontrol
from ada_rotations import *

debug = os.getenv("DVS_DEBUG", "0") != "0"

ALL_AXES = ['tx', 'ty', 'tz', 'x', 'y', 'z']

DEFAULT_ROT_ORDER = 'zxy'

def pri(s):
    if debug:
        print s

def cm2m(value):
    return float(value) / 100.0

def deg2rad(value):
    return float(value) * pi / 180.0;

def name(str, segment):
    return '%s_%s' %(segment, str)

def parse_file(file_name):
    # finds the segment names
    segment_name_regex = re.compile('segment[ ](.+?)[ {]', re.IGNORECASE | re.VERBOSE)
    # find all the data within each segment
    segment_regex = re.compile('segment.+?[{](.+?)[}]', re.IGNORECASE | re.VERBOSE | re.DOTALL)
    # find all connect statements
    connect_regex = re.compile('connect[ ](.+?) [ ]to[ ] (.+?);', re.IGNORECASE | re.VERBOSE | re.DOTALL)
    f = open(file_name, 'r')
    text = f.read()
    f.close()
    segment_names = segment_name_regex.findall(text)
    segments = segment_regex.findall(text)
    connects = connect_regex.findall(text)

    # create skip set
    skip = []
    for i,c in enumerate(connects):
        child_with_dot = connects[i][1]
        child = child_with_dot.replace('.', '_')
        skip.append(child)

    # create site_scale dict
    site_scales = {}
    seg_site_scales = {} 
    ss_site_regex = re.compile('site_scale(.+?);', re.VERBOSE)  # to find the single line starting with site_scale
    ss_site_name_regex = re.compile('\(site\)(.+?)[,]', re.MULTILINE | re.VERBOSE)  # to find the site_scale names
    ss_site_scales_regex = re.compile('\(([0-9.]+?),([0-9.]+?),([0-9.]+?)\),', re.MULTILINE | re.VERBOSE) # to find the scales
    for i, seg in enumerate(segments):
        ss_site_line = ss_site_regex.findall(seg)
        if len(ss_site_line) > 0:
            ss_site_names = ss_site_name_regex.findall(ss_site_line[0])
            ss_site_scales = ss_site_scales_regex.findall(ss_site_line[0])
            for j, ss_name in enumerate(ss_site_names):
                assembly = name(ss_name, segment_names[i])
                site_scales[assembly] = map(float, ss_site_scales[j])
                if j == 0:
                    # want to scale the geometry of each segment by the first site_scale
                    seg_site_scales[segment_names[i]] = map(float, ss_site_scales[0])

    if len(segment_names) != len(segments):
        print "ERROR: Length of segment names (", len(segment_names), ") must be the same as length of segments (", len(segments), ')'
        sys.exit(1)
    return (segment_names, segments, connects, skip, site_scales, seg_site_scales)


def apply_scales(dvs, segment_names, segments, seg_site_scales, entity):

    def seg_site_scale_mod(segment_name, scale_str):
        scale = map(float, scale_str)
        if seg_site_scales.has_key(segment_name):
            ss_mod = seg_site_scales[segment_name]
            result = [scale[i]*ss_mod[i] for i in range(0, len(scale))]
            return result
        else:
            return scale

    # first scale the segment geometries
    scale_regex = re.compile('scale[(](.+?)[,](.+?)[,](.+?)[)]', re.IGNORECASE | re.VERBOSE)
    for i,s in enumerate(segment_names):
        result = scale_regex.findall(segments[i])
        if len(result) > 0:
            scale = seg_site_scale_mod(segment_names[i], result[0])
            dvs.scale(segment_names[i], scale[0], scale[1], scale[2], entity)
        else:
            pri("Skipping scale on segment %s" %(segment_names[i]))


def apply_initial_sets(dvs, segment_names, segments, skip, site_scales, entity):

    def convert_it(assembly, trans):
        result = [cm2m(trans[i]) for i in range(1, len(trans))]
        if site_scales.has_key(assembly):
            scale = site_scales[assembly]
            result = [result[i]*scale[i] for i in range(0, len(result))]
        return result
    
    # finds all the translate calls
    trans_regex = re.compile('site[ ](.+?)->location.+?trans[(](.+?)cm[,](.+?)cm[,](.+?)cm[)]', re.IGNORECASE | re.VERBOSE)
    rot_regex = re.compile('site[ ](.+?)->location.+?xyz[(](.+?)deg[,](.+?)deg[,](.+?)deg[)]', re.IGNORECASE | re.VERBOSE)
    for i,seg in enumerate(segments):
        translates = trans_regex.findall(seg)
        rotates = rot_regex.findall(seg)
        for trans in translates:
            assembly = name(trans[0], segment_names[i])
            if not assembly in skip: 
                if len(assembly) < 32: # Division can only handle lengths of less than 32
                    pos = convert_it(assembly, trans)
                    dvs.set_rot_order(entity, assembly, DEFAULT_ROT_ORDER)
                    dvs.translate(assembly, pos[0], pos[1], pos[2], entity)
                else:
                    print "Skipped %s because name is too long." %(assembly)
            else:
                pri("skipped %s" %(assembly))
        for rot in rotates:
            assembly = name(rot[0], segment_names[i])
            if not assembly in skip:
                if len(assembly) < 32: # Division can only handle lengths of less than 3
                    converted_rot = convert_euler(XYZ_TO_YXZ, (deg2rad(rot[1]), deg2rad(rot[2]), deg2rad(rot[3])))
                    dvs.set_rot_order(entity, assembly, DEFAULT_ROT_ORDER)
                    dvs.rotate(assembly, converted_rot[0], converted_rot[1], converted_rot[2], entity, False) #'xyz_to_yxz')
                else:
                    print "Skipped %s because name is too long." %(assembly)
            else:
                pri("skipped %s" %(assembly))


def apply_links(dvs, segment_names, segments, connects, seg_site_scales, entity):

    def find_seg_index(segment):
        for i, seg in enumerate(segment_names):
            if seg == segment:
                return i
        print 'NO MATCHING SEGMENT'
        sys.exit(1)

    def convert_it(segment_name, trans):
        result = [-cm2m(trans[i]) for i in range(0, len(trans))]
        if seg_site_scales.has_key(segment_name):
            scale = seg_site_scales[segment_name]
            result = [result[i]*scale[i] for i in range(0, len(result))]
        return result

    def setup_asm(dvs, segment_name, joint_site):
        seg = segments[find_seg_index(segment_name)]
        site_trans_regex = re.compile('site[ ]%s->location.+?trans[(](.+?)cm[,](.+?)cm[,](.+?)cm[)]' %(joint_site), re.IGNORECASE | re.VERBOSE)
        site_rot_regex = re.compile('site[ ]%s->location.+?xyz[(](.+?)deg[,](.+?)deg[,](.+?)deg[)]' %(joint_site), re.IGNORECASE | re.VERBOSE)
        site_trans = site_trans_regex.findall(seg)[0]
        pos = convert_it(segment_name, site_trans)
        site_rot = site_rot_regex.findall(seg)
        assembly = '%s_asm' %(segment_name)
        dvs.set_rot_order(entity, assembly, DEFAULT_ROT_ORDER)
        if len(site_rot) > 0:
            # do an inverse rotation since parent/child relationship is swapped!
            converted_rot = convert_euler(XYZ_TO_YXZ,
                                          (deg2rad(site_rot[0][0]),
                                           deg2rad(site_rot[0][1]),
                                           deg2rad(site_rot[0][2])),
                                          True)
            dvs.rotate(assembly,
                       converted_rot[0],
                       converted_rot[1],
                       converted_rot[2],
                       entity)
                              
            # rotate the pos vector from xyz to yxz coordinate system
            pos = convert_vector_xyz_to_yxz(pos, converted_rot)
        dvs.translate('%s_asm' %(segment_name), pos[0], pos[1], pos[2], entity)

    
    # for each connect link the 2nd one as the child to the 1st one as the parent
    # and set the child to (0,0,0) for pos and ori
    to_link_list = []
    for i,c in enumerate(connects):
        parent = connects[i][0].replace('.', '_')
        child_with_dot = connects[i][1]
        child = child_with_dot.replace('.', '_')
        to_link_list.append((parent, child))

        # set the child's segment_asm to negative of the site location
        child_segment_name = child_with_dot[:child_with_dot.find('.')]
        child_site = child_with_dot[child_with_dot.find('.')+1:]
        setup_asm(dvs, child_segment_name, child_site)

    # lower_torso is a special case
    setup_asm(dvs, 'lower_torso', 'proximal')
            
    for (parent, child) in to_link_list:
        dvs.link(parent, child, entity)
        converted_rot = convert_euler(XYZ_TO_YXZ, (0.0, 0.0, 0.0), False)
        dvs.set_rot_order(entity, child, DEFAULT_ROT_ORDER)
        dvs.rotate(child, converted_rot[0], converted_rot[1], converted_rot[2], entity, False)
        dvs.translate(child, 0.0, 0.0, 0.0, entity)
        

def jack_setup(dvs, fig_file, entity):
    (segment_names, segments, connects, skip, site_scales, seg_site_scales) = parse_file(fig_file)
    apply_scales(dvs, segment_names, segments, seg_site_scales, entity)
    apply_initial_sets(dvs, segment_names, segments, skip, site_scales, entity)
    apply_links(dvs, segment_names, segments, connects, seg_site_scales, entity)



def joint_mapping(fig_file):
    f = open(fig_file, 'r')
    text = f.read()
    f.close()
    assembly_name_regex = re.compile('connect[ ].+? [ ]to[ ] (.+?);.+?\}',
                                     re.IGNORECASE | re.VERBOSE | re.DOTALL)
    assemblies_with_dot = assembly_name_regex.findall(text)
    assemblies = [a.replace('.', '_') for a in assemblies_with_dot]

    joint_regex = re.compile('joint[ ](.+?)[ ]\{(.+?)\}',
                                  re.IGNORECASE | re.VERBOSE | re.DOTALL)
    all_joints = joint_regex.findall(text)
    verify_type_regex = re.compile('type[ ]=[ ](.+?);', re.IGNORECASE | re.VERBOSE)
    joints = []
    joints_without_type = {}
    for (name, data) in all_joints:
        joints.append(name)
        if len(verify_type_regex.findall(data)) <= 0:
            # no type for this joint
            joints_without_type[name] = 1
            pri('joint %s has no type info' %(name))
            
    axesline_regex = re.compile('type[ ]=[ ](.+?);', re.IGNORECASE | re.VERBOSE)
    axesline = axesline_regex.findall(text)

    axes_regex = re.compile('R\((.+?)\)', re.IGNORECASE | re.VERBOSE)
    axes = [axes_regex.findall(line) for line in axesline]

    if len(joints) != (len(axes) + len(joints_without_type)) or len(joints) != (len(assemblies)):
        print 'Length of 3 lists must be the same!'
        print 'len(joints): ', len(joints)
        print 'len(axes) + len(joints_without_type): ', len(axes) + len(joints_without_type)
        print 'len(assemblies): ', len(assemblies)
        sys.exit(1)

    jmap = {}
    axes_index = 0
    for i in range(0, len(joints)):
        if joints_without_type.has_key(joints[i]):
            jmap[joints[i]] = (assemblies[i], ALL_AXES)
        else:
            jmap[joints[i]] = (assemblies[i], axes[axes_index])
            axes_index += 1
    return jmap

def get_text(chset_file):
    f = open(chset_file, 'r')
    text = f.read()
    f.close()
    return text

def find_size(text):
    # number of frames
    size_regex = re.compile('size[ ]=[ ]([0-9]+);',
                            re.IGNORECASE | re.VERBOSE)
    size = int(size_regex.findall(text)[0])
    return size

def find_times(text):
    # what time each frame occurs at
    time_regex = re.compile('frame\[[0-9]+?\][ ]=[ ]([0-9.]+?);',
                            re.IGNORECASE | re.VERBOSE)
    times = map(float, time_regex.findall(text))
    return times

def find_figure_frames(text, size, entity, isObject = False):
    """if entity is "" then use assembly.replace('.', '_'), otherwise use entity for the assembly"""

    # frames is a list of lists
    # the first index corresponds to which frame and has as its value a list of
    # dvscontrol.DvsCommand instances which encapsulates all of the commands that
    # occur during that frame
    frames = [[] for i in range(0, size+1)]  # jack size does not count frame 0
    
    # find the figure frames
    fig_regex = re.compile('frame\[([0-9]+?)\][ ]=[ ]\("(.+?)"(.+?);',
                           re.IGNORECASE | re.VERBOSE)
    fig_lines = fig_regex.findall(text)
    trans_regex = re.compile('trans[(](.+?)cm[,](.+?)cm[,](.+?)cm[)]',
                             re.IGNORECASE | re.VERBOSE)
    rot_regex = re.compile('xyz[(](.+?)deg[,](.+?)deg[,](.+?)deg[)]',
                           re.IGNORECASE | re.VERBOSE)
    
    for (index, assembly, line) in fig_lines:
        if isObject:
            dCmd = dvscontrol.DvsCommand(entity)
        else:
            dCmd = dvscontrol.DvsCommand(assembly.replace('.', '_'))
            dCmd.entity = entity

        fig_trans = trans_regex.findall(line)
        if len(fig_trans) > 0:
            trans = (cm2m(fig_trans[0][0]),
                     cm2m(fig_trans[0][1]),
                     cm2m(fig_trans[0][2]))
            dCmd.trans = trans
        fig_rot = rot_regex.findall(line)
        if len(fig_rot) > 0:
            rot = (deg2rad(fig_rot[0][0]),
                   deg2rad(fig_rot[0][1]),
                   deg2rad(fig_rot[0][2]))
            #dCmd.rot = rot
            # Automatically set to 1 because it converts from XYZ to YXZ while moving from Jack to Division
            # This is for the specific rotation of the lower torso proximal 
            dCmd.rot = convert_euler(1, rot)   
        frames[int(index)].append(dCmd)
    return frames

def assemble_frames(joint_dict, chset_file, entity):
    text = get_text(chset_file)
    size = find_size(text)
    times = find_times(text)

    frames = find_figure_frames(text, size, entity, False)
    
    # find the joint frames (first index is joint name, second index is the text inside of the joint)
    joint_regex = re.compile('sharedchannel[ ].+?\{.+?type[ ]=[ ]"joint";.+?object[ ]=[ ]"(.+?)";(.+?)\}',
                                  re.IGNORECASE | re.VERBOSE | re.DOTALL)
    joints = joint_regex.findall(text)

    # one_axes_regex will find frames with a rotation on 1 axis and likewise for 2 and 3
    one_axes_regex = re.compile('frame\[([0-9]+?)\][ ]=[ ]\(([0-9.-]+?)\);',
                                re.IGNORECASE | re.VERBOSE)
    two_axes_regex = re.compile('frame\[([0-9]+?)\][ ]=[ ]\(([0-9.-]+?),([0-9.-]+?)\);',
                                re.IGNORECASE | re.VERBOSE)
    three_axes_regex = re.compile('frame\[([0-9]+?)\][ ]=[ ]\(([0-9.-]+?),([0-9.-]+?),([0-9.-]+?)\);',
                                  re.IGNORECASE | re.VERBOSE)
    six_axes_regex = re.compile('frame\[([0-9]+?)\][ ]=[ ]\(([0-9.-]+?),([0-9.-]+?),([0-9.-]+?),([0-9.-]+?),([0-9.-]+?),([0-9.-]+?)\);',
                                  re.IGNORECASE | re.VERBOSE)

    def make_command(assembly, order, j_frame):
        # for creating the euler rotation order key
        # skip axes tx, ty, tz, ignore negatives, and reverse the order
        # since the .chset file specifies the reverse euler order
        def assemble_key(order_key, axis):
            if axis[0] == 't':
                return order_key
            elif axis[0] == '-':
                return '%s%s' %(axis[1], order_key)
            else:
                return '%s%s' %(axis[0], order_key)
        
        dCmd = dvscontrol.DvsCommand(assembly)
        dCmd.entity = entity
        rot = [0.0, 0.0, 0.0]
        trans = [0.0, 0.0, 0.0]  # only applicable when ALL_AXES are specified
        order_key = ''
        for i, axis in enumerate(order):
            order_key = assemble_key(order_key, axis)
            if axis == 'x':
                rot[0] = j_frame[i]
            elif axis == '-x':
                rot[0] = -j_frame[i]
            elif axis == 'y':
                rot[1] = j_frame[i]
            elif axis == '-y':
                rot[1] = -j_frame[i]
            elif axis == 'z':
                rot[2] = j_frame[i]
            elif axis == '-z':
                rot[2] = -j_frame[i]
            elif axis == 'tx':
                trans[0] = j_frame[i]
            elif axis == 'ty':
                trans[1] = j_frame[i]
            elif axis == 'tz':
                trans[2] = j_frame[i]
            else:
                print 'INVALID AXIS :%s: for assembly :%s: ' %(axis, assembly)
        dCmd.rot = convert_euler(euler_order_map[order_key], rot)
        if len(order) == 6:
            dCmd.trans = trans
        return dCmd

    for (joint_name, joint_text) in joints:
        # if joint_dict has no key for joint_name then skip it
        if joint_dict.has_key(joint_name):
            (assembly, order) = joint_dict[joint_name]
            j_frames = None
            if len(order) == 1:
                j_frames = one_axes_regex.findall(joint_text)
            elif len(order) == 2:
                j_frames = two_axes_regex.findall(joint_text)
            elif len(order) == 3:
                j_frames = three_axes_regex.findall(joint_text)
            elif len(order) == 6:
                # all axes case
                j_frames = six_axes_regex.findall(joint_text)
            for j_frame_tuple in j_frames:
                # convert from tuple to array so we can pop it
                j_frame = [x for x in j_frame_tuple]
                j_frame = map(float, j_frame)
                index = j_frame.pop(0)  # first is the index
                frames[int(index)].append(make_command(assembly, order, j_frame))
    
    return (times, frames)

    
def assemble_frames_for_object(chset_file, entity):
    text = get_text(chset_file)
    size = find_size(text)
    times = find_times(text)
    frames = find_figure_frames(text, size, entity, true)
    return (times, frames)
