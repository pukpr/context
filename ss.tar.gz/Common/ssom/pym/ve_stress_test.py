#!/usr/bin/env python

import sys
import os
from time import sleep, time
from thread import start_new_thread
import threading
from random import randint

sys.path.insert(0, os.environ["PACE_PYM"])

from VeControl import VeControl
import places
from hal import Position, Orientation, Place


class Explosions(threading.Thread):
    
    def run(self):
        ve = VeControl('localhost', '5109')

        home = Place('home', Position(209, 289, 924), Orientation(148, -21, 0))
        ve.move_camera('eyePoint', home)
        
        flt = 'crater_flat.flt'
        for i in range(1, 100):
            print "Making six new craters (%s) " %i
            for j in range(1, 7):
                crater = 'crater_%s_%s' %(i, j)
                exp = 'explosion_%s_%s' %(i, j)
                ve.load_model(crater, flt, True, 0.0, 0.0, 0.0)
                ve.load_effect(exp, 'explosion')
                ve.get_info(crater)
                ve.get_info(exp)
                ve.translate(crater, i*10, j*10, 0)
                ve.link(crater, exp)
                ve.start_effect(exp)
            sleep(5.0)

class Hdqrts(threading.Thread):

    def move_dof(self, entity, dof, i):
        self.ve.get_info(entity)
        self.ve.translate(entity, i, randint(1, 5), 0.0, False, dof)
        self.ve.rotate(entity, randint(1, 360), randint(1, 360), randint(1, 360), dof)

    def blow_up(self, entity):
        dt = 0.05
        now = time()
        while time() < (now + 5.0):
            self.ve.get_height_of_terrain(10, 10, 10)
            for i in range(1, 10):
                self.move_dof(entity, 'dof_%s' %i, i)
            sleep(dt)

    def run(self):
        self.ve = VeControl('localhost', '5109')
        flt = 'terrorist_headquarters.flt'

        for i in range(1, 100):
            print "loading headquarters (%s) " %i
            entity = 'headquarters_%s' %i
            self.ve.load_model(entity, flt, True, 0.0, 0.0, 0.0)
            self.ve.get_info(entity)
            self.ve.translate(entity, i*10, 40, 0)
            self.blow_up(entity)
        
explosions = Explosions()
explosions.setDaemon(True)
explosions.start()

hdqrts = Hdqrts()
hdqrts.setDaemon(True)
hdqrts.start()

while True:
    sleep(1.0)
