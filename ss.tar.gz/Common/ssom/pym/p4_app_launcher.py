#!/usr/bin/env python

import sys
import os
import signal
from subprocess import Popen

sys.path.insert(0, os.environ["PACE_PYM"] + '/../../../cannon/vcs/pym/lib/uio.zip')

_P4_HEARTBEAT_HZ = 2

def main():
    import time
    import uio.Server
    import uio.p4

    if len(sys.argv) < 2:
        print "You must supply 1 argument, which is the script to launch."
        sys.exit(0)

    server = uio.Server
    server.start()

    _p4 = uio.p4.p4(server)
    time.sleep(0.1) # try to make p4 msg last

    p4session = _p4
    p4session.setDaemon(1)
    
    # Chop off first argument (this script)
    args = sys.argv[1:len(sys.argv)]

    # launch app here
    pid = Popen(args).pid
    
    p4session.start()
    
    timeout = 1.0 / _P4_HEARTBEAT_HZ
    while p4session.isAlive():
        time.sleep(timeout)

    # shutdown app here
    os.kill(pid, signal.SIGKILL)
        
    server.stop()
    server.join()
    return

if __name__ == '__main__':
    main()
