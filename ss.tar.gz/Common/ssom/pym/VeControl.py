import os
import sys
import time

from places import Place, PlaceManager
from hal import Position, Orientation
from http_utilities import http_query, HttpConnectException
from XmlUtils import item, item_attr

class VeControl(object):

    __host_ports = []

    def __init__(self, addrs, placesFile = ''):
        if placesFile != '':
            self.place_manager = PlaceManager(placesFile)
        self._addrs_str = addrs
        self._makeAddrs()
        self._east_offset = 512000
        self._north_offset = 3885000
##        self._ssomHost = 'localhost'
##        self._ssomPort = '5601'
##        if os.environ.has_key('ssom'):
##            self._ssomHost = os.environ['ssom']
##        else:
##            print '*** ssom environment variable not set, assuming ' + self._ssomHost + ':' + self._ssomPort

    def _makeAddrs(self):
        if not self._addrs_str:
            return
        hp_list = self._addrs_str.split(' ')
        __host_ports = VeControl.__host_ports
        for item in hp_list:
            if not item:
                continue
            tok = item.split(':')
            if len(tok) < 2:
                continue
            __host_ports.append(tok[:2])
                
    
    #TODO: make a thread for each request...ala uio.utils invoke later
    
    def ve_query(self, xml):
        __host_ports = VeControl.__host_ports
        for host, port in __host_ports:
            try:
                http_query(host, port, 'query.ve_command', xml)
            except HttpConnectException:
                sys.stderr.write('Could not query %s%s.\n' % (host, port))
    
    def ve_query_resp(self, xml):
        if not VeControl.__host_ports:
            return
        host, port = VeControl.__host_ports[0]
        try:
            http_query(host, port, 'query.ve_query', xml)
        except HttpConnectException:
            sys.stderr.write('Could not query %s%s.\n' % (host, port))

    def link(self, parent, child, x=0.0, y=0.0, z=0.0, xr=0.0, yr=0.0, zr=0.0):
        xml = ''.join(['xml=',
                       '<command t="0.0">',
                       '<entity>', parent, '</entity>',
                       '<dof></dof>',
                       '<data>', child, '</data>',
                       '<op>ve_attach</op>',
                       '<param>', str(x), '</param>',
                       '<param>', str(y), '</param>',
                       '<param>', str(z), '</param>',
                       '<param>', str(xr), '</param>',
                       '<param>', str(yr), '</param>',
                       '<param>', str(zr), '</param>',                   
                       '</command>'])
        self.ve_query(xml)

    def link_offset(self, parent, child):
        xml = ''.join(['xml=',
                       '<command t="0.0">',
                       '<entity>', parent, '</entity>',
                       '<dof></dof>',
                       '<data>', child, '</data>',
                       '<op>ve_attach</op>',
                       '</command>'])
        self.ve_query(xml)

    def load_model(self, entity, path, follow, x, y, z, p=0, h=0, r=0, use_offset=False):
        flw = 0.0
        if follow:
            flw = 1.0
        xml = ''.join(['xml=',
                       '<command t="0.0">',
                       '<entity>', entity, '</entity>',
                       '<op>create</op>',
                       '<data>', path, '</data>',
                       '<param>', str(flw), '</param>',
                       '<param>0</param>',
                       '</command>'])
        self.ve_query(xml)
        self.translate(entity, x, y, z, use_offset)
        self.rotate(entity, p, h, r)
        
    def unload_model(self, entity):
        xml = ''.join(['xml=',
                       '<command t="0.0">',
                       '<entity>', entity, '</entity>',
                       '<op>destroy</op>',
                       '</command>'])
        self.ve_query(xml)

    def load_effect(self, entity, effect_type, data = ''):
        xml = item_attr('command', 't', '0.0',
                        item('entity', entity) +
                        item('dof', effect_type) +
                        item('data', '<![CDATA[%s]]>' %data) +
                        item('op', 'create_fx') +
                        item('q_me', ''))
        self.ve_query('xml=%s' %xml)

    def start_effect(self, entity):
        xml = item_attr('command', 't', '0.0',
                        item('entity', entity) +
                        item('data', 'trigger') +
                        item('op', 'fx') +
                        item('q_me', ''))
        self.ve_query('xml=%s' %xml)

    def stop_effect(self, entity):
        xml = item_attr('command', 't', '0.0',
                        item('entity', entity) +
                        item('data', 'stop') +
                        item('op', 'fx') +
                        item('q_me', ''))
        self.ve_query('xml=%s' %xml)

    def rotate(self, entity, p, h, r, dof = ''):
        xml = ''.join(['xml=',
                       '<command t="0.0">',
                       '<entity>', entity, '</entity>',
                       '<dof>', dof, '</dof>',
                       '<op>rotate</op>',
                       '<param>', str(p), '</param>',
                       '<param>', str(r), '</param>',
                       '<param>', str(h), '</param>',
                       '</command>'])
        self.ve_query(xml)

    def scale(self, entity, x, y, z):
        xml = ''.join(['xml=',
                       '<command t="0.0">',
                       '<entity>', entity, '</entity>'
                       '<dof></dof>',
                       '<op>scale</op>',
                       '<param>', str(x), '</param>',
                       '<param>', str(y), '</param>',
                       '<param>', str(z), '</param>',                   
                       '</command>'])
        self.ve_query(xml)

    def translate(self, entity, x, y, z, use_offset=False, dof=''):
        if use_offset:
            x -= self.east_offset
            y -= self.north_offset
        xml = ''.join(['xml=',
                       '<command t="0.0">',
                       '<entity>', entity, '</entity>',
                       '<dof>', dof, '</dof>',
                       '<op>translate</op>',
                       '<param>', str(x), '</param>',
                       '<param>', str(y), '</param>',
                       '<param>', str(z), '</param>',
                       '</command>'])
        self.ve_query(xml)

    def unlink(self, entity):
        xml = ''.join(['xml=',
                       '<command t="0.0">',
                       '<entity>', entity, '</entity>',
                       '<op>ve_detach</op>',
                       '</command>'])
        self.ve_query(xml)

    def set_visible(self, entity, dof=''):
        xml = ''.join(('xml=',
                       '<command t="0.0">',
                       '<entity>', entity, '</entity>',
                       '<dof>', dof, '</dof>',
                       '<data>true</data>',
                       '<op>visibility</op>'
                       '</command>'))
        self.ve_query(xml)

    def set_invisible(self, entity, dof=''):
        xml = ''.join(('xml=',
                       '<command t="0.0">',
                       '<entity>', entity, '</entity>',
                       '<dof>', dof, '</dof>',
                       '<data>false</data>',
                       '<op>visibility</op>'
                       '</command>'))
        self.ve_query(xml)

    def set_state(self, entity, dof, switch_node, state_number, is_on):
        # i haven't verified that this works
        xml = item_attr('command', 't', '0.0',
                        item('entity', entity) +
                        item('dof', dof) +
                        item('data', switch_node) +
                        item('op', 'set_state') +
                        item('param', str(state_number)) +
                        item('param', str(is_on)))
        self.ve_query('xml=%s' %xml)

    def get_info(self, entity, dof = '', want_absolute_pos = True):
        if dof != '':
            dof = item('dof', dof)
        if want_absolute_pos:
            abs = item('data', 'true')
        else:
            abs = item('data', 'false')
        xml = item_attr('command', 't', '0.0',
                        item('entity', entity) +
                        dof +
                        abs +
                        item('op', 'query'))
        self.ve_query_resp('xml=%s' %xml)
        # figure out how to return response

    def get_height_of_terrain(self, x, y, z):
        xml = item_attr('command', 't', '0.0',
                        item('op', 'query_hot') +
                        item('param', x) +
                        item('param', y) +
                        item('param', z))
        self.ve_query_resp('xml=%s' %xml)
        # figure out how to return response                
                            

    def move_camera(self, camera, place):
        if place == None:
            print 'no such place '
        else:
            self.translate(camera, place.pos.x, place.pos.y, place.pos.z)
            self.rotate(camera, place.ori.p, place.ori.h, place.ori.r)

    def place_camera(self, camera, place_name):
        self.move_camera(camera, self.place_manager.find_place(place_name))

    def next_place(self, camera):
        self.move_camera(camera, self.place_manager.get_next_place())

    def previous_place(self, camera):
        self.move_camera(camera, self.place_manager.get_prev_place())

    def create_channel(self, id, x1, x2, y1, y2, vcid=-1, fwd=False):
        # does not yet handle fwd parameter correctly
        xml = item_attr('command', 't', '0.0',
                        item('op', 'create_view') +
                        item('param', str(id)) +
                        item('param', str(x1)) +
                        item('param', str(x2)) +
                        item('param', str(y1)) +
                        item('param', str(y2)) +
                        item('param', str(vcid)))
        self.ve_query('xml=%s' % xml)

    def delete_channel(self, id):
        xml = item_attr('command', 't', '0.0',
                        item('op', 'delete_view') +
                        item('param', id))
        self.ve_query('xml=%s' % xml)
        
    def terrain_op(self, oper, arg):
        data_str = '<![CDATA[<xml><%s>%s</%s></xml>]]>' % (oper, arg, oper)
        xml = item_attr('command', 't', '0.0',
                        item('op', 'terrain_op') +
                        item('data', data_str))
        self.ve_query('xml=%s' % xml)
