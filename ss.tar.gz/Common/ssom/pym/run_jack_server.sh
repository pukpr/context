#! /bin/bash
pym_port=5800
if [ -n "$PYM_PORT" ]; then
  pym_port=$PYM_PORT;
fi
env PACE_NODE=50 SUMIT_WEB_ROOT=html_jack PYM_PORT=$pym_port PACE_PYM=. PYTHONPATH=../plugins/swig/bin/Linux/obj python jack_server.py $*
